<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Credentials', true);
header('Content-Type:application/json; charset=utf-8');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Headers: DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,X_Requested_With,If-Modified-Since,Cache-Control,Content-Type, Accept-Language, Origin, Accept-Encoding, token');
header('Access-Control-Max-Age: 1000');

// [ 应用入口文件 ]
// 定义应用目录
define('APP_PATH', __DIR__ . '/application/');
define('CONF_PATH', __DIR__ . '/config/');

// 加载框架引导文件
require __DIR__ . '/thinkphp/start.php';
