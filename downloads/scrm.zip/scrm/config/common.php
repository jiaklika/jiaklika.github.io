<?php

/**
 * common.php
 * 通用函数
 * Author: chebin
 * Date: 2020/7/21
 * Time: 10:23
 */

use app\api\dao\http\webHook\WebHookHttpDao;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use think\Log;
use think\Request;

const MQ_END_POINT = 'http://1791318055539215.mqrest.cn-shanghai.aliyuncs.com';
//const MQ_ACCESS_ID = 'LTAI0IXBaulPriaR';
//const MQ_ACCESS_KEY = 'bsSuO8CyOFWNPZHBfRbjQ3M8hMQX4N';
const MQ_ACCESS_ID = 'LTAI5tApQCKbVKvdMrYvyQJc';
const MQ_ACCESS_KEY = 'dSZblCk6VYjWlY5Kk8fqBpEuvvRfhx';

if (!function_exists('getAge')) {
    /**
     * 根据生日unix时间戳计算年龄
     *
     * @param int $birthday 出生unix时间戳
     * @return int
     */
    function getAge(int $birthday): int
    {
        if (!$birthday) {
            return 0;
        }

        // 格式化生日年月日
        $byear  = date('Y', $birthday);
        $bmonth = date('m', $birthday);
        $bday   = date('d', $birthday);

        // 格式化当前时间年月日
        $tyear  = date('Y');
        $tmonth = date('m');
        $tday   = date('d');

        // 开始计算年龄
        $age = $tyear - $byear;

        if ($bmonth > $tmonth || $bmonth == $tmonth && $bday > $tday) {
            $age--;
        }

        return $age;
    }
}

if (!function_exists('getRandomStr')) {
    /**
     * 获得随机字符串
     *
     * @param int $len     需要的长度
     * @param bool $special 是否需要特殊符号
     * @return string       返回随机字符串
     */
    function getRandomStr(int $len, bool $special = false): string
    {
        $chars = [
            "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",
            "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",
            "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",
            "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",
            "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",
            "3", "4", "5", "6", "7", "8", "9"
        ];

        if ($special) {
            $chars = array_merge($chars, [
                "!", "@", "#", "$", "?", "|", "{", "/", ":", ";",
                "%", "^", "&", "*", "(", ")", "-", "_", "[", "]",
                "}", "<", ">", "~", "+", "=", ",", "."
            ]);
        }

        $charsLen = count($chars) - 1;
        shuffle($chars);  // 打乱数组顺序
        $str = '';

        for ($i = 0; $i < $len; $i++) {
            $str .= $chars[mt_rand(0, $charsLen)];  // 随机取出一位
        }
        return $str;
    }
}

if (!function_exists('xmlToArray')) {
    /**
     * XML转数组
     *
     * @param string $xml xml字符串
     * @return array
     * @throws Exception
     */
    function xmlToArray(string $xml): array
    {
        if (!$xml) {
            throw new Exception("xml数据异常！");
        }

        //禁止引用外部xml实体
        $disableLibxmlEntityLoader = libxml_disable_entity_loader(true);

        $arr = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);

        libxml_disable_entity_loader($disableLibxmlEntityLoader);

        return $arr;
    }
}

if (! function_exists('tap')) {
    /**
     * 使用给定的值调用给定的Closure，然后返回该值。
     *
     * @param  mixed  $value
     * @param callable|null $callback
     * @return mixed
     */
    function tap($value, callable $callback = null)
    {
        if (is_null($callback)) {
            return new app\api\util\HigherOrderTapProxy($value);
        }

        $callback($value);

        return $value;
    }
}

if (! function_exists('pipeline')) {
    /**
     * 在redis的pipeline中执行命令。
     *
     * @param Redis $redis_client redis对象
     * @param callable|null $callback
     * @return Redis|array
     */
    function pipeline(Redis $redis_client, callable $callback = null)
    {
        $pipeline = $redis_client->pipeline();

        return is_null($callback)
            ? $pipeline
            : tap($pipeline, $callback)->exec();
    }
}

if (! function_exists('uploadFile')) {
    /**
     * 上传文件到本地服务器
     *
     * @param think\File $file   文件
     * @param int        $size   上传文件的最大字节，默认20m
     * @param array      $extArr 允许上传的文件后缀
     * @return array
     */
    function uploadFile(think\File $file, int $size = 20971520, array $extArr = []): array
    {
        if (!empty($file)) {
            $validate = [
                'size' => $size,
            ];

            if ($extArr) {
                $validate['ext'] = $extArr;
            }

            // 使用原文件名
            $info = $file
                ->validate($validate)
                ->move(ROOT_PATH . 'public' . DS . 'uploads/', $file->getInfo()['name']);

            if ($info) {
                return [true, $info];
            }

            // 上传失败获取错误信息
            return [false, $file->getError()];
        }
        return [false, '上传文件不能为空！'];
    }
}

if (! function_exists('downloadExcel')) {
    /**
     * 生成Excel到浏览器
     *
     * @param string  $title
     * @param Closure $closure
     * @throws Exception
     */
    function downloadExcel(string $title, Closure $closure)
    {
        $fileName = sprintf('%s.xlsx', $title);

        $adminInfo = Request::instance()->admin;

        $spreadsheet = new Spreadsheet();

        // Set document properties
        $spreadsheet->getProperties()
            ->setCreator($adminInfo['realname'])
            ->setLastModifiedBy($adminInfo['realname'])
            ->setTitle('Office 2007 XLSX Document')
            ->setSubject('Office 2007 XLSX Document')
            ->setDescription('Document for Office 2007 XLSX, generated using PHP classes.')
            ->setKeywords('office 2007 openxml php')
            ->setCategory('result file');

        // Add some data
        $spreadsheet = tap($spreadsheet, $closure);

        // Rename worksheet
        $spreadsheet->getActiveSheet()->setTitle('客户列表');

        // Set active sheet index to the first sheet, so Excel opens this as the first sheet
        $spreadsheet->setActiveSheetIndex(0);

        // Redirect output to a client’s web browser (Xlsx)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        $writer->save('php://output');
        exit;
    }
}

if (! function_exists('downloadExcelToLocal')) {
    /**
     * 生成Excel到本地服务器
     *
     * @param string  $title
     * @param Closure $closure
     * @throws Exception
     */
    function downloadExcelToLocal(string $title, Closure $closure)
    {
        // $userPath = $_SERVER['DOCUMENT_ROOT']."/public/downloads/";
        try {
            $userPath = realpath(dirname('index.php')) . "/public/downloads/";
            $fileName = sprintf('%s.xlsx', $title);

            $adminInfo = Request::instance()->admin;

            $spreadsheet = new Spreadsheet();

            // Set document properties
            $spreadsheet->getProperties()
                ->setCreator($adminInfo['realname'])
                ->setLastModifiedBy($adminInfo['realname'])
                ->setTitle('Office 2007 XLSX Document')
                ->setSubject('Office 2007 XLSX Document')
                ->setDescription('Document for Office 2007 XLSX, generated using PHP classes.')
                ->setKeywords('office 2007 openxml php')
                ->setCategory('result file');

            // Add some data
            $spreadsheet = tap($spreadsheet, $closure);

            // Set active sheet index to the first sheet, so Excel opens this as the first sheet
            $spreadsheet->setActiveSheetIndex(0);

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $fileName . '"');
            header('Cache-Control: max-age=0');

            $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
            $writer->save($userPath . $fileName);
        } catch (Exception $e) {
            Log::error(
                $e->getMessage() . json_encode($e->getTrace(), JSON_UNESCAPED_UNICODE) . $e->getFile() . $e->getLine()
            );
        }
    }
}


if (! function_exists('with')) {
    /**
     * 返回给定的值，如果第二个参数是闭包，则返回闭包执行结果
     *
     * @param  mixed  $value
     * @param  callable|null $callback
     * @return mixed
     */
    function with($value, callable $callback = null)
    {
        return is_null($callback) ? $value : $callback($value);
    }
}

if (! function_exists('preg_replace_array')) {
    /**
     * 按顺序用数组中的每个值替换给定的模式。
     *
     * @param string $pattern
     * @param  array  $replacements
     * @param string $subject
     * @return string
     */
    function preg_replace_array(string $pattern, array $replacements, string $subject): string
    {
        return preg_replace_callback($pattern, function () use (&$replacements) {
            foreach ($replacements as $key => $value) {
                return array_shift($replacements);
            }
        }, $subject);
    }
}

if (! function_exists('object_get')) {
    /**
     * 使用“.”符号从对象中获取项目。
     *
     * @param  object  $object
     * @param string|null $key
     * @param  mixed  $default
     * @return mixed
     */
    function object_get($object, ?string $key, $default = null)
    {
        if (is_null($key) || trim($key) == '') {
            return $object;
        }

        foreach (explode('.', $key) as $segment) {
            if (! is_object($object) || ! isset($object->{$segment})) {
                return value($default);
            }

            $object = $object->{$segment};
        }

        return $object;
    }
}

if (! function_exists('is_work_time')) {
    /**
     * 是否是工作时间
     * 每周一到周五的9-18点为工作时间
     *
     * @param $unixTime
     * @return bool
     */
    function is_work_time($unixTime): bool
    {
        [
            $workDay,   // 工作日
            $workBegin, // 工作时间开始
            $workEnd,   // 工作时间结束
            $week,      // 当前星期
            $hour       // 当前小时
        ] =
        [
            [1,2,3,4,5],
            9,
            18,
            date('w', $unixTime),
            date('H', $unixTime)
        ];

        if (
            in_array($week, $workDay)
            && $hour >= $workBegin  // 9点30已经上班
            && $hour < $workEnd // 18点01已经下班
        ) {
            return true;
        }

        return false;
    }
}


if (! function_exists('send_msg_to_wecom')) {
    /**
     * 向scrm群发消息
     *
     * @param string $content 消息内容
     * @param array  $toUsers 提醒群中的指定成员
     */
    function send_msg_to_wecom(string $content, array $toUsers = ['chebin'])
    {
        if (config('app_status') == 'pro') {
            try {
                $webHookHttpDao = new WebHookHttpDao();
                $webHookHttpDao->sendTextMsg($content, ['chebin']);
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        } else {
            Log::error($content);
        }
    }
}

if (! function_exists('get_rate')) {
    /**
     * 计算概率，返回两位小数
     *
     * @param $part
     * @param $all
     * @return string
     */
    function get_rate($part, $all): string
    {
        if ($part == 0 || $all == 0) {
            return '0%';
        }
        return sprintf("%01.2f%%", ($part / $all) * 100);
    }
}

if (! function_exists('write_manager_log')) {
    /**
     * 写大后台日志
     *
     * @param string $content
     * @param string $ext
     * @return void
     */
    function write_manager_log(string $content, string $ext = '')
    {
        if (config('app_status') == 'pro') {
            try {
                $webHookHttpDao = new WebHookHttpDao();

                $res = $webHookHttpDao->writeLog($content, $ext);

                if ($res['code'] != 0) {
                    throw new Exception('写大后台日志失败！');
                }
            } catch (Exception $e) {
                send_msg_to_wecom($e->getMessage());
            }
        }
    }
}

if (! function_exists('search_two_dimensional_array')) {
    /**
     * 搜索二维数组
     *
     * @param $keyword
     * @param array $searchTarget
     * @return int|string
     */
    function search_two_dimensional_array($keyword, array $searchTarget)
    {
        foreach ($searchTarget as $key => $value) {
            if (in_array($keyword, $value)) {
                return $key;
            }
        }
        return false;
    }
}

if (! function_exists('merge_two_dimensional_array')) {
    /**
     * 合并二维数组
     *
     * @param array $mergeTarget
     * @return array
     */
    function merge_two_dimensional_array(array $mergeTarget): array
    {
        $targetValues = array_values($mergeTarget);
        $arrayRes = [];
        foreach ($targetValues as $value) {
            $arrayRes = array_merge($arrayRes, $value);
        }
        return $arrayRes;
    }
}

if (! function_exists('resize_image')) {
    /**
     * 改变图片尺寸
     *
     * @param string $oldImagePath 原图片路径
     * @param string $newImagePath 新图片路径
     * @param int $newWidth 新图片宽
     * @param int $newHeight 新图片高
     * @return void
     */
    function resize_image(string $oldImagePath, string $newImagePath, int $newWidth, int $newHeight): void
    {
        [$width, $height] = getimagesize($oldImagePath);

        $oldImageResource = imagecreatetruecolor($newWidth, $newHeight);

        $newImageResource = imagecreatefrompng($oldImagePath);

        imagecopyresampled($oldImageResource, $newImageResource, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

        imagepng($oldImageResource, $newImagePath);
    }
}

if (! function_exists('merge_two_images')) {
    /**
     * 把一张图片合并到背景图上
     *
     * @param string $backgroundPath 背景图路径
     * @param string $frontPath 前置图路径
     * @param string $mergePath 合并后的图片路径
     * @param int $xOffset x偏移量
     * @param int $yOffset y偏移量
     * @param int $alpha 透明度 0-全透明 100-不透明
     * @return void
     */
    function merge_two_images(
        string $backgroundPath,
        string $frontPath,
        string $mergePath,
        int $xOffset,
        int $yOffset,
        int $alpha = 100
    ): void {
        // 创建图片对象
        $backgroundResource = imagecreatefrompng($backgroundPath);
        $backgroundInfo = getimagesize($backgroundPath);
        $frontResource = imagecreatefrompng($frontPath);
        $frontInfo = getimagesize($frontPath);

        imagecopymerge(
            $backgroundResource,
            $frontResource,
            $backgroundInfo[0] - $frontInfo[0] - $xOffset,
            $backgroundInfo[1] - $frontInfo[1] - $yOffset,
            0,
            0,
            $frontInfo[0],
            $frontInfo[1],
            $alpha
        );

        imagepng($backgroundResource, $mergePath);
    }
}

if (! function_exists('addSuffix')) {
    /**
     * 追加字符到链接
     *
     * @param string $originLink 原始链接
     * @param string $suffix 追加的字符
     * @param string $separator
     * @return string
     */
    function addSuffix(
        string $originLink,
        string $suffix = '.html',
        string $separator = '?'
    ): string {
        $pagePath = trim($originLink);
        $pagePathArr = explode($separator, $pagePath);
        $webLink = $pagePathArr[0];
        $param = $pagePathArr[1] ?? '';
        if (substr($webLink, -5) != $suffix) {
            $pagePath = $webLink . $suffix;
            if ($param) {
                $pagePath .= $separator . $param;
            }
        }
        return $pagePath;
    }
}
