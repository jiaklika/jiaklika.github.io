<?php

return [
    // 数据库类型
    'type' => 'mysql',
    // 服务器地址
    'hostname' => '',
    // 数据库名
    'database' => '',
    // 用户名
    'username' => '',
    // 密码
    'password' => '',
    // 端口
    'hostport' => '3306',
    // 数据库编码默认采用utf8
    'charset' => 'utf8',
    // 数据库表前缀
    'prefix' => '',
    // 是否需要断线重连
    'break_reconnect' => true,
];
