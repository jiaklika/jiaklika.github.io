<?php

// 阿里云配置
return [
    'access_key_id'       => '',
    'access_key_secret'   => '',
    'oss_end_point'       => '',
    'oss_bucket'          => '',
    'oss_original_domain' => '',
    'oss_custom_domian'   => ''
];
