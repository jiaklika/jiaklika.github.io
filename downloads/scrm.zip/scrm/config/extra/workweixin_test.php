<?php

return [
    'jssdk_config_url'        => 'http://scrmceshi.bojem.com/api/contact/getConfig', // 获取jssdk的配置
    'detail_data_url'         => 'http://scrmceshi.bojem.com/api/contact/getDetail', // 获取客户详情接口
    'yanzhi_url'              => 'http://kotest.bojem.com/user/info?union_id=%s', // 获取颜值接口
    'liverank_url'            =>
        'https://baojietest.bojem.com/api/appServer/returnUserLiveLevel?unionId=%s', // 获取直播间等级接口
    'usercenter_url'          => 'http://ucenterdev.bojem .com/userCenter/user/getInfoByUnionId', // 获取用户信息接口
    'home_url'                => 'https://hometest.bojem.com/api/bojem.old/getLoginTime?union_id=%s', // app最后登录时间
    'external_contact_secret' => '', // 客户联系的Secret
    'agent_secret'            => '', // 自建应用的Secret
    'user_secret'             => '', // 通讯录管理Secret
    'live_secret'             => '', // 直播Secret
    'session_secret'          => '', // 会话内容存档Secret
    'expire_time'             => 60, // 缓存提前60s到期
    'agent_id'                => 1, // 应用ID
    'log_url'                 => '', // 写大后台操作日志
];
