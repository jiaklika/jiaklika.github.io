<?php

// 微信客服回调配置
return [
    'record_log' => true, // 全局控制是否记录回调日志
    'kefu_callback' => [
        'kefu_token'          => '',
        'kefu_encodingAesKey' => ''
    ],
];
