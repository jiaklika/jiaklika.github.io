<?php

// 企业微信回调配置
return [
    'record_log' => true, // 全局控制是否记录回调日志
    'contact_callback' => [
        'contact_token'          => 'UP8ngiDbpaCdpKIzskJKjy',
        'contact_encodingAesKey' => 'ha5xzjXt79cs89X4DStOCrsMeiXc1PdahfHYiAGAzgp'
    ],
    'user_callback' => [
        'user_token'          => 'XRmEYu5sFDfR',
        'user_encodingAesKey' => 'aT8WT4seCdRHIHkcIW9AFcw74Y2vK4v6Q5anNs8l7za'
    ],
    'msg_callback' => [
        'msg_token'          => 'Kgp9tFCBXpfqaTy0cQHFlmYd7',
        'msg_encodingAesKey' => 'nqVhoW3D8tj6QdG7iGjGAadEdKbnEfZQxnePz7FqcL7'
    ],
    'approval_callback' => [
        'msg_token'          => '',
        'msg_encodingAesKey' => ''
    ]
];
