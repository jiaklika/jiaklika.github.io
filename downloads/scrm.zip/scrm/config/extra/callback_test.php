<?php

// 企业微信回调配置
return [
    'record_log' => true, // 全局控制是否记录回调日志
    'contact_callback' => [
        'contact_token'          => '',
        'contact_encodingAesKey' => ''
    ],
    'user_callback' => [
        'user_token'          => '',
        'user_encodingAesKey' => ''
    ],
    'msg_callback' => [
        'msg_token'          => '',
        'msg_encodingAesKey' => ''
    ],
    'approval_callback' => [
        'msg_token'          => '',
        'msg_encodingAesKey' => ''
    ]
];
