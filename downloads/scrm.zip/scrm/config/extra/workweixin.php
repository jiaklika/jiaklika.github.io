<?php

return [
    'jssdk_config_url'        => 'http://scrmceshi.bojem.com/api/contact/getConfig', // 获取jssdk的配置
    'detail_data_url'         => 'http://scrmceshi.bojem.com/api/contact/getDetail', // 获取客户详情接口
    // 'yanzhi_url'              => 'http://kotest.bojem.com/user/info?union_id=%s', // 获取颜值接口
    'yanzhi_url'              => 'http://ko.bojem.com/user/info?union_id=%s', // 获取颜值接口
    // 'liverank_url'            =>
    // 'https://baojietest.bojem.com/api/appServer/returnUserLiveLevel?unionId=%s', // 获取直播间等级接口
    'liverank_url'            => 'https://baojie.bojem.com/api/appServer/returnUserLiveLevel?unionId=%s', // 获取直播间等级接口
    'usercenter_url'          => 'http://ucenter.bojem.com/userCenter/user/getInfoByUnionId', // 获取用户信息接口
    // 'home_url'                => 'https://hometest.bojem.com/api/bojem.old/getLoginTime?union_id=%s', // app最后登录时间
    'home_url'                => 'https://home.bojem.com/api/bojem.old/getLoginTime?union_id=%s', // app最后登录时间
    'external_contact_secret' => '04zzY7VpqiAYptE13GAIloZnoE3ZR-gN3PX-jXsWAe8', // 客户联系的Secret
    'agent_secret'            => 'H1_5u_kMmKCtz3lqAiqLb1_QPaGY38fjw2AK1ZG1Fqs', // 自建应用的Secret
    'user_secret'             => '3UamrwBVwRVEPBepd6drdnXY7_J-S4BGw0ln76yYAVk', // 通讯录管理Secret
    'session_secret'          => '', // 会话内容存档Secret
    'live_secret'             => '7Z_FT9XNxqx5szv732l3ZYzbMrGaV2Ls_92A5iXA_Nw', // 直播Secret
    'kefu_secret'             => 'yqbAwAYFZXAiE6f3slg7beGbZ1YU9sj6OYytRvqGjUk', // 微信客服Secret
    'expire_time'             => 60, // 缓存提前60s到期
    'agent_id'                => 1000028, // 应用ID
    'add_wechat_url'          => 'http://scrmceshi.bojem.com/api/kefu/addWechatRecord', // 记录添加个微
];
