<?php

namespace app\api\common;

/**
 * 常量
 *
 * Class Constant
 * @package app\api\common
 */
class Constant
{
    // 公用响应码
    public const SUCCESS      = '0000';
    public const PARAM_ERROR  = '1000';
    public const SYSTEM_ERROR = '5000';
    public const HTTP_ERROR   = '5001';
    public const SYSTEM_LOCK  = '5003';
    public const BAD_REQUEST  = '4000';
    public const NO_LOGIN     = '10002';
    public const NO_ACTION    = '4004';

    public const ADMIN_TOKEN_EMPTY = '1010';
    public const ADMIN_NO_LOGIN    = '1011';

}