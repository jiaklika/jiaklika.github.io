<?php

namespace app\api\common;

use think\Log;

class Response
{
    public static $errorMessageMap = [
        Constant::SUCCESS           => '成功',
        Constant::SYSTEM_ERROR      => '系统错误',
        Constant::SYSTEM_LOCK       => '您的操作太频繁啦',
        Constant::HTTP_ERROR        => '请求异常',
        Constant::BAD_REQUEST       => '非法请求',
        Constant::NO_LOGIN          => '请先登录',
        Constant::NO_ACTION         => '请求方法不存在',
        Constant::ADMIN_TOKEN_EMPTY => 'Token为空，请先登录',
        Constant::ADMIN_NO_LOGIN    => '请先登录',
    ];

    /**
     * @param string $msg
     * @param array $data
     * @return void
     */
    public static function success($msg = 'success', $data = [])
    {
        exit(self::json(Constant::SUCCESS, $msg, $data));
    }

    /**
     * @param string $msg
     * @param array $data
     * @return void
     */
    public static function error($msg = 'error', $data = [])
    {
        exit(self::json(Constant::SYSTEM_ERROR, $msg, $data));
    }

    /**
     * @param $code
     * @param string $msg
     * @param array $data
     * @return void
     */
    public static function custom($code, $msg = '', $data = [])
    {
        Log::error($code . '--' . $msg);
        exit(self::json($code, $msg, $data));
    }

    /**
     * @param $code
     * @param string $message
     * @param array $data
     * @return string
     */
    private static function json($code, $message = '', $data = []): string
    {
        //header('content:application/json;charset=uft-8');
        ob_clean();
        $message = empty($message)
            ? (
                self::$errorMessageMap[$code] ?? '未知错误~'
            )
            : $message;

        return json_encode([
            "code"   => $code,
            "msg"    => $message,
            "data"   => !empty($data) ? $data : new \stdClass(),
            "status" => intval($code) == 0
        ], JSON_UNESCAPED_UNICODE);
    }
}
