<?php

declare(strict_types=1);

namespace app\api\util;

use app\api\dao\mysql\kefu\KefuAccountsDao;
use app\api\dao\mysql\message\GroupMsgTemplatesDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\dao\mysql\way\WayUserMapDao;
use app\common\model\ContactWays;
use Exception;

/**
 * 自定义验证规则
 *
 * Trait ValidateTrait
 * @package app\api\util
 */
trait ValidateTrait
{
    /**
     * 检查是否为空字符
     *
     * @param $value
     * @return bool
     */
    protected function checkEmpty($value): bool
    {
        if (is_string($value)) {
            $value = trim($value);
        }

        if (empty($value)) {
            return false;
        }

        return true;
    }

    /**
     * 检查渠道是否存在
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkChannelExits($value): bool
    {
        return ContactChannelsDao::isExistById((int)$value);
    }

    /**
     * 检查路径是否存在
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkWayExits($value): bool
    {
        return ContactWaysDao::isExistById((int)$value);
    }

    /**
     * 检查渠道名称是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkChannelNameRepeat($value): bool
    {
        $channelId = request()->post('channel_id');

        $extraWhere = [
            'channel_name' => $value,
            'is_deleted'   => 0,
        ];

        if ($channelId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'id' => ['<>', $channelId]
                ]
            );
        }

        return !ContactChannelsDao::isExistById(0, $extraWhere);
    }

    /**
     * 检查路径名称是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkWayNameRepeat($value): bool
    {

        [
            $wayId,
            $scene,
            $newUserIdArr
        ] =
        [
            request()->post('way_id'),
            request()->post('scene'),
            request()->post('user_id/a')
        ];

        $extraWhere = [
            'way_name'   => $value,
            'is_deleted' => ContactWays::NOT_DELETED,
            'scene'      => $scene
        ];

        if ($wayId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'id' => ['<>', $wayId]
                ]
            );
        }

        if ($wayInfo = ContactWaysDao::getDetail(['id'], $extraWhere)) {
            $userIdArr = WayUserMapDao::getAllList(['user_id'], ['way_id' => $wayInfo['id']]);
            $originalUserIdArr = array_column($userIdArr, 'user_id');
            $diffRes = array_diff($originalUserIdArr, $newUserIdArr);
            if ($diffRes) {
                return true;
            }
            return false;
        }

        return true;
    }

    /**
     * 检查任务名称是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkTaskNameRepeat($value): bool
    {
        $templateId = request()->post('template_id');

        $extraWhere = [
            'task_name'  => $value,
            'is_deleted' => 0,
        ];

        if ($templateId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'id' => ['<>', $templateId]
                ]
            );
        }

        return !GroupMsgTemplatesDao::isExistById(0, $extraWhere);
    }

    /**
     * 检查两个字段是否同时为空
     *
     * @return bool
     */
    protected function checkMeanwhileEmpty(): bool
    {
        [
            $rangeOption,
            $sender
        ] =
        [
            request()->post('range_option'),
            request()->post('sender/a')
        ];
        if (!$tag = request()->post('tag/a')) {
            $tag = [];
        }

        if ($rangeOption != 2) {
            if (empty(array_filter($tag)) && empty(array_filter($sender))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 检查两条消息不能同时为空
     *
     * @param $value
     * @return bool
     */
    protected function checkContentEmpty($value): bool
    {
        $contentText = request()->post('content_text');

        if (empty($contentText) && $value == 0) {
            return false;
        }

        return true;
    }

    /**
     * 检查群发记录是否存在
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkTemplateExits($value): bool
    {
        return GroupMsgTemplatesDao::isExistById((int)$value);
    }

    /**
     * 检查群发记录的状态
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkTemplateStatus($value): bool
    {
        $templateArr = GroupMsgTemplatesDao::getDetail(['status'], [
            'id' => $value
        ]);

        if ($templateArr['status'] != 0) {
            return false;
        }

        return true;
    }

    /**
     * 检查小程序消息标题最多64个字节
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkTitleLength($value): bool
    {
        return !(strlen($value) > 64);
    }

    /**
     * 检查客服账号是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    protected function checkAccountNameRepeat($value): bool
    {
        $openKfId = request()->post('open_kfid');

        $extraWhere = [
            'account_name' => $value,
            'is_deleted'   => 0,
        ];

        if ($openKfId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'open_kfid' => ['<>', $openKfId]
                ]
            );
        }

        return !KefuAccountsDao::isExistById(0, $extraWhere);
    }
}
