<?php

declare(strict_types=1);

namespace app\api\util;

use Carbon\Carbon;
use Exception;
use GuzzleHttp\Client;
use Throwable;

/**
 * 通用发送http请求
 *
 * Trait HttpClient
 * @package app\api\util
 */
trait HttpClient
{
    /**
     * @var object
     */
    private static $client;

    /**
     * @var int 请求超时时间
     */
    protected static $timeout = 600;

    /**
     * 得到Guzzle实例
     *
     * @param mixed ...$args
     * @return Client
     */
    public static function getInstance(...$args): Client
    {
        if (!isset(self::$client)) {
            self::$client = new Client(...$args);
        }
        return self::$client;
    }

    /**
     * 发送HTTP请求，只支持接口返回json
     *
     * @param string $requestType 请求类型
     * @param string $requestUrl 接口地址
     * @param array $params 请求参数
     * @return array
     * @throws Exception
     */
    public static function sendRequest(
        string $requestType,
        string $requestUrl,
        array $params = []
    ): array {
        try {
            if (!in_array($requestType, ['get', 'post'])) {
                throw new Exception('只支持get或post请求');
            }

            if (empty($requestUrl) || !is_string($requestUrl)) {
                throw new Exception('请求地址不能为空且需要是字符串类型');
            }

            if (!is_array($params)) {
                throw new Exception('请求参数需要是数组');
            }

            $httpRes = $requestType == 'get'
                ? self::getInstance(['timeout' => static::$timeout, 'verify' => false])
                    ->get($requestUrl, $params)
                    ->getBody()
                    ->getContents()
                : self::getInstance(['timeout' => static::$timeout, 'verify' => false])
                    ->post($requestUrl, $params)
                    ->getBody()
                    ->getContents();

            $returnArr = [];
            // 是否返回json
            $isValidJson = function ($string) use (&$returnArr) {
                $returnArr = json_decode($string, true);
                return (json_last_error() == JSON_ERROR_NONE);
            };

            if (!$isValidJson($httpRes)) {
                throw new Exception('接口没有返回json或json格式不正确');
            }

            return $returnArr;
        } catch (Throwable $exception) {
            throw new Exception('sendRequest出错：' . $requestUrl . $exception->getMessage());
        }
    }

    /**
     * 下载远程文件到本地服务器
     *
     * @param string $requestUrl 请求地址
     * @param string $saveName   文件保存名称
     * @return string 本地文件名
     * @throws Exception
     */
    public function downloadRemoteFileToLocal(string $requestUrl, string $saveName = ''): string
    {
        try {
            if (empty($requestUrl) || !is_string($requestUrl)) {
                throw new Exception('请求地址不能为空且需要是字符串类型');
            }

            if (!$saveName) {
                $headerRes = self::getInstance(['timeout' => static::$timeout])->get($requestUrl);

                $contentType = $headerRes->getHeader('Content-Type');
                $mediaType = explode('/', $contentType[0]);

                $mediaName = mt_rand(1, 2000) . Carbon::now()->getPreciseTimestamp(3);
                if (in_array($mediaType[0], ['video', 'audio'])) {
                    if ($mediaType[0] == 'video') {
                        $saveName = $mediaName . '.mp4';
                    }

                    if ($mediaType[0] == 'audio') {
                        $saveName = $mediaName . '.amr';
                    }
                } else {
                    $dispositionArr = $headerRes->getHeader('Content-disposition');

                    if ($dispositionArr) {
                        $disposition = $dispositionArr[0];
                        // 如果没有后缀，就是gif
                        $position = strrpos($disposition, '.');
                        if ($position) {
                            $saveName = trim(substr($disposition, strrpos($disposition, 'filename=') + 9), '"');
                        } else {
                            $saveName = $mediaName . '.gif';
                        }
                    } else {
                        $saveName = $mediaName . '.' . $mediaType[1];
                    }
                }
            }

            $savePath = 'public/downloads/' . $saveName;

            $httpRes = self::getInstance(['timeout' => static::$timeout])->get($requestUrl, ['save_to' => $savePath]);

            if ($httpRes->getStatusCode() == 200 && file_exists($savePath)) {
                return $saveName;
            } else {
                send_msg_to_wecom($requestUrl . json_encode($httpRes));
                return '';
            }
        } catch (Throwable $e) {
            throw new Exception($e->getTraceAsString());
        }
    }
}
