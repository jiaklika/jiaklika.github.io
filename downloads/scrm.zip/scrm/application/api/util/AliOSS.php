<?php

declare(strict_types=1);

namespace app\api\util;

use Carbon\Carbon;
use Exception;
use OSS\Core\OssException;
use OSS\OssClient;
use think\Log;

/**
 * Trait AliOSS
 * @package app\api\util
 */
trait AliOSS
{
    /**
     * @var object
     */
    private static $ossClient;

    /**
     * @var string 默认bucket
     */
    private static $defaultBucket;

    /**
     * @var string 默认域名
     */
    private static $originalDomain;

    /**
     * @var string 自定义域名
     */
    private static $customDomain;

    /**
     * 得到OSS实例
     *
     * @param mixed
     * @return OssClient
     * @throws OssException
     */
    public static function getOssInstance(): OssClient
    {
        if (!isset(self::$ossClient)) {
            $aliYunConfig = config('aliyun');

            [
                $accessKeyId,
                $accessKeySecret,
                $endpoint,
                self::$defaultBucket,
                self::$originalDomain,
                self::$customDomain
            ] = [
                $aliYunConfig['access_key_id'],
                $aliYunConfig['access_key_secret'],
                $aliYunConfig['oss_end_point'],
                $aliYunConfig['oss_bucket'],
                $aliYunConfig['oss_original_domain'],
                $aliYunConfig['oss_custom_domian']
            ];

            self::$ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint);
        }
        return self::$ossClient;
    }


    /**
     * 上传文件到OSS
     *
     * @param string $object        上传文件到OSS时需要指定包含文件后缀在内的完整路径，例如abc/efg/123.jpg
     * @param string $localFilePath 本地文件路径
     * @param string $bucket        存储空间名称
     * @return array
     * @throws Exception
     */
    public function uploadFileToOSS(string $object, string $localFilePath, string $bucket = ''): array
    {
        $ossClient = self::getOssInstance();

        $bucket = $bucket ? : self::$defaultBucket;

        try {
            $uploadRes = $ossClient->uploadFile($bucket, $object, $localFilePath);

            if (
                isset($uploadRes['oss-request-url'])
                && !empty($uploadRes['oss-request-url'])
            ) {
                $uploadRes['oss-request-url'] = str_replace(
                    self::$originalDomain,
                    self::$customDomain,
                    $uploadRes['oss-request-url']
                );

                return ['url' => urldecode($uploadRes['oss-request-url'])];
            }
        } catch (OssException $e) {
            throw new Exception($e->getMessage());
        }
        return ['url' => ''];
    }

    /**
     * 从OSS下载文件
     *
     * @param string $object
     * @param string $fileSuffix 文件后缀
     * @param string $bucket
     * @throws OssException
     */
    public function downloadFileFromOSS(string $object, string $fileSuffix, string $bucket = '')
    {
        $ossClient = self::getOssInstance();

        $bucket = $bucket ? : self::$defaultBucket;

        // 本地指定的文件路径加文件名包括后缀组成，例如/users/local/myfile.txt。
        $localFile = $_SERVER['DOCUMENT_ROOT'] . '/public/downloads/' . Carbon::now()->timestamp . '.' . $fileSuffix;

        $options = [
            OssClient::OSS_FILE_DOWNLOAD => $localFile
        ];

        // 使用try catch捕获异常，如果捕获到异常，则说明下载失败；
        // 如果没有捕获到异常，则说明下载成功。
        try {
            $ossClient->getObject($bucket, $object, $options);
        } catch (OssException $e) {
            Log::error($e->getMessage());
            return;
        }
    }
}
