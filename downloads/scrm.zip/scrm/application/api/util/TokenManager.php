<?php

declare(strict_types=1);

namespace app\api\util;

use Exception;
use think\Cache;

/**
 * Class TokenManager
 * @package app\api\util
 */
class TokenManager
{
    use HttpClient;

    // 获取accessToken的接口地址
    private const GET_TOKEN_URL = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s';
    // 企业ID，固定不会更改
    public const APP_ID = 'wxeac0444a4199b6fb';
    // 要加密的字符串
    private const UNENCRYPTED_STR = 'jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s';

    /**
     * 不同的功能需要不同的jsapi_ticket
     */
    public const COMPANY_TICKET = 1;
    public const APP_TICKET     = 2;

    private const JSAPI_TICKET_URL = [
        self::COMPANY_TICKET =>
            'https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=%s', // 获取企业的jsapi_ticket
        self::APP_TICKET     =>
            'https://qyapi.weixin.qq.com/cgi-bin/ticket/get?access_token=%s&type=agent_config', // 获取应用的jsapi_ticket
    ];

    private const JSAPI_TICKET_TOKEN_NAME = [
        self::COMPANY_TICKET => 'configJsApiTicket', // 企业jsApiTicket缓存名称
        self::APP_TICKET     => 'agentJsApiTicket',  // 应用jsApiTicket缓存名称
    ];

    /**
     * 不同的功能需要不同的secret
     */
    public const CONTACT_INDEX = 1;
    public const APP_INDEX     = 2;
    public const USER_INDEX    = 3;
    public const SESSION_INDEX = 4;
    public const LIVE_INDEX    = 5;
    public const KEFU_INDEX    = 6;

    /**
     * 映射
     */
    private const SECRET_MAP = [
        self::CONTACT_INDEX => 'external_contact_secret',
        self::APP_INDEX     => 'agent_secret',
        self::USER_INDEX    => 'user_secret',
        self::SESSION_INDEX => 'session_secret',
        self::LIVE_INDEX    => 'live_secret',
        self::KEFU_INDEX    => 'kefu_secret',
    ];

    private const TOKEN_CACHE_NAME = [
        self::CONTACT_INDEX => 'contactAccessToken', // 外部联系人token缓存名
        self::APP_INDEX     => 'agentAccessToken',   // 自建应用token缓存名
        self::USER_INDEX    => 'userAccessToken',    // 通讯录管理token缓存名
        self::SESSION_INDEX => 'sessionAccessToken', // 会话内容存档token缓存名
        self::LIVE_INDEX    => 'liveAccessToken',    // 直播token缓存名
        self::KEFU_INDEX    => 'kefuAccessToken',    // 微信客服token缓存名
    ];

    /**
     * 获取不同的AccessToken
     *
     * @param int|null $type 1-外部联系人 2-自建应用 3-通讯录管理 4-会话内容存档 5-微信客服
     * @return string
     * @throws Exception
     */
    public static function getAccessToken(?int $type): string
    {
        if (empty($type) || !array_key_exists($type, self::SECRET_MAP)) {
            throw new Exception('不存在的type类型');
        }

        // 缓存中有就直接返回
        $cacheName = self::TOKEN_CACHE_NAME[$type];

        try {
            if ($accessToken = Cache::get($cacheName)) {
                return $accessToken;
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }

        // 缓存中没有再重新请求，存入缓存
        $secret = self::SECRET_MAP[$type];
        // 拼接url
        $url = sprintf(
            self::GET_TOKEN_URL,
            self::APP_ID,
            config('workweixin.' . $secret)
        );

        $res = self::sendRequest('get', $url);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        try {
            Cache::set($cacheName, $res['access_token'], intval($res['expires_in'] - config('workweixin.expire_time')));
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }

        return $res['access_token'];
    }

    /**
     * 获取企业或应用的jsapi_ticket
     *
     * @param int|null $type 1-企业 2-应用
     * @return mixed
     * @throws Exception
     */
    private static function getJsApiTicket(?int $type)
    {
        if (empty($type) || !array_key_exists($type, self::JSAPI_TICKET_TOKEN_NAME)) {
            throw new Exception('不存在的type类型');
        }

        [
            $cacheName,
            $accessToken,
            $url
        ] = [
            self::JSAPI_TICKET_TOKEN_NAME[$type],
            self::getAccessToken($type),
            self::JSAPI_TICKET_URL[$type]
        ];

        if (!$jsApiTicket = Cache::get($cacheName)) {
            $jsApiTicketUrl = sprintf(
                $url,
                $accessToken
            );

            $res = self::sendRequest('get', $jsApiTicketUrl);

            if ($res['errcode'] != 0) {
                throw new Exception($res['errmsg']);
            }

            $jsApiTicket = $res['ticket'];

            Cache::set($cacheName, $jsApiTicket, intval($res['expires_in'] - config('workweixin.expire_time')));
        }

        return $jsApiTicket;
    }

    /**
     * 生成签名
     *
     * @param string $nonceStr    随机字符串
     * @param int    $timestamp   生成签名的时间戳
     * @param string $redirectUrl 当前网页的URL
     * @param int    $type        默认为企业
     * @return string
     * @throws Exception
     */
    public static function getSignature(
        string $nonceStr,
        int $timestamp,
        string $redirectUrl,
        int $type = self::COMPANY_TICKET
    ): string {
        $unencryptedStr = sprintf(
            self::UNENCRYPTED_STR,
            self::getJsApiTicket($type),
            $nonceStr,
            $timestamp,
            $redirectUrl
        );

        return sha1($unencryptedStr);
    }
}
