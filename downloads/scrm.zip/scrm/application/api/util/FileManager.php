<?php

namespace app\api\util;

use app\api\dao\http\media\MediaHttpDao;
use Carbon\Carbon;
use Closure;
use Exception;
use think\File;

/**
 * 文件管理
 *
 * Class FileManager
 * @package app\api\util
 */
class FileManager
{
    use HttpClient;
    use AliOSS;

    /**
     * 更新临时素材
     *
     * @param string $mediaType 文件类型
     * @param string $suffix 文件后缀
     * @param array $fileData 文件数据
     * @param Closure|null $updateSuccessFunc 上传临时素材成功后操作
     * @return mixed
     * @throws Exception
     */
    public function updateTemporaryMedia(
        string $mediaType,
        string $suffix,
        array $fileData,
        Closure $updateSuccessFunc = null
    ) {
        // 当前时间
        $nowTimestamp = Carbon::now()->timestamp;

        // 临时素材mediaId过期了
        if (
            isset($fileData['create_time'])
            && intval($fileData['create_time'] + MediaHttpDao::MEDIA_EXPIRE_TIME) < $nowTimestamp
        ) {
            // 把oss的下载下来，重新上传
            $saveName = sprintf(
                '%s.%s',
                mt_rand(1, 1000) . $nowTimestamp,
                $suffix
            );

            // 下载到服务器上
            self::downloadRemoteFileToLocal($fileData['media_url'], $saveName);

            // 重新上传
            // 文件路径
            $savePath = 'public/downloads/' . $saveName;
            $mediaHttpDao = new MediaHttpDao();
            $uploadRes = $mediaHttpDao->uploadMedia($mediaType, $savePath, $saveName);
            // 新的三天有效的mediaId
            $mediaId = $uploadRes['media_id'];
            // 成功后执行闭包
            $updateRes = $updateSuccessFunc != null ? $updateSuccessFunc($fileData, $uploadRes) : true;

            // 删除本地文件
            @unlink($savePath);

            if ($updateRes === false) {
                throw new Exception('临时素材更新失败！' . json_encode($fileData, JSON_UNESCAPED_UNICODE));
            }
        } else // 没有过期直接返回原来的
        {
            $mediaId = $fileData['media_id'] ?? $fileData['miniprogram_pic_media_id'];
        }

        return $mediaId;
    }

    /**
     * 上传临时素材
     * 临时素材需要存储在oss
     *
     * @param string $type 文件类型
     * @param File $file 文件
     * @return array
     * @throws Exception
     */
    public function uploadMedia(string $type, File $file): array
    {

        // 先上传到本地
        [$result, $uploadInfo] = uploadFile(
            $file,
            MediaHttpDao::FILE_SIZE_MAP[$type],
            MediaHttpDao::FILE_TYPE_MAP[$type]
        );

        if ($result) { // 上传本地成功后再上传到OSS和企业微信
            $fileName = $uploadInfo->getSaveName();
            $object = sprintf('%s/%s', $type, $fileName);
            $realPath = $uploadInfo->getPathname();

            // 先上传到OSS
            $ossUploadRes = self::uploadFileToOSS($object, $realPath);

            $mediaHttpDao = new MediaHttpDao();
            $uploadRes = $mediaHttpDao->uploadMedia($type, $realPath, $fileName);

            if ($ossUploadRes['url']) {
                // 删除本地文件
                @unlink($realPath);
                return [
                    'media_url'       => urldecode($ossUploadRes['url']),
                    'media_id'        => $uploadRes['media_id'],
                    'media_create_at' => $uploadRes['created_at']
                ];
            }
        } else {
            return [$uploadInfo];
        }
        return [];
    }

    /**
     * 上传永久图片
     *
     * @param File $file
     * @return array
     * @throws Exception
     */
    public function uploadImg(File $file): array
    {
        // 先上传到本地
        // 图片文件大小应在5B~2MB之间
        [$result, $uploadInfo] = uploadFile($file, MediaHttpDao::IMAGE_MAX_SIZE, MediaHttpDao::IMAGE_TYPE);

        if ($result) { // 上传本地成功后再上传到企业微信
            $realPath = $uploadInfo->getPathname();

            $mediaHttpDao = new MediaHttpDao();
            $wxUploadRes = $mediaHttpDao->uploadImg($realPath, $uploadInfo->getSaveName());

            // 删除本地文件
            @unlink($realPath);

            return [true, $wxUploadRes];
        }
        return [false, $uploadInfo];
    }

    /**
     * 上传附件资源
     *
     * @param File $file
     * @param string $fileType
     * @return array
     * @throws Exception
     */
    public function uploadAttachment(File $file, string $fileType): array
    {
        // 先上传到本地

        if ($fileType == 'image') {
            // 图片文件大小应在5B~2MB之间
            [$result, $uploadInfo] = uploadFile($file, MediaHttpDao::IMAGE_MAX_SIZE, MediaHttpDao::IMAGE_TYPE);
        } else {
            // 10MB，支持MP4格式
            [$result, $uploadInfo] = uploadFile($file, MediaHttpDao::VIDEO_MAX_SIZE, MediaHttpDao::VIDEO_TYPE);
        }

        if ($result) { // 上传本地成功后再上传到企业微信
            $fileName = $uploadInfo->getSaveName();
            $object = sprintf('%s/%s', $fileType, $fileName);
            $realPath = $uploadInfo->getPathname();

            // 先上传到OSS
            $ossUploadRes = self::uploadFileToOSS($object, $realPath);

            $mediaHttpDao = new MediaHttpDao();
            $wxUploadRes = $mediaHttpDao->uploadAttachment($realPath, $fileType, $fileName);

            if ($ossUploadRes['url']) {
                // 删除本地文件
                @unlink($realPath);
                return [
                    true,
                    [
                        'media_url'  => $ossUploadRes['url'],
                        'media_id'   => $wxUploadRes['media_id'],
                        'created_at' => $wxUploadRes['created_at']
                    ]
                ];
            }
        }
        return [false, $uploadInfo];
    }

    /**
     * 对企微裂变二维码进行下载，处理和上传到七牛云和企微
     *
     * @param string $qrCodePath 二维码地址
     * @return array
     * @throws Exception
     */
    public function handleAndSaveFissionCode(string $qrCodePath): array
    {
        $backgroundPath = './public/images/background.png';
        // 唯一值
        $uniqueId = md5(mt_rand(1, 2000) . uniqid());
        // 先把二维码下载到服务器上
        $qrCodeLocalSaveName = $uniqueId . '.png';

        self::downloadRemoteFileToLocal($qrCodePath, $qrCodeLocalSaveName);

        $qrCodeLocalSavePath = 'public/downloads/' . $qrCodeLocalSaveName;

        // resize后的本地二维码
        $resizeQrCodeLocalSaveName = $uniqueId . '-400*400.png';
        $resizeQrCodeLocalSavePath = 'public/downloads/' . $resizeQrCodeLocalSaveName;

        // 合并后的本地海报地址
        $mergeSaveName = $uniqueId . '-bg.png';
        $mergePath = 'public/downloads/' . $mergeSaveName;

        // 接着进行图片处理
        // 裁剪图片
        resize_image($qrCodeLocalSavePath, $resizeQrCodeLocalSavePath, 400, 400);
        // 合并图片
        merge_two_images($backgroundPath, $resizeQrCodeLocalSavePath, $mergePath, 500, 152);

        // 再上传到OSS
        $object = sprintf('%s/%s', 'fission_images', $mergeSaveName);
        $ossUploadRes = self::uploadFileToOSS($object, $mergePath);

        // 最后上传到临时素材
        $mediaHttpDao = new MediaHttpDao();
        $uploadRes = $mediaHttpDao->uploadMedia('image', $mergePath, $mergeSaveName);

        if ($ossUploadRes['url']) {
            // 删除本地文件
            @unlink($mergePath);
            @unlink($resizeQrCodeLocalSavePath);
            @unlink($qrCodeLocalSavePath);
            return [
                'media_url'       => $ossUploadRes['url'],    // 七牛云地址
                'media_id'        => $uploadRes['media_id'],  // 临时素材唯一标识，3天内有效
                'media_create_at' => $uploadRes['created_at'] // 临时素材上传时间
            ];
        }
        return [];
    }

    /**
     * 更新客服临时素材
     *
     * @param string $msgType 文件类型
     * @param array $fileData 文件数据
     * @param Closure|null $updateSuccessFunc 上传临时素材成功后操作
     * @return mixed
     * @throws Exception
     */
    public function updateKefuTemporaryMedia(
        string $msgType,
        array $fileData,
        Closure $updateSuccessFunc = null
    ) {
        // 当前时间
        $nowTimestamp = Carbon::now()->timestamp;

        // 临时素材mediaId过期了
        if (
            isset($fileData['media_create_at'])
            && intval($fileData['media_create_at'] + MediaHttpDao::MEDIA_EXPIRE_TIME) < $nowTimestamp
        ) {
            // 下载到服务器上
            $saveName = self::downloadRemoteFileToLocal($fileData['media_url']);

            // 重新上传
            // 文件路径
            $savePath = 'public/downloads/' . $saveName;
            $mediaHttpDao = new MediaHttpDao();
            $uploadRes = $mediaHttpDao->uploadMedia($msgType, $savePath, $saveName);
            // 新的三天有效的mediaId
            $mediaId = $uploadRes['media_id'];
            // 成功后执行闭包
            $updateRes = $updateSuccessFunc != null ? $updateSuccessFunc($fileData, $uploadRes) : true;

            // 删除本地文件
            @unlink($savePath);

            if ($updateRes === false) {
                throw new Exception('临时素材更新失败！' . json_encode($fileData, JSON_UNESCAPED_UNICODE));
            }
        } else // 没有过期直接返回原来的
        {
            $mediaId = $fileData['media_id'] ?? $fileData['miniprogram_pic_media_id'];
        }

        return $mediaId;
    }

    /**
     * 下载临时素材，上传到OSS
     *
     * @param string $mediaId 临时素材id
     * @param string $saveName 文件名
     * @return array
     * @throws Exception
     */
    public function downloadMediaUploadOss(string $mediaId, string $saveName = ''): array
    {
        $fileUrl = '';
        // 先下载到本地
        $mediaHttpDao = new MediaHttpDao();
        $localFileName = $mediaHttpDao->downloadMedia($mediaId, $saveName);

        $localPath = 'public/downloads/' . $localFileName;

        // 上传到OSS
        $object = sprintf('kefu/%s', $localFileName);

        $ossUploadRes = self::uploadFileToOSS($object, $localPath);

        if ($ossUploadRes['url']) {
            // 删除本地文件
            @unlink($localPath);
            $fileUrl = $ossUploadRes['url'];
        }
        return [
            'url'       => $fileUrl,
            'file_name' => $localFileName
        ];
    }
}
