<?php

namespace app\api\exception;

use app\api\common\Response;
use app\api\common\Constant;
use app\api\dao\http\webHook\WebHookHttpDao;
use think\exception\Handle as OriginalHandle;
use think\exception\HttpException;
use Exception;

/**
 * 自定义异常处理类
 *
 * Class Handle
 * @package app\api\exception
 * @link https://www.kancloud.cn/manual/thinkphp5/126075
 */
class Handle extends OriginalHandle
{
    public function render(Exception $e)
    {
        // 请求异常
        if ($e instanceof HttpException) {
            Response::custom(Constant::HTTP_ERROR, $e->getMessage());
        }

        // 自定义的异常
        if ($e instanceof \Throwable) {
            $code = $e->getCode();

            if ($code == 0) {
                $code = Constant::SYSTEM_ERROR;
            }

            $errMsg = sprintf(
                '出错了：%s，文件：%s，第%s行，Trace：%s',
                $e->getMessage(),
                $e->getFile(),
                $e->getLine(),
                $e->getTraceAsString()
            );

            if (config('app_status') == 'pro') {
                try {
                    send_msg_to_wecom($code . $errMsg);
                } catch (Exception $e) {
                }
            }

            Response::custom($code, $errMsg);
        }
    }
}
