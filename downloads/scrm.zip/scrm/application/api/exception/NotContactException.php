<?php

namespace app\api\exception;

use Exception;

class NotContactException extends Exception
{

}
