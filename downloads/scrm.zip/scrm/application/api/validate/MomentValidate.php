<?php

namespace app\api\validate;

use app\api\util\ValidateTrait;
use think\Validate;

/**
 * 朋友圈任务验证器
 *
 * Class MomentValidate
 * @package app\api\validate
 */
class MomentValidate extends Validate
{
    use ValidateTrait;

    // 验证规则
    protected $rule = [
        'id'                 => 'require|integer|checkTemplateExits|checkTemplateStatus',
        'task_name'                   => 'require|checkEmpty|checkTaskNameRepeat',
        'range_option'                => 'require|integer|in:1,2',
        'sender'                      => 'requireIf:range_option,1|checkMeanwhileEmpty',
        'tag'                         => 'checkMeanwhileEmpty',
        'second_type'                 => 'require|checkContentEmpty|in:0,1,2,3',
        'is_plan'                     => 'require|integer|in:0,1',
        'plan_send_time'              => 'requireIf:is_plan,1',
    ];


    // 错误消息
    protected $message = [
        'id.require'                    => '群发记录ID不能为空',
        'id.integer'                    => '群发记录ID格式错误',
        'id.checkTemplateExits'         => '群发记录不存在或已删除',
        'id.checkTemplateStatus'        => '只有未开始的群发才可以编辑',
        'task_name.require'             => '任务名称不能为空',
        'task_name.checkEmpty'          => '任务名称不能为空',
        'task_name.checkTaskNameRepeat' => '已存在此任务名称',
        'range_option.require'          => '请选择发送范围',
        'range_option.integer'          => '发送范围必须是整数',
        'range_option.in'               => '不存在的发送范围',
        'sender.requireIf'              => '请选择添加人',
        'sender.checkMeanwhileEmpty'    => '添加人和标签不能同时为空',
        'tag.checkMeanwhileEmpty'       => '添加人和标签不能同时为空',
        'second_type.checkContentEmpty' => '第1条和第2条不能同时为空',
        'second_type.require'           => '请选择第2条类型',
        'second_type.in'                => '不存在的第2条类型',
        'is_plan.require'               => '请选择发送计划',
        'is_plan.integer'               => '发送计划为整数',
        'is_plan.in'                    => '不存在的发送计划选项',
        'plan_send_time.requireIf'      => '请填写发送时间',
    ];

    // 验证场景
    protected $scene = [
        'add'  => [
            'task_name',
            'range_option',
            'sender',
            'tag',
            'second_type',
            'is_plan',
            'plan_send_time'
        ],
        'edit'  => [
            'template_id',
            'task_name',
            'range_option',
            'sender',
            'tag',
            'second_type',
            'is_plan',
            'plan_send_time'
        ]
    ];
}
