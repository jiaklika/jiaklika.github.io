<?php

namespace app\api\validate;

use app\api\dao\mysql\kefu\KefuKeywordReplyDao;
use app\api\dao\mysql\kefu\KefuMsgMenuDao;
use app\api\util\ValidateTrait;
use Exception;
use think\Validate;

/**
 * 客服验证器
 *
 * Class KefuValidate
 * @package app\api\validate
 */
class KefuValidate extends Validate
{
    use ValidateTrait;

    /**
     * @var string[] 验证规则
     */
    protected $rule = [
        'account_name'              => 'require|checkEmpty|checkAccountNameRepeat',
        'userid'                    => 'require',
        'welcome_text'              => 'requireIf:welcome_type,1',
        'welcome_menu_id'           => 'requireIf:welcome_type,2',
        'rest_time_automatic_reply' => 'requireIf:service_period,2',
        'keyword_title'             => 'require|checkKeywordTitleRepeat|checkEmpty',
        'menu_name'                 => 'require|checkMenuNameRepeat|checkEmpty',
        'reply_json'                => 'checkCount',
        'webhook_url'               => 'requireIf:is_push_to_group,1',
        'maximum_limit'             => 'require|number|between:1,50',
        'keyword'                   => 'require',
        'service_time_start'        => 'requireIf:service_period,2',
        'service_time_end'          => 'requireIf:service_period,2'
    ];


    /**
     * @var string[] 错误消息
     */
    protected $message = [
        'account_name.require'                  => '客户账号名称不能为空',
        'account_name.checkEmpty'               => '客户账号名称不能为空',
        'account_name.checkAccountNameRepeat'   => '已存在此客户账号名称',
        'userid.require'                        => '接待人员不能为空',
        'welcome_text.requireIf'                => '请输入欢迎语文本内容',
        'welcome_menu_id.requireIf'             => '请选择智能菜单',
        'rest_time_automatic_reply.requireIf'   => '请填写非接待时间自动回复',
        'keyword_title.require'                 => '关键词标题不能为空',
        'keyword_title.checkEmpty'              => '关键词标题不能为空',
        'keyword_title.checkKeywordTitleRepeat' => '已存在此关键词标题',
        'menu_name.require'                     => '菜单标题不能为空',
        'menu_name.checkEmpty'                  => '菜单标题不能为空',
        'menu_name.checkMenuNameRepeat'         => '已存在此菜单标题',
        'reply_json.checkCount'                 => '最多添加4条',
        'webhook_url.requireIf'                 => '请填写webhook地址',
        'maximum_limit.require'                 => '请填写接待上限',
        'maximum_limit.number'                  => '接待上限必须是数字',
        'maximum_limit.between'                 => '接待上限只能在1-50之间',
        'keyword.require'                       => '关键词不能为空',
        'service_time_start.requireIf'          => '请填写上班时间',
        'service_time_end.requireIf'            => '请填写下班时间',
    ];

    // 验证场景
    protected $scene = [
        'add'  => [
            'account_name',
            'userid',
            'welcome_text',
            'welcome_menu_id',
            'rest_time_automatic_reply',
            'maximum_limit',
            'service_time_start'
        ],
        'edit' => [
            'account_name',
            'userid',
            'welcome_text',
            'welcome_menu_id',
            'rest_time_automatic_reply',
            'maximum_limit',
            'service_time_start'
        ],
        'add_keyword' => [
            'keyword_title',
            'reply_json',
            'webhook_url',
            'keyword'
        ],
        'edit_keyword' => [
            'keyword_title',
            'reply_json',
            'webhook_url',
            'keyword'
        ],
        'add_menu' => [
            'menu_name'
        ],
        'edit_menu' => [
            'menu_name'
        ],
    ];

    /**
     * 检查关键字标题是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    public function checkKeywordTitleRepeat($value): bool
    {
        $replyId = request()->post('reply_id');

        $extraWhere = [
            'keyword_title' => $value,
            'is_deleted'    => 0,
        ];

        if ($replyId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'id' => ['<>', $replyId]
                ]
            );
        }

        return !KefuKeywordReplyDao::isExistById(0, $extraWhere);
    }

    /**
     * 检查菜单标题是否重复
     *
     * @param $value
     * @return bool
     * @throws Exception
     */
    public function checkMenuNameRepeat($value): bool
    {
        $menuId = request()->post('menu_id');

        $extraWhere = [
            'menu_name'  => $value,
            'is_deleted' => 0,
        ];

        if ($menuId) { // 更新的时候检查不包含自己
            $extraWhere = array_merge(
                $extraWhere,
                [
                    'id' => ['<>', $menuId]
                ]
            );
        }

        return !KefuMsgMenuDao::isExistById(0, $extraWhere);
    }

    /**
     * @param $value
     * @return bool
     */
    public function checkCount($value): bool
    {
        return count($value) <= 4;
    }
}
