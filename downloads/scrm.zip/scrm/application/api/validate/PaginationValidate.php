<?php

namespace app\api\validate;

use think\Validate;

/**
 * 分页验证器
 *
 * Class PaginationValidate
 * @package app\api\validate
 */
class PaginationValidate extends Validate
{
    // 验证规则
    protected $rule = [
        'limit' => 'require|integer|min:1|max:40',
        'page'  => 'require|integer|min:1',
    ];

    // 错误消息
    protected $message = [
        'limit.require' => '请输入需要查询的数量',
        'limit.integer' => '查询数量必须为数值类型',
        'limit.min'     => '查询数量不能少于1',
        'limit.max'     => '查询数量超过系统的阈值',
        'page.require'  => '请输入需要查询的页码',
        'page.integer'  => '页码必须为数值类型',
        'page.min'      => '页码最低为1',
    ];
}
