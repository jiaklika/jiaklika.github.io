<?php

namespace app\api\validate;

use app\api\util\ValidateTrait;
use think\Validate;

/**
 * 渠道验证器
 *
 * Class ContactChannelValidate
 * @package app\api\validate
 */
class ContactChannelValidate extends Validate
{
    use ValidateTrait;

    // 验证规则
    protected $rule = [
        'channel_id'                  => 'require|integer|checkChannelExits',
        'channel_name'                => 'require|min:1|max:20|checkEmpty|checkChannelNameRepeat',
        'is_open_welcome'             => 'require|in:0,1'
    ];


    // 错误消息
    protected $message = [
        'channel_id.require'                    => '渠道ID不能为空',
        'channel_id.integer'                    => '渠道ID格式错误',
        'channel_id.checkChannelExits'          => '渠道不存在或已删除',
        'channel_name.require'                  => '渠道名称不能为空',
        'channel_name.min'                      => '渠道名称最少为1个字符',
        'channel_name.max'                      => '渠道名称最多为20个字符',
        'channel_name.checkEmpty'               => '渠道名称不能为空',
        'channel_name.checkChannelNameRepeat'   => '已存在此渠道名称',
        'is_open_welcome.require'               => '请选择是否启用渠道欢迎语',
        'is_open_welcome.in'                    => '不存在的是否启用渠道欢迎语类型'
    ];

    // 验证场景
    protected $scene = [
        'add'  => [
            'channel_name',
            'is_open_welcome'
        ],
        'edit' => [
            'channel_id',
            'channel_name',
            'is_open_welcome'
        ],
        'del'  => ['channel_id']
    ];
}
