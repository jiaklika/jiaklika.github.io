<?php

declare(strict_types=1);

namespace app\api\validate;

use app\api\util\ValidateTrait;
use think\Validate;

/**
 * 群发消息验证器
 *
 * Class GroupMsgValidate
 * @package app\api\validate
 */
class GroupMsgValidate extends Validate
{
    use ValidateTrait;

    // 验证规则
    protected $rule = [
        'template_id'                 => 'require|integer|checkTemplateExits|checkTemplateStatus',
        'task_name'                   => 'require|checkEmpty|checkTaskNameRepeat',
        'range_option'                => 'require|integer|in:1,2',
        'sender'                      => 'requireIf:range_option,1|checkMeanwhileEmpty',
        'tag'                         => 'checkMeanwhileEmpty',
        'second_type'                 => 'require|checkContentEmpty|in:0,1,2,3',
        'miniprogram_title'           => 'requireIf:second_type,1|checkTitleLength',
        'miniprogram_pic_media_id'    => 'requireIf:second_type,1',
        'miniprogram_pic_url'         => 'requireIf:second_type,1',
        'miniprogram_pic_create_time' => 'requireIf:second_type,1',
        'miniprogram_appid'           => 'requireIf:second_type,1',
        'miniprogram_page'            => 'requireIf:second_type,1',
        'image_pic_url'               => 'requireIf:second_type,2',
        'link_title'                  => 'requireIf:second_type,3',
        'link_url'                    => 'requireIf:second_type,3',
        'is_plan'                     => 'require|integer|in:0,1',
        'plan_send_time'              => 'requireIf:is_plan,1',
    ];


    // 错误消息
    protected $message = [
        'template_id.require'                   => '群发记录ID不能为空',
        'template_id.integer'                   => '群发记录ID格式错误',
        'template_id.checkTemplateExits'        => '群发记录不存在或已删除',
        'template_id.checkTemplateStatus'       => '只有未开始的群发才可以编辑',
        'task_name.require'                     => '任务名称不能为空',
        'task_name.checkEmpty'                  => '任务名称不能为空',
        'task_name.checkTaskNameRepeat'         => '已存在此任务名称',
        'range_option.require'                  => '请选择发送范围',
        'range_option.integer'                  => '发送范围必须是整数',
        'range_option.in'                       => '不存在的发送范围',
        'sender.requireIf'                      => '请选择添加人',
        'sender.checkMeanwhileEmpty'            => '添加人和标签不能同时为空',
        'tag.checkMeanwhileEmpty'               => '添加人和标签不能同时为空',
        'second_type.checkContentEmpty'         => '第1条和第2条不能同时为空',
        'second_type.require'                   => '请选择第2条类型',
        'second_type.in'                        => '不存在的第2条类型',
        'miniprogram_title.requireIf'           => '小程序卡片标题不能为空',
        'miniprogram_title.checkTitleLength'    => '小程序卡片标题最多64字节',
        'miniprogram_pic_media_id.requireIf'    => '小程序卡片封面图不能为空',
        'miniprogram_pic_url.requireIf'         => '小程序卡片封面图不能为空',
        'miniprogram_pic_create_time.requireIf' => '小程序卡片封面图上传时间不能为空',
        'miniprogram_appid.requireIf'           => '请选择小程序',
        'miniprogram_page.requireIf'            => '小程序page路径不能为空',
        'image_pic_url.requireIf'               => '图片链接不能为空',
        'link_title.requireIf'                  => '图文消息标题不能为空',
        'link_url.requireIf'                    => '图文消息链接不能为空',
        'is_plan.require'                       => '请选择发送计划',
        'is_plan.integer'                       => '发送计划为整数',
        'is_plan.in'                            => '不存在的发送计划选项',
        'plan_send_time.requireIf'              => '请填写发送时间',
    ];

    // 验证场景
    protected $scene = [
        'add'  => [
            'task_name',
            'range_option',
            'sender',
            'tag',
            'second_type',
            'miniprogram_title',
            'miniprogram_pic_media_id',
            'miniprogram_pic_url',
            'miniprogram_pic_create_time',
            'miniprogram_appid',
            'miniprogram_page',
            'image_pic_url',
            'link_title',
            'link_url',
            'is_plan',
            'plan_send_time'
        ],
        'edit'  => [
            'template_id',
            'task_name',
            'range_option',
            'sender',
            'tag',
            'second_type',
            'miniprogram_title',
            'miniprogram_pic_media_id',
            'miniprogram_pic_url',
            'miniprogram_pic_create_time',
            'miniprogram_appid',
            'miniprogram_page',
            'image_pic_url',
            'link_title',
            'link_url',
            'is_plan',
            'plan_send_time'
        ]
    ];
}
