<?php

namespace app\api\validate;

use app\api\util\ValidateTrait;
use think\Validate;

/**
 * "联系我"验证器
 *
 * Class ContactWayValidate
 * @package app\api\validate
 */
class ContactWayValidate extends Validate
{
    use ValidateTrait;

    // 验证规则
    protected $rule = [
        'way_id'     => 'require|integer|checkWayExits',
        'way_name'   => 'require|checkEmpty|checkWayNameRepeat',
        'channel_id' => 'require|integer|checkChannelExits',
        'user_id'    => 'require',
        'scene'      => 'require|in:1,2'
    ];

    // 错误消息
    protected $message = [
        'way_id.require'               => '路径ID不能为空',
        'way_id.integer'               => '路径ID类型错误',
        'way_id.checkWayExits'         => '此路径不存在或已删除',
        'way_name.require'             => '路径名称不能为空',
        'way_name.checkEmpty'          => '路径名称不能为空',
        'way_name.checkWayNameRepeat'  => '已存在此路径名称',
        'channel_id.require'           => '请选择渠道',
        'channel_id.integer'           => '渠道ID参数错误',
        'channel_id.checkChannelExits' => '此渠道不存在',
        'user_id.require'              => '请选择咨询助理',
        'scene.require'                => '请选择场景',
        'scene.in'                     => '错误的场景类型',
    ];

    // 验证场景
    protected $scene = [
        'select'   => ['scene'],
        'add'      => ['way_name', 'channel_id', 'user_id', 'scene'],
        'edit'     => ['way_id', 'way_name'],
        'show'     => ['way_id'],
        'del'      => ['way_id'],
        'download' => ['way_id']
    ];
}
