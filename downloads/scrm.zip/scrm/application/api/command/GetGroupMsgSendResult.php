<?php

namespace app\api\command;

use app\api\dao\http\message\GroupMsgHttpDao;
use app\api\dao\mysql\message\GroupMsgIdMapDao;
use app\api\dao\mysql\message\GroupMsgReceiveMapDao;
use app\api\dao\mysql\message\GroupMsgTemplatesDao;
use app\common\model\groupMsg\GroupMsgIdMap;
use app\common\model\groupMsg\GroupMsgTemplates;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每隔1分钟
// */1 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think groupMsgSendResult

/**
 * Class GetGroupMsgSendResult
 * @package app\api\command
 */
class GetGroupMsgSendResult extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('groupMsgSendResult')->setDescription('获取企业群发成员执行结果');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        /*
         * 先使用"获取群发成员发送任务列表"接口获取状态，status为2的时候再使用"获取企业群发成员执行结果"，为0的话只一直请求"获取群发成员发送任务列表"就可以了，减少更改大表。
         * 1分钟跑一次，但接收人数太多，还有未发送的时候状态就被更改了，导致有些数据为0，不会再被更改为1了。
         */

        $getSendResult = function ($results) {
            if (empty($results)) {
                return false;
            }

            $groupMsgHttpDao = new GroupMsgHttpDao();

            foreach ($results as $result) {
                $taskList = $groupMsgHttpDao->getGroupMsgTask($result['msg_id']);

                if (
                    !isset($taskList['task_list'][0]['status'])
                    || $taskList['task_list'][0]['status'] != 2
                ) {
                    continue;
                }

                // 群成员发送结果列表
                $sendList = [];

                static $cursor = '';
                // 每次最多取1000个，需要循环取完
                while (true) {
                    $sendResult = $groupMsgHttpDao->getGroupMsgSendResult(
                        $result['msg_id'],
                        $result['sender_user_id'],
                        1000,
                        $cursor
                    );


                    $sendList[] = $sendResult['send_list'];
                    $nextCursor = $sendResult['next_cursor'];

                    if ($nextCursor) {
                        $cursor = $nextCursor;
                    } else {
                        break;
                    }
                }
                $sendList = array_filter($sendList);

                $externalUserIdArr0 = $externalUserIdArr1 = $externalUserIdArr2 = $externalUserIdArr3 = [];
                // 循环结果列表，把不同状态的客户归为一类
                foreach ($sendList as $sendInfo) { // 每段1000
                    foreach ($sendInfo as $send) {
                        switch ($send['status']) {
                            case 0:
                                $externalUserIdArr0[] = $send['external_userid'];
                                break;

                            case 1:
                                $externalUserIdArr1[] = $send['external_userid'];

                                // $sendTimeArr[$send['external_userid']] = $send['send_time']; // 发送时间
                                break;

                            case 2:
                                $externalUserIdArr2[] = $send['external_userid'];
                                break;

                            case 3:
                                $externalUserIdArr3[] = $send['external_userid'];
                                break;
                        }
                    }
                }


                $updateRes0 = $updateRes1 = $updateRes2 = $updateRes3 = false;

                // 更新receive_map表
                $updateReceiveMapClosure = function ($sendData, $externalUserIdArr, $status) {
                    /*if ($sendTimeArr) {
                        $updateData = [
                            'status' => $status,
                            'send_time' => $sendTimeArr['']
                        ];
                    }*/

                    if (
                        GroupMsgReceiveMapDao::updateData(
                            [
                                'status' => $status,
                            ],
                            [
                                'template_id'     => $sendData['template_id'],
                                'user_id'         => $sendData['sender_user_id'],
                                'external_userid' => ['in', $externalUserIdArr]
                            ]
                        ) === false
                    ) {
                        send_msg_to_wecom('更新ReceiverMap表失败' . $status);
                        return false;
                    } else {
                        return true;
                    }
                };

                // 未发送
                if ($externalUserIdArr0) {
                    $updateRes0 = $updateReceiveMapClosure($result, $externalUserIdArr0, 0);
                }
                // 已发送
                if ($externalUserIdArr1) {
                    $updateRes1 = $updateReceiveMapClosure($result, $externalUserIdArr1, 1);
                }
                // 因客户不是好友导致发送失败
                if ($externalUserIdArr2) {
                    $updateRes1 = $updateReceiveMapClosure($result, $externalUserIdArr2, 2);
                }
                // 因客户已经收到其他群发消息导致发送失败
                if ($externalUserIdArr3) {
                    $updateRes3 = $updateReceiveMapClosure($result, $externalUserIdArr3, 3);
                }

                // 1,2,3只要有1个true，说明这个消息已经被执行获取结果了
                if (
                    $updateRes0 == false // 只要还有未发送的，就不要变成结束
                    && ($updateRes1 || $updateRes2 || $updateRes3)
                ) {
                    $updateSenderMapRes = GroupMsgIdMapDao::updateData(
                        [
                            'is_get_result' => GroupMsgIdMap::IS_GET_RESULT,
                        ],
                        [
                            'msg_id' => $result['msg_id']
                        ]
                    );

                    if ($updateSenderMapRes === false) {
                        send_msg_to_wecom('更新发送者映射表失败');
                    }
                }
                // 1个群发记录可能有多个客服待发送，所有客服都发送了，主表才结束
                // 最后一个客服执行的时候，前面的都结束了
                $allSend = GroupMsgIdMapDao::getAllList(
                    [
                        'id'
                    ],
                    [
                        'template_id'   => $result['template_id'],
                        'is_get_result' => GroupMsgIdMap::NOT_GET_RESULT
                    ]
                );

                if (!$allSend) { // 这个群发记录所有的msgId都执行了
                    // 主表变成已结束
                    if (
                        GroupMsgTemplatesDao::updateData(
                            [
                                'status' => GroupMsgTemplates::STATUS_IS_END
                            ],
                            [
                                'id' => $result['template_id']
                            ]
                        ) === false
                    ) {
                        send_msg_to_wecom('获取群发记录-' . $result['template_id'] . '-执行结果定时任务-更新主表失败');
                    }
                }
            }
            return true;
        };

        GroupMsgIdMapDao::handleDataByChunk(
            [
                'id',
                'template_id',
                'sender_user_id',
                'msg_id'
            ],
            [
                'is_get_result' => GroupMsgIdMap::NOT_GET_RESULT
            ],
            10,
            $getSendResult
        );
    }
}
