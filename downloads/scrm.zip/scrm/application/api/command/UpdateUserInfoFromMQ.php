<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\log\MqLogsDao;
use app\common\model\ContactFollowUser;
use app\common\model\ContactTags;
use app\common\model\ExternalContact;
use app\common\model\MqLogs;
use Exception;
use MQ\Exception\MessageNotExistException;
use MQ\MQClient;
use Opis\Closure\SerializableClosure;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;
use think\Queue;

// crontab
// */1 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think updateUserInfoFromMQ >> updateUserInfoFromMQ.log

/**
 * 从ERP的MQ更新用户等级
 *
 * Class UpdateUserInfoFromMQ
 * @package app\api\command
 */
class UpdateUserInfoFromMQ extends Command
{
    protected function configure()
    {
        $this->setName('updateUserInfoFromMQ')->setDescription('从MQ获取并更新用户信息');
    }

    /**
     * 处理mq里的消息
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        try {
            $client = new MQClient(
                MQ_END_POINT,
                MQ_ACCESS_ID,
                MQ_ACCESS_KEY
            );

            $consumer = $client->getConsumer(
                'MQ_INST_1791318055539215_Bcm7IAYo',
                'normal_msg',
                'GID_erp_info_modify',
                'user_level'
            );

            $messages = $consumer->consumeMessage(16, 0);
        } catch (MessageNotExistException $e) {
            exit(date('Y-m-d H:i:s') . '-no new message\n');
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
            exit($e->getMessage());
        }

        if (empty($messages)) {
            exit('没有需要消费的队列消息');
        }

        // 重新组织标签组数组
        $getNewTagArrClosure = function ($groupId, $otherField) {
            $fields = ['tag_id'];
            array_push($fields, $otherField);
            $tagArr = ContactTagsDao::getAllList($fields, [
                'group_id'       => $groupId,
                'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
            ]);

            $newTagArr = [];

            foreach ($tagArr as $tag) {
                $newTagArr[$tag[$otherField]] = $tag['tag_id'];
            }
            return $newTagArr;
        };

        $contactHttpDao = new ContactHttpDao();

        [
            $levelTagArr,
            $newConsumeTagArr
        ] =
        [
            $getNewTagArrClosure(ContactTags::GROUP_ID_MAP[ContactTags::MEMBER_LEVEL], 'tag_order'),
            $getNewTagArrClosure(ContactTags::GROUP_ID_MAP[ContactTags::NEW_CONTRACT_AMOUNT], 'tag_name')
        ];

        $receiptHandles = [];

        foreach ($messages as $message) {
            if ($message->getMessageBody()) {
                $messageData = json_decode($message->getMessageBody(), true);
                $messageId = $message->messageId;

                if ($messageData['mobile']) {
                    // 可能有两个手机号
                    $mobileArr = explode(',', $messageData['mobile']);

                    foreach ($mobileArr as $mobile) {
                        $mqLogId = MqLogsDao::addData([
                            'erp_msg_id'          => $messageData['id'] ?? 0,
                            'mobile'              => $mobile,
                            'type'                => $messageData['type'],
                            'user_level'          => $messageData['user_level'],
                            'user_level_name'     => $messageData['user_level_name'],
                            'contract_amount_tag' => $messageData['contract_amount_tag'],
                            'message_id'          => $messageId
                        ], true);

                        $consumeInfo = $contactHttpDao->getConsumeSegment($mobile);

                        $utype = $consumeInfo['utype'] ?? 0;

                        $userCenterData = $contactHttpDao->getUserCenterByMobile($mobile);

                        if ($userCenterData['unionId']) {
                            // 这个客户目前的客服
                            $followUserArr = Db::name('contact_follow_user')
                                ->alias('follow')
                                ->field([
                                    'contact.external_userid',
                                    'follow.userid'
                                ])
                                ->join(
                                    'scrm_external_contact contact',
                                    'follow.external_userid = contact.external_userid',
                                    'LEFT'
                                )
                                ->where([
                                    'unionid' => $userCenterData['unionId'],
                                    'status'  => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT] // 不是被客服删除
                                ])
                                ->select();

                            if ($followUserArr) {
                                $fn = function ($isTagSuccess) use ($mqLogId) {
                                    MqLogsDao::updateData(
                                        [
                                            'is_contact'     => MqLogs::IS_CONTACT,
                                            'is_tag_success' => $isTagSuccess,
                                        ],
                                        [
                                            'id' => $mqLogId
                                        ]
                                    );
                                };

                                $wrapper = new SerializableClosure($fn);

                                $removeTags = array_merge(
                                    array_values($levelTagArr),
                                    array_values($newConsumeTagArr)
                                );

                                $addLevelTag = $levelTagArr[$messageData['user_level']] ?? '';
                                if (!isset($newConsumeTagArr[$utype])) {
                                    $addNewConsumeTag = '';
                                    send_msg_to_wecom('累计消费标签有更改！');
                                } else {
                                    $addNewConsumeTag = $newConsumeTagArr[$utype];
                                }

                                $addTags = array_filter([$addLevelTag, $addNewConsumeTag]);

                                // 更改等级
                                $contactUpdateRes = ContactDao::updateData(
                                    [
                                        'user_level_id'         => $messageData['user_level'] ?? 0,
                                        'is_consume'            => ExternalContact::IS_CONSUME,
                                        'actual_consume_amount' => $userCenterData['consume_amount']
                                    ],
                                    [
                                        'unionid' => $userCenterData['unionId']
                                    ]
                                );

                                if ($contactUpdateRes === false) {
                                    send_msg_to_wecom(
                                        sprintf(
                                            '%s-修改等级为-%s-失败',
                                            $userCenterData['unionId'],
                                            $messageData['user_level']
                                        )
                                    );
                                }

                                // 一个客户的所有客服的标签都要变
                                foreach ($followUserArr as $followValue) {
                                    $carryData = [
                                        'add_tags'        => $addTags,
                                        'remove_tags'     => $removeTags,
                                        'userid'          => $followValue['userid'],
                                        'external_userid' => $followValue['external_userid'],
                                        'func'            => serialize($wrapper)
                                    ];

                                    try {
                                        // 推送到打标签队列
                                        Queue::push(
                                            ContactTags::HANDLE_CONTACT_TAG_HANDLER,
                                            $carryData,
                                            ContactTags::HANDLE_CONTACT_TAG_QUEUE
                                        );
                                    } catch (Exception $e) {
                                        send_msg_to_wecom('进入处理标签队列出错：' . $e->getMessage());
                                    }
                                }
                            }
                        }
                    }
                }

                $receiptHandles[] = $message->getReceiptHandle();
            }

            $message->getNextConsumeTime();
        }

        // 确认队列消息已消费
        if ($receiptHandles) {
            $consumer->ackMessage($receiptHandles);
        }
    }
}
