<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\service\user\impl\UserServiceImpl;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;
use think\Log;

/**
 * 打"首单客户"标签
 *
 * Class MarkFirstOrderTag
 * @package app\api\command
 */
class MarkFirstOrderTag extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('markFirstOrderTag')->setDescription('打"首单客户"标签');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $gapTime = 3600 * 48;

        $orderInfo = (array)Db::table('tp_order_log')
            ->field([
                'union_id',
                'create_at'
            ])
            ->select();

        $newOrderInfo = [];

        foreach ($orderInfo as $order) {
            $newOrderInfo[$order['union_id']] = $order['create_at'];
        }

        $allUnionId = array_column($orderInfo, 'union_id');

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $allFriend = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'external_contact b',
                'a.external_userid = b.external_userid',
                'left'
            )
            ->field([
                'userid',
                'unionid',
                'a.external_userid',
                'createtime'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                // 'status'  => ContactFollowUser::NORMAL,
                'unionid' => ['in', $allUnionId]
            ])
            ->select();

        $contactTagHttpDao = new ContactTagHttpDao();
        $insertTagData = [];

        foreach ($allFriend as $friend) {
            if ($friend['createtime'] - $newOrderInfo[$friend['unionid']] < $gapTime) {
                try {
                    $addTagRes = $contactTagHttpDao->markTag(
                        $friend['userid'],
                        $friend['external_userid'],
                        ['et5b2CBwAAU4htvjM_D0GIMP9eFu_DSA']
                    );

                    if ($addTagRes) {
                        // 要记录的数据
                        $insertTagData[] = [
                            'tag_id'          => 'et5b2CBwAAU4htvjM_D0GIMP9eFu_DSA',
                            'external_userid' => $friend['external_userid'],
                            'userid'          => $friend['userid']
                        ];
                    }
                } catch (Exception $e) {
                    Log::error($e->getMessage());
                }
            }
        }

        ContactTagMapDao::addBatchData($insertTagData);
    }
}
