<?php

namespace app\api\command;

use app\api\dao\mysql\moment\MomentSenderMapDao;
use app\api\dao\mysql\moment\MomentTagMapDao;
use app\api\dao\mysql\moment\MomentTaskDao;
use app\api\service\moment\impl\MomentServiceImpl;
use app\common\model\moment\MomentTask;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每隔1分钟
// */1 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendMoment

/**
 * Class SendMoment
 * @package app\api\command
 */
class SendMoment extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('sendGroupMsg')->setDescription('定时企业群发');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output): bool
    {
        $nowTime = Carbon::now()->toDateTimeString();

        $checkPlan = function ($results) use ($nowTime) {
            if (!$results) {
                return false;
            }

            $momentTaskIdArr = array_column($results, 'id');

            // 要发送的客服-begin
            $senderUserArr = MomentSenderMapDao::getAllList(
                [
                    'moment_task_id',
                    'sender_user_id'
                ],
                [
                    'moment_task_id' => ['in', $momentTaskIdArr]
                ]
            );

            $newSenderUserArr = [];

            foreach ($senderUserArr as $sender) {
                $newSenderUserArr[$sender['moment_task_id']][] = $sender['sender_user_id'];
            }
            // 要发送的客服-end

            // 要发送的标签-begin
            $tagArr = MomentTagMapDao::getAllList(
                [
                    'moment_task_id',
                    'tag_id'
                ],
                [
                    'moment_task_id' => ['in', $momentTaskIdArr]
                ]
            );

            $newTagArr = [];

            foreach ($tagArr as $tag) {
                $newTagArr[$tag['moment_task_id']][] = $tag['tag_id'];
            }
            // 要发送的标签-end

            $momentServiceImpl = new MomentServiceImpl();

            foreach ($results as $template) {
                if ($template['send_time'] <= $nowTime) { // 到发送时间了
                }
            }
            return true;
        };

        MomentTaskDao::handleDataByChunk([
            'id',
            'receiver_range',
            'content_text',
            'attachment_type',
            'attachments',
            'send_time',
        ], [
            'is_plan'    => MomentTask::IS_PLAN,
            'is_handle'  => MomentTask::NOT_HANDLE,
            'status'     => MomentTask::STATUS_NOT_BEGIN,
            'is_deleted' => MomentTask::NOT_DELETED
        ], 100, $checkPlan);

        return true;
    }
}
