<?php

namespace app\api\command;

use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每天9点
// 0 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentDataExcel
/**
 * 朋友圈加粉周统计订单表格
 *
 * Class MomentDataExcel
 * @package app\api\command
 */
class MomentDataExcel extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('momentDataExcel')
            ->setDescription('朋友圈加粉周统计订单表格');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $toUser = [
            'chebin',
            'wangderun',
            'xulan',
            'liying',
            'lvjunyan',
            'zhongyongping',
            'zhujing',
            'feiyue',
            'zhaowei',
            'zhoujiaqi'
        ];

        $webHookHttpDao = new WebHookHttpDao();

        $excelData = $webHookHttpDao->getMomentExcelConsumeData();

        $excelTitle = '朋友圈推广用户订单' . date('Y-m-d');

        downloadExcelToLocal($excelTitle, function ($spreadsheet) use ($excelData) {
            $cellValueMap = [
                'A1' => '客户id',
                'B1' => 'unionID',
                'C1' => '昵称',
                'D1' => '首次来源渠道',
                'E1' => '加粉时间',
                'F1' => '下单时间',
                'G1' => '订单号',
                'H1' => '订单金额',
                'I1' => '商品类型',
                'J1' => '商品名称',
                'K1' => '订单状态',
                'L1' => '是否首单',
                'M1' => '转化客户类型',
                'N1' => '客户等级',
                'O1' => '首单转化渠道',
                'P1' => '首单时间'
            ];

            $cellValueFunc = function ($cellValueMap, $index) use ($spreadsheet) {
                foreach ($cellValueMap as $cellKey => $cellValue) {
                    $spreadsheet->setActiveSheetIndex($index)->setCellValue($cellKey, $cellValue);
                }
            };

            $cellValueFunc($cellValueMap, 0);

            // 重命名worksheet
            $spreadsheet->setActiveSheetIndex(0)->setTitle('订单');

            $cellFormatDateFunc = function ($cellValue, $excelKey) use ($spreadsheet) {
                $spreadsheet->getActiveSheet(0)->getStyle($cellValue . $excelKey)
                    ->getNumberFormat()
                    ->setFormatCode('yyyy/mm/dd h:mm:ss');
            };

            if (!$excelData) {
                send_msg_to_wecom('朋友圈推广用户订单为空：' . date('Y-m-d H:i:s'));
            }

            foreach ($excelData as $contactKey => $value) {
                $excelKey = $contactKey + 2;

                $cellFormatDateFunc('E', $excelKey);
                $cellFormatDateFunc('F', $excelKey);

                // sheet0
                $sheet0ValueMap = [
                    'A' . $excelKey => $value['userId'],
                    'B' . $excelKey => $value['unionId'],
                    'C' . $excelKey => $value['name'],
                    'D' . $excelKey => $value['palyFrom'],
                    'E' . $excelKey => $value['joinTime'],
                    'F' . $excelKey => $value['createAt'],
                    'G' . $excelKey => $value['orderSn'],
                    'H' . $excelKey => $value['orderAchievement'],
                    'I' . $excelKey => $value['goodsType'],
                    'J' . $excelKey => $value['goodsName'],
                    'K' . $excelKey => $value['orderType'],
                    'L' . $excelKey => $value['first'],
                    'M' . $excelKey => $value['type'] ?? '-',
                    'N' . $excelKey => $value['userLevelName'],
                    'O' . $excelKey => $value['convert'],
                    'P' . $excelKey => $value['firstOrderTime']
                ];

                $cellValueFunc($sheet0ValueMap, 0);
            }

            $columnFormat = [
                'B' => 30,
                'C' => 25,
                'E' => 18,
                'F' => 18,
                'G' => 18,
                'J' => 30
            ];

            $columnFormatFunc = function ($columnFormat) use ($spreadsheet) {
                foreach ($columnFormat as $columnKey => $columnWidth) {
                    $spreadsheet->getActiveSheet()
                        ->getColumnDimension($columnKey)
                        ->setWidth($columnWidth);
                }
            };

            $columnFormatFunc($columnFormat);
        });

        $mediaHttpDao = new MediaHttpDao();
        $realPath = './public/downloads/' . $excelTitle . '.xlsx';
        $uploadRes = $mediaHttpDao->uploadMedia(MediaHttpDao::FILE, $realPath, $excelTitle . '.xlsx');
        @unlink($realPath);

        $msgHttpDao = new MessageHttpDao();
        $msgHttpDao->sendMessage(MediaHttpDao::FILE, ['media_id' => $uploadRes['media_id']], $toUser);
    }
}
