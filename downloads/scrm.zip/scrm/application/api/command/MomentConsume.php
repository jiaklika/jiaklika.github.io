<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\common\model\ContactFollowUser;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// crontab 每天9点半
// 30 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentConsume
/**
 * 朋友圈未当日消费标签
 *
 * Class MomentConsume
 * @package app\api\command
 */
class MomentConsume extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('momentConsume')
            ->setDescription('朋友圈未当日消费标签');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        // 昨天0点
        $yesterdayZero = strtotime(date('Y-m-d', strtotime('-1 days')));
        // 今天0点
        $todayZero = strtotime(date('Y-m-d 00:00:00'));

        // 昨天企微朋友圈广告加来的人，还是好友的。
        $contactInfo = (array)Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid',
                'b.unionid'
            ])
            ->where([
                'state'  => ContactFollowUser::MOMENT_TRANSFER_STATE,
                'status' => ContactFollowUser::NORMAL,
                'createtime' => ['between', [$yesterdayZero, $todayZero]]
            ])
            ->select();

        if (!$contactInfo) {
            exit();
        }
        $contactTagHttpDao = new ContactTagHttpDao();

        // 今天日期
        $todayDate = sprintf('%s月%s日', date('n'), date('d'));

        $groupId = 'et5b2CBwAASzK6bLOrhWm6UwNr1wTm3w';

        try {
            $momentConsumeTagArr = $contactTagHttpDao->addContactTag([
                'name' => $todayDate . '首次群发'
            ], $groupId);

            $tagId = $momentConsumeTagArr['tag'][0]['id'];

            ContactTagsDao::addData([
                'group_id'          => $groupId,
                'group_name'        => '朋友圈广告触达',
                'group_create_time' => $momentConsumeTagArr['create_time'],
                'tag_id'            => $tagId,
                'tag_name'          => $momentConsumeTagArr['tag'][0]['name'],
                'tag_create_time'   => $momentConsumeTagArr['tag'][0]['create_time'],
            ]);
        } catch (Exception $e) {
            send_msg_to_wecom('创建标签失败！' . $e->getMessage());
            exit();
        }

        $addTags = [$tagId];

        $contactHttpDao = new ContactHttpDao();

        foreach ($contactInfo as $contact) {
            // 在宝姐珠宝和ERP均无消费记录就打标签
            $userCenterData = $contactHttpDao->getUserCenter($contact['unionid']);
            if ($userCenterData['contractAmount'] == 0) {
                if (!$contactHttpDao->getIsConsume($contact['unionid'])) {
                    try {
                        if (
                            $contactTagHttpDao->markTag(
                                $contact['userid'],
                                $contact['external_userid'],
                                $addTags // 打标签
                            )
                        ) {
                            ContactTagMapDao::addData([
                                'external_userid' => $contact['external_userid'],
                                'tag_id'          => $addTags[0],
                                'userid'          => $contact['userid']
                            ]);
                        }
                    } catch (Exception $e) {
                        send_msg_to_wecom('打标签失败！' . $e->getMessage());
                    }
                }
            }
        }
    }
}
