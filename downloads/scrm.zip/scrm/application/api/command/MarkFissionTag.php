<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\http\contactFission\ContactFissionHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\common\model\ContactGroupMembers;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// crontab 每天0点1分
// 1 0 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData

/**
 * 打"企微裂变"标签
 *
 * Class MarkFissionTag
 * @package app\api\command
 */
class MarkFissionTag extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('markFissionTag')->setDescription('打"企微裂变"标签');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $groupId = 'et5b2CBwAA5B9Zp_8TAx293PECtrgJog';
        // 昨天日期
        $yesterdayDate = Carbon::now()->subDay()->toDateString();

        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->field([
                'contact.unionid',
                'contact.gender',
                'follow.external_userid',
                'follow.userid'
            ])
            ->whereRaw('length(state) > 20')
            ->where([
                'create_date' => $yesterdayDate
            ])
            ->select();

        if ($allContact) {
            $contactFissionHttpDao = new ContactFissionHttpDao();
            $contactTagHttpDao = new ContactTagHttpDao();
            // 创建标签
            $consumeNotJoinGroupTagArr = $contactTagHttpDao->addContactTag([
                'name' => $yesterdayDate . '-有转化无进群'
            ], $groupId);


            $consumeNotJoinGroupTagId = $consumeNotJoinGroupTagArr['tag'][0]['id'];

            ContactTagsDao::addData([
                'group_id'          => $groupId,
                'group_name'        => '企微裂变',
                'group_create_time' => $consumeNotJoinGroupTagArr['create_time'],
                'tag_id'            => $consumeNotJoinGroupTagId,
                'tag_name'          => $consumeNotJoinGroupTagArr['tag'][0]['name'],
                'tag_create_time'   => $consumeNotJoinGroupTagArr['tag'][0]['create_time'],
            ]);

            $notConsumeTagArr = $contactTagHttpDao->addContactTag([
                'name' => $yesterdayDate . '-无转化'
            ], $groupId);

            $notConsumeTagId = $notConsumeTagArr['tag'][0]['id'];

            ContactTagsDao::addData([
                'group_id'          => $groupId,
                'group_name'        => '企微裂变',
                'group_create_time' => $notConsumeTagArr['create_time'],
                'tag_id'            => $notConsumeTagId,
                'tag_name'          => $notConsumeTagArr['tag'][0]['name'],
                'tag_create_time'   => $notConsumeTagArr['tag'][0]['create_time'],
            ]);

            foreach ($allContact as $value) {
                if ($value['gender'] == 2) {
                    // 有转化
                    if (!$contactFissionHttpDao->isNewContact($value['unionid'])) {
                        if (ContactGroupMembersDao::getDetail(['id'], ['unionid' => $value['unionid']])) {
                            continue;
                        } else {
                            if (
                                $contactTagHttpDao->markTag(
                                    $value['userid'],
                                    $value['external_userid'],
                                    [$consumeNotJoinGroupTagId] // 打标签
                                )
                            ) {
                                ContactTagMapDao::addData([
                                    'external_userid' => $value['external_userid'],
                                    'tag_id'          => $consumeNotJoinGroupTagId,
                                    'userid'          => $value['userid']
                                ]);
                            }
                        }
                    } else { // 无转化
                        if (
                            $contactTagHttpDao->markTag(
                                $value['userid'],
                                $value['external_userid'],
                                [$notConsumeTagId] // 打标签
                            )
                        ) {
                            ContactTagMapDao::addData([
                                'external_userid' => $value['external_userid'],
                                'tag_id'          => $notConsumeTagId,
                                'userid'          => $value['userid']
                            ]);
                        }
                    }
                }
            }
        }
    }
}
