<?php

namespace app\api\command;

use app\api\dao\mysql\data\StatisticalDataDao;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\StatisticalData;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

/**
 * 1 0 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think writeStatisticsData >> writeStatisticsData.log
 *
 * 每天0点1分执行
 *
 * Class WriteStatisticsData
 * @package app\api\command
 */
class WriteStatisticsData extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('writeStatisticsData')->setDescription('保存统计数据');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output): bool
    {
        ini_set('memory_limit', '520M');
        $userServiceImpl = new UserServiceImpl();
        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 当天0点
        $todayZero = Carbon::now()->startOfDay()->getTimestamp();

        /**
         * 计算统计数据
         *
         * @param int $startTime 统计开始点
         * @return array
         * @throws Exception
         */
        $statisticsDataClosure = function (int $startTime) use ($todayZero, $zhaoweiAccounts, $feiyueAccounts) {

            // 新添加（A） 在对应统计时段内，不同个人号首次添加的去重总人数
            $firstAddCountClosure = function (
                int $beginTime,
                int $endTime,
                array $extraWhere = []
            ) {
                $originalWhere = [
                    'createtime' => ['between', [$beginTime, $endTime]]
                ];

                $where = $extraWhere ? array_merge($originalWhere, $extraWhere) : $originalWhere;

                // 全部添加的
                $allAdd = (array)Db::name('contact_follow_user')
                    ->field([
                        'external_userid'
                    ])
                    ->where($where)
                    ->group('external_userid')
                    ->select();

                $allContactArr = array_column($allAdd, 'external_userid');

                $notFirstOriginalWhere = [
                    'external_userid' => ['in', $allContactArr],
                    'createtime'      => ['<', $beginTime]
                ];

                $notFirstWhere = $extraWhere
                    ? array_merge($notFirstOriginalWhere, $extraWhere)
                    : $notFirstOriginalWhere;

                // 从中去除不是第一次加的
                $notFirstAdd = (array)Db::name('contact_follow_user')
                    ->field([
                        'external_userid'
                    ])
                    ->where($notFirstWhere)
                    ->group('external_userid')
                    ->select();

                $notFirstAddId = array_column($notFirstAdd, 'external_userid');

                return array_diff($allContactArr, $notFirstAddId);
            };
            $companyFirstAddArr = $firstAddCountClosure($startTime, $todayZero);
            $feiyueFirstAddArr = $firstAddCountClosure($startTime, $todayZero, ['userid' => ['in', $feiyueAccounts]]);
            $zhaoweiFirstAddArr = $firstAddCountClosure($startTime, $todayZero, [
                'userid' => ['in', $zhaoweiAccounts]
            ]);

            $insertData['company_first_add_count'] = count($companyFirstAddArr);
            $insertData['feiyue_first_add_count'] = count($feiyueFirstAddArr);
            $insertData['zhaowei_first_add_count'] = count($zhaoweiFirstAddArr);

            // 新添加（A）的那部分人中，在时间段内进群的人 begin
            $joinGroupCountClosure = function (
                int $beginJoinTime,
                int $endJoinTime,
                array $firstAddContactArr,
                array $ownerArr = []
            ) {
                $originalWhere = [
                    'a.userid'     => ['in', $firstAddContactArr],
                    'a.join_time'  => [
                        'between',
                        [
                            $beginJoinTime,
                            $endJoinTime
                        ]
                    ],
                    'b.is_deleted' => ContactGroups::NOT_DELETED
                ];

                $where = $ownerArr ? array_merge($originalWhere, [
                    'b.owner' => ['in', $ownerArr]
                ]) : $originalWhere;

                return Db::name('contact_group_members')
                    ->alias('a')
                    ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                    ->field(['a.userid'])
                    ->where($where)
                    ->count('distinct userid');
            };
            $insertData['company_first_add_join_group_count'] = $joinGroupCountClosure(
                $startTime,
                $todayZero,
                $companyFirstAddArr
            );

            $insertData['feiyue_first_add_join_group_count'] = $joinGroupCountClosure(
                $startTime,
                $todayZero,
                $feiyueFirstAddArr,
                $feiyueAccounts
            );

            $insertData['zhaowei_first_add_join_group_count'] = $joinGroupCountClosure(
                $startTime,
                $todayZero,
                $zhaoweiFirstAddArr,
                $zhaoweiAccounts
            );
            // end

            // 当前号总人数 对应的企微号、泛流量号、电商号名下所有互为好友关系的去重总人数
            $totalFriendCountClosure = function (array $where = []) use ($todayZero) {
                $validContactArr =  (array)Db::name('contact_follow_user')
                    ->field([
                        'external_userid'
                    ])
                    ->where(array_merge([
                        'createtime' => ['<', $todayZero],
                        'status'     => ContactFollowUser::NORMAL
                    ], $where))
                    ->group('external_userid')
                    ->select();

                return array_column($validContactArr, 'external_userid');
            };

            $companyContactsArr = $totalFriendCountClosure();
            $feiyueContactsArr = $totalFriendCountClosure(['userid' => ['in', $feiyueAccounts]]);
            $zhaoweiContactsArr = $totalFriendCountClosure(['userid' => ['in', $zhaoweiAccounts]]);

            $insertData['company_contacts_count'] = count($companyContactsArr);
            $insertData['feiyue_contacts_count']  = count($feiyueContactsArr);
            $insertData['zhaowei_contacts_count'] = count($zhaoweiContactsArr);

            // 在群人数 对应的泛流量号、电商号名下所有互为好友关系的去重总人数在对应名下群内的人数
            $groupMembersCountClosure = function (array $contactArr, array $ownerArr) {
                return Db::name('contact_group_members')
                    ->alias('a')
                    ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                    ->field(['a.userid'])
                    ->where([
                        'a.userid'     => ['in', $contactArr],
                        'b.owner'      => ['in', $ownerArr],
                        'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                        'b.is_deleted' => ContactGroups::NOT_DELETED
                    ])
                    ->count('distinct userid');
            };
            $insertData['feiyue_friend_join_group_count'] = $groupMembersCountClosure(
                $feiyueContactsArr,
                $feiyueAccounts
            );
            $insertData['zhaowei_friend_join_group_count'] = $groupMembersCountClosure(
                $zhaoweiContactsArr,
                $zhaoweiAccounts
            );

            return $insertData;
        };

        // 前一天0点
        $subDayZero = Carbon::now()->subDay()->startOfDay()->getTimestamp();
        $yesterdayInsertData = $statisticsDataClosure($subDayZero);

        $yesterdayInsertData['time_range'] = StatisticalData::DAY;
        $yesterdayInsertData['add_time'] = $subDayZero;

        // 总添加
        $totalAddCountClosure = function (array $where = []) use ($todayZero) {
            return Db::name('contact_follow_user')
                ->field([
                    'external_userid'
                ])
                ->where(array_merge([
                    'createtime' => ['<', $todayZero]
                ], $where))
                ->count('distinct external_userid');
        };

        $companyHistoryContactsArr = $totalAddCountClosure();
        $feiyueHistoryContactsArr  = $totalAddCountClosure(
            ['userid' => ['in', $feiyueAccounts]]
        );
        $zhaoweiHistoryContactsArr = $totalAddCountClosure(
            ['userid' => ['in', $zhaoweiAccounts]]
        );

        // 当前群成员user_id数组
        $totalGroupMembersArrClosure = function (array $ownerArr = []) use ($todayZero) {
            $originalWhere = [
                'a.join_time'  => ['<', $todayZero],
                'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'b.is_deleted' => ContactGroups::NOT_DELETED,
                'a.type'       => ContactGroupMembers::EXTERNAL_USER // 外部联系人
            ];

            $where = $ownerArr ? array_merge($originalWhere, [
                'b.owner' => ['in', $ownerArr]
            ]) : $originalWhere;

            return (array)Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field(['a.userid'])
                ->where($where)
                ->group('userid')
                ->select();
        };

        // 电商号群成员
        $zhaoweiGroupUserIdArr = array_column($totalGroupMembersArrClosure($zhaoweiAccounts), 'userid');

        // 电商号在群但不在其号内人数
        $zhaoweiFriendCount = Db::name('contact_follow_user')
            ->field('external_userid')
            ->where([
                'external_userid' => ['in', $zhaoweiGroupUserIdArr],
                'status'          => ContactFollowUser::NORMAL,
                'userid'          => ['in', $zhaoweiAccounts]
            ])
            ->count('distinct external_userid');

        $companyGroupMembersCount = count($totalGroupMembersArrClosure());
        $feiyueGroupMembersCount = count($totalGroupMembersArrClosure($feiyueAccounts));
        $zhaoweiGroupMembersCount = count($zhaoweiGroupUserIdArr);

        $zhaoweiGroupNotFriendCount = $zhaoweiGroupMembersCount - $zhaoweiFriendCount;

        $handleSameDataClosure = function (&$insertData) use (
            $companyHistoryContactsArr,
            $feiyueHistoryContactsArr,
            $zhaoweiHistoryContactsArr,
            $companyGroupMembersCount,
            $feiyueGroupMembersCount,
            $zhaoweiGroupMembersCount,
            $zhaoweiGroupNotFriendCount
        ) {
            $insertData['company_history_contacts_count'] = $companyHistoryContactsArr;
            $insertData['feiyue_history_contacts_count']  = $feiyueHistoryContactsArr;
            $insertData['zhaowei_history_contacts_count'] = $zhaoweiHistoryContactsArr;
            $insertData['company_group_members_count']    = $companyGroupMembersCount;
            $insertData['feiyue_group_members_count']     = $feiyueGroupMembersCount;
            $insertData['zhaowei_group_members_count']    = $zhaoweiGroupMembersCount;
            $insertData['zhaowei_group_not_friend_count'] = $zhaoweiGroupNotFriendCount;
        };

        $handleSameDataClosure($yesterdayInsertData);

        $insertBatchData[] = $yesterdayInsertData;

        // 每周一
        if (Carbon::now()->isMonday()) {
            // 上周一0点
            $subWeekMondayZero = Carbon::now()->subWeek()->startOfWeek()->getTimestamp();
            $subWeekInsertData = $statisticsDataClosure($subWeekMondayZero);
            $subWeekInsertData['time_range'] = StatisticalData::WEEK;
            $subWeekInsertData['add_time'] = $subWeekMondayZero;

            $handleSameDataClosure($subWeekInsertData);

            $insertBatchData[] = $subWeekInsertData;
        }

        // 每月第一天
        $firstMonthDay = Carbon::now()->startOfMonth()->toDateString();
        $nowDay = Carbon::now()->toDateString();

        if ($firstMonthDay == $nowDay) {
            // 上个月第一天0点
            $subMonthFirstDayZero = Carbon::now()->subMonth()->startOfMonth()->getTimestamp();
            $subMonthInsertData = $statisticsDataClosure($subMonthFirstDayZero);

            $subMonthInsertData['time_range'] = StatisticalData::MONTH;
            $subMonthInsertData['add_time'] = $subMonthFirstDayZero;

            $handleSameDataClosure($subMonthInsertData);

            $insertBatchData[] = $subMonthInsertData;
        }

        if (!StatisticalDataDao::addBatchData($insertBatchData)) {
            send_msg_to_wecom('存储企微数据失败！');
            return false;
        }

        return true;
    }
}
