<?php

namespace app\api\command;

use app\api\service\user\impl\UserServiceImpl;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

/**
 * 分别统计5月份、6月份的泛流量号和电商号当月首次添加的用户数以及这些用户在添加后在当月进群的人数占比。
 *
 * Class EnterGroupStatisticsData
 * @package app\api\command
 */
class EnterGroupStatisticsData extends Command
{
    protected function configure()
    {
        $this->setName('enterGroupStatisticsData')->setDescription('泛流量号和电商号进群率');
    }

    /**
     * @param  Input  $input
     * @param  Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 首次添加的用户数-begin
        $companyValidContactData = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field(
                [
                    'follow.external_userid',
                    'follow.create_time',
                ]
            )
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where(
                [
                    'userid'             => ['in', $feiyueAccounts],
                    'follow.create_time' => ['between', ['2021-05-01', '2021-06-01']], // 添加时间
                ]
            )
            ->group('follow.external_userid') // 去重
            ->select();

        $allCount = count($companyValidContactData);

        // 这些人中，进群的人 begin
        $groupCount = 0;

        foreach ($companyValidContactData as $unionId) {
            $isJoinGroup = Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field(['a.id'])
                ->where([
                    'a.userid'     => $unionId['external_userid'],
                    'a.join_time'  => [
                        'between',
                        [
                            strtotime($unionId['create_time']),
                            strtotime('2021-06-01')
                        ]
                    ],
                    'b.is_deleted' => 0,
                    'b.owner'      => ['in', $feiyueAccounts]
                ])
                ->find();

            if ($isJoinGroup) {
                $groupCount++;
            }
        }
        // end

        // 进群率
        $rate = get_rate((int)$groupCount, (int)$allCount);
        print_r($allCount);
        echo '--';
        print_r($groupCount);
        echo '--';
        print_r($rate);
    }
}
