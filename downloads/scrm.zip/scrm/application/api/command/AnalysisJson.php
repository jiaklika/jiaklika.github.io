<?php

namespace app\api\command;

use app\api\controller\Contact;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\contact\impl\ContactServiceImpl;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;
use think\Log;

/**
 * Class AnalysisJson
 * @package app\api\command
 */
class AnalysisJson extends Command
{
    protected function configure()
    {
        $this->setName('analysisJson')->setDescription('解析json');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    /*protected function execute(Input $input, Output $output)
    {
        $filePath = './555.json';

        $readJson = function () use ($filePath) {
            $handle = fopen($filePath, 'rb');

            while (feof($handle) === false) {
                yield fgets($handle);
            }

            fclose($handle);
        };

        $allUnionIdJson = '';

        foreach ($readJson() as $key => $value) {
            $allUnionIdJson .= $value;
        }

        $allUnionIdArr = json_decode($allUnionIdJson, true);

        $allUnionId = array_column($allUnionIdArr['RECORDS'], 'unionid');

        $contactServiceImpl = new ContactServiceImpl();

        $friendArr = [];

        foreach ($allUnionId as $singleUnionId) {
            $res = $contactServiceImpl->isZhaoweiFriend($singleUnionId);
            if ($res['is_zhaowei_friend'] == true) {
                array_push($friendArr, $singleUnionId);
            }
        }

        $contactTagHttpDao = new ContactTagHttpDao();
        $userServiceImpl = new UserServiceImpl();
        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $insertTagData = [];

        foreach ($allUnionId as $unionId) {
            // 这个客户目前的客服
            $followUserArr = Db::name('contact_follow_user')
                ->alias('follow')
                ->field([
                    'contact.external_userid',
                    'follow.userid'
                ])
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where([
                    'unionid' => $unionId,
                    'status'  => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT], // 不是被客服删除
                    'userid'  => ['in', $zhaoweiAccounts]
                ])
                ->select();

            if (!$followUserArr) {
                continue;
            }
            foreach ($followUserArr as $followUser) {
                try {
                    $addTagRes = $contactTagHttpDao->markTag(
                        $followUser['userid'],
                        $followUser['external_userid'],
                        ['et5b2CBwAACwthdlDMKgWRZ-ESkOzd2A']
                    );

                    if ($addTagRes) {
                        // 要记录的数据
                        $insertTagData[] = [
                            'tag_id'          => 'et5b2CBwAACwthdlDMKgWRZ-ESkOzd2A',
                            'external_userid' => $followUser['external_userid'],
                            'userid'          => $followUser['userid']
                        ];
                    }
                } catch (Exception $e) {
                    Log::error(sprintf(
                        'HandleContactTagJob出错了-%s-%s',
                        $followUser['userid'],
                        $e->getMessage()
                    ));
                }
            }
        }

        if ($insertTagData) {
            ContactTagMapDao::addBatchData($insertTagData);
        }
    }*/

    protected function execute(Input $input, Output $output)
    {
        $groupInfo = (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'b.name',
                'a.original_name',
                'a.unionid',
                'a.userid'
            ])
            ->where([
                'b.chat_id'    => ['in', [
                    'wr5b2CBwAAwYvnN5IDnngn_IwsYHt2jQ',
                    'wr5b2CBwAA8mWQlVpjFCHfzTWz2Og9pA',
                    'wr5b2CBwAAwoGHvr_N-p0V0vE-nj1Iug'
                ]],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.type'       => 2,
                'a.unionid'    => ['<>', '']
            ])
            ->select();

        $userArr = UserDao::getAllList(['userid', 'name'], ['name' => ['like', '%阳阳%']]);

        $userMapArr = array_column($userArr, 'name', 'userid');

        $userIdArr = array_keys($userMapArr);

        $contactHttpDao = new ContactHttpDao();

        foreach ($groupInfo as &$value) {
            $contactFollowArr = ContactFollowUserDao::getAllList([
                'userid'
            ], [
                'status'          => ContactFollowUser::NORMAL,
                'external_userid' => $value['userid'],
                'userid'          => ['in', $userIdArr]
            ]);

            $userNameArr = [];
            $userNameStr = '';

            if ($contactFollowArr) {
                foreach ($contactFollowArr as $follow) {
                    $userNameArr[] = $userMapArr[$follow['userid']];
                }
            }

            if ($userNameArr) {
                $userNameStr = implode(',', $userNameArr);
            }

            $value['yangyang'] = $userNameStr;

            $value['is_consume'] = '否';
            $userCenterData = $contactHttpDao->getUserCenter($value['unionid']);

            if (!$userCenterData['contractAmount']) {
                if ($contactHttpDao->getIsConsume($value['unionid'])) {
                    $value['is_consume'] = '是';
                }
            } else {
                $value['is_consume'] = '是';
            }
        }

        downloadExcelToLocal('母亲节群数据', function ($spreadsheet) use ($groupInfo) {
            $cellValueMap = [
                'A1' => '所属群',
                'B1' => '用户昵称',
                'C1' => 'unionID',
                'D1' => '互为好友的阳阳号',
                'E1' => '是否消费'
            ];

            $cellValueFunc = function ($cellValueMap, $index) use ($spreadsheet) {
                foreach ($cellValueMap as $cellKey => $cellValue) {
                    $spreadsheet->setActiveSheetIndex($index)->setCellValue($cellKey, $cellValue);
                }
            };

            $cellValueFunc($cellValueMap, 0);

            foreach ($groupInfo as $contactKey => $value) {
                $excelKey = $contactKey + 2;

                // sheet0
                $sheet0ValueMap = [
                    'A' . $excelKey => $value['name'],
                    'B' . $excelKey => $value['original_name'],
                    'C' . $excelKey => $value['unionid'],
                    'D' . $excelKey => $value['yangyang'],
                    'E' . $excelKey => $value['is_consume'],
                ];

                $cellValueFunc($sheet0ValueMap, 0);
            }

            /* $columnFormat = [
                 'B' => 30,
                 'C' => 25,
                 'E' => 18,
                 'F' => 18,
                 'G' => 18,
                 'J' => 30
             ];

             $columnFormatFunc = function ($columnFormat) use ($spreadsheet) {
                 foreach ($columnFormat as $columnKey => $columnWidth) {
                     $spreadsheet->getActiveSheet()
                         ->getColumnDimension($columnKey)
                         ->setWidth($columnWidth);
                 }
             };

             $columnFormatFunc($columnFormat);*/
        });
    }
}
