<?php

namespace app\api\command;

use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\common\model\ContactFollowUser;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

/**
 * Class NewbieCount
 * @package app\api\command
 */
class NewbieCount extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('newbieCount')->setDescription('获取纯新人数量');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $wayId = 147;
        $beginTime = strtotime('2021-06-04');
        $endTime = strtotime('2021-06-05');

        $followUserList = ContactFollowUserDao::getAllList(
            [
                'external_userid'
            ],
            [
                'state'      => $wayId,
                'createtime' => ['between', [$beginTime, $endTime]],
                'status'     => ContactFollowUser::NORMAL
            ]
        );

        $followUserIdList = array_column($followUserList, 'external_userid');

        $formerRecord = (array)Db::name('contact_follow_user')
            ->field(['external_userid'])
            ->where([
                'createtime'      => ['<', $beginTime],
                'external_userid' => ['in', $followUserIdList]
            ])
            ->group('external_userid')
            ->select();

        $formerUserIdList = array_column($formerRecord, 'external_userid');

        $diffResults = array_diff($followUserIdList, $formerUserIdList);


        $groupMemberList = ContactGroupMembersDao::getAllList(
            [
                'userid'
            ],
            [
                'userid'    => ['in', $diffResults],
                'join_time' => ['<', $beginTime]
            ]
        );

        $groupMemberUserIdList = array_column($groupMemberList, 'userid');

        $finalDiffResults = array_diff($diffResults, $groupMemberUserIdList);

        echo count($finalDiffResults);
    }
}

