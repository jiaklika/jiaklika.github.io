<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\data\PushFansDao;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// 每天的23点59
// 59 23 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think pushFans
class PushFans extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('pushFans')
            ->setDescription('朋友圈加粉统计')
            ->addOption('other')
            ->addOption('all');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $toUser = [
            'chebin',
            'zhongming',
            'liyin',
            'lvjunyan',
            'xulan'
        ];

        $messageHttpDao = new MessageHttpDao();
        $webHookHpptDao = new WebHookHttpDao();

        $momentConsumeData = $webHookHpptDao->getMomentConsumeData();

        if (!isset($momentConsumeData['fans']) || !$momentConsumeData['fans']) {
            send_msg_to_wecom('获取推粉数据为空');
            return;
        }

        $momentConsumeData = $momentConsumeData['fans'];

        // 今天日期
        $todayDate = Carbon::now()->toDateString();
        $todayZero = date('Y-m-d 00:00:00');

        // 昨日零点
        // $yesterdayZero = date('Y-m-d 00:00:00', strtotime('-1 days'));
        $sendTime = date('H:i');
        $totalContent['content'] =
            "<font color='warning'>{$todayDate} {$sendTime} 宝姐家推粉承接整体数据</font>";

        // 整体推粉数据
        $pushFansInfo = PushFansDao::getAllList([
            'unionid'
        ], [
            'unionid' => ['<>', null]
        ]);

        $getJoinGroupInfo = function (array $unionIdArr) {
            return (array)Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field(['unionid'])
                ->where([
                    'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                    'b.is_deleted' => ContactGroups::NOT_DELETED,
                    'unionid'      => ['in', $unionIdArr]
                ])
                ->group('unionid')
                ->select();
        };

        $unionIdArr = array_column($pushFansInfo, 'unionid');

        $joinGroupUnionIdArr = array_column($getJoinGroupInfo($unionIdArr), 'unionid');
        $joinGroupCount = count($joinGroupUnionIdArr);
        // 在群率
        $joinGroupRate = get_rate($joinGroupCount, $momentConsumeData['totalFans']);

        // 好友
        $friendsInfo = (array)Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'external_contact b',
                'a.external_userid = b.external_userid',
                'left'
            )
            ->field([
                'unionid'
            ])
            ->where([
                'unionid' => ['in', $unionIdArr],
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('unionid')
            ->select();

        // 有效在群率 = 留存人数中在群人数/留存人数
        $friendsCount = count($friendsInfo);
        $validGroupCount = count($getJoinGroupInfo(array_column($friendsInfo, 'unionid')));
        $friendsJoinGroupRate = get_rate($validGroupCount, $friendsCount);

        // 今日群活跃人数
        $groupActiveArr = (array)Db::name('opengid_records')
            ->field(['unionid'])
            ->where([
                'open_time' => ['>', $todayZero],
                'unionid'   => ['in', $unionIdArr]
            ])
            ->group('unionid')
            ->select();

        $groupActiveCount = count($groupActiveArr);
        // 群活跃率 = 群活跃人数/在群人数
        $groupActiveRate = get_rate($groupActiveCount, $joinGroupCount);

        $totalContent['content'] .= "
><font color='warning'>留存</font>
>累计推粉 {$momentConsumeData['totalFans']}
>在企微群人数 {$joinGroupCount} 整体在群率 {$joinGroupRate} 有效在群率 {$friendsJoinGroupRate}
>今日总活跃人数 {$momentConsumeData['todayActive']} 有效活跃率 {$momentConsumeData['todayActivePer']} 
>今日企微群活跃人数 {$groupActiveCount} 活跃率 {$groupActiveRate} 
><font color='warning'>今日转化</font>
>今日新转化人数 {$momentConsumeData['todayBuyFirstUser']} 
>转化金额 {$momentConsumeData['todayFirstBuyMoney']} 最高购买单价 {$momentConsumeData['todayFirstBuyMoneyMax']}
>今日总转化人数 {$momentConsumeData['todayBuyUser']}
>转化金额 {$momentConsumeData['todayBuyMoney']} 最高购买单价 {$momentConsumeData['todayBuyMoneyMax']}
>最高下单数 {$momentConsumeData['todayBuyNumberMax']}
><font color='warning'>今日转化分布</font>
>顾问报款（线下） {$momentConsumeData['todayOfflineOrderNumber']}
><font color='warning'>累计转化</font>
>累计转化人数 {$momentConsumeData['buyUser']} 累计转化单数 {$momentConsumeData['buyNumber']}
>转化率 {$momentConsumeData['buyUserPer']} 累计转化金额 {$momentConsumeData['buyMoney']} 实际转化金额 {$momentConsumeData['buyMoneyReality']}
>平均客单价 {$momentConsumeData['buyMoneyPer']} 平均笔单价 {$momentConsumeData['buyPrice']}
>人均下单数 {$momentConsumeData['buyPer']} 最高购买单价 {$momentConsumeData['buyMaxPrice']}
>最高下单数 {$momentConsumeData['buyNumberMax']}
><font color='warning'>累计转化分布</font>
>顾问报款（线下） {$momentConsumeData['offlineOrderNumber']}
><font color='warning'>转化周期</font>
>3日转化率 {$momentConsumeData['buyDayUserPer'][0]} 7日转化率 {$momentConsumeData['buyDayUserPer'][1]}
>14日转化率 {$momentConsumeData['buyDayUserPer'][2]} 30日转化率 {$momentConsumeData['buyDayUserPer'][3]}
>已转化人数平均决策时长 {$momentConsumeData['buyDay']}";

            $todayContent['content'] =
                "<font color='warning'>{$todayDate} $sendTime 今日宝姐家推粉承接数据</font>";

            $todayContent['content'] .= "
><font color='warning'>留存</font>
>推粉人数 {$momentConsumeData['todayTotalFans']}
><font color='warning'>今日新粉转化</font>
>转化人数 {$momentConsumeData['firstBuyUser']} 转化率 {$momentConsumeData['firstBuyUserPer']}
>新粉当日累计转化 {$momentConsumeData['newUserBuyMoney']}
>平均客单价 {$momentConsumeData['firstBuyUserPrice']} 最高购买单价 {$momentConsumeData['firstBuyMax']} 
><font color='warning'>转化分布</font>
>顾问报款（线下） {$momentConsumeData['firstOfflineOrderNumber']} ";

        try {
            $messageHttpDao->sendMessage('markdown', $totalContent, $toUser);
            sleep(2);
            $messageHttpDao->sendMessage('markdown', $todayContent, $toUser);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }
}
