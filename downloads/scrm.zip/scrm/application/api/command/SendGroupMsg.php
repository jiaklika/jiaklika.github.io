<?php

namespace app\api\command;

use app\api\dao\mysql\message\GroupMsgSenderMapDao;
use app\api\dao\mysql\message\GroupMsgTagMapDao;
use app\api\dao\mysql\message\GroupMsgTemplatesDao;
use app\api\service\groupMsg\impl\GroupMsgServiceImpl;
use app\common\model\groupMsg\GroupMsgTemplates;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Queue;

// crontab 每隔1分钟
// */1 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendGroupMsg

/**
 * Class SendGroupMsg
 * @package app\api\command
 */
class SendGroupMsg extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('sendGroupMsg')->setDescription('定时企业群发');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output): bool
    {
        $nowTime = Carbon::now()->toDateTimeString();

        $checkPlan = function ($results) use ($nowTime) {
            if (!$results) {
                return false;
            }

            $templateIdArr = array_column($results, 'id');

            // 要发送的客服-begin
            $senderUserArr = GroupMsgSenderMapDao::getAllList(
                [
                    'template_id',
                    'sender_user_id'
                ],
                [
                    'template_id' => ['in', $templateIdArr]
                ]
            );

            $newSenderUserArr = [];

            foreach ($senderUserArr as $sender) {
                $newSenderUserArr[$sender['template_id']][] = $sender['sender_user_id'];
            }
            // 要发送的客服-end

            // 要发送的标签-begin
            $tagArr = GroupMsgTagMapDao::getAllList(
                [
                    'template_id',
                    'tag_id'
                ],
                [
                    'template_id' => ['in', $templateIdArr]
                ]
            );

            $newTagArr = [];

            foreach ($tagArr as $tag) {
                $newTagArr[$tag['template_id']][] = $tag['tag_id'];
            }
            // 要发送的标签-end

            $groupMsgServiceImpl = new GroupMsgServiceImpl();

            foreach ($results as $template) {
                if ($template['send_time'] <= $nowTime) { // 到发送时间了
                    [$msgType, $typeData] = $groupMsgServiceImpl->organizeSecondData($template);

                    $originalData = [
                        'template_id'    => $template['id'], // 群发记录ID
                        'receiver_range' => $template['receiver_range'],
                        'content_text'   => $template['content_text'], // 第一条内容
                        'msg_type'       => $msgType, // 第二条类型
                        'type_data'      => $typeData, // 第二条内容,
                    ];

                    $extraData = [];

                    if ($template['receiver_range'] != GroupMsgTemplates::RECEIVER_ONLY_TAG) {
                        $extraData['sender'] = $newSenderUserArr[$template['id']] ?? [];
                    }

                    if ($template['receiver_range'] == GroupMsgTemplates::RECEIVER_SENDER_AND_TAG) {
                        $extraData['tags'] = $newTagArr[$template['id']] ?? [];
                    }

                    $carryData = $extraData ? array_merge($originalData, $extraData) : $originalData;

                    try {
                        // 推送到队列
                        $isPushed = Queue::push(
                            GroupMsgTemplates::JOB_HANDLER,
                            $carryData,
                            GroupMsgTemplates::JOB_QUEUE_NAME
                        );

                        if ($isPushed !== false) {
                            if (
                                GroupMsgTemplatesDao::updateData(
                                    [
                                        'is_handle' => GroupMsgTemplates::HAS_HANDLED
                                    ],
                                    [
                                        'id' => $template['id']
                                    ]
                                ) === false
                            ) {
                                send_msg_to_wecom('更新定时任务执行状态出错！ID:' . $template['id']);
                            }
                        }
                    } catch (Exception $e) {
                        send_msg_to_wecom('群发发送计划进入队列出错！' . $e->getMessage());
                    }
                }
            }
            return true;
        };

        GroupMsgTemplatesDao::handleDataByChunk([
            'id',
            'receiver_range',
            'content_text',
            'second_type',
            'image_pic_url',
            'link_title',
            'link_pic_url',
            'link_desc',
            'link_url',
            'miniprogram_title',
            'miniprogram_pic_media_id',
            'miniprogram_appid',
            'miniprogram_page',
            'send_time',
        ], [
            'is_plan'    => GroupMsgTemplates::IS_PLAN,
            'is_handle'  => GroupMsgTemplates::NOT_HANDLE,
            'status'     => GroupMsgTemplates::STATUS_NOT_BEGIN,
            'is_deleted' => GroupMsgTemplates::NOT_DELETED
        ], 100, $checkPlan);

        return true;
    }
}
