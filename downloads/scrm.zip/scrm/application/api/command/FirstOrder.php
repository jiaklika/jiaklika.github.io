<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\liveData\LiveAudienceDataDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\common\model\ContactFollowUser;
use app\common\model\liveData\LiveAudienceData;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 视频号直播企微客户产生首单人数
 *
 * Class FirstOrder
 * @package app\api\command
 */
class FirstOrder extends Command
{
    protected function configure()
    {
        $this->setName('firstOrder')->setDescription('视频号直播企微客户产生首单人数');
    }

    /**
     * @param  Input  $input
     * @param  Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        [
            $liveStartTime,
            $liveEndTime
        ] = [
            strtotime('2021-06-04 19:00:00'),
            strtotime('2021-06-04 22:30:00')
        ];

        $liveId = 2;

        $liveName = '2021-06-04 视频号直播';

        $consumeAudienceData = LiveAudienceDataDao::getAllList(['unionid'], [
            'live_id'    => $liveId,
            'is_consume' => LiveAudienceData::IS_CONSUME
        ]);

        $allUnionId = array_column($consumeAudienceData, 'unionid');

        $getExternalContactArr = function (array $where = []) use ($allUnionId) {
            $externalContactArr = (array)Db::name('contact_follow_user')
                ->alias('a')
                ->join(
                    'external_contact b',
                    'a.external_userid = b.external_userid',
                    'left'
                )
                ->field([
                    'unionid'
                ])
                ->where(array_merge([
                    'unionid' => ['in', $allUnionId],
                    'status'  => ContactFollowUser::NORMAL
                ], $where))
                ->group('unionid')
                ->select();

            return array_column($externalContactArr, 'unionid');
        };

        $externalContactUnionIdArr = $getExternalContactArr();

        // 排除当场直播首次添加企微的人
        $wayArr = ContactWaysDao::getAllList(
            [
                'id'
            ],
            [
                'channel_id' => 67
            ]
        );

        $wayIdArr = array_column($wayArr, 'id');

        // 当场直播首次添加企微的人
        $nowAddExternalContactUnionIdArr = $getExternalContactArr([
            'state'         => ['in', $wayIdArr],
            'createtime'    => ['between', [$liveStartTime, $liveEndTime]],
            'b.update_time' => null
        ]);

        $externalContactUnionIdArr = array_diff(
            $externalContactUnionIdArr,
            $nowAddExternalContactUnionIdArr
        );

        $contactHttpDao = new ContactHttpDao();

        foreach ($externalContactUnionIdArr as $singleUnionId) {
            $userCenterInfo = $contactHttpDao->getUserCenter($singleUnionId);

            if (empty($userCenterInfo['first_consume_date'])) {
                continue;
            }

            $firstConsumeTime = strtotime($userCenterInfo['first_consume_date']);

            if (
                $firstConsumeTime >= $liveStartTime
                && $firstConsumeTime <= $liveEndTime
            ) {
                file_put_contents(
                    "{$liveName}.txt",
                    $singleUnionId . '-' .
                    $userCenterInfo['nickname'] .
                    '-首次消费金额：' . $userCenterInfo['first_consume_amount'] .
                    '-首次消费时间：' . $userCenterInfo['first_consume_date'] . PHP_EOL,
                    FILE_APPEND
                );
            }
        }
    }
}
