<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

/**
 *
 * 30 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think weekData
 *
 * 每天9点半
 *
 * Class WeekData
 * @package app\api\command
 */
class WeekData extends Command
{
    protected function configure()
    {
        $this->setName('weekData')->setDescription('赵蔚每周进群数据汇总');
    }

    /**
     * @param  Input  $input
     * @param  Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        ini_set('memory_limit', '520M');
        // $toUsers = ['chebin'];
        $toUsers = [
            'chebin',
            'lvjunyan',
            'zhaowei',
            'zhongyongping',
            'zhujing',
        ];

        $messageHttpDao = new MessageHttpDao();

        [
            $lastWeekMondayDate, // 上周一日期
            $lastWeekSundayDate, // 上周末日期
            $lastWeekMondayTime, // 上周一时间戳
            $lastWeekSundayTime, // 上周末时间戳
        ]
        =
        [
            Carbon::now()->subWeek()->startOfWeek()->toDateString(),
            Carbon::now()->subWeek()->endOfWeek()->toDateString(),
            Carbon::now()->subWeek()->startOfWeek()->getTimestamp(),
            Carbon::now()->subWeek()->endOfWeek()->getTimestamp(),
        ];

        $zhaoweiAccounts = Db::name('user_bind_account_map')
            ->alias('a')
            ->join('user b', 'a.account = b.userid', 'LEFT')
            ->field([
                'account',
                'name'
            ])
            ->where([
                'user_id' => 'zhaowei'
            ])
            ->select();

        $zhaoweiUserIdArr = array_column((array)$zhaoweiAccounts, 'account');

        // 顾问号添加新人-begin
        $allMemberCountClosure = function (array $userIdArr) use ($lastWeekMondayTime, $lastWeekSundayTime) {
            return Db::name('contact_follow_user')
                ->where(
                    [
                        // 添加时间
                        'createtime' => ['between', [$lastWeekMondayTime, $lastWeekSundayTime]],
                        'userid'     => ['in', $userIdArr]
                    ]
                )
                ->count('distinct external_userid');
        };
        // 顾问号添加新人-end

        // 净增新人，仍互为好友-begin
        $validCountClosure = function (array $userIdArr) use ($lastWeekMondayTime, $lastWeekSundayTime) {
            $companyValidContactData = Db::name('contact_follow_user')
                ->alias('follow')
                ->field(
                    [
                        'follow.id',
                        'follow.external_userid',
                        'contact.unionid'
                    ]
                )
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where(
                    [
                        'status'     => ContactFollowUser::NORMAL, // 仍互为好友
                        'createtime' => ['between', [$lastWeekMondayTime, $lastWeekSundayTime]], // 添加时间
                        'del_time'   => null, // 首次添加
                        'userid'     => ['in', $userIdArr]
                    ]
                )
                ->group('follow.external_userid') // 去重
                ->select();

            $unionIdArr = array_column((array)$companyValidContactData, 'unionid');

            return [$unionIdArr, count($unionIdArr)];
        };
        // 净增新人，仍互为好友-end

        // 赵蔚所有的群
        $groupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'is_deleted' => ContactGroups::NOT_DELETED,
                'owner'      => ['in', $zhaoweiUserIdArr],
                'name'       => ['<>', '']
            ]
        );

        $chatIdArr = array_column($groupList, 'chat_id');

        // 这些人中，进群的人 begin
        $getJoinGroupCount = function (array $unionIdArr) use (
            $lastWeekMondayTime,
            $lastWeekSundayTime,
            $chatIdArr
        ) {
            $groupCount = 0;

            foreach ($unionIdArr as $unionId) {
                $isLastWeekJoinGroup = ContactGroupMembersDao::getAllList(
                    [
                        'chat_id'
                    ],
                    [
                        'unionid'   => $unionId,
                        'join_time' => ['between', [$lastWeekMondayTime, $lastWeekSundayTime]],
                        'chat_id'   => ['in', $chatIdArr]
                        //'is_deleted' => ContactGroupMembers::NOT_DELETED
                    ]
                );

                if ($isLastWeekJoinGroup) {
                    $groupCount++;
                }
            }
            return $groupCount;
        };
        // end

        // 群总人数净增 begin

        // 群的全部人员数量（去重）
        $countGroupMemberSql = function ($joinGroupTime) use ($chatIdArr) {
            return Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->where(
                    [
                        'b.is_deleted' => ContactGroups::NOT_DELETED, // 群没解散
                        'a.is_deleted' => ContactGroupMembers::NOT_DELETED, // 没退群
                        'type'         => ContactGroupMembers::EXTERNAL_USER, // 外部联系人
                        'join_time'    => ['<', $joinGroupTime],
                        'b.chat_id'    => ['in', $chatIdArr],
                        'b.name'       => ['<>', '']
                    ]
                )
                ->count('distinct unionid');
        };

        // 截至到上周一前群的全部人员数量
        $subLastWeekGroupMemberArr = $countGroupMemberSql($lastWeekMondayTime);

        // 截至到上周日前群的全部人员数量
        $lastWeekAllGroupMemberArr = $countGroupMemberSql($lastWeekSundayTime);

        $groupMemberGrowthCount = $lastWeekAllGroupMemberArr - $subLastWeekGroupMemberArr;
        // end

        // 组织数据，发送
        $summaryContent['content'] =
            "<font color='warning'>{$lastWeekMondayDate}～{$lastWeekSundayDate}</font> **赵蔚**社群进群数据汇总";

        $summaryGroupInfo = $validCountClosure($zhaoweiUserIdArr);

        $joinGroupCount = $getJoinGroupCount($summaryGroupInfo[0]);

        // 进群率
        $summaryRate = get_rate((int)$joinGroupCount, (int)$summaryGroupInfo[1]);

        $summaryRate = $summaryRate == '-' ? '0%' : $summaryRate;

        $summaryContent['content'] .= "
>**顾问号添加新人**：{$allMemberCountClosure($zhaoweiUserIdArr)}人
            >**净增人数（上周添加-上周删除）**：{$summaryGroupInfo[1]}人
            >**其中进群人数**：{$getJoinGroupCount($summaryGroupInfo[0])}人
            >**进群率**：{$summaryRate}
            >－－－－－－－－－－－
            >**群净增人数**：{$groupMemberGrowthCount}人
            >**当前群总人数**：{$lastWeekAllGroupMemberArr}人\n";

        // 单人数据
        $singleContent['content'] = "<font color='warning'>{$lastWeekMondayDate}～{$lastWeekSundayDate}</font>\n";

        foreach ($zhaoweiAccounts as $singleAccount) {
            $singleContent['content'] .=
                "<font color='info'>{$singleAccount['name']}</font>进群数据汇总";

            $singleGroupInfo = $validCountClosure([$singleAccount['account']]);

            $singleJoinGroupCount = $getJoinGroupCount($singleGroupInfo[0]);

            // 进群率
            $singleRate = get_rate((int)$singleJoinGroupCount, (int)$singleGroupInfo[1]);

            $singleRate = $singleRate == '-' ? '0%' : $singleRate;

            $singleContent['content'] .= "
>**顾问号添加新人**：{$allMemberCountClosure([$singleAccount['account']])}人
            >**净增人数（上周添加-上周删除）**：{$singleGroupInfo[1]}人
            >**其中进群人数**：{$getJoinGroupCount($singleGroupInfo[0])}人
            >**进群率**：{$singleRate}\n\n";
        }

        try {
            $messageHttpDao->sendMessage('markdown', $summaryContent, $toUsers);
            $messageHttpDao->sendMessage('markdown', $singleContent, $toUsers);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }
}
