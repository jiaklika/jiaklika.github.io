<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\mysql\data\StatisticalDataDao;
use app\common\model\StatisticalData;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 30 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think enterGroupData >> enterGroupData.log
 *
 * 每天9点半
 *
 * Class EnterGroupData
 *
 * @package app\api\command
 */
class EnterGroupData extends Command
{
    protected function configure()
    {
        $this->setName('enterGroupData')->setDescription('发送每日进群数据');
    }

    /**
     * @param  Input  $input
     * @param  Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output): bool
    {
        // $toUsers = ['chebin'];
        $toUsers = [
            'chebin',
            'lvjunyan',
            'zhaowei',
            'zhongyongping',
            'zhujing',
            // 'zhangji',
            'liyin',
            'jiamin',
            'xuliang',
            'feiyue',
            'xulan'
        ];

        $messageHttpDao = new MessageHttpDao();

        [
            $yesterdayDate, // 昨天日期 2021-07-31
            $yesterdayZero, // 昨日零点时间戳 1627660800
            $subYesterdayZero, // 前天0点时间戳 1627574400
        ]
            =
        [
            date('Y-m-d', strtotime('-1 days')),
            strtotime(date('Y-m-d', strtotime('-1 days'))),
            strtotime(date('Y-m-d', strtotime('-2 days')))
        ];

        /**
         * 组织数据
         *
         * @param int $timeRange 时间范围 1-日 2-周 3-月
         * @param int $latAddTime 上次的时间戳
         * @param int $addTime 本次的时间戳
         * @param string $title 标题
         * @return array
         * @throws Exception
         */
        $organizeData = function (int $timeRange, int $latAddTime, int $addTime, string $title): array {
            $subSubInfo = StatisticalDataDao::getDetail([
                'company_contacts_count',
                'feiyue_contacts_count',
                'zhaowei_contacts_count',
                'company_group_members_count',
                'feiyue_group_members_count',
                'zhaowei_group_members_count'
            ], [
                'time_range' => $timeRange,
                'add_time'   => $latAddTime
            ]);

            $subInfo = StatisticalDataDao::getDetail([
                'company_first_add_count',
                'feiyue_first_add_count',
                'zhaowei_first_add_count',
                'company_history_contacts_count',
                'feiyue_history_contacts_count',
                'zhaowei_history_contacts_count',
                'company_first_add_join_group_count',
                'feiyue_first_add_join_group_count',
                'zhaowei_first_add_join_group_count',
                'company_contacts_count',
                'feiyue_contacts_count',
                'zhaowei_contacts_count',
                'company_group_members_count',
                'feiyue_group_members_count',
                'zhaowei_group_members_count',
                'feiyue_friend_join_group_count',
                'zhaowei_friend_join_group_count',
                'zhaowei_group_not_friend_count'
            ], [
                'time_range' => $timeRange,
                'add_time'   => $addTime
            ]);

            switch ($timeRange) {
                case 1:
                default:
                    $rangeName = '单日';
                    $incrTitleName = '日';
                    break;

                case 2:
                    $incrTitleName = $rangeName = '周';
                    break;

                case 3:
                    $incrTitleName = $rangeName = '月';
                    break;
            }

            $content['content'] =
                "<font color='warning'>{$title} 企微加粉{$rangeName}数据汇总</font>";

            // 当前号总人数净增
            $companyPureIncr = $subInfo['company_contacts_count'] - $subSubInfo['company_contacts_count'];
            $feiyuePureIncr = $subInfo['feiyue_contacts_count'] - $subSubInfo['feiyue_contacts_count'];
            $zhaoweiPureIncr = $subInfo['zhaowei_contacts_count'] - $subSubInfo['zhaowei_contacts_count'];
            // 当前群总人数净增
            $companyGroupPureIncr = $subInfo['company_group_members_count']
                - $subSubInfo['company_group_members_count'];
            $feiyueGroupPureIncr = $subInfo['feiyue_group_members_count']
                - $subSubInfo['feiyue_group_members_count'];
            $zhaoweiGroupPureIncr = $subInfo['zhaowei_group_members_count']
                - $subSubInfo['zhaowei_group_members_count'];
            // 进群率
            $companyJoinGroupRate = get_rate(
                $subInfo['company_first_add_join_group_count'],
                $subInfo['company_first_add_count']
            );
            $feiyueJoinGroupRate = get_rate(
                $subInfo['feiyue_first_add_join_group_count'],
                $subInfo['feiyue_first_add_count']
            );
            $zhaoweiJoinGroupRate = get_rate(
                $subInfo['zhaowei_first_add_join_group_count'],
                $subInfo['zhaowei_first_add_count']
            );
            // 在群率
            $feiyueFriendJoinGroupRate = get_rate(
                $subInfo['feiyue_friend_join_group_count'],
                $subInfo['feiyue_contacts_count']
            );
            $zhaoweiFriendJoinGroupRate = get_rate(
                $subInfo['zhaowei_friend_join_group_count'],
                $subInfo['zhaowei_contacts_count']
            );

            $content['content'] .= "
><font color='warning'>企微号</font>新添加：{$subInfo['company_first_add_count']}人 总添加：{$subInfo['company_history_contacts_count']}人
>新添加的人进群：{$subInfo['company_first_add_join_group_count']}人 进群率：{$companyJoinGroupRate}
>当前号总人数：{$subInfo['company_contacts_count']}人 {$incrTitleName}净增：{$companyPureIncr}人
>当前群总人数：{$subInfo['company_group_members_count']}人 {$incrTitleName}净增：{$companyGroupPureIncr}人
>－－－－－－－－－－－－
><font color='warning'>泛流量号</font>新添加：{$subInfo['feiyue_first_add_count']}人 总添加：{$subInfo['feiyue_history_contacts_count']}人
>新添加的人进群：{$subInfo['feiyue_first_add_join_group_count']}人 进群率：{$feiyueJoinGroupRate}
>当前号总人数：{$subInfo['feiyue_contacts_count']}人 {$incrTitleName}净增：{$feiyuePureIncr}人
>当前群总人数：{$subInfo['feiyue_group_members_count']}人 {$incrTitleName}净增：{$feiyueGroupPureIncr}人
>在群率：{$feiyueFriendJoinGroupRate}
>－－－－－－－－－－－－
><font color='warning'>电商号</font>新添加：{$subInfo['zhaowei_first_add_count']}人 总添加：{$subInfo['zhaowei_history_contacts_count']}人
>新添加的人进群：{$subInfo['zhaowei_first_add_join_group_count']}人 进群率：{$zhaoweiJoinGroupRate}
>当前号总人数：{$subInfo['zhaowei_contacts_count']}人 {$incrTitleName}净增：{$zhaoweiPureIncr}人
>当前群总人数：{$subInfo['zhaowei_group_members_count']}人 {$incrTitleName}净增：{$zhaoweiGroupPureIncr}人
>在群但不在号内人数：{$subInfo['zhaowei_group_not_friend_count']}人
>在群率：{$zhaoweiFriendJoinGroupRate}";

            return $content;
        };

        /**
         * 发送消息
         *
         * @param array $content 消息内容数组
         * @throws Exception
         */
        $sendMessageClosure = function (array $content) use ($messageHttpDao, $toUsers) {
            try {
                $messageHttpDao->sendMessage('markdown', $content, $toUsers);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
        };

        $yesterdayContent = $organizeData(
            StatisticalData::DAY,
            $subYesterdayZero,
            $yesterdayZero,
            $yesterdayDate
        );

        $sendMessageClosure($yesterdayContent);

        // 周一需要返回上一周数据-begin
        // 上周一0点时间戳
        $subWeekMondayZero = Carbon::now()->subWeek()->startOfWeek()->getTimestamp();
        // 上上周一0点时间戳
        $subSubWeekMondayZero = Carbon::now()->subWeek('+2')->startOfWeek()->getTimestamp();
        if (Carbon::now()->isMonday()) {
            // 上周一
            $subWeekMonday = Carbon::now()->subWeek()->startOfWeek()->toDateString();
            // 上周日
            $subWeekSunday = Carbon::now()->subWeek()->endOfWeek()->toDateString();

            $weekTitle = $subWeekMonday . '～' . $subWeekSunday;

            $weekContent = $organizeData(
                StatisticalData::WEEK,
                $subSubWeekMondayZero,
                $subWeekMondayZero,
                $weekTitle
            );
            $sendMessageClosure($weekContent);
        }
        // 周一需要返回上一周数据-end

        // 每月第一天
        $firstMonthDay = Carbon::now()->startOfMonth()->toDateString();
        $nowDay = Carbon::now()->toDateString();
        // 上个月第一天0点时间戳
        $subMonthFirstDayZero = Carbon::now()->subMonth()->startOfMonth()->getTimestamp();
        // 上上个月第一天0点时间戳
        $subSubMonthFirstDayZero = Carbon::now()->subMonth('+2')->startOfMonth()->getTimestamp();

        if ($firstMonthDay == $nowDay) {
            // 上个月第一天
            $subMonthFirstDate = Carbon::now()->subMonth()->startOfMonth()->toDateString();
            // 上个月最后一天
            $subMonthEndDate = Carbon::now()->subMonth()->endOfMonth()->toDateString();

            $monthTitle = $subMonthFirstDate . '～' . $subMonthEndDate;

            $monthContent = $organizeData(
                StatisticalData::MONTH,
                $subSubMonthFirstDayZero,
                $subMonthFirstDayZero,
                $monthTitle
            );
            $sendMessageClosure($monthContent);
        }

        return true;
    }
}
