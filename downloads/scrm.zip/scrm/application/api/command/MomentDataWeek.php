<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每周一上午9:30
// 30 9 * * 1 cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentDataWeek
/**
 * 朋友圈加粉周统计
 *
 * Class MomentDataWeek
 * @package app\api\command
 */
class MomentDataWeek extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('momentDataWeek')
            ->setDescription('朋友圈加粉周统计');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $toUser = [
            'chebin',
            'lvjunyan',
            'wangderun',
            'xulan',
            'liyin',
            'liying',
            'zhongyongping',
            'zhujing',
            'zhaowei'
        ];

        // 上周一日期
        $lastWeekBegin = Carbon::now()->subWeek()->startOfWeek()->toDateString();
        // 上周天日期
        $lastWeekEnd = Carbon::now()->subWeek()->endOfWeek()->toDateString();

        try {
            $webHookHttpDao = new WebHookHttpDao();

            $momentWeekData = $webHookHttpDao->getMomentWeekConsumeData();

            $totalContent['content'] =
                "<font color='warning'>{$lastWeekBegin}至{$lastWeekEnd} 企微推广加粉周数据</font>";

            $totalContent['content'] .= "
><font color='warning'>整体</font>
>上周累计新客数 {$momentWeekData['all']['newCount']} 
>上周新粉转化人数 {$momentWeekData['all']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['all']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['all']['convertAmt']}";

            if (isset($momentWeekData['stone1'])) {
                $totalContent['content'] .= "
><font color='warning'>彩宝1</font>
>上周累计新客数 {$momentWeekData['stone1']['newCount']}
>上周新粉转化人数 {$momentWeekData['stone1']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['stone1']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['stone1']['convertAmt']}";
            }

            if (isset($momentWeekData['stone2'])) {
                $totalContent['content'] .= "
><font color='warning'>彩宝2</font>
>上周累计新客数 {$momentWeekData['stone2']['newCount']} 
>上周新粉转化人数 {$momentWeekData['stone2']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['stone2']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['stone2']['convertAmt']}";
            }

            if (isset($momentWeekData['stone3'])) {
                $totalContent['content'] .= "
><font color='warning'>彩宝3</font>
>上周累计新客数 {$momentWeekData['stone3']['newCount']} 
>上周新粉转化人数 {$momentWeekData['stone3']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['stone3']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['stone3']['convertAmt']}";
            }

            if (isset($momentWeekData['pearl_old'])) {
                $totalContent['content'] .= "
><font color='warning'>珍珠老</font>
>上周累计新客数 {$momentWeekData['pearl_old']['newCount']} 
>上周新粉转化人数 {$momentWeekData['pearl_old']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['pearl_old']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['pearl_old']['convertAmt']}";
            }

            if (isset($momentWeekData['pearl_new'])) {
                $totalContent['content'] .= "
                ><font color='warning'>珍珠新</font>
>上周累计新客数 {$momentWeekData['pearl_new']['newCount']} 
>上周新粉转化人数 {$momentWeekData['pearl_new']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['pearl_new']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['pearl_new']['convertAmt']}
";
            }

            if (isset($momentWeekData['activity_203'])) {
                $totalContent['content'] .= "
                ><font color='warning'>活动引粉</font>
>上周累计新客数 {$momentWeekData['activity_203']['newCount']} 
>上周新粉转化人数 {$momentWeekData['activity_203']['convertCont']}
>上周累计新客有效转化金额 {$momentWeekData['activity_203']['newAmt']}
>上周新粉有效转化金额 {$momentWeekData['activity_203']['convertAmt']}
";
            }

            $messageHttpDao = new MessageHttpDao();
            $messageHttpDao->sendMessage('markdown', $totalContent, $toUser);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getLine() . $e->getMessage());
        }
    }
}
