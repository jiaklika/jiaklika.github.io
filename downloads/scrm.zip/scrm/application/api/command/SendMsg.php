<?php

namespace app\api\command;

use app\api\service\message\impl\MessageServiceImpl;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 0,30 16-22 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendMsg >> sendMsg.log
 *
 * 每天16到22点 每隔半小时
 *
 * Class SendMsg
 * @package app\api\command
 */
class SendMsg extends Command
{
    protected function configure()
    {
        $this->setName('sendMsg')->setDescription('发送统计数据到微信');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $messageService = new MessageServiceImpl();

        //$messageService->sendMsg(['chebin']);

        $messageService->sendMsg([
            'chebin',
            'lvjunyan',
            'jiamin',
            'zhongyongping',
            'zhujing',
            'wangbin',
            'zhangji',
            'feiyue',
            'zhaowei'
        ]);

        echo 'success-' . date('Y-m-d H:i:s') . PHP_EOL;
    }
}
