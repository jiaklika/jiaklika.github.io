<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\log\ConsumeMqLogsDao;
use app\common\model\ExternalContact;
use Exception;
use MQ\Exception\MessageNotExistException;
use MQ\MQClient;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab
// */3 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php
// think updateConsumeFromBojemMQ >> updateConsumeFromBojemMQ.log

/**
 * 从宝姐珠宝MQ更新用户是否消费
 *
 * Class UpdateUserInfoFromMQ
 * @package app\api\command
 */
class UpdateConsumeFromBojemMQ extends Command
{
    protected function configure()
    {
        $this->setName('updateConsumeFromBojemMQ')->setDescription('从宝姐珠宝MQ更新用户是否消费');
    }

    /**
     * 处理mq里的消息
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        try {
            $client = new MQClient(
                MQ_END_POINT,
                MQ_ACCESS_ID,
                MQ_ACCESS_KEY
            );

            $consumer = $client->getConsumer(
                'MQ_INST_1791318055539215_Bcm7IAYo',
                'normal_msg',
                'GID_BOJEM_SCRM_CONSUME',
                'bojem_scrm_consume_tag'
            );

            $messages = $consumer->consumeMessage(10, 0);
        } catch (MessageNotExistException $e) {
            exit(date('Y-m-d H:i:s') . '-no new message\n');
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
            exit($e->getMessage());
        }

        if (empty($messages)) {
            exit('没有需要消费的队列消息');
        }

        $receiptHandles = $insertBatchData = [];

        $contactHttpDao = new ContactHttpDao();

        foreach ($messages as $message) {
            if ($message->getMessageBody()) {
                $messageData = json_decode($message->getMessageBody(), true);

                if (!isset($messageData['unionid'])) {
                    continue;
                }

                $userCenterData = $contactHttpDao->getUserCenter($messageData['unionid']);

                $updateRes = ContactDao::updateData(
                    [
                        'is_consume'            => ExternalContact::IS_CONSUME,
                        'actual_consume_amount' => $userCenterData['consume_amount']
                    ],
                    [
                        'unionid' => $messageData['unionid']
                    ]
                );

                $isContact = $updateRes !== false
                    ? ExternalContact::IS_CONSUME
                    : ExternalContact::NO_CONSUME;

                $insertBatchData[] = [
                    'message_id'        => $message->messageId,
                    'unionid'           => $messageData['unionid'],
                    'consume'           => $messageData['consume'],
                    'is_contact'        => $isContact,
                    'is_update_success' => $updateRes
                ];

                $receiptHandles[] = $message->getReceiptHandle();
            }

            $message->getNextConsumeTime();
        }

        if ($insertBatchData) {
            ConsumeMqLogsDao::addBatchData($insertBatchData);
        }

        // 确认队列消息已消费
        if ($receiptHandles) {
            $consumer->ackMessage($receiptHandles);
        }
    }
}
