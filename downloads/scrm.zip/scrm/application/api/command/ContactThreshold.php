<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use Exception;
use think\Cache;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每隔3分钟
// */3 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think contactThreshold

/**
 * 企微加粉阈值提醒
 *
 * Class ContactThreshold
 * @package app\api\command
 */
class ContactThreshold extends Command
{
    protected function configure()
    {
        $this->setName('contactThreshold')->setDescription('企微加粉阈值提醒');
    }

    /**
     * 当天（0点起算）企微总加粉人数达到1000、1500、2000、2500、3000...人（每隔500提醒）
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $redis = Cache::store()->handler();

        // 当天
        $todayDate = date('Y-m-d');

        $todayCount = $redis->hLen("register-risk:{$todayDate}");

        $webHookHttpDao = new WebHookHttpDao();

        $messageHttpDao = new MessageHttpDao();

        $sendWarning = function (int $count) use (
            $messageHttpDao,
            $redis,
            $webHookHttpDao,
            $todayCount,
            $todayDate
        ) {
            $now = date('Y-m-d H:i:s');

            $redisKey = $todayDate . '-' . $count;

            if (!$redis->get($redisKey)) {
                // 先写标志缓存
                $redis->set($redisKey, 1, 86400);

                /*$toUser = [
                    'chebin'
                ];*/

                $toUser = [
                    'chebin',
                    'feiyue',
                    'lvjunyan',
                    'jiamin',
                    'liyin',
                    'xuliang'
                ];
                $it = null;

                $redis->setOption(\Redis::OPT_SCAN, \Redis::SCAN_RETRY);

                $registerRiskRankVoid = $registerRiskRank0
                    = $registerRiskRank1 = $registerRiskRank2
                    = $registerRiskRank3 = $registerRiskRank4
                    = 0;

                $marketRiskRankVoid = $marketRiskRank0
                    = $marketRiskRank1 = $marketRiskRank2
                    = $marketRiskRank3 = $marketRiskRank4
                    = 0;

                while ($arrKeys = $redis->hScan("register-risk:{$todayDate}", $it)) {
                    foreach ($arrKeys as $strField => $strValue) {
                        switch ($strValue) {
                            case -1:
                                $riskRes = $webHookHttpDao->getRiskRank($strField);
                                $registerRiskRank = $riskRes['data']['register_risk_rank'];
                                switch ($registerRiskRank) {
                                    case -1:
                                        $registerRiskRankVoid++;
                                        break;

                                    case 0:
                                        $registerRiskRank0++;
                                        break;

                                    case 1:
                                        $registerRiskRank1++;
                                        break;

                                    case 2:
                                        $registerRiskRank2++;
                                        break;

                                    case 3:
                                        $registerRiskRank3++;
                                        break;

                                    case 4:
                                        $registerRiskRank4++;
                                        break;
                                }
                                break;

                            case 0:
                                $registerRiskRank0++;
                                break;

                            case 1:
                                $registerRiskRank1++;
                                break;

                            case 2:
                                $registerRiskRank2++;
                                break;

                            case 3:
                                $registerRiskRank3++;
                                break;

                            case 4:
                                $registerRiskRank4++;
                                break;
                        }

                    }
                }

                $it1 = null;

                while ($arrMarketKeys = $redis->hScan("market-risk:{$todayDate}", $it1)) {
                    foreach ($arrMarketKeys as $strMarketField => $strMarketValue) {
                        switch ($strMarketValue) {
                            case -1:
                                $riskRes = $webHookHttpDao->getRiskRank($strMarketField);
                                $marketRiskRank = $riskRes['data']['market_risk_rank'];
                                switch ($marketRiskRank) {
                                    case -1:
                                        $marketRiskRankVoid++;
                                        break;

                                    case 0:
                                        $marketRiskRank0++;
                                        break;

                                    case 1:
                                        $marketRiskRank1++;
                                        break;

                                    case 2:
                                        $marketRiskRank2++;
                                        break;

                                    case 3:
                                        $marketRiskRank3++;
                                        break;
                                }
                                break;

                            case 0:
                                $marketRiskRank0++;
                                break;

                            case 1:
                                $marketRiskRank1++;
                                break;

                            case 2:
                                $marketRiskRank2++;
                                break;

                            case 3:
                                $marketRiskRank3++;
                                break;
                        }
                    }
                }

                $registerRiskRankVoidRate = get_rate($registerRiskRankVoid, $todayCount);
                $registerRiskRank0Rate    = get_rate($registerRiskRank0, $todayCount);
                $registerRiskRank1Rate    = get_rate($registerRiskRank1, $todayCount);
                $registerRiskRank2Rate    = get_rate($registerRiskRank2, $todayCount);
                $registerRiskRank3Rate    = get_rate($registerRiskRank3, $todayCount);
                $registerRiskRank4Rate    = get_rate($registerRiskRank4, $todayCount);
                $marketRiskRankVoidRate   = get_rate($marketRiskRankVoid, $todayCount);
                $marketRiskRank0Rate      = get_rate($marketRiskRank0, $todayCount);
                $marketRiskRank1Rate      = get_rate($marketRiskRank1, $todayCount);
                $marketRiskRank2Rate      = get_rate($marketRiskRank2, $todayCount);
                $marketRiskRank3Rate      = get_rate($marketRiskRank3, $todayCount);
                $marketRiskRank4Rate      = get_rate($marketRiskRank4, $todayCount);

                $content['content'] = "【{$now}】
>**加粉预警**：当天已加粉<font color='warning'>{$count}</font>人！
>**注册风险**：未知{$registerRiskRankVoidRate} 无风险{$registerRiskRank0Rate} 轻微风险{$registerRiskRank1Rate} 低风险{$registerRiskRank2Rate} 中风险{$registerRiskRank3Rate} 高风险{$registerRiskRank4Rate}
>**营销风险**：未知{$marketRiskRankVoidRate} 无风险{$marketRiskRank0Rate} 轻微风险{$marketRiskRank1Rate} 低风险{$marketRiskRank2Rate} 中风险{$marketRiskRank3Rate} 高风险{$marketRiskRank4Rate}";

                try {
                    $messageHttpDao->sendMessage('markdown', $content, $toUser);
                } catch (Exception $e) {
                    send_msg_to_wecom($e->getMessage());
                }
            }
        };

        $thresholdArr = [];

        for ($i = 1000; $i < 10000; $i += 500) {
            $thresholdArr[] = $i;
        }

        foreach ($thresholdArr as $threshold) {
            if ($todayCount >= $threshold) {
                $sendWarning($threshold);
            }
        }
    }
}
