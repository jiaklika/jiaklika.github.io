<?php

namespace app\api\command;

use app\api\dao\http\kefu\KefuHttpDao;
use app\api\dao\mysql\kefu\KefuServiceRecordsDao;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每天0点
// 0 0 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think endKefuChat
/**
 * 查询客服超过48小时无新消息的会话并更新数据
 *
 * Class MomentData
 * @package app\api\command
 */
class EndKefuChat extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('endKefuChat')
            ->setDescription('查询客服超过48小时无新消息的会话并更新数据');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        // 48小时前
        $subTime = Carbon::now()->subHour(48)->toDateTimeString();

        $serviceRecordArr = KefuServiceRecordsDao::getAllList([
            'id',
            'open_kfid',
            'external_userid'
        ], [
            'service_state' => 3,
            'create_time'   => ['<', $subTime]
        ]);

        if (!$serviceRecordArr) {
            exit();
        }

        $kefuHttpDao = new KefuHttpDao();
        try {
            $updateBatchIdArr = [];
            foreach ($serviceRecordArr as $serviceRecord) {
                $serviceState = $kefuHttpDao->getServiceState(
                    $serviceRecord['open_kfid'],
                    $serviceRecord['external_userid']
                );
                if ($serviceState['service_state'] == 4) {
                    array_push($updateBatchIdArr, $serviceRecord['id']);
                }
            }
            if ($updateBatchIdArr) {
                KefuServiceRecordsDao::updateData([
                    'service_state' => 0
                ], [
                    'id' => ['in', $updateBatchIdArr]
                ]);
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
        }
    }
}
