<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\data\PushFansDao;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactTags;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// 每10分钟打推粉标签
// */10 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think tagPushFans
/**
 * 打"推粉"标签
 *
 * Class TagPushFans
 * @package app\api\command
 */
class TagPushFans extends Command
{
    protected function configure()
    {
        $this->setName('tagPushFans')->setDescription('打"推粉"标签');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output): bool
    {
        $groupId = ContactTags::PUSH_FANS_GROUP_TAG;
        // 本周一
        $startOfWeek = Carbon::now()->startOfWeek()->toDateString();
        // 本周日
        $endOfWeek = Carbon::now()->endOfWeek()->toDateString();

        $thisWeekTagName = sprintf('%s~%s', $startOfWeek, $endOfWeek);

        try {
            $pushFansData = PushFansDao::getAllList(['unionid'], [
                'is_handle' => 0
            ]);

            if (!$pushFansData) {
                return false;
            }

            $tagArr = ContactTagsDao::getDetail(['tag_id'], [
                'group_id'       => $groupId,
                'tag_name'       => $thisWeekTagName,
                'tag_is_deleted' => 0
            ]);

            if (!$tagArr) {
                $contactTagHttpDao = new ContactTagHttpDao();
                $tagRes = $contactTagHttpDao->addContactTag([
                    'name' => $thisWeekTagName
                ], $groupId);

                $tagId = $tagRes['tag'][0]['id'];

                ContactTagsDao::addData([
                    'group_id'          => $groupId,
                    'group_name'        => '推粉',
                    'group_create_time' => $tagRes['create_time'],
                    'tag_id'            => $tagId,
                    'tag_name'          => $tagRes['tag'][0]['name'],
                    'tag_create_time'   => $tagRes['tag'][0]['create_time'],
                ]);
            } else {
                $tagId = $tagArr['tag_id'];
            }

            $unionIdArr = array_column($pushFansData, 'unionid');

            $userServiceImpl = new UserServiceImpl();

            $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

            // 赵蔚的好友
            $contactInfo = Db::name('contact_follow_user')
                ->alias('a')
                ->join(
                    'scrm_external_contact b',
                    'a.external_userid = b.external_userid',
                    'LEFT'
                )
                ->field([
                    'a.userid',
                    'a.external_userid',
                    'b.unionid'
                ])
                ->where([
                    'userid'  => ['in', $zhaoweiAccounts],
                    'unionid' => ['in', $unionIdArr],
                    'status'  => ContactFollowUser::NORMAL
                ])
                ->group('a.external_userid')
                ->select();

            // 如果不是赵蔚任一个号里的客户，就直接退出
            if (!$contactInfo) {
                return false;
            }

            $addTags = [$tagId];
            $removeTags = [];

            $contactTagHttpDao = new ContactTagHttpDao();

            $successUnionIdArr = [];

            foreach ($contactInfo as $value) {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                    array_push($successUnionIdArr, $value['unionid']);
                }
            }

            PushFansDao::updateData(
                [
                    'is_handle' => 1,
                ],
                [
                    'unionid' => ['in', $unionIdArr]
                ]
            );

            PushFansDao::updateData(
                [
                    'is_tag'   => 1,
                    'tag_time' => date('Y-m-d H:i:s', time())
                ],
                [
                    'unionid' => ['in', $successUnionIdArr]
                ]
            );

            return true;
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
        }

        return false;
    }
}
