<?php

namespace app\api\command;

use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ExternalContact;
use Carbon\Carbon;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// 每天10点~23每小时 发送给一拨人
// 0 10-23/1 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData

// 每天的14点、18点、22点发送给另一拨人
// 0 14-22/4 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --other

// 每天的9点和23点半发送给全部人
// 0 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --all
// 59 23 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --all

// 每天中午12点和晚上18点推给吕俊彦
// 0 12 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --lv
// 0 18 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --lv

// 每天23点55保存数据
// 55 23 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentData --save
/**
 * 朋友圈加粉统计
 *
 * Class MomentData
 * @package app\api\command
 */
class MomentData extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('momentData')
            ->setDescription('朋友圈加粉统计')
            ->addOption('other')
            ->addOption('all')
            ->addOption('lv')
            ->addOption('save');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $webHookHpptDao = new WebHookHttpDao();

        $momentConsumeData = $webHookHpptDao->getMomentConsumeData();

        if (!$momentConsumeData) {
            send_msg_to_wecom('获取朋友圈广告消费信息为空');
            return;
        }

        $sleepTime = 5;
        $toUser = [
            'chebin',
            'zhongming',

            //'lvjunyan',
            'jiamin',
            'zhaowei',
            'zhongyongping',
            'xujuntao',
            'zhangbo',
            'liying',
        ];

        // 珍珠
        $pearlUser = [
            'chebin',
            //'lvjunyan',
            'zhongming',
            'liying',
            'zhongyongping',
            'zhaowei',
            'feiyue'
        ];

        // 彩宝1
        $gemstone1User = [
            'chebin',
            //'lvjunyan',
            'zhongming',
            'liying',
            'zhongyongping',
            'zhangji',
            'zhaowei',
            'feiyue',
            'zhoujiaqi'
        ];

        // 彩宝3
        $gemstone3User = [
            'chebin',
            'liying',
            'zhongyongping',
            'feiyue',
            'zhaowei'
        ];

        // 彩宝汇总
        $gemstoneAllUser = [
            'chebin',
            'liying',
            'zhaowei',
            'zhongyongping',
        ];

        /*$gemUser = [
            'chebin',
            'lvjunyan',
            'zhongming',
            'zhangbo',
            'xujuntao',
        ];*/

        // 彩宝2
        $gemstone2User = [];

        if ($input->hasOption('other')) {
            $toUser = [
                'chebin',
                'xulan',
                'zhangji',
                'wangjinkai',
                'chubei'
            ];
            $gemstone1User = ['zhangbo', 'louxuchun'];
            $gemstone2User = ['zhangbo', 'zhaowei'];
            $pearlUser = ['zhangbo'];
            // $gemUser = [];
            $gemstoneAllUser = [];
        }

        if ($input->hasOption('all')) {
            $toUser = [
                'chebin',
                'xulan',
                'zhangji',
                'wangjinkai',
                'zhongming',
                // 'lvjunyan',
                'jiamin',
                'zhaowei',
                'zhongyongping',
                'chubei',
                'xujuntao',
                'zhangbo',
                'liying',
            ];
        }

        if ($input->hasOption('lv')) {
            $toUser = $pearlUser = $gemstone1User = $gemstoneAllUser = ['lvjunyan'];
        }

        if ($input->hasOption('save')) {
            $toUser = $pearlUser = $gemstone1User = $gemstone3User = $gemstoneAllUser = ['chebin'];
        }

        $messageHttpDao = new MessageHttpDao();

        $totalInsertBatchData = $todayInsertBatchData = [];

        /**
         * @param int $type 146-珍珠 149-蓝宝石
         * @return array[]
         * @throws Exception
         */
        $handleDataClosure = function (
            int $type
        ) use (
            $momentConsumeData,
            $input,
            &$todayInsertBatchData,
            &$totalInsertBatchData
        ) {
            $pearlIndex    = 146;
            $sapphireIndex = 149;
            $newPearlIndex = 151;
            $gemstone1 = 165;
            $gemstone2 = 166;
            $gemstoneAll = 153;
            $gemstone3 = 190;

            $activity = 203;

            $typeName = '';

            // 今天日期
            $todayDate = Carbon::now()->toDateString();
            $todayZero = Carbon::now()->startOfDay()->getTimestamp();
            // 发送时间
            $sendTime = date('H:i');

            switch ($type) {
                case $pearlIndex:
                    $typeName = '珍珠（老）';
                    $momentConsumeData = $momentConsumeData['pearl_146'];
                    break;

                case $sapphireIndex:
                    $typeName = '宝石';
                    $momentConsumeData = $momentConsumeData['gem'];
                    break;

                case $newPearlIndex:
                    $typeName = '珍珠（新）';
                    $momentConsumeData = $momentConsumeData['pearl_151'];
                    break;

                case $gemstone1:
                    $typeName = '彩宝1';
                    $momentConsumeData = $momentConsumeData['pearl_165'];
                    break;

                case $gemstone2:
                    $typeName = '彩宝2';
                    $momentConsumeData = $momentConsumeData['pearl_166'];
                    break;

                case $gemstone3:
                    $typeName = '私域定投';
                    $momentConsumeData = $momentConsumeData['pearl_190'];
                    break;

                case $gemstoneAll:
                    $typeName = '彩宝汇总';
                    $momentConsumeData = $momentConsumeData['pearl_166_165'];
                    break;

                case $activity:
                    $typeName = '活动引粉';
                    $momentConsumeData = $momentConsumeData['pearl_203'];
                    break;
            }

            $totalContent['content'] =
                "<font color='warning'>{$todayDate} {$sendTime} 企微推广加粉整体数据</font><font color='info'>【{$typeName}】</font>";

            /**
             * 获取加粉人数
             *
             * @param array $extraWhere
             * @return array
             * @throws Exception
             */
            $getFollowUserInfo = function (array $extraWhere = []) use ($type): array {
                $contactOriginWhere = [
                    'add_way' => 100
                ];
                if ($type != 153) {
                    $contactOriginWhere['state'] = $type;
                } else {
                    $contactOriginWhere['state'] = ['in', [165, 166, 190]];
                }
                return (array)Db::name('contact_follow_user')
                    ->alias('a')
                    ->join(
                        'external_contact b',
                        'a.external_userid = b.external_userid',
                        'left'
                    )
                    ->field([
                        'unionid'
                    ])
                    ->where(array_merge($contactOriginWhere, $extraWhere))
                    ->group('unionid')
                    ->select();
            };
            // 累计加粉
            $totalInfo     = $getFollowUserInfo();
            $totalAddCount = count($totalInfo);
            // 累计正常客户
            $normalInfo  = $getFollowUserInfo([
                'status' => ContactFollowUser::NORMAL
            ]);
            $normalCount = count($normalInfo);

            // 留存率 = 正常/累计
            $normalRate = get_rate($normalCount, $totalAddCount);

            // 所有客户的unionid数组
            $totalUnionIdArr = array_column($totalInfo, 'unionid');

            // 在群人数
            $goodStuffChatIdArr = [];
            if ($type == $sapphireIndex) {
                $goodStuffGroups = ContactGroupDao::getAllList(['chat_id'], [
                    'name'       => ['like', '%好物独享%'],
                    'is_deleted' => ContactGroups::NOT_DELETED
                ]);
                $goodStuffChatIdArr = array_column($goodStuffGroups, 'chat_id');
            }

            /**
             * 获取朋友圈推广加粉进群信息
             *
             * @param array $unionIdArr
             * @param array $extraWhere
             * @return array
             * @throws Exception
             */
            $getGroupInfo = function (
                array $unionIdArr,
                array $extraWhere = []
            ) use (
                $goodStuffChatIdArr,
                $type,
                $sapphireIndex
            ) {
                if (!$unionIdArr) {
                    return [];
                }

                $originWhere = [
                    'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                    'b.is_deleted' => ContactGroups::NOT_DELETED,
                    'unionid'      => ['in', $unionIdArr]
                ];
                if ($type == $sapphireIndex) {
                    $originWhere['b.chat_id'] = ['in', $goodStuffChatIdArr];
                }

                return (array)Db::name('contact_group_members')
                    ->alias('a')
                    ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                    ->field(['unionid'])
                    ->where(array_merge($originWhere, $extraWhere))
                    ->group('unionid')
                    ->select();
            };

            $joinGroupInfo = $getGroupInfo($totalUnionIdArr);

            $joinGroupCount = count($joinGroupInfo);
            // 在群率
            $joinGroupRate = get_rate($joinGroupCount, $totalAddCount);

            $groupActiveWhere = [
                'open_time' => ['>', $todayZero],
                'unionid'   => ['in', $totalUnionIdArr]
            ];

            if ($type == $sapphireIndex) {
                $groupActiveWhere['chat_id'] = ['in', $goodStuffChatIdArr];
            }
            // 今日群活跃人数
            $groupActiveArr = (array)Db::name('opengid_records')
                ->field(['unionid'])
                ->where($groupActiveWhere)
                ->group('unionid')
                ->select();

            $groupActiveCount      = count($groupActiveArr);
            $groupActiveUnionIdArr = array_column($groupActiveArr, 'unionid');
            // 活跃客户数
            $groupActiveCustomerCount = ContactDao::getCount([
                'is_consume' => ExternalContact::IS_CONSUME,
                'unionid'    => ['in', $groupActiveUnionIdArr]]);
            // 在群人数中有多少是客户
            $joinGroupUnionIdArr = array_column($joinGroupInfo, 'unionid');
            $joinGroupCustomerCount = ContactDao::getCount([
                'is_consume' => ExternalContact::IS_CONSUME,
                'unionid'    => ['in', $joinGroupUnionIdArr]]);

            // 有效在群率 = 留存人数中在群人数/留存人数
            $validGroupCount = count($getGroupInfo(array_column($normalInfo, 'unionid')));
            $validGroupRate  = get_rate($validGroupCount, $normalCount);

            // 群活跃率 = 群活跃人数/在群人数
            $groupActiveRate = get_rate($groupActiveCount, $joinGroupCount);

            $contactOperation = $momentConsumeData['todayBuyOrderType'][1] + $momentConsumeData['todayBuyOrderType'][2];

            // 客户活跃率
            // 因为分母被筛选，导致分子大于分母
            // $consumerActiveRate = get_rate($groupActiveCustomerCount, $momentConsumeData['buyUser']);
            // 分母改为在群人数中已消费的客户数
            $consumerActiveRate = get_rate($groupActiveCustomerCount, $joinGroupCustomerCount);

            $totalContent['content'] .= "
><font color='warning'>留存</font>
>累计加粉 {$totalAddCount} 
>留存人数 {$normalCount} 留存率 {$normalRate}
>在群人数 {$joinGroupCount} 整体在群率 {$joinGroupRate} 有效在群率 {$validGroupRate}
>今日活跃人数 {$momentConsumeData['todayActive']} 有效活跃率 {$momentConsumeData['todayActivePer']} 
>活跃客户数 {$momentConsumeData['todayActiveUser']} 客户活跃率 {$momentConsumeData['todayActiveUserPer']}
>今日群活跃人数 {$groupActiveCount} 活跃率 {$groupActiveRate} 
>活跃客户数 {$groupActiveCustomerCount} 客户活跃率 {$consumerActiveRate}
><font color='warning'>今日转化</font>
>今日新转化人数 {$momentConsumeData['todayBuyFirstUser']} 
>转化金额 {$momentConsumeData['todayFirstBuyMoney']} 最高购买单价 {$momentConsumeData['todayFirstBuyMoneyMax']}
>今日总转化人数 {$momentConsumeData['todayBuyUser']}
>转化金额 {$momentConsumeData['todayBuyMoney']} 最高购买单价 {$momentConsumeData['todayBuyMoneyMax']}
>最高下单数 {$momentConsumeData['todayBuyNumberMax']}
><font color='warning'>今日转化分布</font>
>用户运营 {$contactOperation} 宝姐珠宝 {$momentConsumeData['todayBuyOrderType'][0]}
>";

            $judgeOrderType = function ($index) use ($momentConsumeData) {
                $orderMap     = [
                    0  => '普通',
                    1  => '秒杀',
                    8  => '直播',
                    9  => '拼团',
                    10 => '回放',
                    11 => '换购',
                    12 => '颜值加价购',
                    13 => '众筹',
                    14 => '社群',
                    15 => '0元购',
                    16 => '0元拼'
                ];
                $orderContent = '';

                foreach ($orderMap as $orderKey => $orderValue) {
                    if ($momentConsumeData[$index][$orderKey]['total']) {
                        $orderContent .= "{$orderValue} {$momentConsumeData[$index][$orderKey]['total']} ";
                        if ($momentConsumeData[$index][$orderKey]['shopping']) {
                            $orderContent .=
                                "<font color='warning'>(购物金{$momentConsumeData[$index][$orderKey]['shopping']})</font> ";
                        }
                        if ($momentConsumeData[$index][$orderKey]['video']) {
                            $orderContent .=
                                "<font color='warning'>(视频号{$momentConsumeData[$index][$orderKey]['video']})</font> ";
                        }
                    }
                }
                return $orderContent;
            };

            $totalContent['content'] .= $judgeOrderType('todayOrderNumber');

            $totalContactOperation = $momentConsumeData['buyOrderType'][1] + $momentConsumeData['buyOrderType'][2];
            // 整体数据
            $actualConversionRate = $momentConsumeData['buyUserERP'] != 0 ? sprintf(
                "%01.2f",
                $momentConsumeData['buyMoneyERP'] / $momentConsumeData['buyUserERP']
            ) : 0;

            $totalContent['content'] .= "
><font color='warning'>累计转化</font>
>累计转化人数 {$momentConsumeData['buyUser']} 累计转化单数 {$momentConsumeData['buyNumber']}
>转化率 {$momentConsumeData['buyUserPer']} 累计转化金额 {$momentConsumeData['buyMoney']}
>平均客单价 {$momentConsumeData['buyMoneyPer']} 平均笔单价 {$momentConsumeData['buyPrice']}
>人均下单数 {$momentConsumeData['buyPer']} 最高购买单价 {$momentConsumeData['buyMaxPrice']}
>最高下单数 {$momentConsumeData['buyNumberMax']}
>实际转化人数 {$momentConsumeData['buyUserERP']} 实际转化金额 {$momentConsumeData['buyMoneyERP']} 实际平均客单价 {$actualConversionRate}
><font color='warning'>累计转化分布</font>
>用户运营 {$totalContactOperation} 宝姐珠宝 {$momentConsumeData['buyOrderType'][0]}
>";

            $totalContent['content'] .= $judgeOrderType('orderNumber');

            $totalContent['content'] .= "
><font color='warning'>转化周期</font>
>3日首购率 {$momentConsumeData['buyDayUserPer'][0]} 7日首购率 {$momentConsumeData['buyDayUserPer'][1]}
>14日首购率 {$momentConsumeData['buyDayUserPer'][2]} 30日首购率 {$momentConsumeData['buyDayUserPer'][3]}
>已转化人数平均决策时长 {$momentConsumeData['buyDay']}
><font color='warning'>复购周期</font>
>周复购率 {$momentConsumeData['buyDayBackPer'][0]}
>月复购率 {$momentConsumeData['buyDayBackPer'][1]}
>季度复购率 {$momentConsumeData['buyDayBackPer'][2]}
><font color='warning'>行为</font>
>手机号授权 {$momentConsumeData['userNumber']} 授权率 {$momentConsumeData['userNumberPer']}
>关注公众号 {$momentConsumeData['gzhNumber']} 新关注 {$momentConsumeData['gzhNewNumber']}";

            $todayContent['content'] =
                "<font color='warning'>{$todayDate} $sendTime 今日企微推广加粉数据</font><font color='info'>【{$typeName}】</font>";

            // 加粉人数
            $todayInfo  = $getFollowUserInfo(['createtime' => ['>', $todayZero]]);
            $todayCount = count($todayInfo);
            // 留存人数
            $todayNormal      = $getFollowUserInfo([
                'createtime' => ['>', $todayZero],
                'status'     => ContactFollowUser::NORMAL
            ]);
            $todayNormalCount = count($todayNormal);

            $todayNormalRate = get_rate($todayNormalCount, $todayCount);
            // 进群人数
            $todayUnionIdArr     = array_column($todayInfo, 'unionid');
            $todayJoinGroup      = $getGroupInfo($todayUnionIdArr, ['join_time' => ['>', $todayZero]]);
            $todayJoinGroupCount = count($todayJoinGroup);
            $todayJoinGroupRate  = get_rate($todayJoinGroupCount, $todayCount);

            // 有效进群率 = 留存人数中进了群的/留存人数
            $todayValidGroupCount = count($getGroupInfo(
                array_column($todayNormal, 'unionid'),
                ['join_time' => ['>', $todayZero]]
            ));

            $todayValidGroupRate = get_rate($todayValidGroupCount, $todayNormalCount);

            $todayContactOperation = $momentConsumeData['firstBuyOrderType'][1]
                + $momentConsumeData['firstBuyOrderType'][2];
            // 今日数据
            $todayContent['content'] .= "
><font color='warning'>留存</font>
>加粉人数 {$todayCount}
>留存人数 {$todayNormalCount} 留存率 {$todayNormalRate}
>进群人数 {$todayJoinGroupCount} 进群率 {$todayJoinGroupRate} 有效进群率 {$todayValidGroupRate}
><font color='warning'>今日新粉转化</font>
>首购人数 {$momentConsumeData['firstBuyUser']} 首购率 {$momentConsumeData['firstBuyUserPer']}
>新粉当日累计转化 {$momentConsumeData['newUserBuyMoney']}
>平均客单价 {$momentConsumeData['firstBuyUserPrice']} 平均笔单价 {$momentConsumeData['firstBuyPrice']}
>人均下单数 {$momentConsumeData['firstBuyNumberPer']} 最高购买单价 {$momentConsumeData['firstBuyMax']} 
>最高下单数 {$momentConsumeData['firstBuyNumber']}
><font color='warning'>转化分布</font>
>用户运营 {$todayContactOperation} 宝姐珠宝 {$momentConsumeData['firstBuyOrderType'][0]}
>";

            $todayContent['content'] .= $judgeOrderType('firstOrderNumber');

            $todayContent['content'] .= "
><font color='warning'>转化周期</font>
>近3日新粉首购率 {$momentConsumeData['buyDayPer'][0]} 近7日新粉首购率 {$momentConsumeData['buyDayPer'][1]}
><font color='warning'>行为</font>
>手机号授权 {$momentConsumeData['firstUserNumber']} 授权率 {$momentConsumeData['firstUserNumberPer']}
>关注公众号 {$momentConsumeData['firstGzhNumber']} 新关注 {$momentConsumeData['firstGzhNewNumber']}";

            if ($input->hasOption('save')) {
                if (
                    in_array($type, [146, 165, 166, 190, 151, 203])
                ) {
                    $todayInsertBatchData[] = [
                        'type'                     => $type,
                        'add_fans_count'           => $todayCount,
                        'retained_fans_count'      => $todayNormalCount,
                        'retained_rate'            => $todayNormalRate,
                        'join_group_count'         => $todayJoinGroupCount,
                        'join_group_rate'          => $todayJoinGroupRate,
                        'valid_join_group_rate'    => $todayValidGroupRate,
                        'first_order_count'        => $momentConsumeData['firstBuyUser'],
                        'first_order_rate'         => $momentConsumeData['firstBuyUserPer'],
                        'newbie_transfer_count'    => $momentConsumeData['newUserBuyMoney'],
                        'average_customer_price'   => $momentConsumeData['firstBuyUserPrice'],
                        'average_unit_price'       => $momentConsumeData['firstBuyPrice'],
                        'consume_per_capita'       => $momentConsumeData['firstBuyNumberPer'],
                        'maximum_purchase_price'   => $momentConsumeData['firstBuyMax'],
                        'highest_consume_count'    => $momentConsumeData['firstBuyNumber'],
                        'user_operation'           => $todayContactOperation,
                        'bojem_jewellery'          => $momentConsumeData['firstBuyOrderType'][0],
                        'three_first_order_rate'   => $momentConsumeData['buyDayPer'][0],
                        'seven_first_order_rate'   => $momentConsumeData['buyDayPer'][1],
                        'mobile_auth'              => $momentConsumeData['firstUserNumber'],
                        'mobile_auth_rate'         => $momentConsumeData['firstUserNumberPer'],
                        'follow_official_accounts' => $momentConsumeData['firstGzhNumber'],
                        'new_follow'               => $momentConsumeData['firstGzhNewNumber']
                    ];

                    $totalInsertBatchData[] = [
                        'type'                             => $type,
                        'cumulative_fans_count'            => $totalAddCount,
                        'retained_fans_count'              => $normalCount,
                        'retained_rate'                    => $normalRate,
                        'in_group_fans_count'              => $joinGroupCount,
                        'total_group_fans_rate'            => $joinGroupRate,
                        'valid_group_fans_rate'            => $validGroupRate,
                        'today_active_count'               => $momentConsumeData['todayActive'],
                        'valid_active_rate'                => $momentConsumeData['todayActivePer'],
                        'consume_active_count'             => $momentConsumeData['todayActiveUser'],
                        'consume_active_rate'              => $momentConsumeData['todayActiveUserPer'],
                        'today_group_active_count'         => $groupActiveCount,
                        'today_group_active_rate'          => $groupActiveRate,
                        'today_group_consume_active_count' => $groupActiveCustomerCount,
                        'today_group_consume_active_rate'  => $consumerActiveRate,
                        'today_new_consume_count'          => $momentConsumeData['todayBuyFirstUser'],
                        'today_new_consume_money'          => $momentConsumeData['todayFirstBuyMoney'],
                        'today_new_maximum_price'          => $momentConsumeData['todayFirstBuyMoneyMax'],
                        'today_consume_count'              => $momentConsumeData['todayBuyUser'],
                        'today_consume_money'              => $momentConsumeData['todayBuyMoney'],
                        'today_total_maximum_price'        => $momentConsumeData['todayBuyMoneyMax'],
                        'today_total_maximum_order'        => $momentConsumeData['todayBuyNumberMax'],
                        'today_transfer_user'              => $contactOperation,
                        'today_transfer_jewellery'         => $momentConsumeData['todayBuyOrderType'][0],
                        'today_normal'                     => $momentConsumeData['todayOrderNumber'][0]['total'],
                        'today_second'                     => $momentConsumeData['todayOrderNumber'][1]['total'],
                        'today_live'                       => $momentConsumeData['todayOrderNumber'][8]['total'],
                        'today_group'                      => $momentConsumeData['todayOrderNumber'][9]['total'],
                        'today_playback'                   => $momentConsumeData['todayOrderNumber'][10]['total'],
                        'today_change'                     => $momentConsumeData['todayOrderNumber'][11]['total'],
                        'today_yanzhi'                     => $momentConsumeData['todayOrderNumber'][12]['total'],
                        'today_crowd_funding'              => $momentConsumeData['todayOrderNumber'][13]['total'],
                        'today_community'                  => $momentConsumeData['todayOrderNumber'][14]['total'],
                        'today_zero_bug'                   => $momentConsumeData['todayOrderNumber'][15]['total'],
                        'today_zero_group'                 => $momentConsumeData['todayOrderNumber'][16]['total'],
                        'cumulative_consume_count'         => $momentConsumeData['buyUser'],
                        'cumulative_order_count'           => $momentConsumeData['buyNumber'],
                        'cumulative_consume_rate'          => $momentConsumeData['buyUserPer'],
                        'cumulative_consume_money'         => $momentConsumeData['buyMoney'],
                        'average_consume_price'            => $momentConsumeData['buyMoneyPer'],
                        'average_bill_price'               => $momentConsumeData['buyPrice'],
                        'average_consume_bill_count'       => $momentConsumeData['buyPer'],
                        'highest_price'                    => $momentConsumeData['buyMaxPrice'],
                        'highest_order_count'              => $momentConsumeData['buyNumberMax'],
                        'valid_transfer_count'             => $momentConsumeData['buyUserERP'],
                        'valid_transfer_money'             => $momentConsumeData['buyMoneyERP'],
                        'valid_average_consume_price'      => $actualConversionRate,
                        'cumulative_user'                  => $totalContactOperation,
                        'cumulative_jewellery'             => $momentConsumeData['buyOrderType'][0],
                        'cumulative_normal'                => $momentConsumeData['orderNumber'][0]['total'],
                        'cumulative_second'                => $momentConsumeData['orderNumber'][1]['total'],
                        'cumulative_live'                  => $momentConsumeData['orderNumber'][8]['total'],
                        'cumulative_group'                 => $momentConsumeData['orderNumber'][9]['total'],
                        'cumulative_playback'              => $momentConsumeData['orderNumber'][10]['total'],
                        'cumulative_change'                => $momentConsumeData['orderNumber'][11]['total'],
                        'cumulative_yanzhi'                => $momentConsumeData['orderNumber'][12]['total'],
                        'cumulative_crowd_funding'         => $momentConsumeData['orderNumber'][13]['total'],
                        'cumulative_community'             => $momentConsumeData['orderNumber'][14]['total'],
                        'cumulative_zero_buy'              => $momentConsumeData['orderNumber'][15]['total'],
                        'cumulative_zero_group'            => $momentConsumeData['orderNumber'][16]['total'],
                        'three_first_order_rate'           => $momentConsumeData['buyDayUserPer'][0],
                        'seven_first_order_rate'           => $momentConsumeData['buyDayUserPer'][1],
                        'fourteen_first_order_rate'        => $momentConsumeData['buyDayUserPer'][2],
                        'thirty_first_order_rate'          => $momentConsumeData['buyDayUserPer'][3],
                        'transfer_average_decision'        => $momentConsumeData['buyDay'],
                        'week_repurchase_rate'             => $momentConsumeData['buyDayBackPer'][0],
                        'month_repurchase_rate'            => $momentConsumeData['buyDayBackPer'][1],
                        'quarter_repurchase_rate'          => $momentConsumeData['buyDayBackPer'][2],
                        'mobile_auth'                      => $momentConsumeData['userNumber'],
                        'auth_rate'                        => $momentConsumeData['userNumberPer'],
                        'follow_wechat_media'              => $momentConsumeData['gzhNumber'],
                        'new_follow'                       => $momentConsumeData['gzhNewNumber'],
                    ];
                }
            }

            return [$totalContent, $todayContent];
        };

        try {
            // 珍珠
            [$pearlTotalContent, $pearlTodayContent] = $handleDataClosure(146);
            $messageHttpDao->sendMessage('markdown', $pearlTotalContent, $toUser);
            sleep($sleepTime);
            $messageHttpDao->sendMessage('markdown', $pearlTodayContent, $toUser);
            sleep($sleepTime);

            // 蓝宝石
            /*if ($gemUser) {
                sleep($sleepTime);
                [$sapphireTotalContent, $sapphireTodayContent] = $handleDataClosure(149);
                $messageHttpDao->sendMessage('markdown', $sapphireTotalContent, $gemUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $sapphireTodayContent, $gemUser);
            }*/

            if ($pearlUser) {
                // 珍珠老
                [$oldPearlTotalContent, $oldPearlTodayContent] = $handleDataClosure(146);
                $messageHttpDao->sendMessage('markdown', $oldPearlTotalContent, $pearlUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $oldPearlTodayContent, $pearlUser);
                sleep($sleepTime);

                // 珍珠新
                [$newPearlTotalContent, $newPearlTodayContent] = $handleDataClosure(151);
                $messageHttpDao->sendMessage('markdown', $newPearlTotalContent, $pearlUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $newPearlTodayContent, $pearlUser);
                sleep($sleepTime);

                // 彩宝2
                [$gemstone2TotalContent, $gemstone2TodayContent] = $handleDataClosure(166);
                $messageHttpDao->sendMessage('markdown', $gemstone2TotalContent, $pearlUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $gemstone2TodayContent, $pearlUser);
                sleep($sleepTime);

                // 活动引粉
                [$activityTotalContent, $activityTodayContent] = $handleDataClosure(203);
                $messageHttpDao->sendMessage('markdown', $activityTotalContent, $pearlUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $activityTodayContent, $pearlUser);
                sleep($sleepTime);
            }

            if ($gemstone2User) {
                // 彩宝2
                [$gemstone2TotalContent, $gemstone2TodayContent] = $handleDataClosure(166);
                $messageHttpDao->sendMessage('markdown', $gemstone2TotalContent, $gemstone2User);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $gemstone2TodayContent, $gemstone2User);
                sleep($sleepTime);
            }

            // 彩宝1
            if ($gemstone1User) {
                [$gemstone1TotalContent, $gemstone1TodayContent] = $handleDataClosure(165);
                $messageHttpDao->sendMessage('markdown', $gemstone1TotalContent, $gemstone1User);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $gemstone1TodayContent, $gemstone1User);
            }

            // 彩宝3
            if ($gemstone3User) {
                [$gemstone3TotalContent, $gemstone3TodayContent] = $handleDataClosure(190);
                $messageHttpDao->sendMessage('markdown', $gemstone3TotalContent, $gemstone3User);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $gemstone3TodayContent, $gemstone3User);
            }

            if ($gemstoneAllUser) {
                // 彩宝汇总
                [$gemstoneAllTotalContent, $gemstoneAllTodayContent] = $handleDataClosure(153);
                $messageHttpDao->sendMessage('markdown', $gemstoneAllTotalContent, $gemstoneAllUser);
                sleep($sleepTime);
                $messageHttpDao->sendMessage('markdown', $gemstoneAllTodayContent, $gemstoneAllUser);
            }

            if ($todayInsertBatchData) {
                DB::name('moments_add_daily_data')->insertAll($todayInsertBatchData);
            }

            if ($totalInsertBatchData) {
                DB::name('moments_add_total_data')->insertAll($totalInsertBatchData);
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getLine() . $e->getMessage());
        }
    }
}
