<?php

namespace app\api\command;

use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\message\MessageHttpDao;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// 10 9 * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think momentDailySendExcel

/**
 * 朋友圈推广表格数据推送
 */
class MomentDailySendExcel extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('momentDailySendExcel')
            ->setDescription('朋友圈推广表格数据推送');
    }

    /**
     * 执行指令
     *
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $toUser = [
            'chebin',
            'liying',
            'feiyue',
            'zhoujiaqi'
        ];

        $excelTitle = '企微推广加粉数据' . date('Y-m-d');

        downloadExcelToLocal($excelTitle, function ($spreadsheet) {
            $sheetNameArr = [
                '彩宝1整体数据',
                '彩宝1每日数据',
                '彩宝2整体数据',
                '彩宝2每日数据',
                '彩宝3整体数据',
                '彩宝3每日数据',
                '珍珠新整体数据',
                '珍珠新每日数据',
                '珍珠老整体数据',
                '珍珠老每日数据',
                '活动引粉整体数据',
                '活动引粉每日数据'
            ];

            // 填充内容
            $cellValueFunc = function ($cellValueMap, $index) use ($spreadsheet) {
                foreach ($cellValueMap as $cellKey => $cellValue) {
                    $spreadsheet->setActiveSheetIndex($index)->setCellValue($cellKey, $cellValue);
                }
            };

            $fillContent = function ($key, $sheetName, $cellValueMap) use ($spreadsheet, $cellValueFunc) {
                $spreadsheet->setActiveSheetIndex($key)->setTitle($sheetName);
                $cellValueFunc($cellValueMap, $key);
            };

            // 合并单元格
            $mergeCell = function ($key, $mergeKey, $mergeValue) use ($spreadsheet) {
                $spreadsheet->getActiveSheet($key)->mergeCells("{$mergeKey}:{$mergeValue}");
            };

            // 居中对齐
            $align = function ($key, $nameKey, $nameValue) use ($spreadsheet) {
                $spreadsheet->getActiveSheet($key)->setCellValue("{$nameKey}", "{$nameValue}");
                $spreadsheet->getActiveSheet($key)->getStyle("{$nameKey}")->applyFromArray([
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                    ],
                ]);
            };

            // 首行
            $firstLine = function ($key, $name) use ($spreadsheet) {
                $spreadsheet->getActiveSheet($key)->setCellValue('A1', $name);
                $spreadsheet->getActiveSheet($key)->getRowDimension('1')->setRowHeight(30);
                $spreadsheet->getActiveSheet($key)->getStyle('A1')
                    ->getFont()->setBold(true)->setName('Arial')->setSize(20);
            };


            foreach ($sheetNameArr as $key => $sheetName) {
                if ($key != 0) {
                    // 创建sheet
                    $spreadsheet->createSheet();
                }
                // 每日数据
                if (($key + 1) % 2 == 0) {
                    $typeIndexMap = [
                        1 => 165,
                        3 => 166,
                        5 => 190,
                        7 => 151,
                        9 => 146,
                        11 => 203
                    ];

                    $cellValueMap = [
                        'A3' => '日期',
                        'B3' => '加粉人数',
                        'C3' => '留存人数',
                        'D3' => '留存率',
                        'E3' => '进群人数',
                        'F3' => '进群率',
                        'G3' => '有效进群率',
                        'H3' => '首购人数',
                        'I3' => '首购率',
                        'J3' => '新粉当日累计转化',
                        'K3' => '平均客单价',
                        'L3' => '平均笔单价',
                        'M3' => '人均下单数',
                        'N3' => '最高购买单价',
                        'O3' => '最高下单数',
                        'P3' => '用户运营',
                        'Q3' => '宝姐珠宝',
                        'R3' => '近3日新粉首购率',
                        'S3' => '近7日新粉首购率',
                        'T3' => '手机号授权',
                        'U3' => '授权率',
                        'V3' => '关注公众号',
                        'W3' => '新关注',
                    ];
                    $excelData = DB::name('moments_add_daily_data')
                        ->field('*')
                        ->where([
                            'type'        => $typeIndexMap[$key],
                            'create_time' => ['<', date('Y-m-d H:i:s', time())]
                        ])
                        ->select();

                    $fillContent($key, $sheetName, $cellValueMap);

                    foreach ($excelData as $contactKey => $value) {
                        $excelKey = $contactKey + 4;

                        // sheet0
                        $sheet0ValueMap = [
                            'A' . $excelKey => date('Y-m-d', strtotime($value['create_time'])),
                            'B' . $excelKey => $value['add_fans_count'],
                            'C' . $excelKey => $value['retained_fans_count'],
                            'D' . $excelKey => $value['retained_rate'] . '%',
                            'E' . $excelKey => $value['join_group_count'],
                            'F' . $excelKey => $value['join_group_rate'] . '%',
                            'G' . $excelKey => $value['valid_join_group_rate'] . '%',
                            'H' . $excelKey => $value['first_order_count'],
                            'I' . $excelKey => $value['first_order_rate'] . '%',
                            'J' . $excelKey => $value['newbie_transfer_count'],
                            'K' . $excelKey => $value['average_customer_price'],
                            'L' . $excelKey => $value['average_unit_price'],
                            'M' . $excelKey => $value['consume_per_capita'],
                            'N' . $excelKey => $value['maximum_purchase_price'],
                            'O' . $excelKey => $value['highest_consume_count'],
                            'P' . $excelKey => $value['user_operation'],
                            'Q' . $excelKey => $value['bojem_jewellery'],
                            'R' . $excelKey => $value['three_first_order_rate'] . '%',
                            'S' . $excelKey => $value['seven_first_order_rate'] . '%',
                            'T' . $excelKey => $value['mobile_auth'],
                            'U' . $excelKey => $value['mobile_auth_rate'] . '%',
                            'V' . $excelKey => $value['follow_official_accounts'],
                            'W' . $excelKey => $value['new_follow'],
                        ];

                        $cellValueFunc($sheet0ValueMap, $key);
                    }
                    // 合并单元格
                    $mergeArr = [
                        'A1' => 'W1',
                        'B2' => 'G2',
                        'H2' => 'O2',
                        'P2' => 'Q2',
                        'R2' => 'S2',
                        'T2' => 'W2'
                    ];

                    foreach ($mergeArr as $mergeKey => $mergeName) {
                        $mergeCell($key, $mergeKey, $mergeName);
                    }

                    $firstLine($key, '每日企微推广加粉数据');

                    $needAlign = [
                        'B2' => '留存',
                        'H2' => '今日新粉转化',
                        'P2' => '转化分布',
                        'R2' => '转化周期',
                        'T2' => '行为',
                    ];

                    foreach ($needAlign as $nameKey => $nameValue) {
                        $align($key, $nameKey, $nameValue);
                    }


                } else {
                    // 整体数据
                    $typeIndexMap = [
                        0 => 165,
                        2 => 166,
                        4 => 190,
                        6 => 151,
                        8 => 146,
                        10 => 203
                    ];

                    $cellValueMap = [
                        'A3' => '日期',
                        'B3' => '累计加粉',
                        'C3' => '留存人数',
                        'D3' => '留存率',
                        'E3' => '在群人数',
                        'F3' => '整体在群率',
                        'G3' => '有效在群率',
                        'H3' => '今日活跃人数',
                        'I3' => '有效活跃率',
                        'J3' => '活跃客户数',
                        'K3' => '客户活跃率',
                        'L3' => '今日群活跃人数',
                        'M3' => '活跃率',
                        'N3' => '活跃客户数',
                        'O3' => '客户活跃率',
                        'P3' => '今日新转化人数',
                        'Q3' => '转化金额',
                        'R3' => '最高购买单价',
                        'S3' => '今日总转化人数',
                        'T3' => '转化金额',
                        'U3' => '最高购买单价',
                        'V3' => '最高下单数',
                        'W3' => '用户运营',
                        'X3' => '宝姐珠宝',
                        'Y3' => '普通',
                        'Z3' => '秒杀',
                        'AA3' => '直播',
                        'AB3' => '拼团',
                        'AC3' => '回放',
                        'AD3' => '换购',
                        'AE3' => '颜值加价购',
                        'AF3' => '众筹',
                        'AG3' => '社群',
                        'AH3' => '0元购',
                        'AI3' => '0元拼',
                        'AJ3' => '累计转化人数',
                        'AK3' => '累计转化单数',
                        'AL3' => '转化率',
                        'AM3' => '累计转化金额',
                        'AN3' => '平均客单价',
                        'AO3' => '平均笔单价',
                        'AP3' => '人均下单数',
                        'AQ3' => '最高购买单价',
                        'AR3' => '最高下单数',
                        'AS3' => '实际转化人数',
                        'AT3' => '实际转化金额',
                        'AU3' => '实际平均客单价',
                        'AV3' => '用户运营',
                        'AW3' => '宝姐珠宝',
                        'AX3' => '普通',
                        'AY3' => '秒杀',
                        'AZ3' => '直播',
                        'BA3' => '拼团',
                        'BB3' => '回放',
                        'BC3' => '换购',
                        'BD3' => '颜值加价购',
                        'BE3' => '众筹',
                        'BF3' => '社群',
                        'BG3' => '0元购',
                        'BH3' => '0元拼',
                        'BI3' => '3日首购率',
                        'BJ3' => '7日首购率',
                        'BK3' => '14日首购率',
                        'BL3' => '30日首购率',
                        'BM3' => '已转化人数平均决策时长',
                        'BN3' => '周复购率',
                        'BO3' => '月复购率',
                        'BP3' => '季度复购率',
                        'BQ3' => '手机号授权',
                        'BR3' => '授权率',
                        'BS3' => '关注公众号',
                        'BT3' => '新关注',
                    ];

                    $excelData = DB::name('moments_add_total_data')
                        ->field('*')
                        ->where([
                            'type'        => $typeIndexMap[$key],
                            'create_time' => ['<', date('Y-m-d H:i:s', time())]
                        ])
                        ->select();

                    $fillContent($key, $sheetName, $cellValueMap);

                    foreach ($excelData as $contactKey => $value) {
                        $excelKey = $contactKey + 4;

                        // sheet0
                        $sheet0ValueMap = [
                            'A' . $excelKey => date('Y-m-d', strtotime($value['create_time'])),
                            'B' . $excelKey => $value['cumulative_fans_count'],
                            'C' . $excelKey => $value['retained_fans_count'],
                            'D' . $excelKey => $value['retained_rate'] . '%',
                            'E' . $excelKey => $value['in_group_fans_count'],
                            'F' . $excelKey => $value['total_group_fans_rate'] . '%',
                            'G' . $excelKey => $value['valid_group_fans_rate'] . '%',
                            'H' . $excelKey => $value['today_active_count'],
                            'I' . $excelKey => $value['valid_active_rate'] . '%',
                            'J' . $excelKey => $value['consume_active_count'],
                            'K' . $excelKey => $value['consume_active_rate'] . '%',
                            'L' . $excelKey => $value['today_group_active_count'],
                            'M' . $excelKey => $value['today_group_active_rate'] . '%',
                            'N' . $excelKey => $value['today_group_consume_active_count'],
                            'O' . $excelKey => $value['today_group_consume_active_rate'] . '%',
                            'P' . $excelKey => $value['today_new_consume_count'],
                            'Q' . $excelKey => $value['today_new_consume_money'],
                            'R' . $excelKey => $value['today_new_maximum_price'],
                            'S' . $excelKey => $value['today_consume_count'],
                            'T' . $excelKey => $value['today_consume_money'],
                            'U' . $excelKey => $value['today_total_maximum_price'],
                            'V' . $excelKey => $value['today_total_maximum_order'],
                            'W' . $excelKey => $value['today_transfer_user'],
                            'X' . $excelKey => $value['today_transfer_jewellery'],
                            'Y' . $excelKey => $value['today_normal'],
                            'Z' . $excelKey => $value['today_second'],
                            'AA' . $excelKey => $value['today_live'],
                            'AB' . $excelKey => $value['today_group'],
                            'AC' . $excelKey => $value['today_playback'],
                            'AD' . $excelKey => $value['today_change'],
                            'AE' . $excelKey => $value['today_yanzhi'],
                            'AF' . $excelKey => $value['today_crowd_funding'],
                            'AG' . $excelKey => $value['today_community'],
                            'AH' . $excelKey => $value['today_zero_bug'],
                            'AI' . $excelKey => $value['today_zero_group'],
                            'AJ' . $excelKey => $value['cumulative_consume_count'],
                            'AK' . $excelKey => $value['cumulative_order_count'],
                            'AL' . $excelKey => $value['cumulative_consume_rate'] . '%',
                            'AM' . $excelKey => $value['cumulative_consume_money'],
                            'AN' . $excelKey => $value['average_consume_price'],
                            'AO' . $excelKey => $value['average_bill_price'],
                            'AP' . $excelKey => $value['average_consume_bill_count'],
                            'AQ' . $excelKey => $value['highest_price'],
                            'AR' . $excelKey => $value['highest_order_count'],
                            'AS' . $excelKey => $value['valid_transfer_count'],
                            'AT' . $excelKey => $value['valid_transfer_money'],
                            'AU' . $excelKey => $value['valid_average_consume_price'],
                            'AV' . $excelKey => $value['cumulative_user'],
                            'AW' . $excelKey => $value['cumulative_jewellery'],
                            'AX' . $excelKey => $value['cumulative_normal'],
                            'AY' . $excelKey => $value['cumulative_second'],
                            'AZ' . $excelKey => $value['cumulative_live'],
                            'BA' . $excelKey => $value['cumulative_group'],
                            'BB' . $excelKey => $value['cumulative_playback'],
                            'BC' . $excelKey => $value['cumulative_change'],
                            'BD' . $excelKey => $value['cumulative_yanzhi'],
                            'BE' . $excelKey => $value['cumulative_crowd_funding'],
                            'BF' . $excelKey => $value['cumulative_community'],
                            'BG' . $excelKey => $value['cumulative_zero_buy'],
                            'BH' . $excelKey => $value['cumulative_zero_group'],
                            'BI' . $excelKey => $value['three_first_order_rate'] . '%',
                            'BJ' . $excelKey => $value['seven_first_order_rate'] . '%',
                            'BK' . $excelKey => $value['fourteen_first_order_rate'] . '%',
                            'BL' . $excelKey => $value['thirty_first_order_rate'] . '%',
                            'BM' . $excelKey => $value['transfer_average_decision'],
                            'BN' . $excelKey => $value['week_repurchase_rate'] . '%',
                            'BO' . $excelKey => $value['month_repurchase_rate'] . '%',
                            'BP' . $excelKey => $value['quarter_repurchase_rate'] . '%',
                            'BQ' . $excelKey => $value['mobile_auth'],
                            'BR' . $excelKey => $value['auth_rate'] . '%',
                            'BS' . $excelKey => $value['follow_wechat_media'],
                            'BT' . $excelKey => $value['new_follow'],
                        ];

                        $cellValueFunc($sheet0ValueMap, $key);
                    }

                    // 合并单元格
                    $mergeArr = [
                        'A1' => 'BT1',
                        'B2' => 'O2',
                        'P2' => 'V2',
                        'W2' => 'AI2',
                        'AJ2' => 'AU2',
                        'AV2' => 'BH2',
                        'BI2' => 'BM2',
                        'BN2' => 'BP2',
                        'BQ2' => 'BT2'
                    ];

                    foreach ($mergeArr as $mergeKey => $mergeName) {
                        $mergeCell($key, $mergeKey, $mergeName);
                    }

                    $firstLine($key, '企微推广加粉整体数据');

                    $totalNeedAlign = [
                        'B2' => '留存',
                        'P2' => '今日转化',
                        'W2' => '今日转化分布',
                        'AJ2' => '累计转化',
                        'AV2' => '累计转化分布',
                        'BI2' => '转化周期',
                        'BN2' => '复购周期',
                        'BQ2' => '行为'
                    ];

                    foreach ($totalNeedAlign as $nameKey => $nameValue) {
                        $align($key, $nameKey, $nameValue);
                    }
                }
            }
        });

        $mediaHttpDao = new MediaHttpDao();
        $realPath = './public/downloads/' . $excelTitle . '.xlsx';
        $uploadRes = $mediaHttpDao->uploadMedia(MediaHttpDao::FILE, $realPath, $excelTitle . '.xlsx');
        @unlink($realPath);

        $msgHttpDao = new MessageHttpDao();
        $msgHttpDao->sendMessage(MediaHttpDao::FILE, ['media_id' => $uploadRes['media_id']], $toUser);
    }
}
