<?php

namespace app\api\command;

use app\api\service\message\impl\MessageServiceImpl;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * Class SendStatisticsData
 * @package app\api\command
 */
class SendStatisticsData extends Command
{
    protected function configure()
    {
        $this->setName('sendStatisticsData')->setDescription('发送统计数据');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return string
     */
    protected function execute(Input $input, Output $output): string
    {
        ini_set('memory_limit', '520M');
        $messageService = new MessageServiceImpl();

        try {
            $messageService->sendStatisticsData(
                [
                    'chebin','lvjunyan','zhongyongping',
                    'jiamin','feiyue','zhaowei','liyin',
                    'zhangji', 'xuliang','zhujing'
                ],
                1
            );

            $messageService->sendStatisticsData(
                [
                    'chebin','lvjunyan','zhongyongping',
                    'jiamin','feiyue','zhaowei',
                    'xuliang','zhujing',
                ],
                2
            );

            $messageService->sendStatisticsData(['chebin','peiyonghao'], 3);

            //$messageService->sendStatisticsData(['chebin'], 4);
            return '发送成功！';
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }
}
