<?php

namespace app\api\command;

use app\api\service\message\impl\MessageServiceImpl;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// */15 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendVideoMsg >> sendVideoMsg.log
/**
 * 每隔15分钟
 *
 * Class SendVideoMsg
 * @package app\api\command
 */
class SendVideoMsg extends Command
{
    protected function configure()
    {
        $this->setName('sendVideoMsg')->setDescription('发送视频号统计数据到企业微信');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $messageService = new MessageServiceImpl();

        /*$messageService->sendVideoMsg([
            'chebin',
            // 'lvjunyan'
        ]);*/

        $messageService->sendVideoMsg([
            'chebin',
            'zhongming',
            'lvjunyan',
            'jiamin',
            'liyin',
            'feiyue',
            'zhongyongping',
            'zhujing',
            'xuliang',
            'zhaowei',
            'xulan',
            'yangchaofan',
            'zhangji',
        ]);

        echo 'success-' . date('Y-m-d H:i:s') . PHP_EOL;
    }
}
