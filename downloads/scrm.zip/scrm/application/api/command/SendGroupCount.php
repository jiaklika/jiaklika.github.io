<?php

namespace app\api\command;

use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Exception;
use think\Cache;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Log;
use think\Queue;

/**
 * 20 9 * * 1 cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendGroupCount >> 123.log
 * 每周一9点20执行
 *
 * #123 用户运营社群消费数据统计2
 * https://bojem.coding.net/p/scrm/backlog/issues/123
 *
 * Class SendGroupCount
 * @package app\api\command
 */
class SendGroupCount extends Command
{
    protected function configure()
    {
        $this->setName('sendGroupCount')->setDescription('每周一统计并发送好物优享群、新粉福利群两个类型群下所有子群的汇总数据');
    }

    /**
     * @param Input $input
     * @param Output $output
     * @return int|void|null
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $redis = Cache::store()->handler();
        // 队列名
        $jobQueue = 'group_count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\GroupCountJob';

        $groupData = ContactGroups::GROUP_MAP;

        foreach ($groupData as $groupEnglish => $groupName) {
            $groupList = ContactGroupDao::getAllList(
                [
                    'chat_id'
                ],
                [
                    'name'  => ['like', "%{$groupName}%"],
                ]
            );

            if (empty($groupList)) {
                return false;
            }

            $redis->set("{$groupEnglish}_group_num_count", count($groupList));

            $chatIdArr = array_column($groupList, 'chat_id');

            foreach ($chatIdArr as $value) {
                // 群的全部人员
                $allGroupMemberArr = ContactGroupMembersDao::getAllList(
                    [
                        'userid',
                        'unionid'
                    ],
                    [
                        'chat_id'    => $value,
                        'is_deleted' => 0,
                        'type'       => ContactGroupMembers::EXTERNAL_USER
                    ]
                );

                foreach ($allGroupMemberArr as $member) {
                    $redis->incr("{$groupEnglish}_group_member_count");
                    try {
                        // 推送到队列
                        $isPushed = Queue::push($jobHandler, $member, $jobQueue);

                        if ($isPushed !== false) {
                            continue;
                        }
                    } catch (Exception $e) {
                        Log::error('队列出错：' . $e->getMessage());
                        return false;
                    }
                }
            }

            sleep(1);

            Queue::push($jobHandler, ["{$groupEnglish}_end" => true], $jobQueue);
        }
    }
}
