<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactTags;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;
use think\Log;

/**
 * Class RemoveTag
 * @package app\api\command
 */
class RemoveTag extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('removeTag')->setDescription('移除错误的是否入群标签');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return bool
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $userServiceImpl = new UserServiceImpl();

        $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue');
        $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $removeTag = ContactTags::NOT_IN_FEIYUE_GROUP_TAG;

        $wrongTagArr = (array)Db::name('contact_tag_map')
            ->alias('a')
            ->join('contact_group_members b', 'a.external_userid = b.userid', 'LEFT')
            ->join('contact_groups c', 'c.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.external_userid' ,
                'a.userid',
                'b.chat_id'
            ])->where([
                'b.is_deleted' => 0,
                'c.owner'      => ['in', $feiyueAccountsArr],
                'a.tag_id'     => $removeTag
            ])
            ->select();

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($wrongTagArr as $tagMap) {
            try {
                $contactTagHttpDao->markTag(
                    $tagMap['userid'],
                    $tagMap['external_userid'],
                    [],
                    [$removeTag]
                );

                ContactTagMapDao::hardDelete([
                    'tag_id'          => $removeTag,
                    'external_userid' => $tagMap['external_userid'],
                    'userid'          => $tagMap['userid']
                ]);
            } catch (Exception $e) {
                Log::error($e->getMessage());
                continue;
            }
        }

        return true;
    }
}
