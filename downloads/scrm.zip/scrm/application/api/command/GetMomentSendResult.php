<?php

namespace app\api\command;

use app\api\dao\mysql\message\GroupMsgIdMapDao;
use app\common\model\groupMsg\GroupMsgIdMap;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;

// crontab 每隔1分钟
// */1 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think groupMsgSendResult

/**
 * Class GetMomentSendResult
 * @package app\api\command
 */
class GetMomentSendResult extends Command
{
    /**
     * 配置指令
     */
    protected function configure()
    {
        $this->setName('getMomentSendResult')->setDescription('获取定时朋友圈发送结果');
    }

    /**
     * 执行指令
     *
     * @param  Input  $input
     * @param  Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        $getSendResult = function ($results) {
            if (empty($results)) {
                return false;
            }
        };
        /*
         */
        GroupMsgIdMapDao::handleDataByChunk(
            [
                'id',
                'template_id',
                'sender_user_id',
                'msg_id'
            ],
            [
                'is_get_result' => GroupMsgIdMap::NOT_GET_RESULT
            ],
            10,
            $getSendResult
        );
    }
}
