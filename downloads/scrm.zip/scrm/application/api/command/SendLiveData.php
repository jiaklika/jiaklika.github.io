<?php

namespace app\api\command;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\liveData\LiveAudienceDataDao;
use app\api\dao\mysql\liveData\LiveDataDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\liveData\LiveData;
use app\common\model\liveData\LiveAudienceData;
use Exception;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Db;

// crontab
// */10 * * * * cd /home/wwwroot/scrm && /usr/local/php/bin/php think sendLiveData

/**
 *
 * Class SendLiveData
 * @package app\api\command
 */
class SendLiveData extends Command
{
    protected function configure()
    {
        $this->setName('sendLiveData')->setDescription('企微直播数据');
    }

    /**
     * @param  Input  $input
     * @param  Output $output
     * @return void
     * @throws Exception
     */
    protected function execute(Input $input, Output $output)
    {
        ini_set('memory_limit', '520M');
        $sendLiveData = function ($results) {
            // $ChannelId = 67; // 视频号直播导流电商——阳阳5（费月）

            /*$toUsers = [
                'chebin'
            ];*/

            $toUsers = [
                'chebin',
                'lvjunyan',
                'jiamin',
                'feiyue',
                'zhaowei',
                'zhongyongping',
                'liyin',
                'gulinlin',
                'zhongming',
                'xuliang',
                'xulan',
                'yangchaofan',
                'zhangji',
                'zhujing',
            ];

            $messageHttpDao = new MessageHttpDao();
            $userService    = new UserServiceImpl();
            $contactHttpDao = new ContactHttpDao();

            $feiyueAccounts  = $userService->getSpecificUserAccount('feiyue', false);
            $zhaoweiAccounts = $userService->getSpecificUserAccount('zhaowei', false);

            foreach ($results as $result) {
                $getAllUnionId = function ($where = []) use ($result) {

                    $liveUserData = (array)Db::name('live_audience_data')
                        ->field([
                            'unionid',
                            'is_consume',
                            'is_first_order'
                        ])
                        ->where(array_merge([
                            'live_id' => $result['live_id']
                        ], $where))
                        ->select();

                    return array_column($liveUserData, 'unionid');
                };


                $allUserUnionId = $getAllUnionId();
                $allConsumeUnionId = $getAllUnionId([
                    'is_consume' => LiveAudienceData::IS_CONSUME
                ]);
                $allFirstOrderUnionId = $getAllUnionId([
                    'is_first_order' => LiveAudienceData::IS_FIRST_ORDER
                ]);
                $luckDrawUnionId = $getAllUnionId([
                    'is_luck_draw' => LiveAudienceData::IS_LUCK_DRAW
                ]);

                $totalAudienceCount = 0;

                $organizeData = function (
                    $allUnionId,
                    $isConsume = false,
                    $firstOrder = false,
                    $isLuckDraw = false
                ) use (
                    $feiyueAccounts,
                    $zhaoweiAccounts,
                    $result,
                    $contactHttpDao,
                    // $ChannelId,
                    &$totalAudienceCount,
                    &$level0,
                    &$level1,
                    &$level2,
                    &$level3,
                    &$level4,
                    &$level5,
                    &$level6
                ) {
                    $level0 = $level1 = $level2 = $level3 = $level4 = $level5 = $level6 = 0;

                    $userCount = count($allUnionId);

                    if (!$isConsume) {
                        $totalAudienceCount = $userCount;
                    }

                    $getExternalContactArr = function (array $where = []) use ($allUnionId) {
                        $externalContactArr = (array)Db::name('contact_follow_user')
                            ->alias('a')
                            ->join(
                                'external_contact b',
                                'a.external_userid = b.external_userid',
                                'left'
                            )
                            ->field([
                                'unionid'
                            ])
                            ->where(array_merge([
                                'unionid' => ['in', $allUnionId],
                                'status'  => ContactFollowUser::NORMAL
                            ], $where))
                            ->group('unionid')
                            ->select();

                        return array_column($externalContactArr, 'unionid');
                    };

                    $externalContactUnionIdArr = $getExternalContactArr();

                    if ($result['live_type'] == LiveData::VIDEO_LIVE) {
                        // 在直播开始前就已经添加了企微或进群的人数
                        $beforeUnionIdArr = $getExternalContactArr([
                            'createtime' => ['<=', $result['start_time']],
                        ]);

                        $beforeGroupMembers = ContactGroupMembersDao::getAllList([
                            'unionid'
                        ], [
                            'unionid'   => ['in', $externalContactUnionIdArr],
                            'join_time' => ['<=', $result['start_time']]
                        ]);
                        $externalContactUnionIdArr = array_unique(array_merge(
                            $beforeUnionIdArr,
                            array_column($beforeGroupMembers, 'unionid')
                        ));
                    }

                    $countLevelClosure = function ($allUnionIdArr) use (
                        $contactHttpDao,
                        &$level0,
                        &$level1,
                        &$level2,
                        &$level3,
                        &$level4,
                        &$level5,
                        &$level6
) {
                        foreach ($allUnionIdArr as $singleUnionId) {
                            try {
                                $userCenterInfo = $contactHttpDao->getUserCenter($singleUnionId);
                            } catch (Exception $e) {
                                continue;
                            }

                            switch ($userCenterInfo['user_level_id']) {
                                case 0:
                                    $level0 += 1;
                                    break;

                                case 1:
                                    $level1 += 1;
                                    break;

                                case 2:
                                    $level2 += 1;
                                    break;

                                case 3:
                                    $level3 += 1;
                                    break;

                                case 4:
                                    $level4 += 1;
                                    break;

                                case 5:
                                    $level5 += 1;
                                    break;

                                case 6:
                                    $level6 += 1;
                                    break;
                            }
                        }
                    };
                    $countLevelClosure($allUnionId);

                    $externalContactCount = count($externalContactUnionIdArr);

                    $rate = get_rate($externalContactCount, $userCount);

                    $getSpecificAccountCount = function ($accounts, $where = []) use ($allUnionId) {
                        return (array)Db::name('contact_follow_user')
                            ->alias('a')
                            ->join(
                                'external_contact b',
                                'a.external_userid = b.external_userid',
                                'left'
                            )
                            ->field([
                                'unionid'
                            ])
                            ->where([
                                'userid'  => ['in', $accounts],
                                'unionid' => ['in', $allUnionId],
                                'status'  => ContactFollowUser::NORMAL
                            ])
                            ->where($where)
                            ->group('unionid')
                            ->select();
                    };

                    $feiyueUnionIdArr  = $getSpecificAccountCount($feiyueAccounts);
                    $zhaoweiUnionIdArr = $getSpecificAccountCount($zhaoweiAccounts);

                    $feiyueCount  = count($feiyueUnionIdArr);
                    $zhaoweiCount = count($zhaoweiUnionIdArr);

                    $onlyZhaoweiCount = count(
                        array_diff(
                            array_column($zhaoweiUnionIdArr, 'unionid'),
                            array_column($feiyueUnionIdArr, 'unionid')
                        )
                    );
                    // 群人数数据
                    $getGroup = function ($accounts, $extraWhere = []) use ($allUnionId) {
                        $where = [
                            'b.owner'      => ['in', $accounts],
                            'a.is_deleted' => ContactGroups::NOT_DELETED,
                            'b.is_deleted' => ContactGroupMembers::NOT_DELETED
                        ];

                        $where['unionid'] = $allUnionId ? ['in', $allUnionId] : null;

                        return (array)Db::name('contact_group_members')
                            ->alias('a')
                            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'left')
                            ->field([
                                'unionid'
                            ])
                            ->where($where)
                            ->where($extraWhere)
                            ->group('unionid')
                            ->select();
                    };

                    $feiyueGroupArr  = $getGroup($feiyueAccounts);
                    $zhaoweiGroupArr = $getGroup($zhaoweiAccounts);

                    $feiyueGroupUnionIdArr  = array_column($feiyueGroupArr, 'unionid');
                    $zhaoweiGroupUnionIdArr = array_column($zhaoweiGroupArr, 'unionid');

                    $feiyueGroupCount = count($feiyueGroupArr);
                    $zhaoweiGroupCount = count($zhaoweiGroupArr);

                    $onlyZhaoweiGroupCount = count(
                        array_diff(
                            $zhaoweiGroupUnionIdArr,
                            $feiyueGroupUnionIdArr
                        )
                    );

                    // 在费月社群
                    $feiyueShareCount = count($getGroup($feiyueAccounts, [
                        'b.name' => ['like', '%知识%']
                    ]));

                    $feiyueYanzhiCount = count($getGroup($feiyueAccounts, [
                        'b.name' => ['like', '%捡漏%']
                    ]));

                    $feiyueOtherCount = count($getGroup($feiyueAccounts, [
                        'b.name' => ['not like', '%知识%'],
                        'name'   => ['not like', '%捡漏%']
                    ]));

                    // 在阳阳社群
                    /*$zhaoweiDiscountGroupArr = $getGroup($zhaoweiAccounts, [
                        'b.name' => ['like', '%优惠%']
                    ]);
                    $zhaoweiDiscountCount = count($zhaoweiDiscountGroupArr);*/

                    $zhaoweiNewFansGroupArr = $getGroup($zhaoweiAccounts, [
                        'b.name' => ['like', '%新粉福利%']
                    ]);
                    $zhaoweiNewFansCount = count($zhaoweiNewFansGroupArr);

                    $zhaoweiOrnamentsGroupArr = $getGroup($zhaoweiAccounts, [
                        'b.name' => ['like', '%饰界%'],
                    ]);
                    $zhaoweiOrnamentsCount = count($zhaoweiOrnamentsGroupArr);

                    $zhaoweiGoodStuffGroupArr = $getGroup($zhaoweiAccounts, [
                        'b.name' => ['like', '%好物优享%'],
                    ]);
                    $zhaoweiGoodStuffCount = count($zhaoweiGoodStuffGroupArr);

                    $zhaoweiVipGroupArr = $getGroup($zhaoweiAccounts, [
                        'b.name' => ['like', '%宝姐家好物专享%'],
                    ]);
                    $zhaoweiVipCount = count($zhaoweiVipGroupArr);

                    // 只在阳阳社群（不在费月名下社群）
                    /*$zhaoweiDiscountGroupUnionIdArr = array_column(
                        $zhaoweiDiscountGroupArr,
                        'unionid'
                    );

                    $zhaoweiDiscountArr = array_diff($zhaoweiDiscountGroupUnionIdArr, $feiyueGroupUnionIdArr);

                    $onlyZhaoweiDiscountCount = count($zhaoweiDiscountArr);*/

                    // 新粉福利
                    $zhaoweiNewFansGroupUnionIdArr = array_column(
                        $zhaoweiNewFansGroupArr,
                        'unionid'
                    );

                    $zhaoweiNewFansArr = array_diff($zhaoweiNewFansGroupUnionIdArr, $feiyueGroupUnionIdArr);

                    $onlyZhaoweiNewFansCount = count($zhaoweiNewFansArr);

                    // 饰界福利
                    $zhaoweiOrnamentsGroupUnionIdArr = array_column(
                        $zhaoweiOrnamentsGroupArr,
                        'unionid'
                    );

                    $zhaoweiOrnamentsArr = array_diff($zhaoweiOrnamentsGroupUnionIdArr, $feiyueGroupUnionIdArr);

                    $onlyZhaoweiOrnamentsCount = count($zhaoweiOrnamentsArr);

                    // 好物优享
                    $zhaoweiGoodStuffGroupUnionIdArr = array_column(
                        $zhaoweiGoodStuffGroupArr,
                        'unionid'
                    );

                    $zhaoweiGoodStuffArr = array_diff($zhaoweiGoodStuffGroupUnionIdArr, $feiyueGroupUnionIdArr);

                    $onlyZhaoweiGoodStuffCount = count($zhaoweiGoodStuffArr);

                    // 宝姐家好物专享群
                    $zhaoweiVipGroupUnionIdArr = array_column(
                        $zhaoweiVipGroupArr,
                        'unionid'
                    );

                    $zhaoweiVipArr = array_diff($zhaoweiVipGroupUnionIdArr, $feiyueGroupUnionIdArr);

                    $onlyZhaoweiVipCount = count($zhaoweiVipArr);

                    $blockName         = $result['live_type'] == LiveData::MINI_PROGRAM_LIVE ? '观看' : '购物袋跳转小程序';
                    $allCountFieldName = $result['live_type'] == LiveData::MINI_PROGRAM_LIVE ? '观看总' : '跳转';
                    $workFieldName     = $result['live_type'] == LiveData::MINI_PROGRAM_LIVE
                        ? '企微人数'
                        : '其中企微人数（排除当场直播首次添加企微的人）';

                    if (!$isConsume) {
                        $content['content'] = "
            >－－－－－－{$blockName}数据－－－－－－     
            >{$allCountFieldName}人数：{$userCount}人";

                        if ($result['live_type'] == LiveData::MINI_PROGRAM_LIVE) {
                            $getPlatformCount = function (int $platform) use ($result) {
                                return LiveAudienceDataDao::getCount([
                                    'live_id'  => $result['live_id'],
                                    'platform' => $platform
                                ]);
                            };

                            $shopWatchCount  = $getPlatformCount(1);
                            $mediaWatchCount = $getPlatformCount(2);
                            $appWatchCount   = $getPlatformCount(3);

                            $content['content'] .=
                                " 宝姐珠宝：{$shopWatchCount}人 宝姐家：{$mediaWatchCount}人 APP：{$appWatchCount}人";
                        }
                    } else {
                        $consumeRate = get_rate($userCount, $totalAudienceCount);

                        if (
                            $result['live_type'] == LiveData::VIDEO_LIVE
                            && $firstOrder
                        ) {
                            $content['content'] = ">－－－－－－新客数据－－－－－－
            >产生新客：{$userCount}人 占比：{$consumeRate}";
                        } else {
                            $content['content'] = "
            >－－－－－－购买数据－－－－－－
            >购买人数：{$userCount}人 占比：{$consumeRate}";
                        }
                    }

                    if ($isLuckDraw) {
                        $content['content'] = ">－－－－－－抽奖数据－－－－－－     
            >参与抽奖人数：{$userCount}人";
                    }

                    // if ($result['live_type'] == LiveData::VIDEO_LIVE && !$isConsume) {
                    // if ($result['live_type'] == LiveData::VIDEO_LIVE && !$firstOrder) {
                    if (!$firstOrder || $isLuckDraw) {
                        $content['content'] .= "
            >人群画像：新人{$level0}人 宝迷{$level1}人 忠实宝迷{$level2}人 铁杆宝迷{$level3}人 名媛{$level4}人 风尚名媛{$level5}人 至尊名媛{$level6}人";
                    }

                    /*$content['content'] .= "
            >{$workFieldName}：{$externalContactCount}人 占比：{$rate}
            >在宝姐家福利官号：{$feiyueCount}人
            >在阳阳号：{$zhaoweiCount}人
            >只在阳阳号（不在宝姐家福利官号）：{$onlyZhaoweiCount}人
            >在泛流量社群：{$feiyueGroupCount}人  知识群：{$feiyueShareCount}人  捡漏群：{$feiyueYanzhiCount}人  其他群：{$feiyueOtherCount}人
            >在电商社群：{$zhaoweiGroupCount}人  新粉福利群：{$zhaoweiNewFansCount}人  饰界福利秒杀群：{$zhaoweiOrnamentsCount}人  好物优享群：{$zhaoweiGoodStuffCount}人 宝姐家好物专享群：{$zhaoweiVipCount}人
            >只在电商社群（不在泛流量社群）：{$onlyZhaoweiGroupCount}人  新粉福利群：{$onlyZhaoweiNewFansCount}人  饰界福利秒杀群：{$onlyZhaoweiOrnamentsCount}人  好物优享群：{$onlyZhaoweiGoodStuffCount}人 宝姐家好物专享群：{$onlyZhaoweiVipCount}人";*/

                    $content['content'] .= "
            >{$workFieldName}：{$externalContactCount}人 占比：{$rate}
            >在阳阳号：{$zhaoweiCount}人
            >在电商社群：{$zhaoweiGroupCount}人  新粉福利群：{$zhaoweiNewFansCount}人  饰界福利秒杀群：{$zhaoweiOrnamentsCount}人  好物优享群：{$zhaoweiGoodStuffCount}人 宝姐家好物专享群：{$zhaoweiVipCount}人";

                    if ($isLuckDraw) {
                        $consumeAndLuckDrawUnionIdArr = LiveAudienceDataDao::getAllList(
                            [
                                'unionid'
                            ],
                            [
                                'live_id'      => $result['live_id'],
                                'is_consume'   => LiveAudienceData::IS_CONSUME,
                                'is_luck_draw' => LiveAudienceData::IS_LUCK_DRAW
                            ]
                        );

                        $consumeAndLuckDrawUnionId = array_column($consumeAndLuckDrawUnionIdArr, 'unionid');

                        $consumeAndLuckDrawCount = count($consumeAndLuckDrawUnionId);
                        $level0 = $level1 = $level2 = $level3 = $level4 = $level5 = $level6 = 0;

                        $countLevelClosure($consumeAndLuckDrawUnionId);

                        $content['content'] .= "     
            >参与抽奖并消费人数：{$consumeAndLuckDrawCount}人
            >人群画像：新人{$level0}人 宝迷{$level1}人 忠实宝迷{$level2}人 铁杆宝迷{$level3}人 名媛{$level4}人 风尚名媛{$level5}人 至尊名媛{$level6}人";
                    }

                    return $content['content'];
                };

                $liveDate = date('Y-m-d', $result['start_time']);

                $startTime = date('Y-m-d H:i:s', $result['start_time']);

                if ($result['live_type'] == LiveData::MINI_PROGRAM_LIVE) {
                    $content['content'] = "{$liveDate} 【小程序直播社群数据】";
                } else {
                    $content['content'] =
                        "{$liveDate} 【<font color='warning'>视频号直播数据</font>】 <font color='info'>{$startTime}开播</font>";
                }

                if ($result['live_type'] == LiveData::MINI_PROGRAM_LIVE) {
                    $content['content'] .= "
>场次名称：<font color='warning'>{$result['live_name']}</font>  <font color='info'>{$startTime}开播</font>";
                }

                $content['content'] .= $organizeData($allUserUnionId);
                $content['content'] .= $organizeData($allConsumeUnionId, true);

                $newConsumerContent['content'] = '';

                if ($result['live_type'] == LiveData::VIDEO_LIVE) {
                    $newConsumerContent['content'] .= $organizeData($allFirstOrderUnionId, true, true);
                }

                // 抽奖数据
                $luckDrawContent['content'] = $organizeData($luckDrawUnionId, true, true, true);

                try {
                    $messageHttpDao->sendMessage('markdown', $content, $toUsers);
                    if ($result['live_type'] == LiveData::VIDEO_LIVE) {
                        $messageHttpDao->sendMessage('markdown', $newConsumerContent, $toUsers);
                    } else {
                        $messageHttpDao->sendMessage('markdown', $luckDrawContent, $toUsers);
                    }

                    LiveDataDao::updateData(['is_send' => LiveData::IS_SEND], [
                        'id' => $result['id']
                    ]);
                } catch (Exception $e) {
                    throw new Exception($e->getMessage());
                }
                sleep(1);
            }
        };

        Db::name('live_data')
            ->field([
                'id',
                'live_id',
                'live_name',
                'live_type',
                'start_time'
            ])
            ->where([
                'is_end'  => LiveData::IS_END,
                'is_send' => LiveData::NOT_SEND
            ])
            ->chunk(2, $sendLiveData);
    }
}
