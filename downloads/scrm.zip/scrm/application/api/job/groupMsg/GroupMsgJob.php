<?php

namespace app\api\job\groupMsg;

use app\api\dao\http\message\GroupMsgHttpDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\message\GroupMsgIdMapDao;
use app\api\dao\mysql\message\GroupMsgReceiveMapDao;
use app\api\dao\mysql\message\GroupMsgTemplatesDao;
use app\api\job\BaseJob;
use app\common\model\ContactFollowUser;
use app\common\model\groupMsg\GroupMsgTemplates;
use Exception;
use Redis;
use think\Cache;
use think\Db;

/**
 * 发送群发异步队列
 * nohup php think queue:work --queue send_group_msg_queue --daemon >/dev/null 2>&1 &
 *
 * Class GroupMsgJob
 * @package app\api\job\groupMsg
 */
class GroupMsgJob extends BaseJob
{
    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();
        $groupHttpDao = new GroupMsgHttpDao();
        $templateId = $carryData['template_id'];
        $senderArr = $carryData['sender'] ?? []; // 发送者
        $tagArr = $carryData['tags'] ?? []; // 要发送的标签

        $redisKeyName = sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_SET_KEY_NAME, $templateId);

        // 去重
        $writeRedisToUnique = function ($results) use ($redis, $templateId, $redisKeyName) {
            if (!$results) {
                return false;
            }

            try {
                $redis->pipeline();

                foreach ($results as $contact) {
                    $redis->hset(
                        sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $templateId),
                        $contact['external_userid'],
                        $contact['userid']
                    );
                }
                $redis->exec();

                return true;
            } catch (Exception $e) {
                send_msg_to_wecom('群发数据刷进Redis出错！' . $e->getMessage());
                return false;
            }
        };

        $where = [
            'status' => ContactFollowUser::NORMAL
        ];

        switch ($carryData['receiver_range']) {
            case 0: // 全部
            default:
                // 找出所有接收客户，通过hash数据结构去重
                Db::name('contact_follow_user')
                    ->field([
                        'id', // chunk需要主键ID
                        'userid',
                        'external_userid',
                    ])
                    ->where($where)
                    ->chunk(10000, $writeRedisToUnique);

                break;

            case 1: // 只按用户筛选
                $where = array_merge(['userid' => ['in', $senderArr]], $where);
                // 找出所有接收客户，通过hash数据结构去重
                Db::name('contact_follow_user')
                    ->field([
                        'id', // chunk需要主键ID
                        'userid',
                        'external_userid',
                    ])
                    ->where($where)
                    ->chunk(10000, $writeRedisToUnique);
                break;

            case 3: // 按用户和标签一起搜
                // 重新组织tag为二维数组
                $tagGroupArr = ContactTagsDao::getAllList(
                    [
                        'group_id',
                        'tag_id'
                    ],
                    [
                        'tag_id' => ['in', $tagArr]
                    ]
                );

                $tagRes = [];
                foreach ($tagGroupArr as $v) {
                    $tagRes[$v['group_id']][] = $v['tag_id'];
                }

                $newTagArr = array_values($tagRes);

                $where = array_merge(
                    [
                        'map.userid' => ['in', $senderArr]
                    ],
                    $where
                );

                foreach ($newTagArr as $tagKey => $tagValue) {
                    Db::name('contact_follow_user')
                        ->alias('follow')
                        ->join(
                            'scrm_contact_tag_map map',
                            'follow.external_userid = map.external_userid',
                            'LEFT'
                        )
                        ->field([
                            'follow.id',
                            'map.userid',
                            'follow.external_userid'
                        ])
                        ->where($where)
                        ->where([
                            'tag_id' => ['in', $tagValue]
                        ])
                        ->chunk(10000, function ($results) use ($redis, $templateId, $tagKey, $redisKeyName) {
                            if (!$results) {
                                return false;
                            }

                            try {
                                $redis->pipeline();

                                foreach ($results as $contact) {
                                    $redis->sadd(
                                        sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_SET_KEY_NAME, $tagKey),
                                        $contact['external_userid']
                                    );

                                    $redis->hset(
                                        sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $templateId),
                                        $contact['external_userid'],
                                        $contact['userid']
                                    );
                                }
                                $redis->exec();

                                return true;
                            } catch (\think\Exception $e) {
                                send_msg_to_wecom('群发数据刷进Redis出错！' . $e->getMessage());
                                return false;
                            }
                        }, 'follow.id');
                }
                $redis->sadd($redisKeyName, '');
                foreach ($newTagArr as $key => $tagValue) {
                    if ($key == 0) {
                        $redis->sUnionStore(
                            $redisKeyName,
                            $redisKeyName,
                            sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_SET_KEY_NAME, $key)
                        );
                    }

                    $redis->sInterStore(
                        $redisKeyName,
                        $redisKeyName,
                        sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_SET_KEY_NAME, $key)
                    );
                    $redis->del(sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_SET_KEY_NAME, $key));
                }
                break;
        }

        // 读取
        $redis->setOption(Redis::OPT_SCAN, Redis::SCAN_RETRY);

        $contactIterator = null;

        $receiveMapInsertData = [];

        try {
            while (
                $contacts = $redis->hscan(
                    sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $templateId),
                    $contactIterator,
                    '*',
                    10000
                )
            ) {
                if ($carryData['receiver_range'] == 3) {
                    foreach ($contacts as $key => $contact) {
                        if ($redis->sIsMember($redisKeyName, $key)) {
                            $receiveMapInsertData[] = [ // 存储进接收客户记录表
                                'template_id'     => $templateId,
                                'external_userid' => $key,
                                'user_id'         => $contact,
                            ];
                        }
                    }
                }

                if ($carryData['receiver_range'] !== 3) {
                    foreach ($contacts as $key => $contact) {
                        $receiveMapInsertData[] = [ // 存储进接收客户记录表
                            'template_id'     => $templateId,
                            'external_userid' => $key,
                            'user_id'         => $contact,
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            send_msg_to_wecom('redis读取接收客户记录失败！');
        }
        if ($receiveMapInsertData) {
            if (!GroupMsgReceiveMapDao::addBatchData($receiveMapInsertData)) {
                send_msg_to_wecom('写入接收客户记录失败！');
                return false;
            }
        }

        // 一个一个客服读
        // 每次最多可传入1万个客户，如果一个客服有1万5000个客户，就要分两次发，就有两个msg_id
        $groupMsgIdMapInsertData = $failList = [];
        foreach ($senderArr as $sender) {
            Db::name('group_msg_receive_map')
                ->field([
                    'id',
                    'user_id',
                    'external_userid'
                ])
                ->where([
                    'template_id' => $templateId,
                    'user_id'     => $sender
                ])
                ->chunk(10000, function ($receiverArr) use (
                    $groupHttpDao,
                    $sender,
                    $carryData,
                    &$groupMsgIdMapInsertData,
                    &$failList
                ) {
                    if (!$receiverArr) {
                        return false;
                    }

                    $sendExternalUserIdArr = array_column($receiverArr, 'external_userid');

                    try {
                        $addHttpRes = $groupHttpDao->addMessageTemplate(
                            GroupMsgHttpDao::SINGLE,
                            $sendExternalUserIdArr, // 最多可传入1万个客户
                            $sender,
                            $carryData['content_text'],
                            $carryData['msg_type'],
                            $carryData['type_data']
                        );

                        if ($addHttpRes['fail_list']) {
                            $failList = array_merge($failList, $addHttpRes['fail_list']);
                        }

                        $groupMsgIdMapInsertData[] = [
                            'template_id'    => $carryData['template_id'],
                            'sender_user_id' => $sender,
                            'msg_id'         => $addHttpRes['msg_id']
                        ];
                    } catch (Exception $e) {
                        // 同一个企业每个自然月内仅可针对一个客户/客户群发送4条消息，超过接收上限的客户将无法再收到群发消息。
                        // 41048-无可发送的客户
                        // 接收的客户全部不是好友或全部接收满4条了
                        if ($e->getCode() == 41048) {
                            $failList = $sendExternalUserIdArr;
                        }
                        send_msg_to_wecom($e->getMessage());
                    }
                    return true;
                });
        }

        if ($failList) {
            // 失败的就记录下来
            GroupMsgReceiveMapDao::updateData(
                [
                    'status' => 4
                ],
                [
                    'external_userid' => ['in', $failList],
                    'template_id'     => $templateId
                ]
            );
        }

        // 把msg_id存储下来
        if (!GroupMsgIdMapDao::addBatchData($groupMsgIdMapInsertData)) {
            send_msg_to_wecom('存储msg_id失败！' . json_encode($groupMsgIdMapInsertData));
        }

        // 更新主表状态为进行中
        $updateTemplateRes = GroupMsgTemplatesDao::updateData(['status' => 1], [
            'id' => $carryData['template_id']
        ]);

        if ($updateTemplateRes === false) {
            send_msg_to_wecom('更新主表状态为进行中失败！');
        }
        return true;
    }
}
