<?php

namespace app\api\job;

use Exception;
use think\Log;
use think\queue\Job;

/**
 * 任务基类
 *
 * Class BaseJob
 * @package app\api\job
 */
abstract class BaseJob
{
    protected static $jobName = '';

    /**
     * fire是消息队列默认调用的方法
     *
     * @param Job         $job  当前的任务对象
     * @param array|mixed $data 发布任务时自定义的数据
     * @throws Exception
     */
    public function fire(Job $job, $data)
    {
        // 执行业务处理
        if ($this->doJob($data)) {
            $job->delete(); // 任务执行成功后删除
        } else {
            // 检查任务重试次数
            if ($job->attempts() > 3) {
                $job->failed();
                $job->delete();
            }
        }
    }

    /**
     * 具体执行方法
     *
     * @param $carryData
     * @return mixed
     */
    abstract public function doJob($carryData);

    /**
     * 处理失败的任务
     *
     * @param $carryData
     * @return void
     * @throws Exception
     */
    public function failed($carryData)
    {
        send_msg_to_wecom(
            sprintf(
                '任务%s已重试3次以上-数据%s',
                static::$jobName,
                json_encode($carryData)
            )
        );
    }
}
