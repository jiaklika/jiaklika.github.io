<?php

namespace app\api\job\syncData;

use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\job\BaseJob;
use Exception;
use think\Db;

/**
 * 寻找首次添加
 *
 * Class FindFirstAddJob
 * @package app\api\job
 */
class FindFirstAddJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '生成群数据Excel任务';

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $externalUserId = $carryData['external_userid'];

        $updateId = Db::name('contact_follow_user')
            ->field([
                'id'
            ])
            ->where([
                'external_userid' => $externalUserId
            ])
            ->order('createtime asc')
            ->find();

        $updateRes = ContactFollowUserDao::updateData([
            'is_first_add' => 1
        ], [
            'id' => $updateId['id']
        ]);

        if ($updateRes !== false) {
            return true;
        }

        return false;
    }
}