<?php

namespace app\api\job\syncData;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\job\BaseJob;
use Exception;
use think\Cache;
use think\Log;

/**
 * Class UpdateUserLevelJob
 * @package app\api\job
 */
class UpdateUserLevelJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '更新视频号添加';

    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $contactHttpDao = new ContactHttpDao();
        $redis = Cache::store()->handler();

        $successJobCountName = 'update_user_level_job';

        $contactData = $contactHttpDao->getUserCenter($carryData['unionid']);

        $newContact = [];

        if ($contactData && isset($contactData['user_level_id'])) {
            if ($contactData['user_level_id'] != 0) {
                $newContact['id'] = $carryData['id'];
                $newContact['user_level_id'] = $contactData['user_level_id'];
                // 直接入库
                $redis->sadd('contactLevel', json_encode($newContact, JSON_UNESCAPED_UNICODE));
            }
        }

        $redis->incr($successJobCountName);

        Log::log($redis->get($successJobCountName) . '-success');

        return true;
    }
}
