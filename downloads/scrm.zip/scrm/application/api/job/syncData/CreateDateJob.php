<?php

namespace app\api\job\syncData;

use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\job\BaseJob;
use Exception;

/**
 * 更新create_date字段的值
 *
 * Class CreateDateJob
 * @package app\api\job\syncData
 */
class CreateDateJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '更新create_date字段的值';

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $createDate = date('Y-m-d', $carryData['createtime']);

        $updateRes = ContactFollowUserDao::updateData(
            [
                'create_date' => $createDate
            ],
            [
                'id' => $carryData['id']
            ]
        );

        if ($updateRes === false) {
            return false;
        }

        return true;
    }
}
