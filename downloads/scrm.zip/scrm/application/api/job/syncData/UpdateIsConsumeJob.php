<?php

namespace app\api\job\syncData;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\job\BaseJob;
use app\common\model\ContactFollowUser;
use app\common\model\ExternalContact;
use Exception;
use think\Db;
use think\Log;

/**
 * 更新是否消费
 *
 * Class UpdateIsConsumeJob
 * @package app\api\job
 */
class UpdateIsConsumeJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '更新是否消费任务';

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $unionid = $carryData['unionid'];

        $isJoinGroup = Db::name('contact_group_members')
                    ->alias('a')
                    ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                    ->field(['a.id'])
                    ->where([
                        'a.unionid'    => $unionid,
                        'a.is_deleted' => 0,
                        'b.is_deleted' => 0
                    ])
                    ->find();

        if ($isJoinGroup) {
            $updateRes = ContactDao::updateData([
                'is_in_group' => 1
            ], [
                'unionid' => $unionid
            ]);

            if ($updateRes !== false) {
                return true;
            }
        }

        return true;
    }*/

    /**
     * 更新是否是好友
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $externalUserId = $carryData['external_userid'];

        if (
            !ContactFollowUserDao::getDetail(
                [
                    'id'
                ],
                [
                    'external_userid' => $externalUserId,
                    'status'          => ContactFollowUser::NORMAL
                ]
            )
        ) {
            ContactDao::updateData(
                [
                    'is_friend' => ExternalContact::NOT_FRIEND
                ],
                [
                    'external_userid' => $externalUserId
                ]
            );
        }
        return true;
    }*/

    public function doJob($carryData): bool
    {
        if (!$unionid = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionid);

        if ($userCenterData['consume_amount']) {
            ContactDao::updateData(
                [
                    'actual_consume_amount' => $userCenterData['consume_amount']
                ],
                [
                    'unionid' => $unionid
                ]
            );
        }
        return true;
    }
}
