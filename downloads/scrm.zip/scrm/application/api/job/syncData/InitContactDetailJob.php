<?php

namespace app\api\job;

use app\api\dao\http\contact\ContactHttpDao;
use Exception;
use think\Cache;
use think\Log;
use think\queue\Job;

/**
 * Class InitContactDetailJob
 * @package app\api\job
 */
class InitContactDetailJob
{
    /**
     * fire是消息队列默认调用的方法
     *
     * @param Job         $job  当前的任务对象
     * @param array|mixed $data 发布任务时自定义的数据
     * @throws Exception
     */
    public function fire(Job $job, $data)
    {
        // 有效消息到达消费者时可能已经不再需要执行了
        /*if(!$this->checkJob($data))
        {
            $job->delete();
            return;
        }*/

        // 执行业务处理
        if ($this->doJob($data)) {
            $job->delete(); // 任务执行成功后删除
        } else {
            // 检查任务重试次数
            if ($job->attempts() > 3) {
                Log::log('已重试3次以上');
                $job->delete();
            }
        }
    }

    /**
     * 消息在到达消费者时可能已经不需要执行了
     *
     * @param array|mixed $data 发布任务时自定义的数据
     * @return boolean 任务执行的结果
     */
    /*private function checkJob($data)
    {
        return true;
    }*/

    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $contacts
     * @return bool
     * @throws Exception
     */
    private function doJob($contacts)
    {
        $contactHttpDao = new ContactHttpDao();
        $redis = Cache::store()->handler();

        $updateContactData = $insertFollowData = [];

        $nowTime = time();

        $successJobCountName = 'init_contact_success_job';

        foreach ($contacts as $contact) {
            // 实际业务流程处理
            $contactDetailArr = $contactHttpDao->getContactDetail($contact['external_userid'], false);

            if ($contactDetailArr) {
                [
                    $externalContactArr,
                    $followUserArr
                ] = [
                    $contactDetailArr['external_contact'],
                    $contactDetailArr['follow_user'],
                ];

                $updateContactData[] = [
                    'id'               => $contact['id'],
                    'name'             => $externalContactArr['name'],
                    'avatar'           => $externalContactArr['avatar'],
                    'type'             => $externalContactArr['type'],
                    'gender'           => $externalContactArr['gender'],
                    'unionid'          => $externalContactArr['unionid'] ?? null,
                    'position'         => $externalContactArr['position'] ?? '',
                    'corp_name'        => $externalContactArr['corp_name'] ?? '',
                    'corp_full_name'   => $externalContactArr['corp_full_name'] ?? '',
                    'external_profile' => $externalContactArr['external_profile'] ?? '',
                    'update_time'      => date('Y-m-d H:i:s', $nowTime)
                ];

                $followUserData = array_map(function ($followUser) use ($contact, $externalContactArr) {
                    return [
                        'external_userid'  => $contact['external_userid'],
                        'userid'           => $followUser['userid'],
                        'remark'           => $followUser['remark'],
                        'description'      => $followUser['description'],
                        'createtime'       => $followUser['createtime'],
                        'tags'             => $followUser['tags']
                            ? json_encode($followUser['tags'], JSON_UNESCAPED_UNICODE)
                            : null,
                        'remark_corp_name' => $followUser['remark_corp_name'] ?? '',
                        'remark_mobiles'   => json_encode($followUser['remark_mobiles'], JSON_UNESCAPED_UNICODE),
                        'oper_userid'      => $followUser['oper_userid'] ?? '',
                        'add_way'          => $followUser['add_way'] ?? 0,
                        'state'            => isset($followUser['state']) ? intval($followUser['state']) : 0,
                    ];
                }, $followUserArr);

                $insertFollowData = array_merge(
                    $insertFollowData,
                    $followUserData
                );
            }
        }

        $redis->pipeline();
        $redis->sadd('follow', json_encode($insertFollowData, JSON_UNESCAPED_UNICODE));
        $redis->sadd('contact', json_encode($updateContactData, JSON_UNESCAPED_UNICODE));
        $redis->incr($successJobCountName);
        $redis->exec();

        Log::log($redis->get($successJobCountName) . '-success');

        return true;
    }
}
