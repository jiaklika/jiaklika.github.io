<?php

namespace app\api\job\syncData;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\job\BaseJob;
use app\common\model\ContactFollowUser;
use Carbon\Carbon;
use Exception;
use think\Cache;
use think\Log;

// php think queue:work --queue get_contact_info_queue --daemon

/**
 * Class GetContactInfoJob
 * @package app\api\job
 */
class GetContactInfoJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '获取客户信息';

    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $contactHttpDao = new ContactHttpDao();
        $redis = Cache::store()->handler();

        $successJobCountName = 'get_contact_info_job';

        $contactData = $contactHttpDao->getUserCenter($carryData['unionid']);

        if (
            $contactData
            && isset($contactData['first_consume_amount'])
            && in_array($contactData['first_consume_amount'], [0.01, 0.1, 1, 9.9])
        ) {
            [
                $carryData['assistant_name'],
                $carryData['user_level_name'],
                $carryData['first_order_consume_money'],
                $carryData['first_order_consume_date']
            ] = [
                $contactData['assistant_name'],
                $contactData['user_level_name'],
                $contactData['first_consume_amount'],
                $contactData['first_consume_date']
            ];

            $redis->sadd('newContact', json_encode($carryData, JSON_UNESCAPED_UNICODE));
            $redis->incr($successJobCountName);
        }

        Log::log($redis->get($successJobCountName) . '-success');

        return true;
    }*/

    /**
     * 忠实宝迷——名媛，活跃人数（一个月内小程序活跃)，企微双向好友
     * 去重：0元拼发起者，拼的产品为非珠宝类的用户，企微双向好友
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        try {
            if (!$unionId = $carryData['unionid']) {
                return true;
            }

            $contactHttpDao = new ContactHttpDao();
            $redis = Cache::store()->handler();

            $consumerInfo = $contactHttpDao->getUserCenter($unionId);

            if (
                !$consumerInfo
                || $consumerInfo['user_level_id'] < 2
                || $consumerInfo['user_level_id'] > 4
            ) {
                $redis->sadd('noLevel', $unionId . '-' . $consumerInfo['user_level_id']);
                return true;
            } else {
                $redis->sadd('yesLevel', $unionId . '-' . $consumerInfo['user_level_id']);
            }

            // 1个月前
            // $oneMonthsAgo = Carbon::now()->subMonth()->getTimestamp();

            // 7天前
            $oneWeekAgo = Carbon::now()->subWeek()->getTimestamp();

            // 登录过
            $isLoginFunc = function ($loginTime) use ($oneWeekAgo) {
                if ($loginTime > $oneWeekAgo) {
                    return true;
                }
                return false;
            };

            [
                $yanZhiInfo,  // 颜值
                $liveRank,    // 直播等级
                $appLastLogin // APP端最后登录
            ] = [
                $contactHttpDao->getYanzhi($unionId),
                $contactHttpDao->getLiveRank($unionId),
                $contactHttpDao->getAppLastLoginTime($unionId)
            ];

            $judgeFunc = function ($lastLogin) use ($isLoginFunc, $unionId) {
                if (
                    !empty($lastLogin)
                    && $isLoginFunc($lastLogin)
                ) {
                    return true;
                }
                return false;
            };

            $yanzhiLogin = $judgeFunc($yanZhiInfo['last_login']);
            $bojemLogin = $judgeFunc($liveRank['last_login']);
            $appLogin = $judgeFunc($appLastLogin['app_last_login']);

            // 1个月内登录过三个中的一个
            if ($yanzhiLogin || $bojemLogin || $appLogin) {
                $redis->sadd('allUnionId', $unionId);

                $contactInfo = ContactFollowUserDao::getAllList(
                    [
                        'external_userid',
                        'userid'
                    ],
                    [
                        'status'          => ContactFollowUser::NORMAL,
                        'external_userid' => $carryData['external_userid'],
                    ]
                );

                if ($contactInfo) {
                    foreach ($contactInfo as $value) {
                        $redis->sadd($value['userid'], $carryData['external_userid']);
                    }
                }

                return true;
            } else {
                $redis->sadd(
                    'notTime',
                    $unionId . '-宝姐家：'
                    . $yanZhiInfo['last_login'] . '-宝姐珠宝：'
                    . $liveRank['last_login'] . '-APP:'
                    . $appLastLogin['app_last_login']
                );
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
        }
        return true;
    }

    /*public function doJob($carryData): bool
    {
        try {
            if (!$unionId = $carryData['unionid']) {
                return true;
            }

            $redis = Cache::store()->handler();

            if (!$redis->sIsMember('allUnionId', $unionId)) {
                $contactInfo = ContactFollowUserDao::getAllList(
                    [
                        'external_userid',
                        'userid'
                    ],
                    [
                        'status'          => ContactFollowUser::NORMAL,
                        'external_userid' => $carryData['external_userid'],
                    ]
                );

                if ($contactInfo) {
                    foreach ($contactInfo as $value) {
                        $redis->sadd($value['userid'], $carryData['external_userid']);
                    }
                    $redis->sadd('allUnionId', $unionId);
                }
                return true;
            } else {
                return true;
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
        }
        return true;
    }*/
}
