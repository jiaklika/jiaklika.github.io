<?php

namespace app\api\job\syncData;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTransferHttpDao;
use app\api\job\BaseJob;
use Exception;
use think\Cache;
use think\Log;

/**
 * Class TransferContactJob
 * @package app\api\job
 */
class TransferContactJob extends BaseJob
{

    /**
     * 转移数据
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();
        $successJobCountName = 'transfer_contact_job';
        $contactTransferHttpDao = new ContactTransferHttpDao();

        $transferRes = $contactTransferHttpDao->transferContact(
            $carryData['external_userid'],
            'fuliguan',
            'baojiejoyee'
        );

        if ($transferRes) {
            Log::info($carryData['unionid'] . '-发送分配成功！');
        } else {
            Log::error($carryData['unionid'] . '-发送分配失败！');
        }

        $redis->incr($successJobCountName);

        return true;
    }*/

    /**
     * 同步企微数据到用户中心
     *
     * @param $carryData
     * @return bool
     */
    public function doJob($carryData): bool
    {
        try {
            $contactHttpDao = new ContactHttpDao();
            $contactHttpDao->addUserCenterData(
                $carryData['id'],
                $carryData['unionid'],
                $carryData['name'],
                $carryData['avatar'],
                $carryData['gender']
            );
        } catch (Exception $e) {
            Log::error($e->getLine() . $e->getTraceAsString());
        }
        return true;
    }
}
