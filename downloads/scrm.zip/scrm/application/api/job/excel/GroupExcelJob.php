<?php

namespace app\api\job\excel;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\media\TemporaryMediaDao;
use app\api\job\BaseJob;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactTags;
use app\common\model\ExternalContact;
use app\common\model\TemporaryMedia;
use Exception;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use think\Cache;
use think\Db;

/**
 * Class GroupExcelJob
 * @package app\api\job
 */
class GroupExcelJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '生成群数据Excel任务';

    /**
     * 生成Excel并临时存储到企业微信
     *
     * @param $groupInfo
     * @return bool
     * @throws Exception
     */
    public function doJob($groupInfo): bool
    {
        /*$groupInfo = [
            'chat_id' => 'wr5b2CBwAAVXe6J9pVI_iJhunE8yQ2_w',
            'name'    => '宝姐家好物优享1群'
        ];*/

        $redis = Cache::store()->handler();

        [
            $lastWeekBeginTime, // 上周一
            $lastWeekEndTime,   // 本周一
            $TwoWeeksAgoBeginTime,
            $TwoWeeksAgoEndTime,
        ] =
        [
            strtotime('-2 sunday +1 day'),
            strtotime('this week Monday'),
            strtotime('-3 sunday +1 day'),
            strtotime('this week Monday'),
        ];

        // 是否是"好物优享群"
        $isGoodStuff = (bool)$redis->sIsMember(
            ContactGroupMembers::GOOD_STUFF_ALL_GROUP_ID_KEY,
            $groupInfo['chat_id']
        );

        $successJobCountName = 'generate_group_excel_job';

        $activityCount = $redis->get(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME);

        $todayDate = date("Y-m-d");

        $contactHttpDao = new ContactHttpDao();

        $fromArr = $contactHttpDao->getFromInfo();

        $contactData = $orderArr = [];

        // 群的全部人员
        $allGroupMemberArr = ContactGroupMembersDao::getAllList(
            [
                'userid',
                'unionid',
                'join_time'
            ],
            [
                'chat_id'    => $groupInfo['chat_id'],
                'is_deleted' => ContactGroupMembers::NOT_DELETED, // 没有退群
                'type'       => ContactGroupMembers::EXTERNAL_USER // 外部联系人
            ]
        );

        // 用户画像
        foreach ($allGroupMemberArr as $key => $member) {
            if ($member['unionid']) {
                // 来源渠道
                $tagMapArr = Db::name('contact_tag_map')
                    ->alias('a')
                    ->join('contact_tags b', 'a.tag_id = b.tag_id', 'LEFT')
                    ->field([
                        'b.tag_name'
                    ])
                    ->where([
                        'a.external_userid' => $member['userid'],
                        'b.group_id'        => ContactTags::GROUP_ID_MAP[ContactTags::SOURCE_CHANNEL]
                    ])
                    ->select();

                $tagNameArr = array_column((array)$tagMapArr, 'tag_name');

                if ($tagNameArr > 0) {
                    $tagNameArr = array_values(array_filter($tagNameArr, function ($val) {
                        if ($val !== '未知渠道') {
                            return true;
                        } else {
                            return false;
                        }
                    }));
                }

                $tagName = $tagNameArr[0] ?? '未知渠道';

                $userCenterInfo = $contactHttpDao->getUserCenter($member['unionid']);

                $contactData[$key] = [
                    'data' => ContactDao::getDetail(
                        [
                            'name',
                            'avatar',
                            'gender'
                        ],
                        [
                            'unionid' => $member['unionid']
                        ]
                    ),
                    'user_center'      => $userCenterInfo,
                    'unionid'          => $member['unionid'],
                    'join_time'        => $member['join_time'],
                    'tag_name'         => $tagName,
                    'is_first_consume' => ($userCenterInfo['first_consume_date']
                        == $userCenterInfo['last_consume_date'])
                        ? '是'
                        : '否' // 是否首单
                ];
            } else {
                $contactData[$key] = [
                    'data'        => [],
                    'user_center' => [],
                    'unionid'     => ''
                ];
            }
        }

        // 消费数据
        foreach ($allGroupMemberArr as $allKey => $allValue) {
            if ($allValue['unionid']) {
                // 有多个订单
                $orderInfo = $contactHttpDao->getMediaOrderList(
                    $allValue['unionid'],
                    $lastWeekBeginTime,
                    $lastWeekEndTime,
                    1
                    /*$TwoWeeksAgoBeginTime,
                    $TwoWeeksAgoEndTime,
                    0*/
                );

                if (
                    $orderInfo
                    && !isset($orderInfo['error'])
                ) {
                    // 有订单的才取颜值信息-begin
                    $yanzhiData = $contactHttpDao->getYanzhi($allValue['unionid']);

                    if ($yanzhiData['yanzhi_total'] < 1000) {
                        $yanzhiLevel = ExternalContact::YANZHI_BRONZE;
                    } elseif ($yanzhiData['yanzhi_total'] >= 10000) {
                        $yanzhiLevel = ExternalContact::YANZHI_GOLD;
                    } else {
                        $yanzhiLevel = ExternalContact::YANZHI_SILVER;
                    }
                    // 颜值-end

                    $contactInfo = ContactDao::getDetail(
                        [
                            'name',
                            'avatar'
                        ],
                        [
                            'unionid' => $allValue['unionid']
                        ]
                    );

                    if (
                        isset($contactInfo['name'])
                        && !empty($contactInfo['name'])
                    ) {
                        $contactName = $contactInfo['name'];
                    } else {
                        $contactName = $contactData[$allKey]['user_center']['nickname'] ??  '';
                    }

                    if (
                        !empty($contactName)
                    ) {
                        if (trim($contactName) == '=_=') {
                            $contactName = '~_~';
                        }

                        if (trim($contactName) == '==') {
                            $contactName = '~~';
                        }
                    }

                    foreach ($orderInfo as &$singleOrder) {
                        // 商品名称和商品编号-begin
                        $goodsList = $singleOrder['goods_list'];

                        $goodsName = $goodsSerialNumber = '';

                        foreach ($goodsList as $orderGood) {
                            $goodsName         .= $orderGood['goods_name'] . PHP_EOL;
                            $goodsSerialNumber .= $orderGood['goods_sn'] . PHP_EOL;
                        }

                        // 商品名称和商品编号-end

                        $singleOrder['name']             = $contactName;
                        $singleOrder['unionid']          = $allValue['unionid'];
                        $singleOrder['join_time']        = $allValue['join_time'];
                        $singleOrder['tag_name']         = $contactData[$allKey]['tag_name'] ?? '';
                        $singleOrder['yanzhi_level']     = $yanzhiLevel;
                        $singleOrder['user_level_name']  = $contactData[$allKey]['user_center']['user_level_name']
                            ?? '新人';
                        $singleOrder['from']             = $fromArr[$singleOrder['from']] ?? '未知';
                        $singleOrder['goods_name']       = $goodsName;
                        $singleOrder['goods_sn']         = $goodsSerialNumber;
                        $singleOrder['is_first_consume'] = $contactData[$allKey]['is_first_consume'] ?? '未知';
                    }

                    $orderArr = array_merge($orderArr, $orderInfo);
                }
            }
        }

        // Excel文件名
        $excelTitle = $groupInfo['name'] . '用户画像&消费数据' . $todayDate;

        downloadExcelToLocal($excelTitle, function ($spreadsheet) use (
            $contactData,
            $orderArr,
            $contactHttpDao,
            $redis,
            $isGoodStuff
        ) {

            $cellValueMap = [
                'A1' => '昵称',
                'B1' => '头像',
                'C1' => '性别',
                'D1' => '年龄',
                'E1' => '地区',
                'F1' => '会员等级',
                'G1' => '最近一次购买时间',
                'H1' => 'unionID',
                'I1' => '企微来源渠道'
            ];

            if ($isGoodStuff) {
                $cellValueMap['J1'] = '来自新粉群';
            }

            $cellValueFunc = function ($cellValueMap, $index) use ($spreadsheet) {
                foreach ($cellValueMap as $cellKey => $cellValue) {
                    $spreadsheet->setActiveSheetIndex($index)->setCellValue($cellKey, $cellValue);
                }
            };

            $cellValueFunc($cellValueMap, 0);

            // 重命名worksheet
            $spreadsheet->setActiveSheetIndex(0)->setTitle('群成员画像');

            foreach ($contactData as $contactKey => $contact) {
                $excelKey = $contactKey + 2;

                $gender = '未知';

                if (isset($contact['data']['gender'])) {
                    switch ($contact['data']['gender']) {
                        case 0:
                        default:
                            break;

                        case 1:
                            $gender = '男';
                            break;

                        case 2:
                            $gender = '女';
                            break;
                    }
                }

                if ($gender == '未知') {
                    if (isset($contact['user_center']['gender']) && !empty($contact['user_center']['gender'])) {
                        $gender = $contact['user_center']['gender'];
                    }
                }

                $name = '';

                if (isset($contact['data']['name']) && !empty($contact['data']['name'])) {
                    $name = $contact['data']['name'];
                } else {
                    if (isset($contact['user_center']['nickname']) && !empty($contact['user_center']['nickname'])) {
                        $name = $contact['user_center']['nickname'];
                    }
                }

                if (
                    !empty($name)
                    && $name == '=_='
                ) {
                    $name = '~_~';
                }

                $area = '未知';

                if (
                    isset($contact['user_center']['province'])
                    && !empty($contact['data']['province'])
                ) {
                    $area = $contact['user_center']['province'] . $contact['user_center']['city'];
                } else {
                    if ($contact['unionid']) {
                        $addressInfo = $contactHttpDao->getUserAddress($contact['unionid']);
                        $area = $addressInfo['province'] . $addressInfo['city'];
                    }
                }

                // sheet0
                $sheet0ValueMap = [
                    'A' . $excelKey => $name,
                    'B' . $excelKey => $contact['data']['avatar'] ?? '',
                    'C' . $excelKey => $gender,
                    'D' . $excelKey => isset($contact['user_center']['birthday'])
                        ? getAge((int)$contact['user_center']['birthday'])
                        : '未知',
                    'E' . $excelKey => $area,
                    'F' . $excelKey => $contact['user_center']['user_level_name']
                        ?? '新人',
                    'G' . $excelKey => $contact['user_center']['last_consume_date']
                        ?? '',
                    'H' . $excelKey => $contact['unionid'] ?? '',
                    'I' . $excelKey => $contact['tag_name'] ?? '',
                ];

                // “是否在过新粉群”为【进过优享群前进入过新粉群】的用户
                if ($isGoodStuff) {
                    $result = '否';

                    $joinTime = $redis->hget(
                        ContactGroupMembers::NEW_FANS_ALL_UNION_ID_KEY,
                        $contact['unionid']
                    );

                    if ($joinTime && $joinTime < $contact['join_time']) {
                        $result = '是';
                    }

                    $sheet0ValueMap['J' . $excelKey] = $result;
                }

                $cellValueFunc($sheet0ValueMap, 0);
            }

            $columnFormat = [
                'A' => 12,
                'B' => 80,
                'E' => 15,
                'F' => 10,
                'G' => 20,
                'H' => 30,
                'I' => 25
            ];

            if ($isGoodStuff) {
                $columnFormat['J'] = 10;
            }

            $columnFormatFunc = function ($columnFormat) use ($spreadsheet) {
                foreach ($columnFormat as $columnKey => $columnWidth) {
                    $spreadsheet->getActiveSheet()
                        ->getColumnDimension($columnKey)
                        ->setWidth($columnWidth);
                }
            };

            $columnFormatFunc($columnFormat);

            // 群成员订单
            $spreadsheet->createSheet();

            $spreadsheet->setActiveSheetIndex(1)->setTitle('群成员上周消费');
            // $spreadsheet->setActiveSheetIndex(1)->setTitle('群成员前2周消费');

            $sheet1TitleMap = [
                'A1' => '昵称',
                'B1' => '会员等级',
                'C1' => '颜值等级',
                'D1' => 'unionID',
                'E1' => '商品名称',
                'F1' => '商品编号',
                'G1' => '订单编号',
                'H1' => '订单金额',
                'I1' => '订单类型',
                'J1' => '订单归属',
                'K1' => '成交平台',
                'L1' => '订单状态',
                'M1' => '用户来源',
                'N1' => '企微来源渠道',
                'O1' => '是否首单'
            ];

            if ($isGoodStuff) {
                $sheet1TitleMap['P1'] = '来自新粉群';
            }

            $cellValueFunc($sheet1TitleMap, 1);

            foreach ($orderArr as $k => $order) {
                $status = '';
                $excelKey1 = $k + 2;

                if (isset($order['order_status'])) {
                    switch ($order['order_status']) {
                        case 0:
                            $status = '待确认,未支付';
                            break;

                        case 1:
                            $status = '已确认';
                            break;

                        case 2:
                            $status = '已收货';
                            break;

                        case 3:
                            $status = '已取消';
                            break;

                        case 4:
                            $status = '已完成';
                            break;

                        case 5:
                            $status = '已作废';
                            break;
                    }
                }


                if (isset($order['order_prom_type'])) {
                    switch ($order['order_prom_type']) {
                        case 0:
                            $orderType = '普通订单';
                            break;

                        case 1:
                            $orderType = '抢购订单';
                            break;

                        case 4:
                            $orderType = '预售订单';
                            break;

                        case 8:
                            $orderType = '直播订单';
                            break;

                        case 9:
                            $orderType = '拼团订单';
                            break;

                        case 1003:
                            $orderType = '销售代下单';
                            break;
                    }
                }

                if (isset($order['order_platform'])) {
                    if ($order['order_platform'] == 0) {
                        $orderBelong = '宝姐珠宝';
                    } else {
                        $orderBelong = '用户运营中心';
                    }
                }

                if (isset($order['is_pick'])) {
                    switch ($order['is_pick']) {
                        case 0:
                            switch ($order['platform']) {
                                case 1:
                                    $orderPlatform = '宝姐家小程序';
                                    break;

                                case 2:
                                    $orderPlatform = '珠宝小程序';
                                    break;

                                case 3:
                                    $orderPlatform = '宝姐家app';
                                    break;
                            }
                            break;

                        case 2:
                            $orderPlatform = '有赞';
                            break;

                        case 3:
                            $orderPlatform = '抖音小店';
                            break;

                        case 4:
                            $orderPlatform = '微信小商店';
                            break;
                    }
                }

                $sheet1ValueMap = [
                    'A' . $excelKey1 => $order['name'] ?? '',
                    'B' . $excelKey1 => $order['user_level_name'] ?? '',
                    'C' . $excelKey1 => $order['yanzhi_level'] ?? '',
                    'D' . $excelKey1 => $order['unionid'] ?? '',
                    'E' . $excelKey1 => $order['goods_name'] ?? '',
                    'F' . $excelKey1 => $order['goods_sn'] ?? '',
                    'H' . $excelKey1 => $order['order_amount'] ?? '',
                    'I' . $excelKey1 => $orderType ?? '未知',
                    'J' . $excelKey1 => $orderBelong ?? '未知',
                    'K' . $excelKey1 => $orderPlatform ?? '未知',
                    'L' . $excelKey1 => $status,
                    'M' . $excelKey1 => $order['from'] ?? '',
                    'N' . $excelKey1 => $order['tag_name'] ?? '',
                    'O' . $excelKey1 => $order['is_first_consume'] ?? '未知'
                ];

                // “是否在过新粉群”为【进过优享群前进入过新粉群】的用户
                if ($isGoodStuff) {
                    $result = '否';

                    $joinTime = $redis->hget(
                        ContactGroupMembers::NEW_FANS_ALL_UNION_ID_KEY,
                        $order['unionid']
                    );

                    if ($joinTime && $joinTime < $order['join_time']) {
                        $result = '是';
                    }

                    $sheet1ValueMap['P' . $excelKey1] = $result;
                }

                $cellValueFunc($sheet1ValueMap, 1);

                $spreadsheet->setActiveSheetIndex(1)
                    ->setCellValueExplicit('G' . $excelKey1, $order['order_sn'] ?? '', DataType::TYPE_STRING);
            }

            $sheet1ColumnFormat = [
                'A' => 12,
                'B' => 10,
                'C' => 10,
                'D' => 30,
                'E' => 50,
                'F' => 20,
                'G' => 20,
                'I' => 10,
                'J' => 12,
                'K' => 12,
                'M' => 25,
                'N' => 25,
            ];

            if ($isGoodStuff) {
                $sheet1ColumnFormat['P'] = 10;
            }

            $columnFormatFunc($sheet1ColumnFormat);
        });

        $mediaHttpDao = new MediaHttpDao();

        $fileName = $excelTitle . '.xlsx';

        $mediaInfo = $mediaHttpDao->uploadMedia(MediaHttpDao::FILE, 'public/downloads/' . $fileName, $fileName);

        TemporaryMediaDao::addData([
            'media_name'       => $groupInfo['name'],
            'media_id'         => $mediaInfo['media_id'],
            'activity_id'      => $activityCount,
            'type'             => 'file',
            'media_created_at' => $mediaInfo['created_at'],
        ]);

        $redis->incr($successJobCountName);

        return true;
    }
}
