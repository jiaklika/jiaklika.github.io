<?php

namespace app\api\job\callback;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contactFission\ContactFissionHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactChannels;
use app\common\model\ContactFissionRecords;
use app\common\model\ContactFollowUser;
use app\common\model\ContactWays;
use app\common\model\ExternalContact;
use Exception;
use think\Cache;
use think\Db;
use think\Queue;

/**
 * 使用nohup后台启动并且不输出nohup.out日志文件
 * nohup php think queue:work --queue callback_add_contact_queue --daemon >/dev/null 2>&1 &
 *
 * Class AddContactJob
 * @package app\api\job\callback
 */
class AddContactJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '回调添加客户处理任务';

    /**
     * 添加客户
     *
     * @param array $carryData 回调数据
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        /*$carryData = [
            'ExternalUserID' => 'wm5b2CBwAAymLhuMvDzxSbQ_PEMsfuXQ',
            'UserID'         => 'yangyang3',
            'State'          => '114',
            'ChangeType'     => 'add_external_contact',
            'random_index'   => 2
        ];*/

        $redis = Cache::store()->handler();

        $endTime = 0;
        if ($fissionEndTime = $redis->get(ContactFissionRecords::REDIS_KEY_FISSION_END_TIME)) {
            $endTime = strtotime($fissionEndTime);
        }

        // 当天
        $todayDate = date('Y-m-d');

        $contactHttpDao = new ContactHttpDao();

        // 通过企业微信接口获取外部联系人详情并存表
        try {
            $contactDetailArr = $contactHttpDao->getContactDetail($carryData['ExternalUserID'], false);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
            return false;
        }

        [
            $externalContactArr,    // 外部联系人通用信息
            $followUserArr,         // 添加了此外部联系人的企业成员各自信息
            $followUserInsertData,  // 第一次添加就增加
            $followUserUpdateData,  // 删除后再次添加就修改
            $followRes,
            $isSuccess
        ] =
        [
            $contactDetailArr['external_contact'],
            $contactDetailArr['follow_user'],
            [],
            [],
            false,
            0
        ];

        try {
            $userCenterArr = [];
            // 事务必须写在try catch里
            Db::startTrans();

            // 获取客户等级
            if (
                isset($externalContactArr['unionid']) && !empty($externalContactArr['unionid'])
            ) {
                if ($userCenterArr = $contactHttpDao->getUserCenter($externalContactArr['unionid'])) {
                    $externalContactArr['user_level_id'] = $userCenterArr['user_level_id'] ? : 0;
                    $externalContactArr['actual_consume_amount'] = $userCenterArr['consume_amount'] ? : 0;
                }

                // 客户是否消费
                // 先从珠宝取
                $isConsume = $contactHttpDao->getIsConsume($externalContactArr['unionid']);
                // 珠宝显示未消费再从ERP取
                if (!$isConsume && $userCenterArr['contractAmount'] > 0) {
                    $isConsume = ExternalContact::IS_CONSUME;
                }

                $externalContactArr['is_consume'] = $isConsume;
            }

            // 1个客户可以添加多个助理
            // 每添加一个新助理，此条数据都会返回
            // 先判断客户是否已经存在，不存在再入表
            if (!ContactDao::isExistById(0, ['external_userid' => $externalContactArr['external_userid']])) {
                // 仅当联系人类型是企业微信用户时有此字段
                if (
                    isset($externalContactArr['external_profile'])
                    && !empty($externalContactArr['external_profile'])
                ) {
                    $externalContactArr['external_profile'] = json_encode(
                        $externalContactArr['external_profile'],
                        JSON_UNESCAPED_UNICODE
                    );
                }
                $contactRes = ContactDao::addData($externalContactArr);
            } else // 存在就更新，因为客户可能改了自己的名字和头像，用户等级也可能变化了
            {
                $updateData = [
                    'name'      => $externalContactArr['name'],
                    'avatar'    => $externalContactArr['avatar'],
                    'is_friend' => ExternalContact::IS_FRIEND
                ];

                if (
                    isset($externalContactArr['unionid'])
                    && !empty($externalContactArr['unionid'])
                ) {
                    $updateData['user_level_id'] = $externalContactArr['user_level_id'] ?? 0;
                }

                $contactRes = ContactDao::updateData(
                    $updateData,
                    [
                        'external_userid' => $externalContactArr['external_userid']
                    ]
                );
            }

            // 返回多个followUsers列表，找到当前添加的助理
            foreach ($followUserArr as $followUser) {
                if ($followUser['userid'] == $carryData['UserID']) {
                    // 不存在就添加，存在就更新
                    if (
                        !ContactFollowUserDao::isExistById(
                            0,
                            [
                                'external_userid' => $externalContactArr['external_userid'],
                                'userid'          => $carryData['UserID']
                            ]
                        )
                    ) {
                        $followUserInsertData = $followUser;
                    } else { // 互相删除之后表里仍有记录
                        // 删了之后再加
                        $followUserUpdateData = $followUser;
                    }

                    break;
                }
            }

            /**
             * 谁发起的添加
             *
             * @param $followUserData
             * @return int
             */
            $getAddType = function ($followUserData) use ($carryData) {
                if (isset($followUserData['oper_userid'])) {
                    switch ($followUserData['oper_userid']) {
                        case $carryData['UserID']:
                            $addType = 1;
                            break;

                        case $carryData['ExternalUserID']:
                            $addType = 2;
                            break;

                        default:
                            $addType = 3;
                            break;
                    }
                } else {
                    $addType = 0;
                }
                return $addType;
            };

            $addWay = $isFirstAdd = $createTime = 0;

            // 首次添加客户
            if ($followUserInsertData) {
                // 是否首次添加
                $isFirstAdd = $followUserInsertData['is_first_add'] = ContactFollowUserDao::getCount([
                    'external_userid' => $externalContactArr['external_userid']
                ]) == 0 ? 1 : 0;

                $followUserInsertData['add_type'] = $getAddType($followUserInsertData);

                $followUserInsertData['external_userid'] = $externalContactArr['external_userid'];

                if (isset($followUserInsertData['wechat_channels'])) {
                    $followUserInsertData['wechat_channels_nickname'] =
                        $followUserInsertData['wechat_channels']['nickname'];
                    $followUserInsertData['wechat_channels_source'] =
                        $followUserInsertData['wechat_channels']['source'];
                }

                // 第一次添加没有标签，描述和备注手机号码，直接unset掉
                unset(
                    $followUserInsertData['description'],
                    $followUserInsertData['tags'],
                    $followUserInsertData['remark_mobiles'],
                    $followUserInsertData['wechat_channels']
                );

                if (isset($followUserInsertData['state'])) {
                    if ($followUserInsertData['state'] === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                        $followUserInsertData['add_way'] = ContactFollowUser::MOMENT_ADD_WAY;
                        $followUserInsertData['state'] = search_two_dimensional_array(
                            $carryData['UserID'],
                            ContactChannels::MOMENT_CHANNEL_MAP
                        );
                    }
                }

                // 视频号添加
                if ($followUserInsertData['add_way'] == 10) {
                    $followUserInsertData['state'] = array_search(
                        $followUserInsertData['wechat_channels_nickname'],
                        ContactFollowUser::VIDEO_STATE_MAP
                    );
                }

                $followUserInsertData['create_date'] = date('Y-m-d', $followUserInsertData['createtime']);
                $followUserInsertData['random_index'] = $carryData['random_index'] ?? 0;

                $followRes = ContactFollowUserDao::addData($followUserInsertData);
                $addWay = $followUserInsertData['add_way'] ?? 0;
                $createTime = $followUserInsertData['createtime'];
            }

            // 删除后再次添加客户
            if ($followUserUpdateData) {
                $addWay = $followUserUpdateData['add_way'] ?? 0;

                if (
                    isset($followUserUpdateData['state'])
                    && $followUserUpdateData['state'] === ContactFollowUser::MOMENT_ORIGIN_STATE
                ) {
                    $followUserUpdateData['state'] = search_two_dimensional_array(
                        $carryData['UserID'],
                        ContactChannels::MOMENT_CHANNEL_MAP
                    );

                    $addWay = ContactFollowUser::MOMENT_ADD_WAY;
                }

                // 视频号添加
                if ($addWay == 10) {
                    $wechatChannelsNickname = $followUserUpdateData['wechat_channels']['nickname'] ?? '';
                    $followUserUpdateData['state'] = array_search(
                        $wechatChannelsNickname,
                        ContactFollowUser::VIDEO_STATE_MAP
                    );
                }

                $followRes = ContactFollowUserDao::updateData(
                    [
                        'status'           => 0, // 再次添加
                        'remark'           => $followUserUpdateData['remark'] ?? '',
                        'description'      => $followUserUpdateData['description'] ?? '',
                        'createtime'       => $followUserUpdateData['createtime'] ?? 0,
                        'create_date'      => isset($followUserUpdateData['createtime'])
                            ? date('Y-m-d', $followUserUpdateData['createtime'])
                            : 0,
                        'add_way'          => $addWay,
                        'oper_userid'      => $followUserUpdateData['oper_userid'] ?? '',
                        'add_type'         => $getAddType($followUserUpdateData),
                        'state'            => $followUserUpdateData['state'] ?? 0,
                        'random_index'     => $carryData['random_index'] ?? 0,
                        'tags'             => (isset($followUserUpdateData['tags'])
                            && !empty($followUserUpdateData['tags']))
                            ? json_encode($followUserUpdateData['tags'], JSON_UNESCAPED_UNICODE) : null,
                        'remark_corp_name' => $followUserUpdateData['remark_corp_name'] ?? '',
                        'remark_mobiles'   => (isset($followUserUpdateData['remark_mobiles'])
                            && !empty($followUserUpdateData['remark_mobiles']))
                            ? implode(',', $followUserUpdateData['remark_mobiles']) : '',
                        'wechat_channels_nickname' => isset($followUserUpdateData['wechat_channels'])
                            ? $followUserUpdateData['wechat_channels']['nickname']
                            : '',
                        'wechat_channels_source'  => isset($followUserUpdateData['wechat_channels'])
                            ? $followUserUpdateData['wechat_channels']['source']
                            : 0,
                        // 'del_time'         => null, // 删除时间仍旧记录下来
                    ],
                    [
                        'external_userid' => $externalContactArr['external_userid'],
                        'userid'          => $carryData['UserID']
                    ]
                );
                $addWay = $followUserUpdateData['add_way'] ?? 0;
                $createTime = $followUserUpdateData['createtime'] ?? 0;
            }
            // contact和follow表都正确写入
            if ($contactRes !== false && $followRes !== false) {
                $isSuccess = 1;
                Db::commit();
                // 根据客户的条件打标签
                // 该外部联系人是企业微信用户时，没有unionid
                if (
                    isset($externalContactArr['unionid'])
                    && !empty($externalContactArr['unionid'])
                ) {
                    try {
                        $contacts = [
                            'unionid'         => $externalContactArr['unionid'],
                            'external_userid' => $externalContactArr['external_userid'],
                            'state'           => $carryData['State'] ?? 0, // 用于打"来源渠道"标签
                            'userid'          => $carryData['UserID']
                        ];
                        // 推送到队列
                        Queue::push(
                            ExternalContact::CALLBACK_TAG_JOB_HANDLER,
                            $contacts,
                            ExternalContact::CALLBACK_TAG_QUEUE
                        );
                    } catch (Exception $e) {
                        send_msg_to_wecom('进入回调打标签队列出错：' . $e->getMessage());
                    }

                    try {
                        // 添加指定微信号后发送请求
                        // if (in_array($this->userId, User::KO_USER_MAP)) {
                        $webHookHttpDao = new WebHookHttpDao();
                        $webHookHttpDao->noticeKoContactEvent($externalContactArr['unionid']);
                        //}

                        // 推荐官
                        if (
                            isset($carryData['State'])
                            && $carryData['State'] == ContactWays::RECRUITING_OFFICER_ID
                        ) {
                            $webHookHttpDao->joinSharerCallback($externalContactArr['unionid']);
                        }

                        // 添加赵蔚的企微账号后通知宝姐珠宝
                        $userServiceImpl = new UserServiceImpl();

                        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

                        if (in_array($carryData['UserID'], $zhaoweiAccounts)) {
                            $webHookHttpDao->noticeBaojieAddContact($externalContactArr['unionid']);
                        }
                        if ($addWay != 202) { // 管理员/负责人分配
                            // 人数统计，写进redis的hash
                            $riskRes = $webHookHttpDao->getRiskRank($externalContactArr['unionid']);
                            if ($riskRes['code'] == '0000') {
                                $registerRiskRank = $riskRes['data']['register_risk_rank'];
                                $redis->hSet(
                                    "register-risk:{$todayDate}",
                                    $externalContactArr['unionid'],
                                    $registerRiskRank
                                );

                                $marketRiskRank = $riskRes['data']['market_risk_rank'];
                                $redis->hSet(
                                    "market-risk:{$todayDate}",
                                    $externalContactArr['unionid'],
                                    $marketRiskRank
                                );
                            }
                        }
                        // 发送朋友圈广告企微用户给宝姐家
                        if (
                            isset($carryData['State'])
                            && $carryData['State'] === ContactFollowUser::MOMENT_ORIGIN_STATE
                        ) {
                            $webHookHttpDao->sendMomentUnionId($externalContactArr['unionid']);
                        }

                        if (time() < $endTime) {
                            // 企微裂变通知宝姐家
                            if (
                                isset($carryData['State'])
                                && strlen($carryData['State']) > 20
                            ) {
                                $contactFissionHttpDao = new ContactFissionHttpDao();

                                $isDistinguishGender = $redis->get(ContactFissionRecords::IS_DISTINGUISH_GENDER);
                                // 区分性别
                                if (
                                    ($isDistinguishGender == 1 && $externalContactArr['gender'] != 1)
                                    || $isDistinguishGender == 0
                                ) {
                                    if ($contactFissionHttpDao->bojemIsNewContact($externalContactArr['unionid'])) {
                                        // 完全纯粹的陌生人才通知
                                        if (
                                            $isFirstAdd
                                            &&
                                            !ContactGroupMembersDao::getDetail(['id'], [
                                                'unionid' => $externalContactArr['unionid']
                                            ])
                                        ) {
                                            $contactFissionHttpDao->sendFansHelp(
                                                $carryData['State'],
                                                $externalContactArr['unionid'],
                                                $createTime,
                                                $externalContactArr['avatar'],
                                                $externalContactArr['name']
                                            );
                                        }
                                    }
                                }
                            }
                        }
                    } catch (Exception $e) {
                        send_msg_to_wecom($e->getLine() . $e->getMessage());
                    }

                    try {
                        if (
                            isset($externalContactArr['unionid'])
                        ) {
                            $contactInfo = ContactDao::getDetail(['id', 'name', 'avatar', 'gender'], [
                                'unionid' => $externalContactArr['unionid']
                            ]);

                            if ($contactInfo) {
                                $contactHttpDao->addUserCenterData(
                                    $contactInfo['id'],
                                    $externalContactArr['unionid'],
                                    $contactInfo['name'],
                                    $contactInfo['avatar'],
                                    $contactInfo['gender']
                                );
                            }
                        }
                    } catch (Exception $e) {
                        send_msg_to_wecom($e->getMessage());
                    }
                }
            } else {
                Db::rollback();
            }
        } catch (Exception $e) {
            Db::rollback();
            send_msg_to_wecom(json_encode($carryData) . $e->getMessage());
            return false;
        }

        if (
            isset($carryData['func'])
            && !empty($carryData['func'])
        ) {
            $wrapper = unserialize($carryData['func']);

            $closure = $wrapper->getClosure();

            $closure($carryData['ChangeType'], $isSuccess);
        }

        return true;
    }
}
