<?php

namespace app\api\job\tag;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\job\BaseJob;
use app\api\service\message\impl\MessageServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactTags;
use Exception;
use think\Cache;
use think\Log;
use think\queue\Job;

class MarkTagJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '批量打标签任务';

    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        $addTags = [
            'et5b2CBwAA3ocC8xD2VbawG-Ivtukbtw'
        ];
        $removeTags = [

        ];

        $contactTagHttpDao = new ContactTagHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($contact['unionid']);

        if (!isset($userCenterData['user_level_id'])
            || $userCenterData['user_level_id'] == 0)
        {
            try {
                if ($markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                ))
                {
                    Log::info($contact['unionid'].'-打新人标签成功！');
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        } else
        {
            Log::info($contact['unionid'].'-不是新人！');
        }

        return true;
    }*/

    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob1($contact)
    {
        $addTags = [
            'et5b2CBwAA3ocC8xD2VbawG-Ivtukbtw'
        ];
        $removeTags = [

        ];

        $contactTagHttpDao = new ContactTagHttpDao();
        $redis = Cache::store()->handler();

        $successJobCountName = 'mark_contact_tag_job';

        $contactHttpDao = new ContactHttpDao();

        // 7天以前
        $sevenDaysAgo = strtotime(date('Y-m-d', strtotime('-7 days')));

        $isLoginFunc = function($loginTime) use ($sevenDaysAgo){
            if ($loginTime > $sevenDaysAgo)
                return true;
            return false;
        };

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($contact['unionid']),
            $contactHttpDao->getLiveRank($contact['unionid']),
            $contactHttpDao->getAppLastLoginTime($contact['unionid'])
        ];

        $judgeFunc = function ($lastLogin, $platform) use ($isLoginFunc, $redis,$successJobCountName,$contact){
            if (!empty($lastLogin)
                && $isLoginFunc($lastLogin))
            {
                Log::info($contact['unionid'].$platform.'-登陆时间-'.$lastLogin);
                return true;
            }

            $redis->incr($successJobCountName);
            Log::info($contact['unionid'].$platform.'-无登陆或时间不满足-'.$lastLogin);
            return false;
        };

        if (!$res = $judgeFunc($yanZhiInfo['last_login'],'宝姐家'))
            if (!$res = $judgeFunc($liveRank['last_login'], '宝姐珠宝'))
                $res = $judgeFunc($appLastLogin['app_last_login'], 'APP');

        if ($res)
        {
            $insertTagData = [];
            try {
                if ($markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                ))
                {
                    if ($addTags) // 成功添加后记录
                    {
                        foreach ($addTags as $addTagId)
                        {
                            $insertTagData[] = [
                                'external_userid' => $contact['external_userid'],
                                'tag_id'          => $addTagId
                            ];
                        }

                        $addRes = ContactTagMapDao::addBatchData($insertTagData);

                        if ($addRes)
                            Log::info($contact['unionid'].'-打标签-'.json_encode($addTags).'-成功');
                    }

                    if ($removeTags)
                    {
                        foreach ($removeTags as $removeTagId)
                        {
                            $deleteRes = ContactTagMapDao::hardDelete([
                                'external_userid' => $contact['external_userid'],
                                'tag_id'          => $removeTagId
                            ]);

                            if ($deleteRes !== false)
                                Log::info($contact['unionid'].'-移除标签-'.$removeTagId.'-成功');
                        }
                    }
                }
            } catch (Exception $e)
            {
                Log::error($e->getMessage());
            }
        }
        else
            Log::error($contact['unionid'].'-都没有登陆-');

        return true;
    }*/

    /**
     * 初始化打颜值标签
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        $bronzeTag = [
            'et5b2CBwAAtqme5MTAO85dLN-4e4LRkQ' // 颜值青铜
        ];

        $silverTag = [
            'et5b2CBwAA6EDeMLkk3fMqmPV0I95pgg' // 颜值白银
        ];

        $goldTag = [
            'et5b2CBwAAJLNzLCPZ_IgMJDSL09HUjA' // 颜值黄金
        ];

        $removeTags = [

        ];

        $contactTagHttpDao = new ContactTagHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $yanzhiData = $contactHttpDao->getYanzhi($contact['unionid']);

        if ((int)$yanzhiData['yanzhi_total'] < 1000)
        {
            $addTags = $bronzeTag;
            $level = '青铜';
        }
        elseif ((int)$yanzhiData['yanzhi_total'] >= 10000)
        {
            $addTags = $goldTag;
            $level = '黄金';
        }
        else
        {
            $addTags = $silverTag;
            $level = '白银';
        }


        try {
            if ($markRes = $contactTagHttpDao->markTag(
                $contact['userid'],
                $contact['external_userid'],
                $addTags, // 打标签
                $removeTags // 移除标签
            ))
            {
                Log::info($contact['unionid'].'-打颜值标签-'.$level.'-成功！');

                if (!ContactTagMapDao::addData([
                    'tag_id'          => implode('', $addTags),
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid']
                ]))
                    Log::error($contact['unionid'].'-存表失败！');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 韬韬号名下客户打上会员等级标签
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        $tagMap = [
            'et5b2CBwAApoBsNUYArAS4PmqCYNrBsw', // 新人
            'et5b2CBwAA9-FmA2KwZuruIl88-TjFaw', // 宝迷
            'et5b2CBwAAb4kaos98Q9pzBL3FSOQ7_g', // 忠实宝迷
            'et5b2CBwAAeuiVrbmplHQpLuh_maL9NA', // 铁杆宝迷
            'et5b2CBwAA-2nMZYUJfl1QGXAOm3ZtBw', // 名媛
            'et5b2CBwAAWZL2H8xhLL361g1ZuUMcwQ', // 风尚名媛
            'et5b2CBwAAyHU-v6fCaFpchJRLM11llw' // 至尊名媛
        ];

        $tagStrMap = [
            '新人',
            '宝迷',
            '忠实宝迷',
            '铁杆宝迷',
            '名媛',
            '风尚名媛',
            '至尊名媛'
        ];

        $removeTags = [

        ];

        $contactTagHttpDao = new ContactTagHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($contact['unionid']);

        if (isset($userCenterData['user_level_id'])
        && $userCenterData['user_level_id'] !== null)
        {
            $addTags = [$tagMap[$userCenterData['user_level_id']]];
            $logStr  = $tagStrMap[$userCenterData['user_level_id']];
        } else {
            $addTags = ['et5b2CBwAApoBsNUYArAS4PmqCYNrBsw'];
            $logStr  = '新人';
        }

        try {
            if ($markRes = $contactTagHttpDao->markTag(
                $contact['userid'],
                $contact['external_userid'],
                $addTags, // 打标签
                $removeTags // 移除标签
            ))
            {
                Log::info($contact['unionid'].'-打会员等级标签-'.$logStr.'-成功！');

                if (!ContactTagMapDao::addData([
                    'tag_id'          => implode('', $addTags),
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid']
                ]))
                    Log::error($contact['unionid'].'-存表失败！');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }


        return true;
    }*/

    /**
     * 阳阳1、阳阳、运营客服、晓晓、凡凡
     *
     * 颜值白银新客：当前颜值白银用户中未消费过的人
     * 颜值黄金新客：当前颜值黄金用户中未消费过的人
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid'])
            return true;

        $silverTag = [
            'et5b2CBwAAoblzd5iT3oCv4CTdk-2I2A' // 颜值白银新客
        ];

        $goldTag = [
            'et5b2CBwAAjOv-eRGjRYJVJW52e_H_yg' // 颜值黄金新客
        ];

        $addTags = $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $yanzhiData = $contactHttpDao->getYanzhi($unionId);
        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if ((int)$yanzhiData['yanzhi_total'] >= 1000
            && (int)$yanzhiData['yanzhi_total'] < 10000)
        {
            if ($userCenterData['consume_amount'] == 0)
            {
                $addTags = $silverTag;
                $level = '颜值白银新客';
            }
        }

        if ((int)$yanzhiData['yanzhi_total'] >= 10000)
        {
            if ($userCenterData['consume_amount'] == 0)
            {
                $addTags = $goldTag;
                $level = '颜值黄金新客';
            }
        }

        if ($addTags)
        {
            try {
                if ($markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                ))
                {
                    Log::info($contact['unionid'].'-打颜值标签-'.$level.'-成功！');

                    if (!ContactTagMapDao::addData([
                        'tag_id'          => implode('', $addTags),
                        'external_userid' => $contact['external_userid'],
                        'userid'          => $contact['userid']
                    ]))
                        Log::error($contact['unionid'].'-存表失败！');
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $newGroupClosure = function ($groupId) {
            $tagMap = [];
            $groupTagData = ContactTagsDao::getAllList(['tag_order', 'tag_id'], [
                'group_id'       => $groupId,
                'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
            ]);

            foreach ($groupTagData as $tag) {
                $tagMap[$tag['tag_order']] = $tag['tag_id'];
            }

            return $tagMap;
        };

        [
            $levelTagMap,  // 会员等级
            $yanzhiTagMap, // 颜值等级
            $consumeTagMap // 累计消费
        ] = [
            $newGroupClosure('et5b2CBwAAkSMm5yU8poo265T8Ctpc6w'),
            $newGroupClosure('et5b2CBwAA2psCik_tcO25trr6X49JJw'),
            $newGroupClosure('et5b2CBwAAm6Vyw5uJwhrHyMtrsvZ_qw')
        ];

        $yanzhiData = $contactHttpDao->getYanzhi($unionId);
        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        // 颜值等级
        $yanzhiTag = $this->getYanzhiTag($yanzhiTagMap, $yanzhiData);
        // 会员等级
        $levelTag = $this->getLevelTag($levelTagMap, $userCenterData);
        // 累计消费
        $consumeTag = $this->getConsumeAmountTag($consumeTagMap, $userCenterData);

        $addTags = array_filter([$yanzhiTag, $levelTag, $consumeTag]);
        $removeTags = array_merge($levelTagMap, $yanzhiTagMap, $consumeTagMap);

        $contactTagHttpDao = new ContactTagHttpDao();

        $insertBatchData = [];

        $removeTagRes = $addTagRes = true;


        try {
            // 先移除所有标签
            $removeTagRes = $contactTagHttpDao->markTag(
                $carryData['userid'],
                $carryData['external_userid'],
                [],
                $removeTags
            );
            // 再打上新的标签
            $addTagRes = $contactTagHttpDao->markTag($carryData['userid'], $carryData['external_userid'], $addTags);

            foreach ($addTags as $tagId) {
                $searchData = [
                    'tag_id'          => $tagId,
                    'external_userid' => $carryData['external_userid'],
                    'userid'          => $carryData['userid']
                ];
                if (!ContactTagMapDao::isExistById(0, $searchData)) {
                    $insertBatchData[] = $searchData;
                }
            }
        } catch (Exception $e) {
            send_msg_to_wecom($carryData['unionid'] . '-' . $e->getMessage());
        }

        if ($removeTagRes == false || !$addTagRes) {
            send_msg_to_wecom($carryData['unionid'] . '-回调打标签失败！');
        } else {
            if ($insertBatchData) {
                if (!ContactTagMapDao::addBatchData($insertBatchData)) {
                    send_msg_to_wecom($carryData['unionid'] . '-回调打标签入库失败！');
                }
            }
        }

        return true;
    }


    /**
     * 获取用户的颜值标签
     *
     * @param array $yanzhiTagMap
     * @param array $yanzhiData
     * @return string
     */
    private function getYanzhiTag(array $yanzhiTagMap, array $yanzhiData): string
    {
        if ($yanzhiData['yanzhi_total'] < 1000) {
            $addTag = $yanzhiTagMap[1];
        } elseif ($yanzhiData['yanzhi_total'] >= 10000) {
            $addTag = $yanzhiTagMap[3];
        } else {
            $addTag = $yanzhiTagMap[2];
        }

        return $addTag;
    }

    /**
     * 获取用户的等级标签
     *
     * @param array $levelTagMap
     * @param array $userCenterData
     * @return mixed
     */
    private function getLevelTag(array $levelTagMap, array $userCenterData)
    {
        if (
            !isset($userCenterData['user_level_id'])
            || $userCenterData['user_level_id'] == null
        ) {
            $addTag = $levelTagMap[0];
        } else {
            $addTag = $levelTagMap[$userCenterData['user_level_id']];
        }

        return $addTag;
    }

    /**
     * 获取用户的累计消费标签
     *
     * @param array $consumeTagMap
     * @param array $userCenterData
     * @return string
     */
    private function getConsumeAmountTag(array $consumeTagMap, array $userCenterData): string
    {
        /*$addTag = '';

        if (
            $userCenterData['contractAmount'] == 0.0 ||
            $userCenterData['contractAmount'] === null
        ) {
            $addTag = $consumeTagMap[0];
        }

        if ($userCenterData['contractAmount'] == 1) {
            $addTag = $consumeTagMap[1];
        }

        if (
            $userCenterData['contractAmount'] > 1
            && $userCenterData['contractAmount'] <= 99
        ) {
            $addTag = $consumeTagMap[2];
        }

        if (
            $userCenterData['contractAmount'] > 99
            && $userCenterData['contractAmount'] <= 1000
        ) {
            $addTag = $consumeTagMap[3];
        }

        if (
            $userCenterData['contractAmount'] > 1000
            && $userCenterData['contractAmount'] <= 3000
        ) {
            $addTag = $consumeTagMap[4];
        }

        if (
            $userCenterData['contractAmount'] > 3000
            && $userCenterData['contractAmount'] <= 5000
        ) {
            $addTag = $consumeTagMap[5];
        }

        if ($userCenterData['contractAmount'] > 5000) {
            $addTag = $consumeTagMap[6];
        }

        return $addTag;*/
    }
}
