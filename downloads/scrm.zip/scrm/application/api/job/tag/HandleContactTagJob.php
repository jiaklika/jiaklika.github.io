<?php

namespace app\api\job\tag;

use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\job\BaseJob;
use Exception;

/**
 * 全局标签处理
 * 企业微信会经常返回-1系统繁忙，需要再次发起请求
 * 只负责和企业微信接口交互，处理客户的标签
 *
 * nohup php think queue:work --queue handle_contact_tag_queue --daemon >/dev/null 2>&1 &
 *
 * Class HandleContactTagJob
 * @package app\api\job\tag
 */
class HandleContactTagJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '标签处理任务';

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $contactTagHttpDao = new ContactTagHttpDao();

        $insertTagData = [];

        [
            $removeTags,
            $addTags
        ] =
        [
            $carryData['remove_tags'] ?? [],
            $carryData['add_tags'] ?? []
        ];

        try {
            $removeTagRes = $addTagRes = false;
            // 移除
            if ($removeTags) {
                $removeTagRes = $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    [],
                    array_filter($removeTags)
                );
            }

            // 添加
            if ($addTags) {
                $addTagRes = $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    array_filter(array_values($addTags))
                );

                if ($addTagRes) {
                    // 要记录的数据
                    foreach ($addTags as $addTag) {
                        $insertTagData[] = [
                            'tag_id'          => $addTag,
                            'external_userid' => $carryData['external_userid'],
                            'userid'          => $carryData['userid']
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            send_msg_to_wecom(sprintf(
                'HandleContactTagJob出错了-%s-%s',
                $carryData['userid'],
                $e->getMessage()
            ));
            return false; // 重试
        }

        $isTagSuccess = $deleteRes = $addRes = true;

        if ($removeTagRes) {
            // 删除旧数据，新数据入表
            $deleteRes = ContactTagMapDao::hardDelete([
                'external_userid' => $carryData['external_userid'],
                'tag_id'          => ['in', $removeTags],
                'userid'          => $carryData['userid']
            ]);
        }

        if ($addTagRes) {
            $addRes = ContactTagMapDao::addBatchData($insertTagData);
        }

        if ($deleteRes === false || !$addRes) {
            $isTagSuccess = false;
            send_msg_to_wecom('更改表失败！'); // 不需要重试了
        }

        if (
            isset($carryData['func'])
            && !empty($carryData['func'])
        ) {
            $wrapper = unserialize($carryData['func']);

            $closure = $wrapper->getClosure();

            $closure($isTagSuccess);
        }

        return true;
    }
}
