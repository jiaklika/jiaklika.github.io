<?php

namespace app\api\job\tag;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\data\PushFansDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactTags;
use app\common\model\ContactWays;
use Carbon\Carbon;
use Exception;
use think\Cache;
use think\Db;
use think\Queue;

/**
 * 标签都放在这儿统一处理
 *
 * nohup php think queue:work --queue callback_tag_queue --daemon > callback_tag_queue.log 2>&1 &
 * nohup php think queue:work --queue callback_tag_queue --daemon >/dev/null 2>&1 &
 *
 * Class CallbackMarkTagJob
 * @package app\api\job
 */
class CallbackMarkTagJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '回调标签处理任务';

    /**
     * 添加客户后为其添加标签
     *
     * @param array $carryData 客户详情数组
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        /*$carryData = [
            'external_userid' => 'wm5b2CBwAAf0mW1qcBHQmuToCxzw-L7Q',
            'unionid'         => 'owTq1jsqtFF1r4J83a5cRxBYataw',
            'userid'          => 'yangyang3',
            'state'           => 114
        ];*/

        // 推送到打标签队列
        $pushToQueueClosure = function (array $queueCarryData, string $errorMsg) {
            try {
                Queue::push(
                    ContactTags::HANDLE_CONTACT_TAG_HANDLER,
                    $queueCarryData,
                    ContactTags::HANDLE_CONTACT_TAG_QUEUE
                );
            } catch (Exception $e) {
                send_msg_to_wecom("进入{$errorMsg}处理标签队列出错：" . $e->getMessage());
            }
        };

        $unionId = $carryData['unionid'];

        $contactHttpDao = new ContactHttpDao();

        // 加了好友后，添加"好友"标签，移除"非好友"标签-begin
        $pushToQueueClosure(
            [
                'add_tags'        => [ContactTags::IS_FRIEND_TAG],
                'remove_tags'     => [ContactTags::NOT_FRIEND_TAG],
                'userid'          => $carryData['userid'],
                'external_userid' => $carryData['external_userid']
            ],
            '好友组'
        );

        // 该客户所有的联系人-begin
        // 客户删除员工，照样打标签
        $allFollowUsers = ContactFollowUserDao::getAllList(
            [
                'userid',
                'external_userid'
            ],
            [
                'external_userid' => $carryData['external_userid'],
                'status'          => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]
            ]
        );
        // 该客户所有的联系人-end

        // 根据标签组ID获取所有标签 begin
        $redis = Cache::store()->handler();

        // 从表里查找
        $newGroupClosure = function ($groupId, $groupName, $keyName) use ($redis) {
            $tagMap = [];
            $groupTagData = ContactTagsDao::getAllList(['tag_order', 'tag_id', 'tag_name'], [
                'group_id'       => $groupId,
                'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
            ]);

            foreach ($groupTagData as $tag) {
                $tagMap[$tag[$keyName]] = $tag['tag_id'];
            }

            $redis->hset(ContactTags::CALLBACK_REDIS_SET_KEY, $groupName, json_encode($tagMap));

            return $tagMap;
        };

        // redis是否有值
        $getDataFromRedis = function ($name) use ($redis) {
            return ($json = $redis->hget(ContactTags::CALLBACK_REDIS_SET_KEY, $name)) ? json_decode($json, true) : '';
        };

        // redis没值就从表里取
        $getTagArr = function ($groupId, $groupName, $keyName) use ($getDataFromRedis, $newGroupClosure) {
            return $getDataFromRedis($groupName) ? : $newGroupClosure($groupId, $groupName, $keyName);
        };

        [
            $levelTagMap,
            $yanzhiTagMap,
            $newConsumeTagMap
        ] =
        [
            $getTagArr(ContactTags::GROUP_ID_MAP['member_level'], ContactTags::MEMBER_LEVEL, 'tag_order'),
            $getTagArr(ContactTags::GROUP_ID_MAP['yanzhi_rank'], ContactTags::YANZHI_RANK, 'tag_order'),
            $getTagArr(ContactTags::GROUP_ID_MAP['new_contract_amount'], ContactTags::NEW_CONTRACT_AMOUNT, 'tag_name')
        ];

        // 根据标签组ID获取所有标签 end
        try {
            // 根据用户信息获取对应的标签-begin
            $yanzhiData = $contactHttpDao->getYanzhi($unionId);
            $userCenterData = $contactHttpDao->getUserCenter($unionId);
            // 颜值等级
            $yanzhiTag = $this->getYanzhiTag($yanzhiTagMap, $yanzhiData);
            // 会员等级
            $levelTag = $this->getLevelTag($levelTagMap, $userCenterData);
            // 新的累计消费
            $newConsumeTag = $this->getNewConsumeAmountTag($contactHttpDao, $newConsumeTagMap, $userCenterData);

            // 来源渠道
            $channelTag = $this->getChannelTag($carryData['state'], $carryData['userid']);
            // 2021-03-24 #258
            // 是否入群
            $inFeiyueGroupTag = $this->getNotInSpecialGroupTag('feiyue', $carryData['external_userid']);
            $inZhaoweiGroupTag = $this->getNotInSpecialGroupTag('zhaowei', $carryData['external_userid']);
            // 根据用户信息获取对应的标签-end
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage() . $e->getTraceAsString());
            return false;
        }

        // 组织要添加和移除的标签-begin
        $addTags = array_filter([$yanzhiTag, $levelTag, $newConsumeTag]);
        if ($inFeiyueGroupTag) {
            array_push($addTags, $inFeiyueGroupTag);
        }
        if ($inZhaoweiGroupTag) {
            array_push($addTags, $inZhaoweiGroupTag);
        }
        $removeTags = array_merge($levelTagMap, $yanzhiTagMap, array_values($newConsumeTagMap));

        // 组织要添加和移除的标签-end

        // 来源渠道是各打各的，所以没有循环，只打一次
        $pushToQueueClosure(
            [
                'add_tags'        => [$channelTag],
                'userid'          => $carryData['userid'],
                'external_userid' => $carryData['external_userid']
            ],
            '来源渠道'
        );

        // 颜值，等级和累计消费是通用的
        // 即A客户有X，Y，Z三名客服，当A客户的等级由宝迷变为铁杆宝迷时，X，Y，Z的A客户标签都要变
        // X,Y,Z中Z打不上，不影响X，Y打，打不上肯定有原因，发出通知
        foreach ($allFollowUsers as $followValue) {
            $pushToQueueClosure(
                [
                    'add_tags'        => $addTags,
                    'remove_tags'     => $removeTags,
                    'userid'          => $followValue['userid'],
                    'external_userid' => $followValue['external_userid']
                ],
                '颜值等'
            );
        }

        // 是否在宝姐家小红书福利群中
        $isInRedBookGroup = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'left')
            ->field([
                'a.id'
            ])
            ->where([
                'b.name'       => ['like', '%小红书福利%'],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.userid'     => $carryData['external_userid']
            ])
            ->find();

        $redBookUserId = 'joyee';
        if ($isInRedBookGroup || $carryData['userid'] === $redBookUserId) {
            // 判定该用户之前是否添加过公司任一企微号
            $firstAddInfo = ContactFollowUserDao::getDetail(
                [
                    'userid',
                ],
                [
                    'external_userid' => $carryData['external_userid'],
                    'is_first_add'    => 1
                ]
            );

            if (!$firstAddInfo) {
                // 是否进过任一企微群
                if (!ContactGroupMembersDao::getDetail(['id'], ['userid' => $carryData['external_userid']])) {
                    // 若没有则打上"小红书"标签。
                    $pushToQueueClosure(
                        [
                            'add_tags'        => [ContactTags::RED_BOOK_TAG],
                            'userid'          => $carryData['userid'],
                            'external_userid' => $carryData['external_userid']
                        ],
                        '小红书'
                    );
                }
            }
        }

        $pushFansData = PushFansDao::getDetail(
            [
                'id',
                'is_tag',
                'create_time'
            ],
            [
                'unionid' => $unionId,
            ]
        );
        if (
            isset($pushFansData['is_tag'])
            && $pushFansData['is_tag'] == 0
        ) {
            $year  = date('Y', strtotime($pushFansData['create_time']));
            $month = date('m', strtotime($pushFansData['create_time']));
            $day   = date('d', strtotime($pushFansData['create_time']));
            $date = Carbon::create($year, $month, $day);
            $createDate = $date->startOfWeek()->toDateString();
            $tagData = ContactTagsDao::getDetail(
                [
                    'tag_id'
                ],
                [
                    'group_id' => ContactTags::PUSH_FANS_GROUP_TAG,
                    'tag_name' => ['like', "%{$createDate}%"]
                ]
            );

            if ($tagData) {
                $pushToQueueClosure(
                    [
                        'add_tags'        => [$tagData['tag_id']],
                        'userid'          => $carryData['userid'],
                        'external_userid' => $carryData['external_userid']
                    ],
                    '后加好友打推粉标签'
                );
            }

            PushFansDao::updateData(
                [
                    'is_tag'   => 1,
                    'tag_time' => time()
                ],
                [
                    'id' => $pushFansData['id']
                ]
            );
        }

        // 分享员标签
        if ($carryData['state'] == ContactWays::RECRUITING_OFFICER_ID) {
            $pushToQueueClosure(
                [
                    'add_tags'        => [ContactTags::SHARER_TAG],
                    'userid'          => $carryData['userid'],
                    'external_userid' => $carryData['external_userid']
                ],
                '分享员标签'
            );
        }


        return true;
    }

    /**
     * 获取用户的颜值标签
     *
     * @param array $yanzhiTagMap
     * @param array $yanzhiData
     * @return string
     */
    private function getYanzhiTag(array $yanzhiTagMap, array $yanzhiData): string
    {
        if ($yanzhiData['yanzhi_total'] < 1000) {
            $addTag = $yanzhiTagMap[1];
        } elseif ($yanzhiData['yanzhi_total'] >= 10000) {
            $addTag = $yanzhiTagMap[3];
        } else {
            $addTag = $yanzhiTagMap[2];
        }

        return $addTag;
    }

    /**
     * 获取用户的等级标签
     *
     * @param array $levelTagMap
     * @param array $userCenterData
     * @return mixed
     */
    private function getLevelTag(array $levelTagMap, array $userCenterData)
    {
        if (
            !isset($userCenterData['user_level_id'])
            || $userCenterData['user_level_id'] == null
        ) {
            $addTag = $levelTagMap[0];
        } else {
            $addTag = $levelTagMap[$userCenterData['user_level_id']];
        }

        return $addTag;
    }

    /**
     * 获取新的用户的累计消费标签
     *
     * @param ContactHttpDao $contactHttpDao
     * @param array $newConsumeTagMap
     * @param array $userCenterData
     * @return string
     * @throws Exception
     */
    private function getNewConsumeAmountTag(
        ContactHttpDao $contactHttpDao,
        array $newConsumeTagMap,
        array $userCenterData
    ): string {
        $addTag = $newConsumeTagMap[0];

        if ($mobile = $userCenterData['mobile']) {
            try {
                $consumeInfo = $contactHttpDao->getConsumeSegment($mobile);
                if (isset($consumeInfo['utype']) && !empty($consumeInfo['utype'])) {
                    $addTag = $newConsumeTagMap[$consumeInfo['utype']];
                }
            } catch (Exception $e) {
                send_msg_to_wecom($mobile . $e->getMessage());
            }
        }

        return $addTag;
    }

    /**
     * 获取用户的来源渠道
     *
     * @param mixed $state 路径ID
     * @param $user
     * @return string
     * @throws Exception
     */
    private function getChannelTag($state, $user): string
    {
        if ($state !== 0) {
            /**
             * 获取渠道对应的标签ID
             *
             * @param int $channelId 渠道ID
             * @return string
             * @throws Exception
             */
            $getTagId = function (int $channelId): string {
                $tagIdInfo = ContactChannelsDao::getDetail(
                    ['tag_id'],
                    [
                        'id'         => $channelId,
                        'is_deleted' => 0
                    ]
                );
                return $tagIdInfo['tag_id'] ?? '';
            };

            if ($state === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                $channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);

                if (in_array($user, $channelMap)) {
                    $channelTag = $getTagId(search_two_dimensional_array($user, ContactChannels::MOMENT_CHANNEL_MAP));
                }
            } else {
                if (
                    $wayInfo = ContactWaysDao::getDetail(
                        ['channel_id'],
                        [
                            'id' => $state
                        ]
                    )
                ) {
                    $channelTag = $getTagId($wayInfo['channel_id']);
                }
            }
        }

        return (isset($channelTag) && $channelTag)
            ? $channelTag
            : ContactTags::CHANNEL_UNKNOWN_TAG_ID;
    }

    /**
     * 获取"是否入群"标签
     *
     * @param string $userId 员工userId
     * @param string $externalUserId 外部联系人的userId
     * @return string
     * @throws Exception
     */
    private function getNotInSpecialGroupTag(string $userId, string $externalUserId): string
    {
        $userServiceImpl = new UserServiceImpl();
        $accountsArr = $userServiceImpl->getSpecificUserAccount($userId);

        $accountsGroupArr = ContactGroupDao::getAllList(['chat_id'], [
            'owner'      => ['in', $accountsArr],
            'is_deleted' => ContactGroups::NOT_DELETED
        ]);

        $nowGroupArr = ContactGroupMembersDao::getAllList(['chat_id'], [
            'userid'     => $externalUserId,
            'is_deleted' => ContactGroupMembers::NOT_DELETED
        ]);

        if (
            array_intersect(
                array_column($nowGroupArr, 'chat_id'),
                array_column($accountsGroupArr, 'chat_id')
            )
        ) {
            return '';
        }

        return ContactTags::NOT_IN_GROUP_TAG[$userId];
    }
}
