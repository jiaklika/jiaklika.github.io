<?php

namespace app\api\job\tag;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\job\BaseJob;
use Exception;
use think\Log;

/**
 * Class InitContactTagJob
 * @package app\api\job\tag
 */
class InitContactTagJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '初始化客户标签任务';

    /**
     * @param $carryData
     * @return mixed|void
     * @throws Exception
     */
    public function doJob($carryData)
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        [
            $contactHttpDao,
            $contactTagHttpDao
        ] =
        [
            new ContactHttpDao(),
            new ContactTagHttpDao()
        ];

        $userCenterData = $contactHttpDao->getUserCenter($unionId);


        $newConsumeTagMap = [
            0              => 'et5b2CBwAA76ReXTkes_D-nKUSTd6MJA',
            '(0,10]'       => 'et5b2CBwAAGEM3h6pr0Z0IVFbF0jLatg',
            '(10,100]'     => 'et5b2CBwAAoXwtl-WENfT6kwqW06J7_w',
            '(100,500]'    => 'et5b2CBwAAVf-KFhLfaSKgEBLWqZy7dw',
            '(500,1k]'     => 'et5b2CBwAAJNluhi4VCtC7390ayoqWqw',
            '(1k,3k]'      => 'et5b2CBwAA3268_JvgFLiGmi6Ru_WkBA',
            '(3k,5k]'      => 'et5b2CBwAA5YIudYAaxVt4w_4U30ZkwQ',
            '(5k,1w]'      => 'et5b2CBwAAUbTNXdp5kexYIkEKpX0JhQ',
            '(1w,3w]'      => 'et5b2CBwAAW_ZpBOSr1uPInhS5PJS7kA',
            '(3w,5w]'      => 'et5b2CBwAAXMCVDnnjmGlvXa5bo_XB7A',
            '(5w,10w]'     => 'et5b2CBwAAuqtpn2YqHP0iUHuSsRu3mg',
            '(10w,30w]'    => 'et5b2CBwAA93qpyFN013I0lS5opyrTPA',
            '(30w,50w]'    => 'et5b2CBwAAaH8YJfJQ7sLs9RM-L-eZ-g',
            '(50w,100w]'   => 'et5b2CBwAAZFm9popS-jOITu4_z0kWRg',
            '(100w,300w]'  => 'et5b2CBwAAMBzvOWrPKoSRstK0w8Jc9A',
            '(300w,500w]'  => 'et5b2CBwAADpign5ANQA9Ttr0jssUY9w',
            '(500w,1000w]' => 'et5b2CBwAAZNwdWClKasg03q9bAQuYwg',
            '(1000w,+∞)'   => 'et5b2CBwAAL6fkRIWFa8TqFv4op34Iug',
        ];

        try {
            // 新的累计消费
            $addTag = $newConsumeTagMap[0];

            if ($mobile = $userCenterData['mobile']) {
                $consumeInfo = $contactHttpDao->getConsumeSegment($mobile);

                if (isset($consumeInfo['utype']) && !empty($consumeInfo['utype'])) {
                    $addTag = $newConsumeTagMap[$consumeInfo['utype']];
                }
            }

            // 打上新的标签
            $contactTagHttpDao->markTag(
                $carryData['userid'],
                $carryData['external_userid'],
                [$addTag]
            );

            ContactTagMapDao::hardDelete([
                'tag_id'          => $addTag,
                'external_userid' => $carryData['external_userid'],
                'userid'          => $carryData['userid']
            ]);

            // 组织待写入标签映射表的数据
            ContactTagMapDao::addData([
                'tag_id'          => $addTag,
                'external_userid' => $carryData['external_userid'],
                'userid'          => $carryData['userid']
            ]);
        } catch (Exception $e) {
            Log::error($e->getMessage());
            return false;
        }
        return true;
    }
}
