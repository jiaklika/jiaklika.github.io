<?php

namespace app\api\job\tag;

use app\api\controller\ContactGroup;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\OpengidRecordsDao;
use app\api\dao\mysql\message\GroupMsgReceiveMapDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ExternalContact;
use Carbon\Carbon;
use Exception;
use think\Cache;
use think\Db;
use think\Log;
use think\queue\Job;

//
/**
 * Class MarkPropagandaTagJob
 * @package app\api\job
 */
class MarkPropagandaTagJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '打宣传标签任务';

    /**
     * 不在宝姐家优享群、宝姐家新粉福利群、进群看群公告、宝姐家珠宝知识视频分享群的
     *
     * 1、不在群内的铁杆及以上的宝迷，打标签"周五宣传"
     * 2、不在群内的忠实宝迷，打标签"周六宣传"
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if(!$unionId = $contact['unionid'])
            return true;

        $redis = Cache::store()->handler();

        $addTags = $removeTags = [];

        // 在群里，判断是否在那三类群中
        if ($groupMemberInfo = ContactGroupMembersDao::getAllList(
            ['chat_id'],
            [
                'is_deleted' => ContactGroupMembers::NOT_DELETED,
                'unionid'    => $unionId
            ]
        ))
        {
            $groupIdArr = array_column($groupMemberInfo, 'chat_id');

            foreach ($groupIdArr as $chatId)
            {
                // 在三类群中，直接退出了
                if ($redis->sIsMember('notInGroupChatId', $chatId))
                    return true;
            }
        }

        // 不在任何群或三类群里，就判断等级

        $contactTagHttpDao = new ContactTagHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if ($userCenterData['user_level_id'] == ExternalContact::LOYAL_FANS)
        {
            $addTags = [
                'et5b2CBwAAp90y9F4jFlYceGl87Zx2jg' // 周六宣传
            ];

            Log::info($contact['unionid'].'-周六宣传！');
        }

        if ($userCenterData['user_level_id'] >= ExternalContact::BIG_FANS)
        {
            $addTags = [
                'et5b2CBwAAebDL12M5IEG2c3aO99gj7w' // 周五宣传
            ];
            Log::info($contact['unionid'].'-周五宣传！');
        }
        // 等级不满足条件，就退出
        if (!$addTags)
            return true;

        Log::info($contact['unionid'].'-等级是-'.$userCenterData['user_level_id']);

        try {
            if ($markRes = $contactTagHttpDao->markTag(
                $contact['userid'],
                $contact['external_userid'],
                $addTags, // 打标签
                $removeTags // 移除标签
            ))
            {
                if (ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]))
                    Log::info($contact['unionid'].'-添加成功！');
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 消费大于等于99小于等于3000
     * 1个月内没登录过三端的
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        // 消费条件不满足，直接退出
        if (
            $userCenterData['contractAmount'] < 99
            || $userCenterData['contractAmount'] > 3000
        ) {
            return true;
        }

        // 判断登录条件-begin
        // 1个月以前
        $oneMonthsAgo = strtotime(date('Y-m-d', strtotime('-1 months')));

        // 登录过
        $isLoginFunc = function ($loginTime) use ($oneMonthsAgo) {
            if ($loginTime > $oneMonthsAgo) {
                return true;
            }
            return false;
        };

        $removeTags = [];

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($unionId),
            $contactHttpDao->getLiveRank($unionId),
            $contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $judgeFunc = function ($lastLogin) use ($isLoginFunc, $unionId) {
            if (
                !empty($lastLogin)
                && $isLoginFunc($lastLogin)
            ) {
                return true;
            }
            return false;
        };

        // 1个月内登录过三个中的一个就退出
        if (
            $judgeFunc($yanZhiInfo['last_login'])
            || $judgeFunc($liveRank['last_login']
            || $judgeFunc($appLastLogin['app_last_login']))
        ) {
            return true;
        } else {
            $redis = Cache::store()->handler();
            $redis->sAdd('tag_unoinId', $unionId);
            $addTags = ['et5b2CBwAAGjugn8GXZL7skWsYNGXfAw'];
        }
        // 判断登录条件-end

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 阳阳1、阳阳、费月的号
     * 忠实到名媛
     * 周日宣传
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if (!in_array($userCenterData['user_level_id'], [2,3,4])) {
            return true;
        }

        $addTags = ['et5b2CBwAA3santZ4W29vqP9zlnMwAZQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 给外部联系人删除员工的用户打上“非好友”标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        // 不在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');
        $zhaoweiAccounts = array_filter($zhaoweiAccounts, function ($val) {
            if ($val !== 'xiuxiu') {
                return true;
            }
            return false;
        });

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $carryData,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->select();

        // 如果是赵蔚名下任一个号里的客户，就直接退出
        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAzJk_AYP9IyWLWmobjWrrKA'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $contact) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $contact['userid'],
                        $contact['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $contact['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $contact['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 阳阳1和阳阳号上的，不在宝姐家好物优享群和宝姐家新粉福利群的消费为0的用户打上“群外新客”
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        // 先判断消费
        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if ($userCenterData['contractAmount'] != 0) {
            return true;
        }

        $getGroupClosure = function ($groupName) {
            $groupArr = ContactGroupDao::getAllList(
                [
                    'chat_id'
                ],
                [
                    'name'       => ['like', "%{$groupName}%"],
                    'is_deleted' => ContactGroups::NOT_DELETED
                ]
            );

            return array_column($groupArr, 'chat_id');
        };

        $allChatIdArr = array_merge($getGroupClosure('好物优享'), $getGroupClosure('新粉福利'));

        // 在群里就退出
        if (
            ContactGroupMembersDao::getDetail(
                [
                    'id'
                ],
                [
                    'unionid'    => $unionId,
                    'chat_id'    => ['in', $allChatIdArr],
                    'is_deleted' => ContactGroupMembers::NOT_DELETED
                ]
            )
        ) {
            return true;
        }

        $addTags = ['et5b2CBwAAwrjXwMCVH3o-Aary0BRQ9w'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 将颜值大于等于1000且最后1次登陆宝姐家小程序时间在1个月内的用户打上“颜值加价购推广”标签
     *
     * @param $contact
     * @return bool|mixed
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        // 先判断颜值
        $contactHttpDao = new ContactHttpDao();

        $yanzhiData = $contactHttpDao->getYanzhi($unionId);

        if ($yanzhiData['yanzhi_total'] < 1000) {
            return true;
        }

        // 1个月前
        $mtime = strtotime(date('Y-m-d 00:00:00', strtotime('-1 month')));

        if ($yanzhiData['last_login'] < $mtime) {
            return true;
        }

        // 不在赵蔚群内
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        if ($groupInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAUINtCvGhQE4cANVVwRgZfg'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 7.30继承
     *
     * @param $contact
     * @return bool|mixed
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        // 先判断消费过的
        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($unionId);

        if ($userInfo['contractAmount'] == 0) {
            return true;
        }

        // 3个月内登录过宝姐家小程序
        $loginInfo = $contactHttpDao->getYanzhi($unionId);
        $mtime = strtotime(date('Y-m-d 00:00:00', strtotime('-3 month')));

        if ($loginInfo['last_login'] < $mtime) {
            return true;
        }

        // 不在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $contactInfo = ContactFollowUserDao::getDetail(['id'], [
            'userid'          => ['in', $zhaoweiAccounts],
            'external_userid' => $contact['external_userid'],
            'status'          => ContactFollowUser::NORMAL
        ]);

        if ($contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAnNKFs1T7NwNHNBTrtefEQA'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 0802抽奖活动
     *
     * @param $contact
     * @return bool|mixed
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $addTags = ['et5b2CBwAA6svlfRBLnk39fwkjfp9itQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 大拍画册
     *
     * @param $contact
     * @return bool|mixed
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        // 消费低于300元（含）的用户
        $contactHttpDao = new ContactHttpDao();

        $contactInfo = $contactHttpDao->getUserCenter($unionId);

        if ($contactInfo['contractAmount'] > 300) {
            return true;
        }

        $addTags = ['et5b2CBwAAsE3LJafxjpX2rbjIX8I2rg'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $markRes = $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contact['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contact['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * ⑴0元＜消费＜300元 标签名称：画册用户
     * ⑵未消费的用户，10000≤颜值＜50000 标签名称：画册低颜
     * ⑶未消费的用户，50000≤颜值＜100000 标签名称：画册高颜
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $contactInfo = $contactHttpDao->getUserCenter($unionId);

        if ($contactInfo['contractAmount'] != 0) {
            return true;
        }

        $addTags = [];

        // 未消费的用户
        if ($contactInfo['contractAmount'] == 0) {
            $yanzhiData = $contactHttpDao->getYanzhi($unionId);

            $yanzhiTotal = $yanzhiData['yanzhi_total'];

            if ($yanzhiTotal < 10000 || $yanzhiTotal >= 100000) {
                return true;
            }

            if ($yanzhiTotal >= 10000 && $yanzhiTotal < 50000) {
                $addTags = ['et5b2CBwAAJyTDXltAf2TJLmHWxRjcxA']; // 画册低颜
            }

            if ($yanzhiTotal >= 50000 && $yanzhiTotal < 100000) {
                $addTags = ['et5b2CBwAAXiabb8kJ6A1Bz3OihzAxvg']; // 画册高颜
            }
        }
        /*if (
            $contactInfo['contractAmount'] > 0
            && $contactInfo['contractAmount'] <= 300
        ) {
            $addTags = ['et5b2CBwAASGPA-_c6RPtRymnjL6mt_A']; // 画册用户
        }*/

        /*if ($addTags) {
            $contactTagHttpDao = new ContactTagHttpDao();

            try {
                if (
                    $markRes = $contactTagHttpDao->markTag(
                        $carryData['userid'],
                        $carryData['external_userid'],
                        $addTags // 打标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $carryData['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $carryData['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 8月继承
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData) {
            return true;
        }

        // 不在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.id',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->find();

        // 如果是赵蔚名下任一个号里的客户，就直接退出
        if ($contactInfo) {
            return true;
        }

        // 再查一遍
        $contactData = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->find();

        if (!$contactData) {
            return true;
        }

        $addTags = ['et5b2CBwAAl2lRPnThxxDBdt_NqhHkqQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $contactData['userid'],
                    $contactData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $contactData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $contactData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 按月份打x月推粉标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('a.external_userid')
            ->select();

        // 如果不是赵蔚名下任一个号里的客户，就直接退出
        if (!$contactInfo) {
            return true;
        }

        $addTags = [];

        if ($carryData['year'] == '2021') {
            switch ($carryData['month']) {
                case '01':
                    $addTags = ['et5b2CBwAAXupPUCMC3pww_UUe1X6xjw'];
                    break;
                case '02':
                    $addTags = ['et5b2CBwAArIcta6b_VA2bvWp9-BCj8A'];
                    break;
                case '03':
                    $addTags = ['et5b2CBwAAQJ9N7Md611M4u8AWMqLkNw'];
                    break;
                case '04':
                    $addTags = ['et5b2CBwAAT3yzCljlpnGio0XljSafCg'];
                    break;
                case '05':
                    $addTags = ['et5b2CBwAAKyS34Cz63AtQ6KbB_o9NDQ'];
                    break;
                case '06':
                    $addTags = ['et5b2CBwAAAdm3Qrt9qz4l_Vc7jR4Rkg'];
                    break;
                case '07':
                    $addTags = ['et5b2CBwAA2HBAIWMOXlnUi_HL_7V4yw'];
                    break;
                case '08':
                    $addTags = ['et5b2CBwAAujg9a5boRSBtn-BjZbJXFw'];
                    break;
                case '09':
                    $addTags = ['et5b2CBwAAf6y-uZfwd5cwUNJSDJP-lw'];
                    break;
                case '10':
                    $addTags = ['et5b2CBwAAFpF8l3sIpxvSq9VK5xiMvA'];
                    break;
            }
        } else {
            switch ($carryData['month']) {
                case '04':
                    $addTags = ['et5b2CBwAAb5LsNBmj8ND1DhLb4Lhsgw'];
                    break;
                case '05':
                    $addTags = ['et5b2CBwAA__SFecfCbnXMD3kHnfFzwQ'];
                    break;
                case '06':
                    $addTags = ['et5b2CBwAAPJAVAW_rthmFHQYU71BG4g'];
                    break;
                case '07':
                    $addTags = ['et5b2CBwAAG1VZaf_pS2mNBgzWJWkPbA'];
                    break;
                case '08':
                    $addTags = ['et5b2CBwAAcW7HC-5YQQKGtOiXon1DdA'];
                    break;
                case '09':
                    $addTags = ['et5b2CBwAA96aPUuw3IZ5ajNiV7lOVug'];
                    break;
                case '10':
                    $addTags = ['et5b2CBwAA6aCz07Myc242SZpnmiBWkQ'];
                    break;
                case '11':
                    $addTags = ['et5b2CBwAAIJC1jR1fs4oKbFM3mAGqdQ'];
                    break;
                case '12':
                    $addTags = ['et5b2CBwAAKus4_7ffxf5U5ZgR5NTCSw'];
                    break;
            }
        }
        if (!$addTags) {
            return true;
        }

        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 匹配出在企微里的人，去重打上公司级标签“9月推粉”
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在任一企微号中
        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('a.external_userid')
            ->select();

        // 如果不是任一个号里的客户，就直接退出
        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAlUGgUzIB2ZTkQR67cNI5iw'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * “拼团10.15”标签
     * 费月名下个人号里，8月1日至今有过购买行为的客户
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $eightFirstDay = strtotime('2021-08-01');

        $userCenterInfo = $contactHttpDao->getUserCenter($unionId);

        if (
            !isset($userCenterInfo['last_consume_date'])
            || strtotime($userCenterInfo['last_consume_date']) < $eightFirstDay
        ) {
            return true;
        }

        $addTags = ["et5b2CBwAAOuxBcdGjLDjBt6M6LURkTQ"];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * “10.23群享价活动”标签
     * 不在赵蔚群内的
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        // 在赵蔚的群中就直接退出
        $isInZhaoWeiGroup = Db::name('contact_group_members')
            ->alias('a')
            ->join(
                'scrm_contact_groups b',
                'a.chat_id = b.chat_id',
                'LEFT'
            )
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'unionid'      => $unionId,
                'a.is_deleted' => 0,
                'b.is_deleted' => 0
            ])
            ->find();

        if ($isInZhaoWeiGroup) {
            return true;
        }

        $addTags = ["et5b2CBwAA_tF5XJmxTy4dZjbUWbjV_g"];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 给客户打"朋友圈推广"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('a.external_userid')
            ->select();

        // 如果不是赵蔚名下任一个号里的客户，就直接退出
        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAohb8ztYCc34qKYxvTuqu7w'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 商品偏好标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->select();

        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAO8g1ckTXx8bLg7rhFqwq1g'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 双11通知
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 6个月前
        $sixMonthAgo = 1620489600;
        // 1年以前
        $oneYearAgo = 1604851200;

        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($unionId);
        $login1 = $contactHttpDao->getYanzhi($unionId);
        $login2 = $contactHttpDao->getAppLastLoginTime($unionId);
        $login3 = $contactHttpDao->getLiveRank($unionId);

        $addTags = [];

        if ($userInfo['user_level_id'] == 1) {
            if (
                $login1['last_login'] >= $sixMonthAgo
                || $login2['app_last_login'] >= $sixMonthAgo
                || $login3['last_login'] >= $sixMonthAgo
            ) {
                $addTags = ['et5b2CBwAA6GQ-lH8CR_0OuXkj9RXAxQ'];
            }
        } elseif (in_array($userInfo['user_level_id'], [2,3,4])) {
            if (
                $login1['last_login'] >= $oneYearAgo
                || $login2['app_last_login'] >= $oneYearAgo
                || $login3['last_login'] >= $oneYearAgo
            ) {
                $addTags = ['et5b2CBwAAbXteIPODK90sxaXw65Gf5w'];
            }
        } else {
            return true;
        }

        if (empty($addTags)) {
            return true;
        }

        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 6个月前
        $sixMonthAgo = 1620489600;
        // 1年以前
        $oneYearAgo = 1604851200;

        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($unionId);
        $login1 = $contactHttpDao->getYanzhi($unionId);
        $login2 = $contactHttpDao->getAppLastLoginTime($unionId);
        $login3 = $contactHttpDao->getLiveRank($unionId);

        $addTags = [];

        if ($userInfo['user_level_id'] == 1) {
            if (
                $login1['last_login'] >= $sixMonthAgo
                || $login2['app_last_login'] >= $sixMonthAgo
                || $login3['last_login'] >= $sixMonthAgo
            ) {
                $addTags = ['et5b2CBwAA6GQ-lH8CR_0OuXkj9RXAxQ'];
            }
        } elseif (in_array($userInfo['user_level_id'], [2,3,4])) {
            if (
                $login1['last_login'] >= $oneYearAgo
                || $login2['app_last_login'] >= $oneYearAgo
                || $login3['last_login'] >= $oneYearAgo
            ) {
                $addTags = ['et5b2CBwAAbXteIPODK90sxaXw65Gf5w'];
            }
        } else {
            return true;
        }

        if (empty($addTags)) {
            return true;
        }

        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 双11退群
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        // 如果是赵蔚名下任一群里的客户，就直接退出
        if ($groupInfo) {
            return true;
        }

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL,
                'userid'  => ['in', $zhaoweiAccounts]
            ])
            ->group('a.external_userid')
            ->select();

        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAOnSyoNxiLM6pyEfoiISqZQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 筛出【在费月名下个号】（不在赵蔚名下各个号和群内）且【互为好友关系】的【已消费】（珠宝后台有支付订单）客户并打上标签【转粉】（营销业务标签）；
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        // 如果是赵蔚名下任一群里的客户，就直接退出
        if ($groupInfo) {
            return true;
        }

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL,
                'userid'  => ['in', $zhaoweiAccounts]
            ])
            ->select();

        // 如果是赵蔚的客户，就直接退出
        if ($contactInfo) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();
        $isConsume = $contactHttpDao->getIsConsume($unionId);

        // 如果没消费，直接退出
        if (!$isConsume) {
            return true;
        }

        $addTags = ['et5b2CBwAAEB_wzfvDWSctZIdPOenWAA'];

        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * 转粉2
     * 2、筛出【只在费月群内】（不在赵蔚名下各个号和群内，不在费月号内）的【已消费】（珠宝后台有支付订单）客户，导出excel，表头如下：
    昵称、会员等级、所在群（如有多个群的话，展示多行）
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        // 如果是赵蔚名下任一群里的客户，就直接退出
        if ($groupInfo) {
            return true;
        }

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL,
                'userid'  => ['in', $zhaoweiAccounts]
            ])
            ->select();

        // 如果是赵蔚的客户，就直接退出
        if ($contactInfo) {
            return true;
        }

        $feiyueContactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL,
                'userid'  => ['in', $feiyueAccounts]
            ])
            ->select();

        // 如果是费月的客户，就直接退出
        if ($feiyueContactInfo) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();
        $isConsume = $contactHttpDao->getIsConsume($unionId);

        // 如果没消费，直接退出
        if (!$isConsume) {
            return true;
        }

        file_put_contents('1.txt', $unionId . ',' . PHP_EOL, FILE_APPEND);
        return true;
    }*/

    /**
     * 推粉
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        // 赵蔚的好友
        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('a.external_userid')
            ->select();

        // 如果不是赵蔚任一个号里的客户，就直接退出
        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAswTzYbo7jMadby6LfDEuzQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 给朋友圈客户打"11.26~12.11珍珠加粉定向"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAAMuWmLl7ia0TJFWVKsKMExQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }


        return true;
    }*/

    /**
     * 打"12.16珍珠广告加粉"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $memberInfo = Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'member.unionid'
            ])
            ->join(
                'scrm_contact_groups groups',
                'member.chat_id = groups.chat_id',
                'LEFT'
            )
            ->where([
                'owner'             => ['in', $zhaoweiAccountsArr],
                'groups.is_deleted' => ContactGroups::NOT_DELETED,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'member.type'       => ContactGroupMembers::EXTERNAL_USER,
                'member.userid'     => $carryData['external_userid']
            ])
            ->find();
        // 在阳阳群里的就直接退出
        if ($memberInfo) {
            Log::info('在阳阳群里' . $memberInfo['unionid']);
            return true;
        }

        $addTags = ['et5b2CBwAAT0oXROuBLSxzB1Bo5OQGAQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }


        return true;
    }*/

    /**
     * 秒杀30群客户转移
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $contactInfo = ContactFollowUserDao::getAllList(
            [
                'external_userid',
                'userid'
            ],
            [
                'external_userid' => $carryData['userid'],
                'userid'          => ['in', ['yangyang123', 'yangyang3']],
                'status'          => ContactFollowUser::NORMAL
            ]
        );


        if (!$contactInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAO9gG7SONLYTMVKYGFTCSLA'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 打"小红书"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $redBookUserId = 'joyee';

        $firstAddInfo = ContactFollowUserDao::getDetail(
            [
                'userid',
            ],
            [
                'external_userid' => $carryData['userid'],
                'is_first_add'    => 1
            ]
        );
        if (
            empty($firstAddInfo)
            || $firstAddInfo['userid'] == $redBookUserId
        ) {
            // 是否进过其他的任一企微群
            if (
                !ContactGroupMembersDao::getDetail(
                    ['id'],
                    [
                        'userid'  => $carryData['userid'],
                        'chat_id' => ['<>', 'wr5b2CBwAADxnIZmUowyJraD5d1Harag']
                    ]
                )
            ) {
                $addTags = ['et5b2CBwAAEVojNvI7cEkBfdSsikP8sw'];
                $removeTags = [];

                $contactTagHttpDao = new ContactTagHttpDao();

                try {
                    if (
                        $contactTagHttpDao->markTag(
                            $redBookUserId,
                            $carryData['userid'],
                            $addTags, // 打标签
                            $removeTags // 移除标签
                        )
                    ) {
                        ContactTagMapDao::addData([
                            'external_userid' => $carryData['userid'],
                            'tag_id'          => $addTags[0],
                            'userid'          => $redBookUserId
                        ]);
                    }
                } catch (Exception $e) {
                    Log::error($e->getMessage());
                }
            }
        }

        return true;
    }*/

    /**
     * 宝姐家秀秀号
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        try {
            $userServiceImpl = new UserServiceImpl();

            $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
            $zhaoweiAccounts = array_filter($zhaoweiAccounts, function ($val) {
                if ($val !== 'xiuxiu') {
                    return true;
                }
            });

            $isYangyangFriend = ContactFollowUserDao::getDetail(
                [
                    'id',
                ],
                [
                    'external_userid' => $carryData['external_userid'],
                    'userid'          => ['in', $zhaoweiAccounts],
                    'status'          => 0
                ]
            );
            // 在阳阳号的
            if ($isYangyangFriend) {
                return true;
            }

            $groupInfo = Db::name('contact_group_members')
                ->alias('a')
                ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field([
                    'a.id'
                ])
                ->where([
                    'b.owner'      => ['in', $zhaoweiAccounts],
                    'a.is_deleted' => 0,
                    'b.is_deleted' => 0,
                    'a.userid'     => $carryData['external_userid']
                ])
                ->find();

            if ($groupInfo) {
                return true;
            }

            $addTags = ['et5b2CBwAAdTVSojHjv0A-EsXMCc_xuQ'];
            $removeTags = [];

            $contactTagHttpDao = new ContactTagHttpDao();

            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage() . $e->getLine());
        }

        return true;
    }*/

    /**
     * 翡翠手绳活动邀请
     *
     * @param $carryData
     * @return bool
     */
    /*public function doJob($carryData): bool
    {
        try {
            $userServiceImpl = new UserServiceImpl();

            $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

            if (
                Db::name('contact_group_members')
                ->alias('a')
                ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field([
                    'a.id'
                ])
                ->where([
                    'b.owner'      => ['in', $zhaoweiAccounts],
                    'a.is_deleted' => 0,
                    'b.is_deleted' => 0,
                    'a.userid'     => $carryData['external_userid']
                ])
                ->find() || (GroupMsgReceiveMapDao::getCount([
                    'external_userid' => $carryData['external_userid'],
                    'status'          => 1,
                    'update_time'     => '2022-01-01 00:00:00'
                ])) > 1
            ) {
                return true;
            }

            $addTags = ['et5b2CBwAAL1ZovSZ6HKsoPp0kzYOD9A'];
            $removeTags = [];

            $contactTagHttpDao = new ContactTagHttpDao();

            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage() . $e->getLine());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $yangyangAccounts = [
            'yangyang1',
            'yangyang123',
            'yangyang3',
            'yangyang4',
            'yangyang5',
            'yangyang2',
            'youyou'
        ];

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $yangyangAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->group('a.external_userid')
            ->select();

        if (!$contactInfo) {
            return true;
        }

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionId'    => $unionId
            ])
            ->find();

        if ($groupInfo) {
            return true;
        }

        $addTags = ['et5b2CBwAAQ4uTA-cNO_LmWZIidoDntQ'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        foreach ($contactInfo as $contact) {
        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }
        }

        return true;
    }*/

    /**
     * "彩宝1"标签
     *
     * @param $carryData
     * @return bool
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAArtH04PhvxBsFPyPExy1bMw'];
        $removeTags = ['et5b2CBwAA5ffiLu_hos1juabnCBTZqw'];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::hardDelete([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $removeTags[0],
                    'userid'          => $carryData['userid']
                ]);

                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }
        return true;
    }*/

    /**
     * "翡翠多宝吊坠"标签
     *
     * @param $carryData
     * @throws Exception
     * @return bool
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $addTags = ['et5b2CBwAAZB5qvEwp3mCnIxAKTNlDxQ'];
        $removeTags = [];

        $contactHttpDao = new ContactHttpDao();

        $userCenterInfo = $contactHttpDao->getUserCenter($unionId);

        if (
            !isset($userCenterInfo['contractAmount'])
            || $userCenterInfo['contractAmount'] < 50000
            || $userCenterInfo['contractAmount'] > 100000
        ) {
            return false;
        }

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }
        return true;
    }*/

    /**
     * "企微裂变种子用户"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAAEAw2atanJsD2Og_JdtaRQw'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    'yangyang1',
                    $carryData,
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData,
                    'tag_id'          => $addTags[0],
                    'userid'          => 'yangyang1'
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }
        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        if (
            ContactGroupMembersDao::getDetail(['id'], [
            'userid' => $carryData['external_userid'],
            ])
        ) {
            return true;
        }

        $addTags = ['et5b2CBwAAjW57qMrPj19OQ3GPDbM2gw'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        // 在任一电商号中
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.userid'     => $carryData['external_userid']
            ])
            ->find();

        // 如果是赵蔚名下任一群里的客户，就直接退出
        if ($groupInfo) {
            return true;
        }

        $addTags    = ['et5b2CBwAAz8sWySCOUA2PO6hWF-ahfw'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }
    }*/

    /**
     * 2月添加销售
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAAVjMN6FH9kGqQDrERaejoQA'];
        $removeTags = [];

        $contactHttpDao = new ContactHttpDao();
        $contactData = [];

        $contactInfo = $contactHttpDao->getUserCenterByMobile($carryData);
        if ($contactInfo['unionId']) {
            $contactData = Db::name('contact_follow_user')
                ->alias('a')
                ->join(
                    'scrm_external_contact b',
                    'a.external_userid = b.external_userid',
                    'LEFT'
                )
                ->field([
                    'a.userid',
                    'a.external_userid'
                ])
                ->where([
                    'unionid' => $contactInfo['unionId'],
                    'status'  => ContactFollowUser::NORMAL
                ])
                ->group('a.external_userid')
                ->select();
        }

        $contactTagHttpDao = new ContactTagHttpDao();

        if (!$contactData) {
            return true;
        }

        foreach ($contactData as $contact) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $contact['userid'],
                        $contact['external_userid'],
                        $addTags, // 打标签
                        $removeTags // 移除标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $contact['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $contact['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();

        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 不在赵蔚群内
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        if ($groupInfo) {
            return true;
        }

        // 判断登录条件-begin
        $oneMonthDateAgo = date('Y-m-d', strtotime('-1 months'));
        $oneMonthsAgo = strtotime(date('Y-m-d', strtotime('-1 months')));

        // 登录过
        $isLoginFunc = function ($loginTime) use ($oneMonthsAgo) {
            if ($loginTime > $oneMonthsAgo) {
                return true;
            }
            return false;
        };

        $contactHttpDao = new ContactHttpDao();

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($unionId),
            $contactHttpDao->getLiveRank($unionId),
            $contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $judgeFunc = function ($lastLogin) use ($isLoginFunc, $unionId) {
            if (
                !empty($lastLogin)
                && $isLoginFunc($lastLogin)
            ) {
                return true;
            }
            return false;
        };

        if (
            $judgeFunc($yanZhiInfo['last_login'])
            || $judgeFunc($liveRank['last_login']
                || $judgeFunc($appLastLogin['app_last_login']))
        ) {
            $userCenterData = $contactHttpDao->getUserCenter($unionId);

            if (
                $userCenterData['contractAmount'] > 0
                && $userCenterData['last_consume_date'] > $oneMonthDateAgo
            ) {
                $redis->sadd('1-consume', $unionId);
            } else {
                $redis->sadd('1-not-consume', $unionId);
            }
        }

        return true;
    }*/

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAASOvcdu3FptP7TP4wCmN2EQ'];
        $removeTags = [];

        // 不在赵蔚群内
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $carryData['unionid']
            ])
            ->find();

        if ($groupInfo) {
            return true;
        }

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /**
     * "企微海报加粉1.0"标签
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $addTags = ['et5b2CBwAA82Q-10Yo5awcA2rf5qWycg'];
        $removeTags = [];

        $contactHttpDao = new ContactHttpDao();

        $authTime = $contactHttpDao->getFirstAuthorizeTime($carryData['unionid']);

        if ($authTime['gzh'] !== false && $authTime['xxx'] !== false) {
            if (
                $authTime['gzh'] < $carryData['createtime']
                || $authTime['xxx'] < $carryData['createtime']
            ) {
                Log::alert($carryData['unionid']);
                return true;
            }
        }

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.join_time'
            ])
            ->where([
                'a.unionid' => $carryData['unionid']
            ])
            ->find();

        if ($groupInfo && $groupInfo['join_time'] < $carryData['createtime']) {
            Log::error($carryData['unionid']);
            return true;
        }

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $addTags = ['et5b2CBwAApeQCJWsZu8-VO04ysP26Ow'];
        $removeTags = [];

        $contactTagHttpDao = new ContactTagHttpDao();

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if ($userCenterData['consume_amount'] < 99) {
            return true;
        }
        // 0-新人 1-宝迷 2-忠实宝迷 3-铁杆宝迷 4-名媛 5-风尚名媛 6-至尊名媛
        if (!in_array($userCenterData['user_level_id'], [1,2,3])) {
            return true;
        }

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags, // 打标签
                    $removeTags // 移除标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        // 电商群
        $groupData = ContactGroupDao::getAllList([
            'chat_id'
        ], [
            'owner'      => ['in', $zhaoweiAccounts],
            'is_deleted' => 0,
        ]);

        $chatIdArr = array_column($groupData, 'chat_id');

        $opengidRecordsData = OpengidRecordsDao::getDetail(
            [
                'id'
            ],
            [
                'chat_id'      => ['in', $chatIdArr],
                'program_type' => 1,
                'create_time'  => ['>', '2022-01-14 00:00:00'],
                'unionid'      => $unionId
            ]
        );
        if (!$opengidRecordsData) {
            Log::error('不在群里' . $unionId);
            return true;
        }

        $redis = Cache::store()->handler();

        if (!$redis->sIsMember('caibao', $unionId)) {
            Log::notice('不是浏览者' . $unionId);
            return true;
        }

        $userCenterData = $contactHttpDao->getUserCenter($unionId);
        $contactTagHttpDao = new ContactTagHttpDao();

        $addTags = ['et5b2CBwAA_qcSLQC3AauHxkFwbMljhw'];

        if ($userCenterData['contractAmount'] == 0) {
            if (!$contactHttpDao->getIsConsume($unionId)) {
                Log::info('成功' . $unionId);
                try {
                    if (
                        $contactTagHttpDao->markTag(
                            $carryData['userid'],
                            $carryData['external_userid'],
                            $addTags// 打标签
                        )
                    ) {
                        ContactTagMapDao::addData([
                            'external_userid' => $carryData['external_userid'],
                            'tag_id'          => $addTags[0],
                            'userid'          => $carryData['userid']
                        ]);
                    }
                } catch (Exception $e) {
                    Log::error($e->getMessage());
                }
            } else {
                Log::info('-珠宝有消费' . $unionId);
            }
        } else {
            Log::alert('ERP有消费' . $unionId);
        }

        return true;
    }*/

    public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }
        $contactHttpDao = new ContactHttpDao();

        /*$followRes = ContactFollowUserDao::getDetail([
            'id'
        ], [
            'external_userid' => $carryData['external_userid'],
            'userid'          => ['in', [
                'yangyang1',
                'yangyang123',
                'yangyang3',
                'yangyang4',
                'yangyang5',
                'yangyang2',
                'youyou',
                'baojiejiayangyang9',
                'qingqing'
            ]],
            'status' => ContactFollowUser::NORMAL
        ]);

        if ($followRes) {
            return true;
        }*/

        $userInfo = $contactHttpDao->getUserCenter($unionId);

        /*if ($userInfo['first_consume_date'] < '2022-07-01 00:00:00') {
            return true;
        }

        if ($userInfo['first_consume_amount'] > 10000) {
            return true;
        }*/

        if ($userInfo['consume_amount'] > 0) {
            return true;
        }

        if ($contactHttpDao->getIsConsume($unionId)) {
            return true;
        }

        if (
            $carryData['add_way'] == 100
            && $carryData['state'] == 190
        ) {
            return true;
        }

        /*$redis = Cache::store()->handler();

        if ($redis->sIsMember('today_friend_circle', $carryData['external_userid'])) {
            return true;
        }*/

        // 0-新人 1-宝迷 2-忠实宝迷 3-铁杆宝迷 4-名媛 5-风尚名媛 6-至尊名媛
        /*if (!in_array($userInfo['user_level_id'], [3,4])) {
            return  true;
        }*/

        /*$isInGroup = ContactGroupMembersDao::getDetail(['id'], [
            'chat_id'    => 'wr5b2CBwAAjy39a2_OhhucUpXPYSKC8A',
            'unionid'    => $unionId,
            'is_deleted' => 0
        ]);
        if ($isInGroup) {
            return true;
        }*/

        // 不在电商群内
        /*$userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->find();

        if ($groupInfo) {
            return true;
        }*/

        // 判断登录条件-begin
        // 一年以前
        /*$oneYearAgo = strtotime(date('Y-m-d', strtotime('-3 months')));

        // 登录过
        $isLoginFunc = function ($loginTime) use ($oneYearAgo) {
            if ($loginTime > $oneYearAgo) {
                return true;
            }
            return false;
        };

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($unionId),
            $contactHttpDao->getLiveRank($unionId),
            $contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $judgeFunc = function ($lastLogin) use ($isLoginFunc, $unionId) {
            if (
                !empty($lastLogin)
                && $isLoginFunc($lastLogin)
            ) {
                return true;
            }
            return false;
        };

        if (
            !$judgeFunc($yanZhiInfo['last_login'])
            && !$judgeFunc($liveRank['last_login']
                && !$judgeFunc($appLastLogin['app_last_login']))
        ) {
            return true;
        }*/

        /*$receiveMsg = GroupMsgReceiveMapDao::getDetail([
            'id'
        ], [
            'status'          => 1,
            'external_userid' => $carryData['external_userid'],
            'update_time'     => ['>', '2022-08-11 00:00:00']
        ]);
        if ($receiveMsg) {
            return true;
        }*/

        /*$redis = Cache::store()->handler();

        if ($redis->sIsMember('join_group', $carryData['external_userid'])) {
            return true;
        }

        if ($redis->sIsMember('join_group2', $carryData['external_userid'])) {
            return true;
        }
        switch ($userInfo['user_level_id']) {
            case 0:
                $addTags = ['et5b2CBwAAbp51_8mm7Rdk-BzT79HlJQ'];
                break;

            case 1:
                $addTags = ['et5b2CBwAAfP-VbAsc3FEmU2TSsdn1QQ'];
                break;

            case 2:
                $addTags = ['et5b2CBwAAuA9cAKxwXorrnF2I0qlEPg'];
                break;

            default:
                $addTags = [];
                break;
        }

        if (!$addTags) {
            return true;
        }*/

        // 在气质法宝💐珍珠闪购群
        /*$groupInfo = Db::name('contact_group_members')
            ->field([
                'id'
            ])
            ->where([
                'is_deleted' => 0,
                'unionid'    => $unionId,
                'chat_id'    => 'wr5b2CBwAAfrKb_ft3t4CdhTY6H5y-jw'
            ])
            ->find();

        if (!$groupInfo) {
            return true;
        }*/

        $addTags = ['et5b2CBwAAP7ZZJ3l8slFGRmAiAS6XaA'];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags // 打标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }

    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        // 在“闪购群”就退出
        $chatArr = ContactGroupDao::getAllList([
            'chat_id'
        ], [
            'name'       => ['like', '%宝姐家好物专享群%'],
            'is_deleted' => 0
        ]);
        $chatIdArr = array_column($chatArr, 'chat_id');

        if (
            ContactGroupMembersDao::getDetail(['id'], [
                'chat_id'    => ['in', $chatIdArr],
                'unionid'    => $unionId,
                'is_deleted' => 0
            ])
        ) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($unionId);

        if ($userInfo['consume_amount'] > 0) {
            return true;
        }

        if ($contactHttpDao->getIsConsume($unionId)) {
            return true;
        }

        // 判断登录条件-begin
        // 6个月以前
        $oneMonthsAgo = strtotime(date('Y-m-d', strtotime('-6 months')));

        // 登录过
        $isLoginFunc = function ($loginTime) use ($oneMonthsAgo) {
            if ($loginTime > $oneMonthsAgo) {
                return true;
            }
            return false;
        };

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($unionId),
            $contactHttpDao->getLiveRank($unionId),
            $contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $judgeFunc = function ($lastLogin) use ($isLoginFunc, $unionId) {
            if (
                !empty($lastLogin)
                && $isLoginFunc($lastLogin)
            ) {
                return true;
            }
            return false;
        };

        if (
            !$judgeFunc($yanZhiInfo['last_login'])
            && !$judgeFunc($liveRank['last_login']
                && !$judgeFunc($appLastLogin['app_last_login']))
        ) {
            return true;
        }

        $addTags = ['et5b2CBwAAwQUqKUdZDrMEZNRkc07M0A'];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags// 打标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        $contactHttpDao = new ContactHttpDao();

        $contactDetailArr = $contactHttpDao->getContactDetail($carryData['external_userid'], false);

        if (!$contactDetailArr) {
            exit();
        }

        $followUserArr = $contactDetailArr['follow_user'];

        foreach ($followUserArr as $follow) {
            if ($follow['userid'] == $carryData['userid']) {
                if (isset($follow['wechat_channels'])) {
                    $wechatChannelsNickname = $follow['wechat_channels']['nickname'];
                    $wechatChannelsSource = $follow['wechat_channels']['source'];

                    $state = array_search($wechatChannelsNickname, ContactFollowUser::VIDEO_STATE_MAP);

                    $updateData = [
                        'wechat_channels_nickname' => $wechatChannelsNickname,
                        'wechat_channels_source'  => $wechatChannelsSource,
                        'state' => $state
                    ];
                    ContactFollowUserDao::updateData($updateData, [
                        'id' => $carryData['id']
                    ]);
                }
                break;
            }
        }

        return true;
    }*/

    /**
     * 1、不在电商群内
     * 2、珠宝后台和erp中均无消费记录的用户
     * 3、近3个月登陆过宝姐家小程序
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $yanzhiData = $contactHttpDao->getYanzhi($unionId);

        // 6个月前
        $mtime = strtotime(date('Y-m-d 00:00:00', strtotime('-6 month')));

        if ($yanzhiData['last_login'] < $mtime) {
            return true;
        }

        $chatArr = (array)Db::name('contact_groups')
            ->field(['chat_id'])
            ->whereOr('name', 'like', '%宝姐家好物专享群%')
            ->whereOr('name', 'like', '%宝姐家好物优享%')
            ->whereOr('name', 'like', '%宝姐家新粉福利%')
            ->whereOr('name', 'like', '%宝姐饰界福利秒杀%')
            ->whereOr('name', 'like', '%闪购%')
            ->where('is_deleted', 0)
            ->select();

        $chatIdArr = array_column($chatArr, 'chat_id');

        if (
            ContactGroupMembersDao::getDetail(['id'], [
                'chat_id'    => ['in', $chatIdArr],
                'unionid'    => $unionId,
                'is_deleted' => 0
            ])
        ) {
            return true;
        }

        // 不在宝姐家好物专享群
        $groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => $unionId
            ])
            ->where(
                'b.name',
                'like',
                [
                    '%宝姐家好物专享群%',
                    '%宝姐家好物优享%',
                    '%宝姐家新粉福利%',
                    '%宝姐饰界福利秒杀%',
                    '%闪购%',
                ],
                'OR'
            )
            ->find();

        if ($groupInfo) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($unionId);

        if ($userInfo['consume_amount'] <= 99) {
            return true;
        }

        if ($contactHttpDao->getIsConsume($unionId)) {
            return true;
        }

        $addTags = ['et5b2CBwAA6mJFsP3ttzCbx4suiUnD8Q'];

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    $addTags// 打标签
                )
            ) {
                ContactTagMapDao::addData([
                    'external_userid' => $carryData['external_userid'],
                    'tag_id'          => $addTags[0],
                    'userid'          => $carryData['userid']
                ]);
            }
        } catch (Exception $e) {
            Log::error($e->getMessage());
        }

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $redis = Cache::store()->handler();

        if (!$redis->sIsMember('view', $unionId)) {
            return true;
        }

        $addTags = ['et5b2CBwAAruaNkWU2Itd1-hFSoPOaHg'];

        if ($addTags) {
            $contactTagHttpDao = new ContactTagHttpDao();

            try {
                if (
                    $contactTagHttpDao->markTag(
                        $carryData['userid'],
                        $carryData['external_userid'],
                        $addTags // 打标签
                    )
                ) {
                    ContactTagMapDao::addData([
                        'external_userid' => $carryData['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $carryData['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }*/
}
