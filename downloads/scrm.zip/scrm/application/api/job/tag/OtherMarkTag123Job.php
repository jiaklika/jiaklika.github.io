<?php

namespace app\api\job\tag;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactTags;
use Exception;
use think\Cache;
use think\Log;
use think\queue\Job;

class OtherMarkTag123Job extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '批量打标签任务';

    /**
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $tagId = 'et5b2CBwAA2cgsL4ILL4sLZZs8CYJT7Q';// 意向客户

        $contactHttpDao = new ContactHttpDao();

        // 1个月以前
        $thirtyDaysAgo = strtotime(date('Y-m-d', strtotime('-30 days')));

        // 1个月内有登录
        $isLoginFunc = function ($loginTime) use ($thirtyDaysAgo) {
            if ($loginTime > $thirtyDaysAgo) {
                return true;
            }
            return false;
        };

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($contact['unionid']),
            $contactHttpDao->getLiveRank($contact['unionid']),
            $contactHttpDao->getAppLastLoginTime($contact['unionid'])
        ];

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        // 一个月内活跃（登陆过3端应用）的颜值白银
        $judgeLoginFunc = function ($lastLogin) use ($isLoginFunc, $contact, $yanZhiInfo) {
            if (
                $yanZhiInfo['yanzhi_total'] >= 1000
                && $yanZhiInfo['yanzhi_total'] < 10000
            ) { // 颜值白银
                if (
                    !empty($lastLogin)
                    && $isLoginFunc($lastLogin)
                ) {
                    return true;
                }
            }

            return false;
        };

        // 颜值黄金的宝迷
        $yanzhiRes = false;

        if (
            $yanZhiInfo['yanzhi_total'] >= 10000
            && $userCenterData['user_level_id'] == 1
        ) {
            $yanzhiRes = true;
        }

        if (!$loginRes = $judgeLoginFunc($yanZhiInfo['last_login'])) {
            if (!$loginRes = $judgeLoginFunc($liveRank['last_login'])) {
                $loginRes = $judgeLoginFunc($appLastLogin['app_last_login']);
            }
        }

        if ($loginRes || $yanzhiRes) {
            //Log::notice($unionId.'-满足条件');
            $contactTagHttpDao = new ContactTagHttpDao();

            try {
                // 打上"意向客户"标签
                $addTagRes = $contactTagHttpDao->markTag($contact['userid'], $contact['external_userid'], [$tagId]);

                $searchData = [
                    'tag_id'          => $tagId,
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid']
                ];

                if ($addTagRes) {
                    ContactTagMapDao::addData($searchData);
                }
            } catch (Exception $e) {
                send_msg_to_wecom($contact['unionid'] . '-' . $e->getMessage());
            }
        }

        return true;
    }*/

    /**
     * 打"来源渠道"标签
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $sourceTagId = ContactTags::CHANNEL_UNKNOWN_TAG_ID;

        if ($state = $contact['state']) {
            $wayInfo = ContactWaysDao::getDetail(['channel_id'], ['id' => $state]);

            $tagInfo = ContactChannelsDao::getDetail(['tag_id'], ['id' => $wayInfo['channel_id']]);

            $sourceTagId = $tagInfo['tag_id'];
        }

        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            $addTagRes = $contactTagHttpDao->markTag($contact['userid'], $contact['external_userid'], [$sourceTagId]);

            $searchData = [
                'tag_id'          => $sourceTagId,
                'external_userid' => $contact['external_userid'],
                'userid'          => $contact['userid']
            ];

            if ($addTagRes) {
                ContactTagMapDao::addData($searchData);
            }
        } catch (Exception $e) {
            send_msg_to_wecom($contact['unionid'] . '-' . $e->getMessage());
        }


        return true;
    }*/

    /**
     * 打"群内客户"标签
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        // 只判断指定群的加群人员，得到指定群的groupId数组-begin
        $userServiceImpl = new UserServiceImpl();
        $contactTagHttpDao = new ContactTagHttpDao();
        $redis = Cache::store()->handler();

        $getGroupIdArr = function (string $userId) use ($userServiceImpl, $redis) {
            $accountsArr = $userServiceImpl->getSpecificUserAccount($userId);

            if ($groupJson = $redis->get($userId . '_group_arr')) {
                return json_decode($groupJson, true);
            } else {
                $groupArr = ContactGroupDao::getAllList(['chat_id'], [
                    'owner'      => ['in', $accountsArr],
                    'is_deleted' => ContactGroups::NOT_DELETED
                ]);
                $groupIdArr = array_column($groupArr, 'chat_id');
                $redis->set($userId . '_group_arr', json_encode($groupIdArr, JSON_UNESCAPED_UNICODE));

                return $groupIdArr;
            }
        };

        $feiyueGroupIdArr = $getGroupIdArr('feiyue');

        $zhaoweiGroupIdArr = $getGroupIdArr('zhaowei');
        // 得到指定群的groupId数组-end

        $nowGroupArr = ContactGroupMembersDao::getAllList(['chat_id'], [
            'userid'     => $contact['external_userid'],
            'is_deleted' => ContactGroupMembers::NOT_DELETED
        ]);

        $addTagClosure = function ($groupIdArr, $addTag) use ($nowGroupArr, $contactTagHttpDao, $contact) {

            if (!array_intersect(array_column($nowGroupArr, 'chat_id'), $groupIdArr)) {
                $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    [$addTag]
                );

                // 直接移除旧的
                ContactTagMapDao::hardDelete([
                    'tag_id'          => $addTag,
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid'],
                ]);
                // 添加进tagMap表
                ContactTagMapDao::addData([
                    'tag_id'          => $addTag,
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid'],
                ]);
            }
        };

        $addTagClosure($zhaoweiGroupIdArr, ContactTags::NOT_IN_GROUP_TAG['zhaowei']);

        $addTagClosure($feiyueGroupIdArr, ContactTags::NOT_IN_GROUP_TAG['feiyue']);

        return true;
    }*/

    /**
     * 添加"好友"标签
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*public function doJob($contact)
    {
        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $contact['userid'],
                    $contact['external_userid'],
                    [ContactTags::IS_FRIEND_TAG],
                    [ContactTags::NOT_FRIEND_TAG]
                )
            ) {
                // 直接移除旧的
                ContactTagMapDao::hardDelete([
                    'tag_id'          => ContactTags::NOT_FRIEND_TAG,
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid'],
                ]);
                // 添加进tagMap表
                ContactTagMapDao::addData([
                    'tag_id'          => ContactTags::IS_FRIEND_TAG,
                    'external_userid' => $contact['external_userid'],
                    'userid'          => $contact['userid'],
                ]);
            } else {
                return false;
            }
        } catch (Exception $e) {
            return false;
        }

        return true;
    }*/

    /**
     * taotao的3300个随机用户打继承标签
     *
     * @param $carryData
     * @return bool
     */
    public function doJob($carryData)
    {
        $contactTagHttpDao = new ContactTagHttpDao();

        try {
            if (
                $contactTagHttpDao->markTag(
                    $carryData['userid'],
                    $carryData['external_userid'],
                    ['et5b2CBwAAhcPJxPOSNxqJYPlYA6NpUw']
                )
            ) {
                // 添加进tagMap表
                ContactTagMapDao::addData([
                    'tag_id'          => 'et5b2CBwAAhcPJxPOSNxqJYPlYA6NpUw',
                    'external_userid' => $carryData['external_userid'],
                    'userid'          => $carryData['userid'],
                ]);
            } else {
                return false;
            }
        } catch (Exception $e) {
            return false;
        }

        return true;
    }
}
