<?php

namespace app\api\job;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\user\UserDao;
use think\Cache;
use think\Db;
use think\Log;

class TestJob extends BaseJob
{
    public static $jobName = '测试任务';

    /*public function doJob($carryData)
    {
        $c = new ContactHttpDao();
        $b = ContactGroupMembersDao::getAllList(['unionid'], [
            'chat_id' => $carryData['chat_id'],
            'is_deleted' => 0,
            'type' => 2
        ]);
        $consumeCount = 0;
        foreach ($b as $unionId) {
            $d = $c->getUserCenter($unionId['unionid']);
            if (isset($d['consume_amount']) && $d['consume_amount'] > 0) {
                $consumeCount += 1;
            }
        }
        $owner = UserDao::getDetail(['name'], ['userid' => $carryData['owner']]);
        $groupCount = count($b);
        file_put_contents('1.txt', $carryData['name'] . ' 群主：'.$owner['name'] .' 成员总数：' . $groupCount . ' 客户总数：' . $consumeCount . ' 比例：' . number_format($consumeCount/$groupCount, 2) * 100 . '%' . PHP_EOL, FILE_APPEND);

        return true;
    }*/

    /*public function doJob($carryData): bool
    {
        try {
            $a = ContactFollowUserDao::getDetail(['status'], [
                'external_userid' => $carryData['external_userid'],
                'userid' => 'yanyan'
            ]);
            $redis = Cache::store()->handler();

            if (isset($a['status']) && $a['status'] == 0) {
                $redis->sadd('yanyan', $carryData['external_userid']);
            }
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
        return true;
    }*/

    public function doJob($carryData)
    {
        $contactHttpDao = new ContactHttpDao();
        $res = $contactHttpDao->getUserCenterByMobile($carryData['mobile']);

        $unionId = $res['unionId'];

        $contactInfo = ContactDao::getDetail(['user_level_id'], [
            'unionid' => $unionId
        ]);

        if ($res['user_level_id'] != $contactInfo['user_level_id']) {
            Log::error($carryData['mobile']);
        }
        return true;
    }
}
