<?php

namespace app\api\job\count;

use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Exception;
use think\Cache;
use think\Db;

/**
 * 统计Excel里用户企微分布情况
 *
 * Class ExcelCountJob
 * @package app\api\job\count
 */
class ExcelCountJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '统计Excel里用户企微分布情况';

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();

        // 企微人数（在号或者群内）
        $contact = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'external_contact b',
                'a.external_userid = b.external_userid',
                'left'
            )
            ->field([
                'a.id'
            ])
            ->where([
                'b.unionid' => $carryData,
                'a.status'  => ContactFollowUser::NORMAL
            ])
            ->find();

        // 如果不是好友，就查是否在群里面
        if (!$contact) {
            $isGroupMember = Db::name('contact_group_members')
                ->field(['id'])
                ->where(['unionid' => $carryData])
                ->find();

            if ($isGroupMember) {
                $redis->sadd('is_contact', $carryData);
            }
        } else {
            $redis->sadd('is_contact', $carryData);
        }

        $userService = new UserServiceImpl();
        $feiyueAccounts = $userService->getSpecificUserAccount('feiyue', false);
        $zhaoweiAccounts = $userService->getSpecificUserAccount('zhaowei', false);

        // 是否是指定账号的好友
        $isSpecificAccountFriend = function (
            string $userName,
            array $accounts,
            array $extraAccounts = []
        ) use (
            $carryData,
            $userService,
            $redis
) {
            $isUserContact = (array)Db::name('contact_follow_user')
                ->alias('a')
                ->join(
                    'external_contact b',
                    'a.external_userid = b.external_userid',
                    'left'
                )
                ->field([
                    'unionid'
                ])
                ->where([
                    'userid'  => ['in', $accounts],
                    'unionid' => $carryData,
                    'status'  => ContactFollowUser::NORMAL
                ])
                ->group('unionid')
                ->select();

            if ($userName != 'unique' && $isUserContact) {
                $redis->sadd($userName . '_contact', $carryData);
            }

            if ($userName == 'unique' && $isUserContact) {
                $NotUniqueContact = (array)Db::name('contact_follow_user')
                    ->alias('a')
                    ->join(
                        'external_contact b',
                        'a.external_userid = b.external_userid',
                        'left'
                    )
                    ->field([
                        'unionid'
                    ])
                    ->where([
                        'userid'  => ['in', $extraAccounts],
                        'unionid' => $carryData,
                        'status'  => ContactFollowUser::NORMAL
                    ])
                    ->group('unionid')
                    ->select();

                if (!$NotUniqueContact) {
                    $redis->sadd('unique_contact', $carryData);
                }
            }
        };
        // 在宝姐家福利官号
        $isSpecificAccountFriend('feiyue', $feiyueAccounts);
        // 在阳阳号
        $isSpecificAccountFriend('zhaowei', $zhaoweiAccounts);
        // 只在阳阳号（不在宝姐家福利官号）
        $isSpecificAccountFriend('unique', $zhaoweiAccounts, $feiyueAccounts);

        // 群人数数据
        $isSpecificGroupMember = function (
            string $userName,
            array $accounts,
            array $extraAccounts = []
        ) use (
            $carryData,
            $redis,
            $userService
) {
             $isUserGroupMember = Db::name('contact_group_members')
                ->alias('a')
                ->join(
                    'contact_groups b',
                    'a.chat_id = b.chat_id',
                    'left'
                )
                ->field([
                    'unionid'
                ])
                ->where([
                    'a.unionid'    => $carryData,
                    'b.owner'      => ['in', $accounts],
                    'a.is_deleted' => ContactGroups::NOT_DELETED,
                    'b.is_deleted' => ContactGroupMembers::NOT_DELETED
                ])
                ->group('unionid')
                ->select();

            if ($userName != 'unique' && $isUserGroupMember) {
                $redis->sadd($userName . '_group_member', $carryData);
            }

            if ($userName == 'unique' && $isUserGroupMember) {
                $NotUniqueGroupMember = Db::name('contact_group_members')
                    ->alias('a')
                    ->join(
                        'contact_groups b',
                        'a.chat_id = b.chat_id',
                        'left'
                    )
                    ->field([
                        'unionid'
                    ])
                    ->where([
                        'a.unionid'    => $carryData,
                        'b.owner'      => ['in', $extraAccounts],
                        'a.is_deleted' => ContactGroups::NOT_DELETED,
                        'b.is_deleted' => ContactGroupMembers::NOT_DELETED
                    ])
                    ->group('unionid')
                    ->select();

                if (!$NotUniqueGroupMember) {
                    $redis->sadd('unique_group_member', $carryData);
                }
            }
        };
        // 在泛流量社群
        $isSpecificGroupMember('feiyue', $feiyueAccounts);
        // 在电商社群
        $isSpecificGroupMember('zhaowei', $zhaoweiAccounts);
        // 只在电商社群（不在泛流量社群）
        $isSpecificGroupMember('unique', $zhaoweiAccounts, $feiyueAccounts);

        return true;
    }
}
