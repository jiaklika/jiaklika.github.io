<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use Exception;
use think\Cache;

class CountAllJob extends BaseJob
{
    /**
     * 根据消息中的数据进行实际的业务处理
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        if (empty($carryData['unionid'])) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();
        $redis = Cache::store()->handler();

        $feiyueAccountsArr = $zhaoweiAccountsArr = [];

        /*$userServiceImpl = new UserServiceImpl();
        $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue');
        $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei');*/

        $userCenterData = $contactHttpDao->getUserCenter($carryData['unionid']);
        $mobile = $userCenterData['mobile'];

        $consumeInfo = $mobile ? $contactHttpDao->getConsumeSegment($mobile) : [];

        $handleData  = function ($userId) use (
            $carryData,
            $userCenterData,
            $redis,
            $feiyueAccountsArr,
            $zhaoweiAccountsArr,
            $consumeInfo
        ) {

            $writeRedis = function ($userId) use ($userCenterData, $redis, $consumeInfo) {
                switch ($userCenterData['user_level_id']) {
                    case 1:
                        $redis->incr($userId . '_level_1');
                        break;

                    case 2:
                        $redis->incr($userId . '_level_2');
                        break;

                    case 3:
                        $redis->incr($userId . '_level_3');
                        break;

                    case 4:
                        $redis->incr($userId . '_level_4');
                        break;

                    case 5:
                        $redis->incr($userId . '_level_5');
                        break;

                    case 6:
                        $redis->incr($userId . '_level_6');
                        break;

                    case 0:
                    default:
                        $redis->incr($userId . '_level_0');
                        break;
                }

                $utype = $consumeInfo['utype'] ?? '0';

                $redis->incr($userId . '_' . $utype);
            };

            if ($userId != 'company') {
                if (in_array($userId, $feiyueAccountsArr)) {
                    $userId = 'feiyue';
                }

                if (in_array($userId, $zhaoweiAccountsArr)) {
                    $writeRedis('zhaowei');
                }
            }

            $writeRedis($userId);
        };

        // $handleData($carryData['userid']);
        $handleData('company');

        return true;
    }
}
