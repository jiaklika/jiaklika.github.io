<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\job\BaseJob;
use Exception;
use think\Cache;

/**
 * 公司社群数据汇总
 *
 * Class CountGroupJob
 * @package app\api\job
 */
class CountGroupJob extends BaseJob
{
    /**
     * 公司社群数据汇总
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData)
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $redis = Cache::store()->handler();

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        $mobile = $userCenterData['mobile'];

        $consumeInfo = $mobile ? $contactHttpDao->getConsumeSegment($mobile) : [];
        if (
            isset($consumeInfo['contract_amount'])
            && $consumeInfo['contract_amount']
        ) {
            $redis->incr('company_contract_amount_count');
        }

        $utype = $consumeInfo['utype'] ?? '0';

        $redis->incr('company_' . $utype);

        switch ($userCenterData['user_level_id']) {
            case 0:
            default:
                $redis->incr('zero');
                break;

            case 1:
                $redis->incr('one');
                break;

            case 2:
                $redis->incr('two');
                break;

            case 3:
                $redis->incr('three');
                break;

            case 4:
                $redis->incr('four');
                break;

            case 5:
                $redis->incr('five');
                break;

            case 6:
                $redis->incr('six');
                break;
        }

        return true;
    }
}
