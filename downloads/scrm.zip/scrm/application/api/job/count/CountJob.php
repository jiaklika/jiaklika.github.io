<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\media\TemporaryMediaDao;
use app\api\dao\mysql\user\UserDao;
use app\api\job\BaseJob;
use app\common\model\ContactFollowUser;
use Exception;
use think\Cache;
use think\Db;
use think\Log;
use think\queue\Job;

/**
 * Class CountJob
 * @package app\api\job
 */
class CountJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '统计数据任务';

    /**
     * 三个月内没登录过三端应用的人数
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact): bool
    {
        if (!$unionId = $contact['unionid']) {
            return true;
        }

        $contactHttpDao = new ContactHttpDao();
        $redis = Cache::store()->handler();

        // 三个月以前
        $threeMonthsAgo = strtotime(date('Y-m-d', strtotime('-3 months')));

        $isLoginFunc = function ($loginTime) use ($threeMonthsAgo) {
            if ($loginTime > $threeMonthsAgo) {
                return true;
            }
            return false;
        };

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $appLastLogin // APP端最后登录
        ] = [
            $contactHttpDao->getYanzhi($unionId),
            $contactHttpDao->getLiveRank($unionId),
            $contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $judgeFunc = function ($lastLogin) use ($isLoginFunc, $redis, $unionId) {
            if (
                !empty($lastLogin)
                && $isLoginFunc($lastLogin)
            ) {
                Log::info($unionId . '-三个月内登录过三端');
                $redis->incr('login');
                return true;
            } else {
                Log::info($unionId . '-三个月内未登录过三端');
                return false;
            }
        };

        if (!$judgeFunc($yanZhiInfo['last_login'])) {
            if (!$judgeFunc($liveRank['last_login'])) {
                $judgeFunc($appLastLogin['app_last_login']);
            }
        }

        return true;
    }*/

    /**
     * 统计有消费的人数
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$contact['unionid'])
            return true;

        $redis = Cache::store()->handler();

        $count = 'consumers_confirm_count'; // 客户数
        $groupOrderCount = 'group_order_count';
        $mediaCount = 'media_count';
        $mediaGroupCount = 'media_group_count';

        $contactHttpDao = new ContactHttpDao();

        $orderInfo = $contactHttpDao->getMediaOrderList($contact['unionid']);

        if (isset($orderInfo['error']))
            return true;

        if ($orderInfo['all_confirm_order'])
        {
            $redis->incr($count);
            Log::info($contact['unionid'].'-有消费');
        }

        if ($orderInfo['from_group_order'])
        {
            $redis->incr($groupOrderCount);
            Log::info($contact['unionid'].'-有群聊消费');
        }

        if ($orderInfo['media_confirm_order'])
        {
            $redis->incr($mediaCount);
            Log::info($contact['unionid'].'-有用户营销中心消费');
        }

        if ($orderInfo['media_group'])
        {
            $redis->incr($mediaGroupCount);
            Log::info($contact['unionid'].'-有用户营销中心的群聊消费');
        }

        if (!$orderInfo['all_confirm_order']
            && !$orderInfo['from_group_order']
            && !$orderInfo['media_confirm_order']
            && !$orderInfo['media_group'])
        {
            Log::info($contact['unionid'].'-无');
        }

        $userCenterData = $contactHttpDao->getUserCenter($contact['unionid']);

        if ($userCenterData['consume_amount'])
        {
            $redis->incr('hahaha');
        }

        switch ($userCenterData['user_level_id']){
            case 0:
            default:
                $redis->incr('zero');
                break;

            case 1:
                $redis->incr('one');
                break;

            case 2:
                $redis->incr('two');
                break;

            case 3:
                $redis->incr('three');
                break;

            case 4:
                $redis->incr('four');
                break;

            case 5:
                $redis->incr('five');
                break;

            case 6:
                $redis->incr('six');
                break;
        }

        return true;
    }*/

    /**
     * 公域裂变人数指的是无三端应用登录记录的、颜值为0的新用户
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid'])
            return true;

        $groupList = ContactGroupDao::getAllList(
            [
                'name',
                'chat_id'
            ],
            [
                'name'  => ['like', "%圣诞%"]
            ]
        );

        $groupIdData = array_column($groupList, 'chat_id');

        $redis = Cache::store()->handler();

        $contactHttpDao = new ContactHttpDao();

        $appLastLoginTime = $contactHttpDao->getAppLastLoginTime($unionId);

        // APP登录时间
        $appLogin = $appLastLoginTime['app_last_login'];

        $liveRankData = $contactHttpDao->getLiveRank($unionId);

        // 珠宝登录时间
        $baojieLogin = $liveRankData['last_login'];

        $mediaData = $contactHttpDao->getYanzhi($unionId);

        // 媒体登录时间
        $mediaLogin = $mediaData['last_login'];
        // 颜值数
        $yanzhiCount = $mediaData['yanzhi_total'];

        if ($baojieLogin == 0
            && $mediaLogin === false
            && $appLogin == 0
            && $yanzhiCount == 0)
        {
            Log::info($unionId.'-是公域新人～');
            $redis->incr('newbie');
        } else {
            Log::info($unionId.'-不是公域新人！');
            // 在不在别的群里
            $groupIdArr = ContactGroupMembersDao::getAllList(
                            ['chat_id'],
                            [
                                'unionid' => $unionId,
                                'chat_id' => ['not in', $groupIdData]
                            ]
                        );

            if (!empty($groupIdArr))// 在别的群里存在，不计数，直接退出
            {
                Log::info($unionId.'-在别的群里存在');
                return true;
            }

            // 判断是否是客户
            $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);
            // 不是客户，满足条件
            if (empty($contactInfo))
            {
                Log::info($unionId.'-不是客户');
                $redis->incr('hahaha');
            }else{
                Log::info($unionId.'-是客户!');
            }
        }

        return true;
    }*/

    /*private function doJob($contact)
    {
        if (!$unionId = $contact['unionid'])
            return true;

        $redis = Cache::store()->handler();

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        if ($userCenterData['consume_amount'])
        {
            $redis->incr('consumer');
            Log::info($unionId.'-消费过～');
        } else {
            Log::info($unionId.'-没有消费过！');
        }


        switch ($userCenterData['user_level_id']){
            case 0:
            default:
                Log::info($unionId.'-是新人！');
                $redis->incr('zero');
                break;

            case 1:
                Log::info($unionId.'-是宝迷！');
                $redis->incr('one');
                break;

            case 2:
                Log::info($unionId.'-是忠实宝迷！');
                $redis->incr('two');
                break;

            case 3:
                Log::info($unionId.'-是铁杆宝迷！');
                $redis->incr('three');
                break;

            case 4:
                Log::info($unionId.'-是名媛！');
                $redis->incr('four');
                break;

            case 5:
                Log::info($unionId.'-是风尚名媛！');
                $redis->incr('five');
                break;

            case 6:
                Log::info($unionId.'-是至尊名媛！');
                $redis->incr('six');
                break;
        }

        return true;
    }*/


    /**
     * #123 用户运营社群消费数据统计2
     * https://bojem.coding.net/p/scrm/backlog/issues/123
     *
     * @param $contact
     * @return bool
     * @throws Exception
     */
    /*private function doJob($contact)
    {
        $messageHttpDao = new MessageHttpDao();

        if (isset($contact['unionid'])
            && $unionId = $contact['unionid'])
        {
            $redis = Cache::store()->handler();

            $contactHttpDao = new ContactHttpDao();

            $userCenterData = $contactHttpDao->getUserCenter($unionId);
            $orderInfo = $contactHttpDao->getPlatformOrderList($unionId);

            if ($userCenterData)
            {
                $consumeAmount = $userCenterData['consume_amount'];

                if ($consumeAmount != 0)
                    $redis->incr('other_consumer_count');

                if ($consumeAmount >= 0.01 && $consumeAmount < 10)
                    $redis->incr('other_zero');
                if ($consumeAmount >= 1000)
                    $redis->incr('other_four');
                if ($consumeAmount >= 10 && $consumeAmount < 100)
                    $redis->incr('other_one');
                if ($consumeAmount >= 100 && $consumeAmount < 500)
                    $redis->incr('other_two');
                if ($consumeAmount >= 500 && $consumeAmount < 1000)
                    $redis->incr('other_three');

                $logConsumeAmount = $consumeAmount ? : 0;

                Log::info($contact['unionid'].'-累计消费'.$logConsumeAmount);
            }

            if (isset($orderInfo['error']))
                return true;

            if ($orderInfo['last_week_buy_count'])
            {
                $redis->incr('other_last_week_buy_count');
                Log::info($contact['unionid'].'-上周购买过');
            }

            if ($orderInfo['last_week_buy_count_group'])
            {
                $redis->incr('other_last_week_buy_count_group');
                Log::info($contact['unionid'].'-上周在群聊购买过');
            }

            if ($orderInfo['last_week_buy_count_platform_1'])
            {
                $redis->incr('other_last_week_buy_count_platform_1');
                Log::info($contact['unionid'].'-上周在用户运营商品购买过');
            }

            if ($orderInfo['last_week_buy_count_platform_1_group'])
            {
                $redis->incr('other_last_week_buy_count_platform_1_group');
                Log::info($contact['unionid'].'-上周用户运营商品群聊购买过');
            }
        }

        if (isset($contact['unionid'])
        && empty($contact['unionid']))
            return true;

        if (isset($contact['end'])
            && $contact['end'] == true)
        {
            $todayDate = date('Y-m-d');
            $redis = Cache::store()->handler();

            $content['content'] =
                "{$todayDate} 【新粉福利群】";

            // $content['content'] = "圣诞群";

            $rateClosure = function ($part, $all){
                if ($all == 0)
                    return '0%';
                return sprintf("%01.2f%%", ($part / $all)*100);
            };

            $rate1 = $rateClosure($redis->get('other_consumer_count'), $redis->get('other_group_member_count'));

            $rate2 = $rateClosure($redis->get('other_last_week_buy_count'), $redis->get('other_group_member_count'));

            $rate3 = $rateClosure(
                $redis->get('other_last_week_buy_count_group'),
                $redis->get('other_group_member_count')
            );

            $rate4 = $rateClosure(
                $redis->get('other_last_week_buy_count_platform_1'),
                $redis->get('other_group_member_count')
            );

            $rate5 = $rateClosure(
                $redis->get('other_last_week_buy_count_platform_1_group'),
                $redis->get('other_group_member_count')
            );


            $content['content'] .= "
>**总群数**：{$redis->get('other_group_num_count')}个
            >**总人数**：{$redis->get('other_group_member_count')}人
            >**客户数（消费过的）**：{$redis->get('other_consumer_count')}人
            >**客户占比**：$rate1
            >**当前客户消费**：
            0.01元<累计＜10元：{$redis->get('other_zero')}人
            10元<=累计＜100元：{$redis->get('other_one')}人
            100元<=累计<500元：{$redis->get('other_two')}人
            500元<=累计<1000元 ：{$redis->get('other_three')}人
            累计≥1000元：{$redis->get('other_four')}人
            >**上周购买人数**：{$redis->get('other_last_week_buy_count')}人
            >**购买率**：$rate2
            >**上周群聊购买人数**：{$redis->get('other_last_week_buy_count_group')}人
            >**群聊购买率**：$rate3
            >**上周用户运营商品购买总人数**：{$redis->get('other_last_week_buy_count_platform_1')}人
            >**购买率**：$rate4
            >**上周用户运营商品群聊购买人数**：{$redis->get('other_last_week_buy_count_platform_1_group')}人
            >**群聊购买率**：$rate5
            \n";

            try {
                $messageHttpDao->sendMessage('markdown', $content,  ['chebin']);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }

        }

        return true;
    }*/

    /**
     * 1、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过个人号和进过其他群的人数；
     * 2、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过阳阳、阳阳1个人号和进过阳阳、阳阳1其他群的人数；
     *
     * @return void
     */
    /*public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $groupList = ContactGroupDao::getAllList(
            [
                'name',
                'chat_id'
            ],
            [
                'name' => ['like', "%进群看群公告%"]
            ]
        );

        $conversionGroupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'owner'  => ['in', [
                    'yangyang1',
                    'yangyang123'
                ]]
            ]
        );

        $conversionGroupIdArr = array_column($conversionGroupList, 'chat_id');

        $groupIdData = array_column($groupList, 'chat_id');

        $redis = Cache::store()->handler();

        $contactHttpDao = new ContactHttpDao();

        $appLastLoginTime = $contactHttpDao->getAppLastLoginTime($unionId);

        // APP登录时间
        $appLogin = $appLastLoginTime['app_last_login'];

        $liveRankData = $contactHttpDao->getLiveRank($unionId);

        // 珠宝登录时间
        $baojieLogin = $liveRankData['last_login'];

        $mediaData = $contactHttpDao->getYanzhi($unionId);

        // 媒体登录时间
        $mediaLogin = $mediaData['last_login'];
        // 颜值数
        $yanzhiCount = $mediaData['yanzhi_total'];

        $userCenterData = $contactHttpDao->getUserCenter($unionId);

        $consumeAmount = $userCenterData['consume_amount'];


        $otherGroup = ContactGroupMembersDao::getAllList(
            ['chat_id'],
            [
                            'unionid' => $unionId,
                            'chat_id' => ['not in', $groupIdData]
                        ]
        );

        $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

        if (
            $baojieLogin == 0
            && $mediaLogin === false
            && $appLogin == 0
            && $yanzhiCount == 0
            && $consumeAmount == 0
            && empty($otherGroup)
            && empty($contactInfo)
        ) {
            Log::info($unionId . '-是公域新人～');
            $redis->incr('newbie');
        } else {
            Log::info($unionId . '-不是公域新人！');
            // 在不在别的群里
            //$groupIdArr = ContactGroupMembersDao::getAllList(['chat_id'],['unionid' => $unionId,'chat_id' => ['not in', $groupIdData]]);
            $groupIdArr = ContactGroupMembersDao::getAllList(
                ['chat_id'],
                [
                    'unionid' => $unionId,
                    'chat_id' => ['in', $conversionGroupIdArr]
                ]
            );

            //if (!empty($groupIdArr))// 在别的群里存在，不计数，直接退出
            if ($groupIdArr) { // 进过阳阳群
                Log::info($unionId . '-在别的群里存在');
                return true;
            }

            // 判断是否是客户
            //$contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

            // 判断是否加过阳阳和阳阳1
            $isContact = ContactFollowUserDao::getAllList(['id'], [
                'external_userid' => $carryData['userid'],
                'userid'          => ['in', ['yangyang1', 'yangyang123']]
            ]);

            // 不是客户，满足条件
            //if (empty($contactInfo)){
            if (empty($isContact)) {
                Log::info($unionId . '-不是客户');

                $redis->incr('hahaha123');
            } else {
                Log::info($unionId . '-是客户!');
            }
        }

        return true;
    }*/

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();
        $yangyangArr = UserDao::getAllList(
            [
                'userid'
            ],
            [
                'name' => ['like', "%阳阳%"]
            ]
        );

        $yangyangArr = array_column($yangyangArr, 'userid');

        $externalContactArr = (array)Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'external_contact b',
                'a.external_userid = b.external_userid',
                'left'
            )
            ->field([
                'create_date'
            ])
            ->where([
                'unionid' => $carryData['unionid'],
                'userid'  => ['in', $yangyangArr],
            ])
            ->find();

        if (!$externalContactArr) {
            $redis->sadd('notFriend', $carryData['unionid']);
            return true;
        }

        $createTime = strtotime($externalContactArr['create_date']);
        $firstOrderTime = strtotime($carryData['date']);

        if ($firstOrderTime < $createTime) {
            $redis->sadd('less', $carryData['unionid']);
        } elseif ($firstOrderTime == $createTime) {
            $redis->sadd('equal', $carryData['unionid']);
        } else {
            $redis->sadd('gt', $carryData['unionid']);
        }

        return true;
    }
}
