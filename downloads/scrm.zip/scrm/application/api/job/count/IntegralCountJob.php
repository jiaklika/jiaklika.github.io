<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\job\BaseJob;
use think\Cache;

/**
 * Class IntegralCountJob
 * @package app\api\job\count
 */
class IntegralCountJob extends BaseJob
{
    /**
     * @var string 任务名称
     */
    public static $jobName = '用户颜值分布';

    public function doJob($carryData)
    {
        if (empty($carryData)) {
            return true;
        }

        $redis = Cache::store()->handler();
        $contactHttpDao = new ContactHttpDao();
        $yanzhiInfo = $contactHttpDao->getYanzhi($carryData);
        $userLevelInfo = $contactHttpDao->getUserCenter($carryData);

        $suffixKeyName = 'feiyue';

        $writeRedis = function ($keyName) use ($userLevelInfo, $redis, $suffixKeyName) {

            $redis->incr("{$suffixKeyName}_{$keyName}_all");

            if ($userLevelInfo['user_level_id'] == null) {
                $redis->incr("{$suffixKeyName}_{$keyName}_0");
            } else {
                $userLevel = $userLevelInfo['user_level_id'];
                $redis->incr("{$suffixKeyName}_{$keyName}_{$userLevel}");
            }
        };

        if ($yanzhiInfo['yanzhi_total'] == 0) {
            $writeRedis('0');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 0
            && $yanzhiInfo['yanzhi_total'] <= 200
        ) {
            $writeRedis('(0, 200]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 200
            && $yanzhiInfo['yanzhi_total'] <= 1000
        ) {
            $writeRedis('(200,1000]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 1000
            && $yanzhiInfo['yanzhi_total'] <= 5000
        ) {
            $writeRedis('(1K,5K]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 5000
            && $yanzhiInfo['yanzhi_total'] <= 10000
        ) {
            $writeRedis('(5K, 1w]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 10000
            && $yanzhiInfo['yanzhi_total'] <= 50000
        ) {
            $writeRedis('(1w,5w]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 50000
            && $yanzhiInfo['yanzhi_total'] <= 100000
        ) {
            $writeRedis('(5w,10w]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 100000
            && $yanzhiInfo['yanzhi_total'] <= 300000
        ) {
            $writeRedis('(10w,30w]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 300000
            && $yanzhiInfo['yanzhi_total'] <= 1000000
        ) {
            $writeRedis('(30W,100W]');
        }

        if (
            $yanzhiInfo['yanzhi_total'] > 1000000
        ) {
            $writeRedis('100w以上');
        }

        return true;
    }
}
