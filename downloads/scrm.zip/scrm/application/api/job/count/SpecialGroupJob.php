<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\job\BaseJob;
use Exception;
use think\Cache;

/**
 * 指定群数据汇总
 *
 * Class SpecialGroupJob
 * @package app\api\job
 */
class SpecialGroupJob extends BaseJob
{
    /**
     * 好物优享群
     * 新粉福利群
     *
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        if (!$unionId = $carryData['unionid']) {
            return true;
        }

        $redis = Cache::store()->handler();

        $key_name = $carryData['key_name'];

        $contactHttpDao = new ContactHttpDao();

        $userCenterData = $contactHttpDao->getUserCenter($unionId);
        $mobile = $userCenterData['mobile'];
        $consumeInfo = $mobile ? $contactHttpDao->getConsumeSegment($mobile) : [];

        $orderInfo = $contactHttpDao->getPlatformOrderList($unionId);

        if ($consumeInfo) {
            $contractAmount = $consumeInfo['contract_amount'] ?? 0;

            if ($contractAmount != 0) {
                $redis->incr($key_name . '_contract_amount'); // 客户数（消费过的）
            }

            $utype = $consumeInfo['utype'];


        } else {
            $utype = '0';
        }

        $redis->incr($key_name . '_' . $utype);

        if (isset($orderInfo['error'])) {
            return true;
        }

        if ($orderInfo['last_week_buy_count']) {
            $redis->incr($key_name . '_last_week_buy_count');
        }

        if ($orderInfo['last_week_buy_count_group']) {
            $redis->incr($key_name . '_last_week_buy_count_group');
        }

        if ($orderInfo['last_week_buy_count_platform_1']) {
            $redis->incr($key_name . '_last_week_buy_count_platform_1');
        }

        if (!empty($orderInfo['last_week_buy_count_platform_1_group'])) {
            $redis->incr($key_name . '_last_week_buy_count_platform_1_group');
        }

        return true;
    }
}
