<?php

namespace app\api\job\count;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\job\BaseJob;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Exception;
use think\Cache;
use think\Db;

/**
 * Class CountGroupMemberJob
 * @package app\api\job\count
 */
class CountGroupMemberJob extends BaseJob
{
    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    /*public function doJob($carryData): bool
    {
        $redis = Cache::store()->handler();
        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($carryData);

        if (!isset($userInfo['contractAmount']) || $userInfo['contractAmount'] == 0) {
            return true;
        } else {
            $redis->sadd('consumer', $carryData);
        }

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $isZhaoweiGroupMember = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'member.unionid'
            ])
            ->join(
                'scrm_contact_groups groups',
                'member.chat_id = groups.chat_id',
                'LEFT'
            )
            ->where([
                'owner'             => ['in', $zhaoweiAccountsArr],
                'groups.is_deleted' => ContactGroups::NOT_DELETED,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'member.type'       => ContactGroupMembers::EXTERNAL_USER,
                'member.unionid'    => $carryData
            ])
            ->find();

        if ($isZhaoweiGroupMember) {
            return true;
        }

        $isZhaoweiFriend = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.unionid',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid'  => ['in', $zhaoweiAccountsArr],
                'unionid' => $carryData,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->find();

        if ($isZhaoweiFriend) {
            return true;
        }

        $redis->sadd('notZhaoweiGroupMemberOrFriend', $carryData);

        return true;
    }*/

    /**
     * @param $carryData
     * @return bool
     * @throws Exception
     */
    public function doJob($carryData): bool
    {
        if (!$carryData) {
            return true;
        }

        $isFriend = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.unionid',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => $carryData,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->find();

        if ($isFriend) {
            return true;
        }
        $contactHttpDao = new ContactHttpDao();

        $userInfo = $contactHttpDao->getUserCenter($carryData);
        $redis = Cache::store()->handler();

        if (!isset($userInfo['contractAmount']) || $userInfo['contractAmount'] == 0) {
            $orderInfo = $contactHttpDao->getMediaOrderList($carryData);

            if ($orderInfo && !isset($orderInfo['error'])) {
                $redis->sadd('consumer1', $carryData);
            }
            return true;
        } else {
            $redis->sadd('consumer2', $carryData);
        }

        return true;
    }
}
