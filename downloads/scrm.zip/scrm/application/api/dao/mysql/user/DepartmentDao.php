<?php

namespace app\api\dao\mysql\user;

use app\api\dao\mysql\BaseDao;
use app\common\model\Department;
use Exception;

/**
 * Class DepartmentDao
 * @package app\api\dao\mysql\user
 */
class DepartmentDao extends BaseDao
{
    protected static $currentTable = self::DEPARTMENT_TABLE;

    /**
     * 得到所有一级部门
     *
     * @throws Exception
     */
    public static function getAllFirstLevelDepartment()
    {
        return self::getAllList(['department_id'], [
            'department_parentid' => Department::ROOT_PARENT_DEPARTMENT_ID,
            'is_deleted'          => Department::NOT_DEL
        ]);
    }

    /**
     * 获取全部部门路径
     *
     * @param int $departmentId 部门ID
     * @param bool $clear 是否注销静态变量
     * @return array
     * @throws Exception
     */
    public static function getAllDepartmentPath(int $departmentId, bool $clear = false)
    {
        static $departmentNameArr = [];

        if ($clear) {
            $departmentNameArr = [];
        }

        $departmentInfo = self::getDetail(
            [
                'department_name',
                'department_parentid'
            ],
            [
                'department_id' => $departmentId,
                'is_deleted'    => Department::NOT_DEL
            ]
        );

        if (
            isset($departmentInfo['department_parentid'])
            && $departmentInfo['department_parentid'] !== 0
        ) {
            array_unshift($departmentNameArr, $departmentInfo['department_name']);

            self::getAllDepartmentPath($departmentInfo['department_parentid']);
        }

        return $departmentNameArr;
    }
}
