<?php

namespace app\api\dao\mysql\user;

use app\api\dao\mysql\BaseDao;

/**
 * Class UserDao
 * @package app\api\dao\mysql\user
 */
class UserDao extends BaseDao
{
    protected static $currentTable = self::USER_TABLE;
}
