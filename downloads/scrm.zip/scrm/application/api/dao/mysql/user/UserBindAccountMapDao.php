<?php

namespace app\api\dao\mysql\user;

use app\api\dao\mysql\BaseDao;

/**
 * Class UserBindAccountMapDao
 * @package app\api\dao\mysql\user
 */
class UserBindAccountMapDao extends BaseDao
{
    protected static $currentTable = self::USER_BIND_ACCOUNT_MAP_TABLE;
}
