<?php

namespace app\api\dao\mysql\log;

use app\api\dao\mysql\BaseDao;

/**
 * Class MqLogsDao
 * @package app\api\dao\mysql\log
 */
class ConsumeMqLogsDao extends BaseDao
{
    protected static $currentTable = self::CONSUME_MQ_LOGS_TABLE;
}
