<?php

namespace app\api\dao\mysql\log;

use app\api\dao\mysql\BaseDao;

/**
 * Class MqLogsDao
 * @package app\api\dao\mysql\log
 */
class MqLogsDao extends BaseDao
{
    protected static $currentTable = self::MQ_LOGS_TABLE;
}
