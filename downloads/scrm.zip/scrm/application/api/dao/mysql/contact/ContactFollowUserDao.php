<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;
use Exception;
use think\Db;
use think\db\Query;

/**
 * Class ContactFollowUserDao
 * @package app\api\dao\mysql\contact
 */
class ContactFollowUserDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_FOLLOW_USER_TABLE;

    /**
     * 获取客户列表
     *
     * @param array  $fields 查询字段
     * @param array  $where  查询条件
     * @param int    $page   页数
     * @param int    $limit  每页条数
     * @param string $order  排序
     * @return mixed
     * @throws Exception
     */
    public static function getContactList(
        array $fields,
        array $where,
        int $page = 1,
        int $limit = 10,
        string $order = 'follow.id DESC',
        $extraWhere = []
    ) {
        $model = self::getModel($fields, $where, $extraWhere);

        if ($page && $limit) {
            $model = tap($model, function ($object) use ($page, $limit) {
                $object->page($page, $limit);
            });
        }

        return $model->order($order)->select();
    }

    /**
     * 获取客户总数
     *
     * @param array $where 查询条件
     * @param array $extraWhere
     * @return int
     * @throws \think\Exception
     */
    public static function getContactCount(array $where, array $extraWhere = []): int
    {
        $model = self::getModel(['follow.id'], $where, $extraWhere);
        return $model->count();
    }

    /**
     * 获取模型
     *
     * @param array $fields
     * @param array $where
     * @param array $extraWhere
     * @return Query
     */
    private static function getModel(array $fields, array $where, array $extraWhere = []): Query
    {
        if (isset($where['tag.tag_id'])) {
            return Db::name(self::$currentTable)
                ->alias('follow')
                ->field($fields)
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->join(
                    'scrm_contact_ways way',
                    'follow.state = way.id',
                    'LEFT'
                )
                ->join(
                    'scrm_contact_tag_map tag',
                    'follow.external_userid = tag.external_userid',
                    'LEFT'
                )
                ->where($where);
        }
        if ($extraWhere) {
            return Db::name(self::$currentTable)
                ->alias('follow')
                ->field($fields)
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->join(
                    'scrm_contact_ways way',
                    'follow.state = way.id',
                    'LEFT'
                )
                ->where(function ($query) use ($where) {
                    $query->where($where);
                })->where(function ($query) use ($where, $extraWhere) {
                    $query->where($extraWhere[0])->whereOr($extraWhere[1]);
                });
        } else {
            return Db::name(self::$currentTable)
                ->alias('follow')
                ->field($fields)
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->join(
                    'scrm_contact_ways way',
                    'follow.state = way.id',
                    'LEFT'
                )
                ->where($where);
        }
    }
}
