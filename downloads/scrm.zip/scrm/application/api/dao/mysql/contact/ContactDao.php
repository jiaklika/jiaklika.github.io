<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;
use app\common\model\ExternalContact;

/**
 * Class ContactDao
 * @package app\api\dao\mysql\contact
 */
class ContactDao extends BaseDao
{
    protected static $currentTable = self::EXTERNAL_CONTACT_TABLE;

    /**
     * 获取宝姐客户等级列表
     *
     * @return array
     */
    public static function getUserLevelList(): array
    {
        return ExternalContact::USER_LEVEL_LIST;
    }
}
