<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

class ContactFissionRecordsDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_FISSION_RECORDS_TABLE;
}
