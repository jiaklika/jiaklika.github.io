<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactTagsDao
 * @package app\api\dao\mysql\contact
 */
class ContactTagsDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_TAGS_TABLE;
}
