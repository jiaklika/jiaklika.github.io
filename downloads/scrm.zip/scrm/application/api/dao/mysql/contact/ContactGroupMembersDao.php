<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactGroupMembersDao
 * @package app\api\dao\mysql\contact
 */
class ContactGroupMembersDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_GROUP_MEMBERS_TABLE;
}
