<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactTagMapDao
 * @package app\api\dao\mysql\contact
 */
class ContactTagMapDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_TAG_MAP_TABLE;
}
