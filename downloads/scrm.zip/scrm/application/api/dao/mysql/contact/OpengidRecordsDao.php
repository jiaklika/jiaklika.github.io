<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

/**
 * Class OpengidRecordsDao
 * @package app\api\dao\mysql\contact
 */
class OpengidRecordsDao extends BaseDao
{
    protected static $currentTable = self::OPENGID_RECORDS_TABLE;
}