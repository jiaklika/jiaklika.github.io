<?php

namespace app\api\dao\mysql\contact;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactGroupDao
 * @package app\api\dao\mysql\contact
 */
class ContactGroupDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_GROUPS_TABLE;
}
