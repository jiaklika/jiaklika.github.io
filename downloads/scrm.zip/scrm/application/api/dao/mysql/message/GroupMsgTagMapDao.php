<?php

namespace app\api\dao\mysql\message;

use app\api\dao\mysql\BaseDao;

/**
 * Class GroupMsgTagMapDao
 * @package app\api\dao\mysql\message
 */
class GroupMsgTagMapDao extends BaseDao
{
    protected static $currentTable = self::GROUP_MSG_TAG_MAP_TABLE;
}
