<?php

namespace app\api\dao\mysql\message;

use app\api\dao\mysql\BaseDao;

/**
 * Class GroupMsgIdMapDao
 * @package app\api\dao\mysql\message
 */
class GroupMsgIdMapDao extends BaseDao
{
    protected static $currentTable = self::GROUP_MSG_ID_MAP_TABLE;
}
