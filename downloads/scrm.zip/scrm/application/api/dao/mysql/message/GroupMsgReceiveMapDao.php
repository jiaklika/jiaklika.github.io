<?php

namespace app\api\dao\mysql\message;

use app\api\dao\mysql\BaseDao;

/**
 * Class GroupMsgReceiveMapDao
 * @package app\api\dao\mysql\message
 */
class GroupMsgReceiveMapDao extends BaseDao
{
    protected static $currentTable = self::GROUP_MSG_RECEIVE_MAP_TABLE;
}
