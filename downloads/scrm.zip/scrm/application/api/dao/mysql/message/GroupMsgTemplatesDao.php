<?php

namespace app\api\dao\mysql\message;

use app\api\dao\mysql\BaseDao;
use think\Db;

/**
 * Class GroupMsgTemplatesDao
 * @package app\api\dao\mysql\message
 */
class GroupMsgTemplatesDao extends BaseDao
{
    protected static $currentTable = self::GROUP_MSG_TEMPLATES_TABLE;
}
