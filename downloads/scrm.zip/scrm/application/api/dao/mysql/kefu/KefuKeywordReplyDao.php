<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 关键词表
 *
 * Class KefuKeywordReplyDao
 * @package app\api\dao\mysql\kefu
 */
class KefuKeywordReplyDao extends BaseDao
{
    protected static $currentTable = self::KEYWORD_REPLY_TABLE;
}
