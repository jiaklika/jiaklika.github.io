<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 聊天记录表
 *
 * Class KefuChatRecordsDao
 * @package app\api\dao\mysql\kefu
 */
class KefuChatRecordsDao extends BaseDao
{
    protected static $currentTable = self::KEFU_CHAT_RECORDS_TABLE;
}
