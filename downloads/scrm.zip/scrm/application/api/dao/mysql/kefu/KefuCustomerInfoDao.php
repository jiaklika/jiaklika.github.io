<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 客户基础信息表
 *
 * Class KefuCustomerInfoDao
 * @package app\api\dao\mysql\kefu
 */
class KefuCustomerInfoDao extends BaseDao
{
    protected static $currentTable = self::KEFU_CUSTOMER_INFO_TABLE;
}
