<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 聊天列表
 *
 * Class KefuChatListDao
 * @package app\api\dao\mysql\kefu
 */
class KefuChatListDao extends BaseDao
{
    protected static $currentTable = self::KEFU_CHAT_LIST_TABLE;
}
