<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 客服账号链接表
 *
 * Class KefuAccountUrlDao
 * @package app\api\dao\mysql\kefu
 */
class KefuAccountUrlDao extends BaseDao
{
    protected static $currentTable = self::KEFU_ACCOUNT_URL_TABLE;
}
