<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 关键词附件表
 *
 * Class KefuKeywordReplyAttachmentsDao
 * @package app\api\dao\mysql\kefu
 */
class KefuKeywordReplyAttachmentsDao extends BaseDao
{
    protected static $currentTable = self::KEFU_KEYWORD_REPLY_ATTACHMENTS_TABLE;
}
