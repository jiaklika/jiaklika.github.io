<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 关键词映射表
 *
 * Class KefuKeywordMapDao
 * @package app\api\dao\mysql\kefu
 */
class KefuKeywordMapDao extends BaseDao
{
    protected static $currentTable = self::KEYWORD_MAP_TABLE;
}
