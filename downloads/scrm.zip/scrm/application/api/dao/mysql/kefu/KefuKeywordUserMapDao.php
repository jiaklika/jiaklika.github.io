<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 用户关键词触发表
 *
 * Class KefuKeywordUserMapDao
 * @package app\api\dao\mysql\kefu
 */
class KefuKeywordUserMapDao extends BaseDao
{
    protected static $currentTable = self::KEFU_KEYWORD_USER_MAP_TABLE;
}
