<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 消息日志表
 *
 * Class KefuMsgLogDao
 * @package app\api\dao\mysql\kefu
 */
class KefuMsgLogDao extends BaseDao
{
    protected static $currentTable = self::KEFU_MSG_LOG_TABLE;
}
