<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 接待人员映射表
 *
 * Class KefuServicerMapDao
 * @package app\api\dao\mysql\kefu
 */
class KefuServicerMapDao extends BaseDao
{
    protected static $currentTable = self::KEFU_SERVICER_MAP_TABLE;
}
