<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 客服回调日志表
 *
 * Class KefuCallbackLogDao
 * @package app\api\dao\mysql\kefu
 */
class KefuCallbackLogDao extends BaseDao
{
    protected static $currentTable = self::KEFU_CALLBACK_LOG_TABLE;
}
