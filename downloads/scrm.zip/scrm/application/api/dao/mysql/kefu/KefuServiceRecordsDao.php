<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 接待记录表
 *
 * Class KefuServiceRecordsDao
 * @package app\api\dao\mysql\kefu
 */
class KefuServiceRecordsDao extends BaseDao
{
    protected static $currentTable = self::KEFU_SERVICE_RECORDS_TABLE;
}
