<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 客服账号表
 *
 * Class KefuAccountsDao
 * @package app\api\dao\mysql\kefu
 */
class KefuAccountsDao extends BaseDao
{
    protected static $currentTable = self::KEFU_ACCOUNTS_TABLE;
}
