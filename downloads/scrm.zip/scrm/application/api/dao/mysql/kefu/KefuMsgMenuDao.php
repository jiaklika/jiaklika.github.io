<?php

namespace app\api\dao\mysql\kefu;

use app\api\dao\mysql\BaseDao;

/**
 * 智能菜单表
 *
 * Class KefuMsgMenuDao
 * @package app\api\dao\mysql\kefu
 */
class KefuMsgMenuDao extends BaseDao
{
    protected static $currentTable = self::KEFU_MSG_MENU_TABLE;
}
