<?php

namespace app\api\dao\mysql\living;

use app\api\dao\mysql\BaseDao;

class LivingDao extends BaseDao
{
    protected static $currentTable = self::LIVE_INFO_TABLE;
}
