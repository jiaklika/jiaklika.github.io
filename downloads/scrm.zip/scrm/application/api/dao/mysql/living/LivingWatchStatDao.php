<?php

namespace app\api\dao\mysql\living;

use app\api\dao\mysql\BaseDao;

class LivingWatchStatDao extends BaseDao
{
    protected static $currentTable = self::LIVE_WATCH_STAT_TABLE;
}
