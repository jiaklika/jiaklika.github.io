<?php

namespace app\api\dao\mysql\liveData;

use app\api\dao\mysql\BaseDao;

/**
 * Class VideoLiveTaskDao
 * @package app\api\dao\mysql\liveData
 */
class VideoLiveTaskDao extends BaseDao
{
    protected static $currentTable = self::VIDEO_LIVE_TASK_TABLE;
}
