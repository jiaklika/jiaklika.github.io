<?php

namespace app\api\dao\mysql\liveData;

use app\api\dao\mysql\BaseDao;

/**
 * Class LiveAudienceDataDao
 * @package app\api\dao\mysql\liveData
 */
class LiveAudienceDataDao extends BaseDao
{
    protected static $currentTable = self::LIVE_AUDIENCE_DATA_TABLE;
}
