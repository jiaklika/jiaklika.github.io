<?php

namespace app\api\dao\mysql\liveData;

use app\api\dao\mysql\BaseDao;

/**
 * Class LiveDataDao
 * @package app\api\dao\mysql\liveData
 */
class LiveDataDao extends BaseDao
{
    protected static $currentTable = self::LIVE_DATA_TABLE;
}
