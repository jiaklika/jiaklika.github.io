<?php

namespace app\api\dao\mysql\way;

use app\api\dao\mysql\BaseDao;

/**
 * Class UnifyServiceDao
 * @package app\api\dao\mysql\way
 */
class UnifyServiceDao extends BaseDao
{
    protected static $currentTable = self::UNIFY_SERVICE_TABLE;
}