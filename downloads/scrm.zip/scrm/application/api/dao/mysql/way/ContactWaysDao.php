<?php

namespace app\api\dao\mysql\way;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactWaysDao
 * @package app\api\dao\mysql\way
 */
class ContactWaysDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_WAYS_TABLE;
}
