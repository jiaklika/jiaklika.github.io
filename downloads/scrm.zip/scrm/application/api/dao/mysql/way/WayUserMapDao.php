<?php

namespace app\api\dao\mysql\way;

use app\api\dao\mysql\BaseDao;

/**
 * Class WayUserMapDao
 * @package app\api\dao\mysql\way
 */
class WayUserMapDao extends BaseDao
{
    protected static $currentTable = self::WAY_USER_MAP_TABLE;
}
