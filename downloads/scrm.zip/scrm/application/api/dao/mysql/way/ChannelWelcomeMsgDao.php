<?php

namespace app\api\dao\mysql\way;

use app\api\dao\mysql\BaseDao;

/**
 * Class ChannelWelcomeMsgDao
 * @package app\api\dao\mysql\way
 */
class ChannelWelcomeMsgDao extends BaseDao
{
    protected static $currentTable = self::CHANNEL_WELCOME_MSG_TABLE;
}
