<?php

namespace app\api\dao\mysql\way;

use app\api\dao\mysql\BaseDao;

/**
 * Class ContactChannelsDao
 * @package app\api\dao\mysql\way
 */
class ContactChannelsDao extends BaseDao
{
    protected static $currentTable = self::CONTACT_CHANNELS_TABLE;
}
