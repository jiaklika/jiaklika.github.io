<?php

namespace app\api\dao\mysql\moment;

use app\api\dao\mysql\BaseDao;

/**
 * 朋友圈群发任务记录表
 *
 * Class MomentTaskDao
 * @package app\api\dao\mysql\moment
 */
class MomentTaskDao extends BaseDao
{
    protected static $currentTable = self::MOMENT_TASK_TABLE;
}
