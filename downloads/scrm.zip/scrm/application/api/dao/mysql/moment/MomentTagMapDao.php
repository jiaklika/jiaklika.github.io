<?php

namespace app\api\dao\mysql\moment;

use app\api\dao\mysql\BaseDao;

/**
 * 朋友圈群发指定标签表
 *
 * Class MomentTagMapDao
 * @package app\api\dao\mysql\moment
 */
class MomentTagMapDao extends BaseDao
{
    protected static $currentTable = self::MOMENT_TAG_MAP_TABLE;
}
