<?php

namespace app\api\dao\mysql\moment;

use app\api\dao\mysql\BaseDao;

/**
 * Class MomentImageMapDao
 * @package app\api\dao\mysql\moment
 */
class MomentImageMapDao extends BaseDao
{
    protected static $currentTable = self::MOMENT_IMAGE_MAP_TABLE;
}
