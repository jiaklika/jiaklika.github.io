<?php

namespace app\api\dao\mysql\moment;

use app\api\dao\mysql\BaseDao;

/**
 * 朋友圈群发指定员工表
 *
 * Class MomentSenderMapDao
 * @package app\api\dao\mysql\moment
 */
class MomentSenderMapDao extends BaseDao
{
    protected static $currentTable = self::MOMENT_SENDER_MAP_TABLE;
}
