<?php

namespace app\api\dao\mysql\moment;

use app\api\dao\mysql\BaseDao;

/**
 * Class MomentListDao
 * @package app\api\dao\mysql\moment
 */
class MomentListDao extends BaseDao
{
    protected static $currentTable = self::MOMENT_LIST_TABLE;
}
