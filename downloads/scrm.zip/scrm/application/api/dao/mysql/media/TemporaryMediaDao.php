<?php

namespace app\api\dao\mysql\media;

use app\api\dao\mysql\BaseDao;

/**
 * Class TemporaryMediaDao
 * @package app\api\dao\mysql\media
 */
class TemporaryMediaDao extends BaseDao
{
    protected static $currentTable = self::TEMPORARY_MEDIA_TABLE;
}
