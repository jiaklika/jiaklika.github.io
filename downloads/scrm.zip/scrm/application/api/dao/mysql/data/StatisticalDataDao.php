<?php

namespace app\api\dao\mysql\data;

use app\api\dao\mysql\BaseDao;

/**
 * Class SaveStatisticsDataDao
 * @package app\api\dao\mysql\data
 */
class StatisticalDataDao extends BaseDao
{
    protected static $currentTable = self::STATISTICAL_DATA_TABLE;
}
