<?php

namespace app\api\dao\mysql\data;

use app\api\dao\mysql\BaseDao;

/**
 * Class PushFansDao
 * @package app\api\dao\mysql\data
 */
class PushFansDao extends BaseDao
{
    protected static $currentTable = self::PUSH_FANS_TABLE;
}
