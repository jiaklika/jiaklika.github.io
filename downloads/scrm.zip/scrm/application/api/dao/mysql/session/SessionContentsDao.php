<?php

namespace app\api\dao\mysql\session;

use app\api\dao\mysql\BaseDao;

/**
 * Class SessionContentsDao
 * @package app\api\dao\mysql\session
 */
class SessionContentsDao extends BaseDao
{
    protected static $currentTable = self::SESSION_CONTENTS_TABLE;
}
