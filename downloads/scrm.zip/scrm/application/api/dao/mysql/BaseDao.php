<?php

declare(strict_types=1);

namespace app\api\dao\mysql;

use Carbon\Carbon;
use Closure;
use Exception;
use think\Db;
use think\Model;

/**
 * Class BaseDao
 * @package app\api\dao\mysql
 */
class BaseDao
{
    // 企业微信员工表
    public const USER_TABLE = 'user';
    // 企业微信部门表
    public const DEPARTMENT_TABLE = 'department';
    // 用户绑定企微账号映射表
    public const USER_BIND_ACCOUNT_MAP_TABLE = 'user_bind_account_map';

    // 企业微信外部联系人表
    public const EXTERNAL_CONTACT_TABLE = 'external_contact';
    // 外部联系人对应用户表
    public const CONTACT_FOLLOW_USER_TABLE = 'contact_follow_user';

    // 添加企业客户标签表
    public const CONTACT_TAGS_TABLE = 'contact_tags';
    // 企业客户添加渠道表
    public const CONTACT_CHANNELS_TABLE = 'contact_channels';
    // 企业客户联系我路径表
    public const CONTACT_WAYS_TABLE = 'contact_ways';
    // 联系方式的用户映射表
    public const WAY_USER_MAP_TABLE = 'way_user_map';

    // 企业微信回调记录表
    public const CALLBACK_LOGS_TABLE = 'callback_logs';

    // 客户群表
    public const CONTACT_GROUPS_TABLE = 'contact_groups';
    // 客户群成员表
    public const CONTACT_GROUP_MEMBERS_TABLE = 'contact_group_members';

    // 临时素材表
    public const TEMPORARY_MEDIA_TABLE = 'temporary_media';

    // 渠道欢迎语表
    public const CHANNEL_WELCOME_MSG_TABLE = 'channel_welcome_msg';

    // 客户企业标签映射表
    public const CONTACT_TAG_MAP_TABLE = 'contact_tag_map';

    // 会话内容表
    public const SESSION_CONTENTS_TABLE = 'session_contents';

    // 直播详情表
    public const LIVE_INFO_TABLE = 'live_info';

    // 看直播人员表
    public const LIVE_WATCH_STAT_TABLE = 'live_watch_stat';

    // mq数据日志表
    public const MQ_LOGS_TABLE = 'mq_logs';

    // 宝姐珠宝消费队列日志表
    public const CONSUME_MQ_LOGS_TABLE = 'consume_mq_logs';

    // 朋友圈发表记录表
    public const MOMENT_LIST_TABLE = 'moment_list';

    // 朋友圈发表记录表
    public const MOMENT_IMAGE_MAP_TABLE = 'moment_image_map';

    // 企业群发记录表
    public const GROUP_MSG_TEMPLATES_TABLE = 'group_msg_templates';
    // 企业群发指定客服发送
    public const GROUP_MSG_SENDER_MAP_TABLE = 'group_msg_sender_map';
    // 企业群发指定标签发送
    public const GROUP_MSG_TAG_MAP_TABLE = 'group_msg_tag_map';
    // 企业群发接收客户表
    public const GROUP_MSG_RECEIVE_MAP_TABLE = 'group_msg_receive_map';
    // 企业群发消息ID记录表
    public const GROUP_MSG_ID_MAP_TABLE = 'group_msg_id_map';

    // 直播场次数据表
    public const LIVE_DATA_TABLE = 'live_data';
    // 观看直播用户数据表
    public const LIVE_AUDIENCE_DATA_TABLE = 'live_audience_data';

    // 企微数据统计表
    public const STATISTICAL_DATA_TABLE = 'statistical_data';

    /**
     * @var string 小程序在客户群启动信息表
     */
    public const OPENGID_RECORDS_TABLE = 'opengid_records';

    /**
     * @var string 朋友圈任务记录表
     */
    public const MOMENT_TASK_TABLE = 'moment_task';

    /**
     * @var string 朋友圈群发指定员工表
     */
    public const MOMENT_SENDER_MAP_TABLE = 'moment_sender_map';

    /**
     * @var string 朋友圈群发指定标签表
     */
    public const MOMENT_TAG_MAP_TABLE = 'moment_tag_map';

    /**
     * @var string 视频号直播任务表
     */
    public const VIDEO_LIVE_TASK_TABLE = 'video_live_task';

    /**
     * @var string 推粉记录表
     */
    public const PUSH_FANS_TABLE = 'push_fans';

    /**
     * @var string 客户裂变记录表
     */
    public const CONTACT_FISSION_RECORDS_TABLE = 'contact_fission_records';

    /**
     * @var string 客服账号表
     */
    public const KEFU_ACCOUNTS_TABLE = 'kefu_accounts';

    /**
     * @var string 客服账号表
     */
    public const KEFU_ACCOUNT_URL_TABLE = 'kefu_account_url';

    /**
     * @var string 客服账号和接待员映射表
     */
    public const KEFU_SERVICER_MAP_TABLE = 'kefu_servicer_map';

    /**
     * @var string 客服聊天列表
     */
    public const KEFU_CHAT_LIST_TABLE = 'kefu_chat_list';

    /**
     * @var string 客服聊天记录表
     */
    public const KEFU_CHAT_RECORDS_TABLE = 'kefu_chat_records';

    /**
     * @var string 智能菜单表
     */
    public const KEFU_MSG_MENU_TABLE = 'kefu_msg_menu';

    /**
     * @var string 关键词回复表
     */
    public const KEYWORD_REPLY_TABLE = 'kefu_keyword_reply';

    /**
     * @var string 关键词回复映射表
     */
    public const KEYWORD_MAP_TABLE = 'kefu_keyword_map';

    /**
     * @var string 关键词回复映射表
     */
    public const KEFU_SERVICE_RECORDS_TABLE = 'kefu_service_records';

    /**
     * @var string 客户基础信息表
     */
    public const KEFU_CUSTOMER_INFO_TABLE = 'kefu_customer_info';

    /**
     * @var string 消息日志表
     */
    public const KEFU_MSG_LOG_TABLE = 'kefu_msg_log';

    /**
     * @var string 客服回调日志表
     */
    public const KEFU_CALLBACK_LOG_TABLE = 'kefu_callback_log';

    /**
     * @var string 统一咨询员工表
     */
    public const UNIFY_SERVICE_TABLE = 'unify_service';

    /**
     * @var string 客服关键词回复附件表
     */
    public const KEFU_KEYWORD_REPLY_ATTACHMENTS_TABLE = 'kefu_keyword_reply_attachments';

    /**
     * @var string 用户关键词触发统计表
     */
    public const KEFU_KEYWORD_USER_MAP_TABLE = 'kefu_keyword_user_map';

    // 当前操作的表
    protected static $currentTable;

    /**
     * 分页获得列表
     *
     * @param array $fields         所需字段
     * @param array $whereCondition 查询条件
     * @param int $page             页码
     * @param int $limit            每页条数
     * @param string $orderBy       排序
     * @return mixed
     * @throws Exception
     */
    public static function getPaginationList(
        array $fields,
        array $whereCondition,
        int $page,
        int $limit,
        string $orderBy = 'id'
    ): array {
        return Db::name(static::$currentTable)
                ->field($fields)
                ->where($whereCondition)
                ->page($page, $limit)
                ->order($orderBy)
                ->select();
    }

    /**
     * 获取总数
     *
     * @param array $whereCondition
     * @return int
     * @throws Exception
     */
    public static function getCount(array $whereCondition): int
    {
        return Db::name(static::$currentTable)
                ->where($whereCondition)
                ->count(1);
    }

    /**
     * 获得所有列表
     *
     * @param array $fields         所需字段
     * @param array $whereCondition 查询条件
     * @param string $orderBy       排序
     * @return mixed
     * @throws Exception
     */
    public static function getAllList(
        array $fields,
        array $whereCondition = [],
        string $orderBy = 'id'
    ): array {
        return Db::name(static::$currentTable)
                ->field($fields)
                ->where($whereCondition)
                ->order($orderBy)
                ->select();
    }

    /**
     * 获取统计信息
     *
     * @param array  $fields  所需字段
     * @param array  $where   查询条件
     * @param string $groupBy 分组汇总
     * @return mixed
     * @throws Exception
     */
    public static function getSum(array $fields, array $where, string $groupBy)
    {
        return Db::name(static::$currentTable)
            ->field($fields)
            ->where($where)
            ->group($groupBy)
            ->select();
    }

    /**
     * 获取详情
     *
     * @param array $fields 所需字段
     * @param array $where 查询条件
     * @param string $order 排序
     * @return array
     * @throws Exception
     */
    public static function getDetail(array $fields, array $where, string $order = 'id'): array
    {
         return ($res = Db::name(static::$currentTable)
                ->field($fields)
                ->where($where)
                ->order($order)
                ->find()) ? $res : [];
    }

    /**
     * 根据主键id判断数据是否存在
     *
     * @param int   $autoId     主键ID
     * @param array $extraWhere 额外查询条件
     * @return bool
     * @throws Exception
     */
    public static function isExistById(int $autoId = 0, array $extraWhere = []): bool
    {
        $whereCondition = [
            'id'         => $autoId,
            'is_deleted' => 0
        ];

        if ($autoId == 0) {
            $whereCondition = $extraWhere;
        }

        $res = Db::name(static::$currentTable)
                ->field('id')
                ->where($whereCondition)
                ->find();

        return !empty($res['id']);
    }

    /**
     * 添加数据
     *
     * @param array $insertData 插入单条数据
     * @param bool $getInsertId 是否获取插入id
     * @return int|string
     */
    public static function addData(array $insertData, bool $getInsertId = false)
    {
        if ($getInsertId) {
            return Db::name(static::$currentTable)->insertGetId($insertData);
        }

        return Db::name(static::$currentTable)->insert($insertData);
    }

    /**
     * 批量添加数据
     *
     * @param array $insertData 插入数据
     * @return bool
     */
    public static function addBatchData(array $insertData)
    {
        return Db::name(static::$currentTable)->insertAll($insertData);
    }

    /**
     * 更新数据
     *
     * @param array $updateData 需要更新的数据
     * @param array $where      查询条件，为空更新整张表
     * @return mixed
     * @throws Exception
     */
    public static function updateData(array $updateData, array $where = [])
    {
        return tap(Db::name(static::$currentTable), function ($model) use ($where) {
            if ($where) {
                return $model->where($where);
            } else {
                return $model->whereRaw('1=1');
            }
        })->update(
            array_merge(
                [
                    'update_time' => Carbon::now()
                ],
                $updateData
            )
        );
    }

    /**
     * 批量更新数据
     *
     * @param Model $model 实体数据模型对象
     * @param array $updateData 需要更新的数据，二维数组
     * @return array|false
     * @throws Exception
     */
    public static function updateBatchData(Model $model, array $updateData)
    {
        return $model->saveAll($updateData);
    }

    /**
     * 根据自增id软删除数据
     *
     * @param int   $autoId     主键ID
     * @param array $extraField 额外查询字段
     * @param array $extraWhere 额外搜索条件
     * @return int|string
     * @throws Exception
     */
    public static function deleteById(int $autoId, array $extraField = [], array $extraWhere = [])
    {
        $updateField = [
            'is_deleted' => 1,
            'del_time'   => Carbon::now()
        ];

        $whereCondition = [
            'id' => $autoId
        ];

        if ($extraField) {
            $updateField = array_merge($extraField, $updateField);
        }

        if ($autoId == 0) {
            $whereCondition = $extraWhere;
        }

        return Db::name(static::$currentTable)
                ->where($whereCondition)
                ->update($updateField);
    }

    /**
     * 硬删除数据
     *
     * @param array $deleteCondition 删除条件
     * @return int
     * @throws Exception
     */
    public static function hardDelete(array $deleteCondition): int
    {
        return Db::name(static::$currentTable)
            ->where($deleteCondition)
            ->delete();
    }

    /**
     * 软删除数据
     *
     * @param array $deleteCondition 删除条件
     * @throws Exception
     */
    public static function softDelete(array $deleteCondition): bool
    {
        return (bool)Db::name(static::$currentTable)
            ->where($deleteCondition)
            ->update([
                'is_deleted' => 1,
                'del_time'   => Carbon::now()->toDateString()
            ]);
    }

    /**
     * 分块处理数据
     *
     * @param array   $fields         查询字段
     * @param array   $whereCondition 查询条件
     * @param int     $limit          每次处理数量
     * @param Closure $handleFunction 处理函数
     * @return void
     */
    public static function handleDataByChunk(
        array $fields,
        array $whereCondition,
        int $limit,
        Closure $handleFunction
    ) {
        Db::name(static::$currentTable)
            ->field($fields)
            ->where($whereCondition)
            ->chunk($limit, $handleFunction);
    }
}
