<?php

namespace app\api\dao\mysql\callback;

use app\api\dao\mysql\BaseDao;

/**
 * Class CallbackLogsDao
 * @package app\api\dao\mysql\callback
 */
class CallbackLogsDao extends BaseDao
{
    protected static $currentTable = self::CALLBACK_LOGS_TABLE;
}
