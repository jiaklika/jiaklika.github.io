<?php

namespace app\api\dao\http\contactFission;

use app\api\util\HttpClient;
use Exception;

/**
 * 企微裂变
 *
 * Class ContactFissionHttpDao
 * @package app\api\dao\http\contactFission
 */
class ContactFissionHttpDao
{
    use HttpClient;

    /**
     * @var string 通知宝姐家被邀请人信息
     */
    public const FANS_HELP_URL =
        'https://ko.bojem.com/scrm/fansHelp?help_union_id=%s&share_union_id=%s&help_time=%d&avatar=%s&help_name=%s';

    /**
     * @var string 宝姐家判断新老客
     */
    public const IS_NEW_CONTACT_URL =
        'https://ko.bojem.com/scrm/fansHelpNew?union_id=%s';

    /**
     * @var string 宝姐珠宝判断新老客
     */
    public const BOJEM_IS_NEW_CONTACT_URL =
        'https://baojie.bojem.com/api/user/isNewByUnionId?union_id=%s';

    /**
     * 发送邀请信息给宝姐家
     *
     * @param string $inviterUnionId 邀请人unionId
     * @param string $followerUnionId 被邀请人unionId
     * @param int $addTime 添加时间
     * @param string $avatar 被邀请人头像
     * @param string $helpName 被邀请人昵称
     * @return void
     * @throws Exception
     */
    public function sendFansHelp(
        string $inviterUnionId,
        string $followerUnionId,
        int $addTime,
        string $avatar,
        string $helpName
    ): void {
        $fansHelpUrl = sprintf(
            self::FANS_HELP_URL,
            $followerUnionId,
            $inviterUnionId,
            $addTime,
            $avatar,
            $helpName
        );

        $res = self::sendRequest('get', $fansHelpUrl);

        if ($res['state'] != 1) {
            send_msg_to_wecom($res['msg']);
        }
    }

    /**
     *  宝姐家判断新老客
     *
     * @param string $unionId
     * @return bool
     * @throws Exception
     */
    public function isNewContact(string $unionId): bool
    {
        $isNewContactUrl = sprintf(
            self::IS_NEW_CONTACT_URL,
            $unionId
        );

        $res = self::sendRequest('get', $isNewContactUrl);

        if ($res['code'] != 1) {
            send_msg_to_wecom($res['msg']);
        }
        return $res['data']['is_new'];
    }

    /**
     * 宝姐珠宝判断新老客
     *
     * @param string $unionId
     * @return bool
     * @throws Exception
     */
    public function bojemIsNewContact(string $unionId): bool
    {
        $bojemIsNewContactUrl = sprintf(
            self::BOJEM_IS_NEW_CONTACT_URL,
            $unionId
        );

        $res = self::sendRequest('get', $bojemIsNewContactUrl);

        if ($res['status'] != 1) {
            send_msg_to_wecom($res['msg']);
        }
        return $res['result'];
    }
}
