<?php

namespace app\api\dao\http\webHook;

use app\api\util\HttpClient;
use Exception;
use think\Request;

/**
 * 外部链接
 *
 * Class WebHookHttpDao
 * @package app\api\dao\http\webHook
 */
class WebHookHttpDao
{
    use HttpClient;

    // 机器人web hook地址
    public const WEB_HOOK_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=a6964218-e837-4b31-aa35-5bd7bcf4dd64';
    // 小程序导流企微社群
    public const NOTICE_KO_CONTACT_EVENT_URL = 'https://ko.bojem.com/user/videoTask?union_id=%s';
    // 小程序导流企微社群
    // public const TEST_NOTICE_KO_CONTACT_EVENT_URL = 'http://kotest.bojem.com/user/videoTask?union_id=%s';

    /**
     * @var string 通知宝姐珠宝添加赵蔚的号为好友
     */
    public const NOTICE_BAOJIE_ADD_CONTACT_URL = 'https://baojie.bojem.com/api/SCRM/zhaowei?union_id=%s';

    /**
     * @var string 通知宝姐家进入"宝姐家珠宝捡漏"群
     */
    public const KO_NOTICE_JOIN_GROUP_URL = 'https://ko.bojem.com/seven/notify?union_id=%s';

    /**
     * @var string 获取风险等级
     */
    public const RISK_RANK_URL = 'https://ko.bojem.com/user/getRiskRank?union_id=%s';

    /**
     * @var string 获取购买数据
     */
    public const PURCHASE_DATA_URL = 'https://baojie.bojem.com/api/SCRM/order?m=%d';

    /**
     * @var string 传递朋友圈广告添加企微的用户给宝姐家
     */
    public const SEND_MOMENT_AD_UNION_ID_URL = 'https://ko.bojem.com/ad/addActV3?source=1&type=SCANCODE&click_id=%s';

    /**
     * @var string 朋友圈广告统计数据
     */
    public const GET_MOMENT_CONSUME_URL = 'https://ko.bojem.com/scrm/fly';

    /**
     * @var string 朋友圈周消费数据
     */
    public const GET_MOMENT_WEEK_CONSUME_URL =
        'https://erp-api.bojem.com/consul-analysis/visitInterface/getAdvertisePush';

    /**
     * @var string 朋友圈推广用户的订单表格数据
     */
    public const GET_MOMENT_EXCEL_CONSUME_URL =
        'https://erp-api.bojem.com/consul-analysis/visitInterface/getAdvertiseExcel';

    /**
     * @var string 加入分享员回调
     */
    public const JOIN_SHARER_URL =
        'https://baojie.bojem.com/api/recommender/createSharer';

    /**
     * @var string 加群增加购物金回调
     */
    public const JOIN_SHARE_GROUP_URL =
        'https://baojie.bojem.com/api/Recommender/addShareUserMoney';

    /**
     * 向群发送文本消息
     *
     * @param string $content      文本内容
     * @param array $mentionedList 提醒群中的指定成员
     * @return void
     * @throws Exception
     */
    public function sendTextMsg(string $content, array $mentionedList)
    {
        $params = [
            'msgtype' => 'text',
            'text' => [
                'content'        => $content,
                'mentioned_list' => $mentionedList
            ]
        ];

        self::sendRequest('post', self::WEB_HOOK_URL, ['json' => $params]);
    }

    /**
     * 添加指定企微员工后通知宝姐家
     *
     * @param string $unionId 微信用户的unionId
     * @return void
     * @throws Exception
     */
    public function noticeKoContactEvent(string $unionId)
    {
        $noticeKoContactEventUrl = sprintf(
            self::NOTICE_KO_CONTACT_EVENT_URL,
            $unionId
        );

        $res = self::sendRequest('get', $noticeKoContactEventUrl);


        /*$testNoticeKoContactEventUrl = sprintf(
            self::TEST_NOTICE_KO_CONTACT_EVENT_URL,
            $unionId
        );

        $testRes = self::sendRequest('get', $testNoticeKoContactEventUrl);

        Log::info($unionId . '-已向正式服ko发送好友信息-返回结果：' . json_encode($res, JSON_UNESCAPED_UNICODE));


        Log::info($unionId . '-已向测试服ko发送好友信息-返回结果：' . json_encode($testRes, JSON_UNESCAPED_UNICODE));*/

        /*send_msg_to_wecom(
            $unionId . '-已向正式服ko发送好友信息-返回结果：' . json_encode($res, JSON_UNESCAPED_UNICODE),
            ['chebin', 'yuqing']
        );

        send_msg_to_wecom(
            $unionId . '-已向测试服ko发送好友信息-返回结果：' . json_encode($testRes, JSON_UNESCAPED_UNICODE),
            ['chebin', 'yuqing']
        );*/
    }

    /**
     * 添加赵蔚的企微账号后通知宝姐珠宝
     *
     * @param string $unionId 微信用户的unionId
     * @return void
     * @throws Exception
     */
    public function noticeBaojieAddContact(string $unionId)
    {
        $noticeBaojieContactEventUrl = sprintf(
            self::NOTICE_BAOJIE_ADD_CONTACT_URL,
            $unionId
        );

        self::sendRequest('get', $noticeBaojieContactEventUrl);
    }

    /**
     * 通知宝姐家进入"宝姐家珠宝捡漏"群
     *
     * @param string $unionId 微信用户的unionId
     * @return void
     * @throws Exception
     */
    public function noticeKoJoinGroup(string $unionId)
    {
        $noticeKoJoinGroupUrl = sprintf(
            self::KO_NOTICE_JOIN_GROUP_URL,
            $unionId
        );

        self::sendRequest('get', $noticeKoJoinGroupUrl);
    }

    /**
     * 获取风险等级
     *
     * @param string $unionId 微信用户的unionId
     * @return array
     * @throws Exception
     */
    public function getRiskRank(string $unionId): array
    {
        $riskRankUrl = sprintf(
            self::RISK_RANK_URL,
            $unionId
        );

        return self::sendRequest('get', $riskRankUrl);
    }

    /**
     * 获取购买数据
     *
     * @param int $passMinutes
     * @return array
     * @throws Exception
     */
    public function getPurchaseData(int $passMinutes): array
    {
        $purchaseDataUrl = sprintf(
            self::PURCHASE_DATA_URL,
            $passMinutes
        );

        return self::sendRequest('get', $purchaseDataUrl);
    }

    /**
     * 写操作日志
     *
     * @param string $content 修改描述
     * @param string $ext 修改内容
     * @return array
     * @throws Exception
     */
    public function writeLog(string $content, string $ext): array
    {
        $logData = Request::instance()->log;

        $param = [
            'headers' => [
                'token' => $logData['token']
            ],
            'json' => [
                'module'     => $logData['module'],
                'controller' => $logData['controller'],
                'action'     => $logData['action'],
                'content'    => $content,
                'ext'        => $ext,
                'url'        => null
            ]
        ];

        return self::sendRequest('post', config('workweixin.log_url'), $param);
    }

    /**
     * 发送朋友圈广告企微用户给宝姐家
     *
     * @param string $unionId
     * @return void
     * @throws Exception
     */
    public function sendMomentUnionId(string $unionId)
    {
        $sendMomentAdUnionIdUrl = sprintf(
            self::SEND_MOMENT_AD_UNION_ID_URL,
            $unionId
        );

        self::sendRequest('get', $sendMomentAdUnionIdUrl);

        // Log::info(json_encode($res));
    }

    /**
     * 获取朋友圈广告客户消费数据
     *
     * @return array
     */
    public function getMomentConsumeData(): array
    {
        try {
            $res = self::sendRequest('get', self::GET_MOMENT_CONSUME_URL);
            return $res['data'];
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }
        return [];
    }

    /**
     * 获取朋友圈周消费数据
     *
     * @return array
     */
    public function getMomentWeekConsumeData(): array
    {
        try {
            $params = new \stdClass();

            $res = self::sendRequest('post', self::GET_MOMENT_WEEK_CONSUME_URL, ['json' => $params]);
            if ($res['returnCode'] != 200) {
                exception($res['returnMsg']);
            }
            return $res['returnData'][0];
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }
        return [];
    }


    /**
     * 获取朋友圈推广用户的订单表格数据
     *
     * @return array
     */
    public function getMomentExcelConsumeData(): array
    {
        try {
            $params = new \stdClass();
            $res = self::sendRequest('post', self::GET_MOMENT_EXCEL_CONSUME_URL, ['json' => $params]);

            if ($res['returnCode'] != 200) {
                exception($res['returnMsg']);
            }

            return $res['returnData'];
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }
        return [];
    }

    /**
     * 向群发送客服消息
     *
     * @param string $content      文本内容
     * @param array $mentionedList 提醒群中的指定成员
     * @return void
     * @throws Exception
     */
    public function sendKefuMsg(string $webHookUrl, string $content, array $mentionedList = [])
    {
        $params = [
            'msgtype' => 'text',
            'text' => [
                'content'        => $content,
                'mentioned_list' => $mentionedList
            ]
        ];
        try {
            self::sendRequest('post', $webHookUrl, ['json' => $params]);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }
    }

    /**
     * 加入分享员回调
     *
     * @param string $unionId
     * @return void
     * @throws Exception
     */
    public function joinSharerCallback(string $unionId)
    {
        $params = $queryParams = [
            'sharer' => $unionId
        ];
        $extParams = [
            'app_key' => 'scrm_service',
            'nonce'   => uniqid(),
            'expires' => 100 + time()
        ];

        $params = array_merge($params, $extParams);
        // 按照key进行排序
        ksort($params);

        $paramsToSign = http_build_query($params);

        $extParams['signature'] = substr(
            md5(base64_encode(hash_hmac('sha256', $paramsToSign, 'BMicahqu5thaiXRK', true))),
            5,
            10
        );

        $param = array_merge($queryParams, $extParams);

        $param = http_build_query($param);

        $url = self::JOIN_SHARER_URL . '?' . $param;

        $res = self::sendRequest('get', $url);

        // send_msg_to_wecom($unionId . '推荐官回调返回结果：' . json_encode($res));
    }

    /**
     * 加入分享员群回调
     *
     * @param string $unionId
     * @param int $groupId
     * @return void
     * @throws Exception
     */
    public function joinSharerGroupCallback(string $unionId, int $groupId)
    {
        $joinShareGroupUrl = sprintf(
            self::JOIN_SHARE_GROUP_URL,
            $unionId
        );

        $param = [
            'type'     => 12,
            'union_id' => $unionId,
            'group_id' => $groupId
        ];

        $res = self::sendRequest('post', $joinShareGroupUrl, $param);
        send_msg_to_wecom($unionId . '加入分享员群回调返回结果：' . json_encode($res));
    }
}
