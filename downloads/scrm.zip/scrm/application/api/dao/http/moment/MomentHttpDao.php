<?php

declare(strict_types=1);

namespace app\api\dao\http\moment;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * 客户朋友圈
 *
 * Class MomentHttpDao
 * @package app\api\dao\http\moment
 */
class MomentHttpDao extends BaseHttpDao
{
    use HttpClient;

    /**
     * @var string 创建发表任务
     */
    public const GET_ADD_MOMENT_TASK_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/add_moment_task?access_token=%s';

    /**
     * @var string 获取企业全部的发表列表
     */
    public const GET_MOMENT_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_moment_list?access_token=%s';

    /**
     * @var string 获取客户朋友圈企业发表的列表
     */
    public const GET_MOMENT_TASK_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_moment_task?access_token=%s';

    /**
     * @var string 获取客户朋友圈发表时选择的可见范围
     */
    public const SEND_GROUP_CHAT_MESSAGE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_moment_customer_list?access_token=%s';

    /**
     * @var string 获取客户朋友圈发表后的可见客户列表
     */
    public const GET_MOMENT_SEND_RESULT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_moment_send_result?access_token=%s';

    /**
     * @var string 获取客户朋友圈的互动数据
     */
    public const GET_MOMENT_COMMENTS_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_moment_comments?access_token=%s';

    /**
     * MomentHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 创建发表任务
     *
     * @param string $content 消息文本内容
     * @param array $attachments 附件，最多支持9个图片类型，或者1个视频，或者1个链接。类型只能三选一
     * @param array $userList 发表任务的执行者用户列表
     * @param array $tagList 可见到该朋友圈的客户标签列表
     * @param array $departmentList 发表任务的执行者部门列表
     * @return mixed
     * @throws Exception
     */
    public function addMomentTask(
        string $content,
        array $attachments,
        array $userList,
        array $tagList,
        array $departmentList = []
    ) {
        $getAddMomentTaskUrl = sprintf(
            self::GET_ADD_MOMENT_TASK_URL,
            $this->_token
        );

        $params = [
            'text' => [
                'content' => $content
            ],
            'attachments' => $attachments,
            'visible_range' => [
                'sender_list' => [
                    'user_list' => $userList,
                ]
            ]
        ];

        if ($departmentList) {
            $params['visible_range']['sender_list']['department_list'] = $departmentList;
        }

        if ($tagList) {
            $params['external_contact_list']['tag_list'] = $tagList;
        }
        // print_r($params);die;

        $res = self::sendRequest('post', $getAddMomentTaskUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['jobid'];
    }

    /**
     * 获取企业全部的发表列表
     *
     * @param int    $startTime  朋友圈记录开始时间
     * @param int    $endTime    朋友圈记录结束时间
     * @param string $creator    朋友圈创建人企业账号id
     * @param int    $filterType 朋友圈类型。0：企业发表 1：个人发表 2：所有，包括个人创建以及企业创建，默认情况下为所有类型
     * @param string $cursor     用于分页查询的游标，字符串类型，由上一次调用返回，首次调用可不填
     * @param int    $limit      返回的最大记录数，整型，最大值100，默认值100，超过最大值时取默认值
     * @return array
     * @throws Exception
     */
    public function getMomentList(
        int $startTime,
        int $endTime,
        string $creator = '',
        int $filterType = 2,
        string $cursor = '',
        int $limit = 10
    ): array {
        if ($endTime - $startTime > 2592000) {
            return ['error' => '朋友圈记录的起止时间间隔不能超过1个月'];
        }

        $getMomentListUrl = sprintf(
            self::GET_MOMENT_LIST_URL,
            $this->_token
        );

        $params = [
            'start_time'  => $startTime,
            'end_time'    => $endTime,
            'filter_type' => $filterType,
            'cursor'      => $cursor,
            'limit'       => $limit
        ];

        if ($creator) {
            $params['creator'] = $creator;
        }

        $res = self::sendRequest('post', $getMomentListUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'next_cursor' => $res['next_cursor'],
            'moment_list' => $res['moment_list']
        ];
    }
}
