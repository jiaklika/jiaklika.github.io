<?php


namespace app\api\dao\http\session;

use app\api\util\TokenManager;

/**
 * Class SessionContentsHttpDao
 * @package app\api\dao\http\session
 */
class SessionContentsHttpDao
{
    private static $_obj;

    private static $_privateKey;

    public function __construct()
    {
        try {
            self::$_obj = new \WxworkFinanceSdk(
                TokenManager::APP_ID,
                config('workweixin.session_secret'),
                [
                    "proxy_password" => "world",
                    "timeout"        => -2,
                ]
            );

            // 私钥地址
            self::$_privateKey = file_get_contents('private.pem');
        }catch(\WxworkFinanceSdkException $e) {
            var_dump($e->getMessage(), $e->getCode());
        }

    }

    /**
     * @param $seq
     * @param int $limit
     */
    public function getData(int $seq, int $limit = 1000)
    {
        $chats = json_decode(self::$_obj->getChatData($seq, $limit), true);

        foreach ($chats['chatdata'] as $val)
        {
            $decryptRandKey = null;
            openssl_private_decrypt(base64_decode($val['encrypt_random_key']), $decryptRandKey, self::$_privateKey, OPENSSL_PKCS1_PADDING);
            //$obj->downloadMedia($sdkFileId, "/tmp/download/文件新名称.后缀");
        }
    }

    private function _handleText()
    {
        // 存表
    }
}