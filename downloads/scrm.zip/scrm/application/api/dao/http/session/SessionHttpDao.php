<?php

declare(strict_types=1);

namespace app\api\dao\http\session;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * Class SessionHttpDao
 * @package app\api\dao\http\session
 */
class SessionHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取会话内容存档开启成员列表
    const GET_PERMIT_USER_LIST_URL = 'https://qyapi.weixin.qq.com/cgi-bin/msgaudit/get_permit_user_list?access_token=%s';
    // 获取会话同意情况
    const CHECK_SINGLE_AGREE_URL = 'https://qyapi.weixin.qq.com/cgi-bin/msgaudit/check_single_agree?access_token=%s';
    // 获取会话内容存档内部群信息
    const GET_GROUP_CHAT_URL = 'https://qyapi.weixin.qq.com/cgi-bin/msgaudit/groupchat/get?access_token=%s';

    /**
     * SessionHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::SESSION_INDEX);
    }

    /**
     * 获取会话内容存档开启成员列表
     *
     * @param int $type 拉取对应版本的开启成员列表。1表示办公版；2表示服务版；3表示企业版。非必填，不填写的时候返回全量成员列表。
     * @return array
     * @throws Exception
     */
    public function getPermitUserList(?int $type) : array
    {
        $getPermitUserListUrl = sprintf(
            self::GET_PERMIT_USER_LIST_URL,
            $this->_token
        );

        $params = $type !== null ? [
            'type' => $type
        ] : [];

        $res = self::sendRequest('post', $getPermitUserListUrl, ['json' => $params]);

        if ($res['errcode'] != 0)
            throw new Exception($res['errmsg']);

        return $res['ids'];
    }

    /**
     * 获取会话同意情况
     *
     * @param array $userArr 内部成员信息数组
     * @return array
     * @throws Exception
     */
    public function checkSingleAgree(array $userArr) : array
    {
        $checkSingleAgreeUrl = sprintf(
            self::CHECK_SINGLE_AGREE_URL,
            $this->_token
        );

        $params = [
            'info' => $userArr
        ];

        $res = self::sendRequest('post', $checkSingleAgreeUrl, ['json' => $params]);

        if ($res['errcode'] != 0)
            throw new Exception($res['errmsg']);

        return $res['agreeinfo'];
    }

    /**
     * 获取会话内容存档内部群信息
     *
     * @param string $roomId 待查询的群id
     * @return array
     * @throws Exception
     */
    public function getGroupChat(string $roomId) : array
    {
        $getGroupChatUrl = sprintf(
            self::GET_GROUP_CHAT_URL,
            $this->_token
        );

        $params = [
            'roomid' => $roomId
        ];

        $res = self::sendRequest('post', $getGroupChatUrl, ['json' => $params]);

        if ($res['errcode'] != 0)
            throw new Exception($res['errmsg']);

        return $res;
    }
}