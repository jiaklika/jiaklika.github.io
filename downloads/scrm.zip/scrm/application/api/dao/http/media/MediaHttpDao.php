<?php

declare(strict_types=1);

namespace app\api\dao\http\media;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Carbon\Carbon;
use Exception;

/**
 * 素材管理
 *
 * Class MediaHttpDao
 * @package app\api\dao\http\media
 */
class MediaHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 上传临时素材
    public const UPLOAD_MEDIA_URL = 'https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token=%s&type=%s';
    // 获取临时素材
    public const GET_MEDIA_URL = 'https://qyapi.weixin.qq.com/cgi-bin/media/get?access_token=%s&media_id=%s';
    // 上传图片
    public const UPLOAD_IMG_URL = 'https://qyapi.weixin.qq.com/cgi-bin/media/uploadimg?access_token=%s';
    // 上传附件资源
    public const UPLOAD_ATTACHMENT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/media/upload_attachment?access_token=%s&media_type=%s&attachment_type=%d';

    // 临时素材的媒体文件类型
    /**
     * @var string 图片
     */
    public const IMAGE = 'image';

    /**
     * @var string 语音
     */
    public const VOICE = 'voice';

    /**
     * @var string 视频
     */
    public const VIDEO = 'video';

    /**
     * @var string 普通文件
     */
    public const FILE = 'file';

    /**
     * @var int 图片最大2MB，2m=2097152b
     */
    public const IMAGE_MAX_SIZE = 2097152;

    /**
     * @var int 语音最大2MB，2m=2097152b
     */
    public const VOICE_MAX_SIZE = 2097152;

    /**
     * @var int 视频最大10MB
     */
    public const VIDEO_MAX_SIZE = 10485760;

    /**
     * @var int 普通文件最大20MB
     */
    public const FILE_MAX_SIZE = 20971520;

    /**
     * @var array 永久图片支持格式
     */
    public const IMAGE_TYPE = ['jpg','png','gif','jpeg'];

    /**
     * @var array 朋友圈上传附件资源支持格式
     */
    public const VIDEO_TYPE = ['mp4'];

    /**
     * @var array 文件类型映射
     */
    public const FILE_TYPE_MAP = [
        self::IMAGE => ['jpg', 'png'],
        self::VOICE => ['amr'],
        self::VIDEO => ['mp4'],
        self::FILE  => ['pdf', 'doc', 'xlsx', 'xls', 'csv'],
    ];

    /**
     * @var array 文件大小映射
     */
    public const FILE_SIZE_MAP = [
        self::IMAGE => self::IMAGE_MAX_SIZE,
        self::VOICE => self::VOICE_MAX_SIZE,
        self::VIDEO => self::VIDEO_MAX_SIZE,
        self::FILE  => self::FILE_MAX_SIZE
    ];

    /**
     * @var int 临时素材主动过期时间，3天-半小时
     */
    public const MEDIA_EXPIRE_TIME = 257400;

    /**
     * MediaHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::APP_INDEX);
    }

    /**
     * 上传临时素材，三天内有效
     *
     * @param string $type 媒体文件类型
     * @param string $filePath 文件路径
     * @param string $fileName 文件名
     * @return array
     * @throws Exception
     */
    public function uploadMedia(string $type, string $filePath, string $fileName): array
    {
        $uploadMediaUrl = sprintf(
            self::UPLOAD_MEDIA_URL,
            $this->_token,
            $type
        );

        $params = [
            'multipart' => [
                [
                    'name'         => 'media',
                    'filename'     => date('Y') . '-' . $fileName,
                    'contents'     => fopen($filePath, 'r')
                ],
            ],
        ];

        $res = self::sendRequest('post', $uploadMediaUrl, $params);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'type'       => $res['type'],
            'media_id'   => $res['media_id'],
            'created_at' => (int)$res['created_at']
        ];
    }

    /**
     * 下载临时素材到本地
     *
     * @param string $mediaId 媒体文件id
     * @param string $saveName 文件名
     * @return string
     * @throws Exception
     */
    public function downloadMedia(string $mediaId, string $saveName = ''): string
    {
        $getMediaUrl = sprintf(
            self::GET_MEDIA_URL,
            $this->_token,
            $mediaId
        );

        try {
            return self::downloadRemoteFileToLocal($getMediaUrl, $saveName);
        } catch (Exception $e) {
            send_msg_to_wecom('下载临时素材到本地出错：' . $e->getMessage());
        }

        return '';
    }

    /**
     * 上传图片得到图片URL，该URL永久有效
     *
     * @param string $filePath 文件路径
     * @param string $fileName 文件名称
     * @return array
     * @throws Exception
     */
    public function uploadImg(string $filePath, string $fileName): array
    {
        $uploadImgUrl = sprintf(
            self::UPLOAD_IMG_URL,
            $this->_token
        );

        $params = [
            'multipart' => [
                [
                    'name'     => 'media',
                    'filename' => date('Y') . '-' . $fileName,
                    'contents' => fopen($filePath, 'r')
                ],
            ]
        ];
        $res = self::sendRequest('post', $uploadImgUrl, $params);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'url' => $res['url']
        ];
    }

    /**
     * 上传附件资源
     *
     * @param string $filePath 文件路径
     * @param string $fileType 媒体文件类型，分别有图片（image）、视频（video）、普通文件（file）
     * @param string $fileName
     * @param int $attachmentType 附件类型，不同的附件类型用于不同的场景。1：朋友圈；2:商品图册
     * @return array
     * @throws Exception
     */
    public function uploadAttachment(
        string $filePath,
        string $fileType,
        string $fileName,
        int $attachmentType = 1
    ): array {
        $uploadAttachmentUrl = sprintf(
            self::UPLOAD_ATTACHMENT_URL,
            $this->_token,
            $fileType,
            $attachmentType
        );

        $params = [
            'multipart' => [
                [
                    'name'     => 'media',
                    'filename' => date('Y') . '-' . $fileName,
                    'contents' => fopen($filePath, 'r')
                ],
            ]
        ];

        $res = self::sendRequest('post', $uploadAttachmentUrl, $params);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res;
    }
}
