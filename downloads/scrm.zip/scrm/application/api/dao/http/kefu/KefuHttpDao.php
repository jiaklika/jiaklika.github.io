<?php

namespace app\api\dao\http\kefu;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * 微信客服
 *
 * Class KefuHttpDao
 * @package app\api\dao\http\kefu
 */
class KefuHttpDao extends BaseHttpDao
{
    use HttpClient;

    /**
     * @var string 添加客服账号
     */
    public const ADD_KEFU_ACCOUNT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/account/add?access_token=%s';

    /**
     * @var string 删除客服账号
     */
    public const DEL_KEFU_ACCOUNT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/account/del?access_token=%s';

    /**
     * @var string 修改客服账号
     */
    public const UPDATE_KEFU_ACCOUNT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/account/update?access_token=%s';

    /**
     * @var string 获取客服账号列表
     */
    public const GET_KEFU_ACCOUNT_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/account/list?access_token=%s';

    /**
     * @var string 获取客服账号链接
     */
    public const GET_KEFU_ADD_CONTACT_WAY_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/add_contact_way?access_token=%s';

    /**
     * @var string 添加接待人员
     */
    public const ADD_KEFU_SERVICER_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/servicer/add?access_token=%s';

    /**
     * @var string 删除接待人员
     */
    public const DEL_KEFU_SERVICER_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/servicer/del?access_token=%s';

    /**
     * @var string 获取接待人员列表
     */
    public const GET_KEFU_SERVICER_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/servicer/list?access_token=%s&open_kfid=%s';

    /**
     * @var string 读取消息
     */
    public const GET_SYNC_MSG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/sync_msg?access_token=%s';

    /**
     * @var string 发送消息
     */
    public const GET_SEND_MSG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/send_msg?access_token=%s';

    /**
     * @var string 发送欢迎语等事件响应消息
     */
    public const GET_SEND_MSG_ON_EVENT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/send_msg_on_event?access_token=%s';

    /**
     * @var string 获取会话状态
     */
    public const GET_SERVICE_STATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/service_state/get?access_token=%s';

    /**
     * @var string 变更会话状态
     */
    public const TRANS_SERVICE_STATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/service_state/trans?access_token=%s';

    /**
     * @var string 获取客户基础信息
     */
    public const GET_CUSTOMER_INFO_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/kf/customer/batchget?access_token=%s';

    /**
     * KefuHttpDao constructor.
     *
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::KEFU_INDEX);
    }

    /**
     * 添加客服账号
     *
     * @param string $name 客服名称
     * @param string $mediaId 客服头像临时素材
     * @return string 新创建的客服账号ID
     * @throws Exception
     */
    public function addKefuAccount(string $name, string $mediaId): string
    {
        $addKefuAccountUrl = sprintf(
            self::ADD_KEFU_ACCOUNT_URL,
            $this->_token
        );

        $param = [
            'name'     => $name,
            'media_id' => $mediaId,
        ];

        $res = self::sendRequest('post', $addKefuAccountUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['open_kfid'] ?? '';
    }

    /**
     * 删除客服账号
     *
     * @param string $openKfId 客服账号ID
     * @return bool
     * @throws Exception
     */
    public function delKefuAccount(string $openKfId): bool
    {
        $delKefuAccountUrl = sprintf(
            self::DEL_KEFU_ACCOUNT_URL,
            $this->_token
        );

        $param = [
            'open_kfid' => $openKfId
        ];

        $res = self::sendRequest('post', $delKefuAccountUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }

    /**
     * 修改客服账号
     *
     * @param string $openKfId 客服账号ID
     * @param string $name 新的客服名称，如不需要修改可不填。
     * @param string $mediaId 新的客服头像临时素材，如不需要修改可不填。
     * @return bool
     * @throws Exception
     */
    public function updateKefuAccount(string $openKfId, string $name = '', string $mediaId = ''): bool
    {
        $updateKefuAccountUrl = sprintf(
            self::UPDATE_KEFU_ACCOUNT_URL,
            $this->_token
        );

        $param = [
            'open_kfid' => $openKfId,
        ];
        if ($name) {
            $param['name'] = $name;
        }
        if ($mediaId) {
            $param['media_id'] = $mediaId;
        }

        $res = self::sendRequest('post', $updateKefuAccountUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['errcode'] == 0;
    }

    /**
     * 获取客服账号列表
     *
     * @return array 账号信息列表
     * @throws Exception
     */
    public function getKefuAccountList(): array
    {
        $getKefuAccountListUrl = sprintf(
            self::GET_KEFU_ACCOUNT_LIST_URL,
            $this->_token
        );

        $res = self::sendRequest('get', $getKefuAccountListUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['account_list'] ?? [];
    }

    /**
     * 获取客服账号链接
     *
     * @param string $openKfId 客服账号ID
     * @param string $scene 场景值，字符串类型，由开发者自定义。
     * @return string 账号信息列表
     * @throws Exception
     */
    public function getKefuAddContactWay(string $openKfId, string $scene): string
    {
        $getKefuAddContactWayUrl = sprintf(
            self::GET_KEFU_ADD_CONTACT_WAY_URL,
            $this->_token
        );

        $param = [
            'open_kfid' => $openKfId,
            'scene'     => $scene,
        ];

        $res = self::sendRequest('post', $getKefuAddContactWayUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['url'] ?? '';
    }

    /**
     * 添加接待人员
     *
     * @param string $openKfId 客服帐号ID
     * @param array $userIdList 接待人员userid列表
     * @return array
     * @throws Exception
     */
    public function addKefuServicer(string $openKfId, array $userIdList): array
    {
        $addKefuServicerUrl = sprintf(
            self::ADD_KEFU_SERVICER_URL,
            $this->_token
        );

        $param = [
            'open_kfid'   => $openKfId,
            'userid_list' => array_values($userIdList),
        ];

        $res = self::sendRequest('post', $addKefuServicerUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['result_list'] ?? [];
    }

    /**
     * 删除接待人员
     *
     * @param string $openKfId 客服帐号ID
     * @param array $userIdList 接待人员userid列表
     * @return array
     * @throws Exception
     */
    public function delKefuServicer(string $openKfId, array $userIdList): array
    {
        $delKefuServicerUrl = sprintf(
            self::DEL_KEFU_SERVICER_URL,
            $this->_token
        );

        $param = [
            'open_kfid'   => $openKfId,
            'userid_list' => $userIdList,
        ];

        $res = self::sendRequest('post', $delKefuServicerUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['result_list'] ?? [];
    }

    /**
     * 获取接待人员列表
     *
     * @return array 账号信息列表
     * @throws Exception
     */
    public function getKefuServicerList(string $openKfId): array
    {
        $getKefuServicerListUrl = sprintf(
            self::GET_KEFU_SERVICER_LIST_URL,
            $this->_token,
            $openKfId
        );

        $res = self::sendRequest('get', $getKefuServicerListUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['servicer_list'] ?? [];
    }

    /**
     * 读取消息
     *
     * 当微信客户、接待人员发消息或有行为动作时，企业微信后台会将事件的回调数据包发送到企业指定URL；企业收到请求后，再通过读取消息接口主动读取具体的消息内容。
     *
     * @param string $token 回调事件返回的token字段，10分钟内有效
     * @param string $cursor 上一次调用时返回的next_cursor
     * @param int $limit
     * @return array
     * @throws Exception
     */
    public function getSyncMsg(string $token = '', string $cursor = '', int $limit = 1): array
    {
        $syncMsgUrl = sprintf(
            self::GET_SYNC_MSG_URL,
            $this->_token
        );

        $param = [
            'cursor' => $cursor,
            'token'  => $token,
            'limit'  => $limit
        ];

        $res = self::sendRequest('post', $syncMsgUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res;
    }

    /**
     * 发送消息
     *
     * @param string $toUser
     * @param string $openKfId
     * @param string $msgType
     * @param array $msgContent
     * @return string
     * @throws Exception
     */
    public function sendMsg(string $toUser, string $openKfId, string $msgType, array $msgContent): string
    {
        $sendMsgUrl = sprintf(
            self::GET_SEND_MSG_URL,
            $this->_token
        );

        $param = [
            'touser'    => $toUser,
            'open_kfid' => $openKfId,
            'msgtype'   => $msgType,
            $msgType    => $msgContent
        ];

        $res = self::sendRequest('post', $sendMsgUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception(
                sprintf(
                    "发送消息异常！原因：%s，接收者：%s，账号：%s",
                    $res['errmsg'],
                    $toUser,
                    $openKfId
                )
            );
        }

        return $res['msgid'];
    }

    /**
     * 发送消息
     *
     * @param string $code
     * @param string $msgType
     * @param array $msgContent
     * @return string
     * @throws Exception
     */
    public function sendMsgOnEvent(string $code, string $msgType, array $msgContent): string
    {
        $sendMsgOnEventUrl = sprintf(
            self::GET_SEND_MSG_ON_EVENT_URL,
            $this->_token
        );

        $param = [
            'code'    => $code,
            'msgtype' => $msgType,
            $msgType  => $msgContent
        ];

        $res = self::sendRequest('post', $sendMsgOnEventUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['msgid'];
    }

    /**
     * 获取会话状态
     *
     * @param string $openKfId 客服账号ID
     * @param string $externalUserId 微信客户的external_userid
     * @return array
     * @throws Exception
     */
    public function getServiceState(string $openKfId, string $externalUserId): array
    {
        $getServiceStateUrl = sprintf(
            self::GET_SERVICE_STATE_URL,
            $this->_token
        );

        $param = [
            'open_kfid'       => $openKfId,
            'external_userid' => $externalUserId,
        ];

        $res = self::sendRequest('post', $getServiceStateUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'service_state'   => $res['service_state'],
            'servicer_userid' => $res['servicer_userid'] ?? ''
        ];
    }

    /**
     * 变更会话状态
     *
     * @param string $openKfId 客服账号ID
     * @param string $externalUserId 微信客户的external_userid
     * @param int $serviceState 变更的目标状态
     * @param string $servicerUserId 接待人员的userid
     * @return string
     * @throws Exception
     */
    public function transServiceState(
        string $openKfId,
        string $externalUserId,
        int $serviceState,
        string $servicerUserId = ''
    ): string {
        $transServiceStateUrl = sprintf(
            self::TRANS_SERVICE_STATE_URL,
            $this->_token
        );

        $param = [
            'open_kfid'       => $openKfId,
            'external_userid' => $externalUserId,
            'service_state'   => $serviceState
        ];

        if ($serviceState == 3) {
            $param['servicer_userid'] = $servicerUserId;
        }

        $res = self::sendRequest('post', $transServiceStateUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception(
                sprintf(
                    '客服账号：%s，客户：%s，状态：%s，客服：%s，异常：%s',
                    $openKfId,
                    $externalUserId,
                    $serviceState,
                    $servicerUserId,
                    $res['errmsg']
                )
            );
        }

        return $res['msg_code'] ?? '';
    }

    /**
     * 获取客户基础信息
     *
     * @param array $externalUserIdArr external_userid列表
     * @return array
     * @throws Exception
     */
    public function getCustomerInfo(array $externalUserIdArr): array
    {
        $getCustomerInfoUrl = sprintf(
            self::GET_CUSTOMER_INFO_URL,
            $this->_token
        );

        $param = [
            'external_userid_list' => $externalUserIdArr
        ];

        $res = self::sendRequest('post', $getCustomerInfoUrl, ['json' => $param]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }
        if ($res['invalid_external_userid']) {
            send_msg_to_wecom('获取客户基础信息失败！' . json_encode($res['invalid_external_userid']));
        }

        return $res['customer_list'];
    }
}
