<?php

declare(strict_types=1);

namespace app\api\dao\http;

use app\api\util\TokenManager;
use Exception;

/**
 * Class BaseHttpDao
 * @package app\api\dao\http
 */
class BaseHttpDao
{
    /**
     * @var string
     */
    protected $_token;

    /**
     * BaseHttpDao constructor.
     *
     * @param int $tokenType
     * @throws Exception
     */
    public function __construct(int $tokenType)
    {
        $this->_token = TokenManager::getAccessToken($tokenType);
    }
}