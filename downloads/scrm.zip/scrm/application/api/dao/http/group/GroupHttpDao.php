<?php

namespace app\api\dao\http\group;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;

/**
 * Class GroupHttpDao
 * @package app\api\dao\http\group
 */
class GroupHttpDao extends BaseHttpDao
{
    use HttpClient;
}
