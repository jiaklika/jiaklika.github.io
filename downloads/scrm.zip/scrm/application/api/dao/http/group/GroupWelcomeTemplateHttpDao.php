<?php

namespace app\api\dao\http\group;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;
use think\Log;

/**
 * 入群欢迎语素材管理
 *
 * Class GroupWelcomeTemplateHttpDao
 * @package app\api\dao\http\group
 */
class GroupWelcomeTemplateHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 添加入群欢迎语素材
    public const ADD_GROUP_WELCOME_TEMPLATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/group_welcome_template/add?access_token=%s';
    // 编辑入群欢迎语素材
    public const EDIT_GROUP_WELCOME_TEMPLATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/group_welcome_template/edit?access_token=%s';
    // 获取入群欢迎语素材
    public const GET_GROUP_WELCOME_TEMPLATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/group_welcome_template/get?access_token=%s';
    // 删除入群欢迎语素材
    public const DELETE_GROUP_WELCOME_TEMPLATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/group_welcome_template/del?access_token=%s';

    /**
     * GroupWelcomeTemplateHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 添加入群欢迎语素材
     *
     * @param string $textContent 消息文本内容
     * @param array $attachments  附件
     * @return bool
     * @throws Exception
     */
    public function addGroupWelcomeTemplate(
        string $textContent = '',
        array $attachments = []
    ): bool {
        if (!trim($textContent) && !$attachments) {
            throw new Exception('文本和附件不能同时为空');
        }

        $addGroupWelcomeTemplateUrl = sprintf(
            self::ADD_GROUP_WELCOME_TEMPLATE_URL,
            $this->_token
        );

        if ($textContent) {
            $params['text'] = ['content' => $textContent];
        }

        if ($attachments) {
            $params['miniprogram'] = $attachments;
        }
        $params['notify'] = 0;

        $res = self::sendRequest('post', $addGroupWelcomeTemplateUrl, ['json' => $params]);

        Log::info(json_encode($res, JSON_UNESCAPED_UNICODE));

        if ($res['errcode'] != 0 && $res['errcode'] != 41051) {
            throw new Exception($res['errmsg']);
        }
        return true;
    }

    /**
     * 编辑入群欢迎语素材
     *
     * @param string $templateId 欢迎语素材id
     * @param string $textContent 消息文本内容
     * @param array $attachments 附件
     * @return bool
     * @throws Exception
     */
    public function editGroupWelcomeTemplate(
        string $templateId,
        string $textContent = '',
        array $attachments = []
    ): bool {
        if (!trim($textContent) && !$attachments) {
            throw new Exception('文本和附件不能同时为空');
        }

        $editGroupWelcomeTemplateUrl = sprintf(
            self::EDIT_GROUP_WELCOME_TEMPLATE_URL,
            $this->_token
        );

        $params['template_id'] = $templateId;

        if ($textContent) {
            $params['text'] = ['content' => $textContent];
        }

        if ($attachments) {
            $params['miniprogram'] = $attachments;
        }
        $params['notify'] = 0;

        $res = self::sendRequest('post', $editGroupWelcomeTemplateUrl, ['json' => $params]);

        Log::info(json_encode($res, JSON_UNESCAPED_UNICODE));

        if ($res['errcode'] != 0 && $res['errcode'] != 41051) {
            throw new Exception($res['errmsg']);
        }
        return true;
    }
}