<?php

declare(strict_types=1);

namespace app\api\dao\http\living;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * Class LivingHttpDao
 * @package app\api\dao\http\living
 */
class LivingHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取成员直播ID列表
    public const GET_USER_LIVING_ID_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/living/get_user_livingid?access_token=%s';
    // 获取直播详情
    public const GET_LIVING_INFO_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/living/get_living_info?access_token=%s&livingid=%s';
    // 获取看直播统计
    public const GET_WATCH_STAT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/living/get_watch_stat?access_token=%s';

    /**
     * LivingHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::LIVE_INDEX);
    }

    /**
     * 获取成员直播ID列表
     *
     * @param string $userId    企业成员的userId
     * @param int    $beginTime 开始时间，最长只能拉取180天前数据。只能取到2020-04-23日后数据
     * @param int    $endTime   结束时间，时间跨度不超过180天
     * @param string $nextKey   上一次调用时返回的next_key，初次调用可以填”0”
     * @param int    $limit     每次拉取的数据量，默认值和最大值都为100
     * @return array
     * @throws Exception
     */
    public function getUserLivingId(
        string $userId,
        int $beginTime,
        int $endTime,
        string $nextKey = "0",
        int $limit = 100
    ): array {
        $getUserLivingIdUrl = sprintf(
            self::GET_USER_LIVING_ID_URL,
            $this->_token
        );

        $params = [
            'userid'     => $userId,
            'begin_time' => $beginTime,
            'end_time'   => $endTime,
            'next_key'   => $nextKey,
            'limit'      => $limit,
        ];

        $res = self::sendRequest('post', $getUserLivingIdUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'ending'        => $res['ending'],
            'next_key'      => $res['next_key'] ?? '',
            'livingid_list' => $res['livingid_list']
        ];
    }

    /**
     * 获取直播详情
     *
     * @param string $livingId 直播ID
     * @return array
     * @throws Exception
     */
    public function getLivingInfo(string $livingId): array
    {
        $getLivingInfoUrl = sprintf(
            self::GET_LIVING_INFO_URL,
            $this->_token,
            $livingId
        );

        $res = self::sendRequest('get', $getLivingInfoUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['living_info'];
    }

    /**
     * 获取看直播统计
     *
     * @param string $livingId 直播的id
     * @param string $nextKey  上一次调用时返回的next_key，初次调用可以填”0”
     * @return array
     * @throws Exception
     */
    public function getWatchStat(string $livingId, string $nextKey = "0"): array
    {
        $getWatchStatUrl = sprintf(
            self::GET_WATCH_STAT_URL,
            $this->_token
        );

        $params = [
            'livingid' => $livingId,
            'next_key' => $nextKey,
        ];

        $res = self::sendRequest('post', $getWatchStatUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'ending'    => $res['ending'],
            'next_key'  => $res['next_key'] ?? '',
            'stat_info' => $res['stat_info']
        ];
    }
}
