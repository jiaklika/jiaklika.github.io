<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\exception\NotContactException;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;
use think\Cache;
use think\Log;

/**
 * 客户资料
 *
 * Class ContactHttpDao
 * @package app\api\dao\http\contact
 */
class ContactHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取配置了客户联系功能的成员列表
    public const GET_FOLLOW_USER_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_follow_user_list?access_token=%s';
    // 获取客户列表
    public const CONTACT_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/list?access_token=%s&userid=%s';
    // 获取客户详情
    public const CONTACT_DETAIL_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get?access_token=%s&external_userid=%s';
    // 获取联系客户统计数据
    public const GET_USER_BEHAVIOR_DATA_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_user_behavior_data?access_token=%s';
    // 发送新客户欢迎语
    public const SEND_WELCOME_MSG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/send_welcome_msg?access_token=%s';

    // 内部系统接口
    // 获取珠宝的订单数据
    public const GET_MEDIA_ORDER_URL = 'https://baojie.bojem.com/api/order/getMediaOrder?unionId=%s';
    // 获取珠宝的用户地址
    public const GET_USER_ADDRESS_URL = 'https://baojie.bojem.com/api/user/getUserAddrByUniOnId?unionId=%s';
    // 获取媒体的用户地址
    public const GET_ADDRESS_FROM_KO_URL = 'http://ko.bojem.com/user/getWXAddress?union_id=%s';
    // 获取珠宝的用户来源
    public const GET_FROM_INFO_URL = 'https://baojie.bojem.com/api/order/getShopFrom';
    // 获取ERP的用户当前消费区间段
    public const GET_ERP_CONTACT_CONSUME_SEGMENT = 'https://erp-api.bojem.com/consul-analysis/userTag/userContractTag';
    // 获取ERP的用户当前消费区间段
    public const GET_CONSUME_INFO = 'https://baojie.bojem.com/api/SCRM/consume?union_id=%s';
    // 更新用户中心的用户信息
    public const ADD_USER_CENTER_DATA_URL = 'https://ucenter.bojem.com/userCenter/user/returnUserInfo';
    /**
     * @var string 首次关注公众号和授权小程序的时间
     */
    public const FIRST_AUTHORIZE_URL = 'https://ko.bojem.com/scrm/userInfo?union_id=%s';

    // 微信详情redis前缀
    public const REDIS_WEIXIN_DETAIL_PREFIX = 'weixin:detail:%s';
    // 微信详情缓存时间
    public const DETAIL_EXPIRE_TIME = 86400;

    /**
     * @var array 消费区间段数组
     */
    public const PRICE_SEGMENT_ARR = [
        '0',
        '(0,100]',
        '(100,500]',
        '(500,1k]',
        '(1k,3k]',
        '(3k,5k]',
        '(5k,1w]',
        '(1w,3w]',
        '(3w,5w]',
        '(5w,10w]',
        '(10w,30w]',
        '(30w,50w]',
        '(50w,100w]',
        '(100w,300w]',
        '(300w,500w]',
        '(500w,1000w]',
        '(1000w,+∞)'
    ];

    /**
     * ContactHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 获取客户列表
     *
     * @param string $internalUserId 企业成员的userid
     * @return array
     * @throws Exception
     */
    public function getContactList(string $internalUserId): array
    {
        $listUrl = sprintf(
            self::CONTACT_LIST_URL,
            $this->_token,
            $internalUserId
        );

        $res = self::sendRequest('get', $listUrl);

        // 有外部联系人的权限，但是没有一个外部联系人
        if ($res['errcode'] == 84061) {
            return [];
        }

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['external_userid'];
    }

    /**
     * 获取客户详情
     *
     * @param string $externalContactUserId 外部联系人的userId
     * @param bool $getFromCache            是否从缓存获取，默认是
     * @return array
     * @throws Exception
     */
    public function getContactDetail(string $externalContactUserId, bool $getFromCache = true): array
    {
        $detailCache = '';
        if ($getFromCache) {
            $detailCache = sprintf(self::REDIS_WEIXIN_DETAIL_PREFIX, $externalContactUserId);

            if ($detailInfo = Cache::get($detailCache)) {
                return ['external_contact' => $detailInfo];
            }
        }

        $detailUrl = sprintf(
            self::CONTACT_DETAIL_URL,
            $this->_token,
            $externalContactUserId
        );

        $res = self::sendRequest('get', $detailUrl);

        if ($res['errcode'] == 84061) {
            throw new NotContactException($externalContactUserId . '-not external contact');
        }

        if ($res['errcode'] != 0 && $res['errcode'] != 84061) {
            throw new Exception($externalContactUserId . '-getContactDetail出错：' . $res['errmsg']);
        }

        if ($getFromCache && $detailCache) {
            Cache::set($detailCache, $res['external_contact'], self::DETAIL_EXPIRE_TIME);
        }

        return [
            'external_contact' => $res['external_contact'],
            'follow_user'      => $res['follow_user']
        ];
    }

    /**
     * 颜值数据
     *
     * @param string|null $unionId
     * @return array
     * @throws Exception
     */
    public function getYanzhi(?string $unionId): array
    {
        $userInfoUrl = sprintf(
            config('workweixin.yanzhi_url'),
            $unionId
        );

        $res = self::sendRequest('get', $userInfoUrl);

        if ($res['code'] != '0000') {
            throw new Exception($res['msg'] ??  '错误代码：' . $res['code']);
        }

        return [
            'yanzhi_total' => $res['data']['yanzhi_total'] ?? 0,
            'last_login'   => $res['data']['last_login'] ?? 0
        ];
    }

    /**
     * 直播等级
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getLiveRank(string $unionId): array
    {
        $liveRankUrl = sprintf(
            config('workweixin.liverank_url'),
            $unionId
        );

        $res = self::sendRequest('get', $liveRankUrl);

        if ($res['code'] != 0) {
            throw new Exception($res['msg'] ?? '错误代码：' . $res['code']);
        }

        return [
            'level'      => $res['data']['level'] ?? '暂无',
            'last_login' => $res['data']['lastLoginTime'] ?? 0
        ];
    }

    /**
     * 用户中心
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getUserCenter(string $unionId): array
    {
        if (empty($unionId)) {
            return [];
        }

        $params = [
            'json' => [
                'union_id' => $unionId
            ]
        ];

        $res = self::sendRequest('post', config('workweixin.usercenter_url'), $params);

        if ($res['code'] != 0 && $res['code'] != 20001) {
            throw new Exception(
                isset($res['msg'])
                ? 'getUserCenter-' . $unionId . $res['msg']
                : '错误代码：' . $res['code']
            );
        }

        return $res['data'] ?? [];
    }


    /**
     * 通过手机号获取用户unionId
     *
     * @param string $mobile
     * @return array
     * @throws Exception
     */
    public function getUserCenterByMobile(string $mobile): array
    {
        if (empty($mobile)) {
            return [];
        }

        $params = [
            'json' => [
                'mobile' => $mobile
            ]
        ];

        $res = self::sendRequest('post', config('workweixin.usercenter_url'), $params);

        if ($res['code'] != 0 && $res['code'] != 20001) {
            throw new Exception(
                isset($res['msg'])
                    ? 'getUserCenterByMobile-' . $mobile . $res['msg']
                : '错误代码：' . $res['code']
            );
        }

        return $res['data'] ?? [];
    }

    /**
     * 获取app端最后登录时间
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getAppLastLoginTime(string $unionId): array
    {
        $homeUrl = sprintf(
            config('workweixin.home_url'),
            $unionId
        );

        $res = self::sendRequest('get', $homeUrl);

        if ($res['code'] != 0) {
            throw new Exception($res['msg'] ?? '错误代码：' . $res['code']);
        }

        return [
            'app_last_login' => $res['data'] ?? 0
        ];
    }

    /**
     * 获取JS-SDK相关数据
     *
     * @param string $url
     * @return array
     * @throws Exception
     */
    public function verifyAuth(string $url): array
    {
        [
            $nonceStr,   // 随机字符串
            $timestamp,  // 时间戳
        ] = [
            getRandomStr(16),
            time()
        ];

        return [
            'appId'            => TokenManager::APP_ID,
            'config_noncestr'  => $nonceStr,
            'config_timestamp' => $timestamp,
            'config_signature' => TokenManager::getSignature($nonceStr, $timestamp, $url),
            'agent_noncestr'   => $nonceStr,
            'agent_timestamp'  => $timestamp,
            'agent_signature'  => TokenManager::getSignature($nonceStr, $timestamp, $url, 2),
            'agent_id'         => config('workweixin.agent_id')
        ];
    }

    /**
     * 获取联系客户统计数据
     *
     * @param array $userId     成员ID列表
     * @param array $partyId    部门ID列表
     * @param string $startTime 数据起始时间
     * @param string $endTime   数据结束时间
     * @return array
     * @throws Exception
     */
    public function getUserBehaviorData(
        array $userId,
        array $partyId,
        string $startTime,
        string $endTime
    ): array {

        $allData = $insertData = [];

        // 只能获取过去180天的，每30天为一个范围区间
        for ($i = 1; $i < 181; $i += 30) {
            $params = [
                'json' => [
                    'userid'     => $userId,
                    'start_time' => strtotime(sprintf("-%s days", (int)($i + 29))),
                    'end_time'   => strtotime(sprintf("-%s days", $i))
                ]
            ];
        }

        if ($allData) {
            $insertData = array_filter($allData, function ($val) {
                return ($val['chat_cnt'] != 0
                    || $val['message_cnt'] != 0
                    || $val['negative_feedback_cnt'] != 0
                    || $val['new_apply_cnt'] != 0
                    || $val['new_contact_cnt'] != 0);
            });

            array_walk($insertData, function (&$val) use ($userId) {
                $val['user_id'] = $userId;
            });
        }

        return array_reduce($insertData, function ($carry, $item) {
            $newContactCarry =  $carry['new_contact_cnt'] + $item['new_contact_cnt'];
            $negativeFeedbackCarry = $carry['negative_feedback_cnt']  + $item['negative_feedback_cnt'];
            return [
                'new_contact_cnt' => $newContactCarry,
                'negative_feedback_cnt' => $negativeFeedbackCarry
            ];
        }, ['new_contact_cnt' => 0, 'negative_feedback_cnt' => 0]);
    }

    /**
     * 发送新客户欢迎语
     *
     * @param string $welcomeCode 通过添加外部联系人事件推送给企业的发送欢迎语的凭证
     * @param string $textContent 消息文本内容
     * @param array $attachments  附件，最多可添加9个附件
     * @return void
     * @throws Exception
     */
    public function sendWelcomeMsgToContact(
        string $welcomeCode,
        string $textContent = '',
        array $attachments = []
    ): void {
        if (!trim($textContent) && !$attachments) {
            throw new Exception('文本和附件不能同时为空');
        }

        $sendWelcomeMsgUrl = sprintf(
            self::SEND_WELCOME_MSG_URL,
            $this->_token
        );

        $params = [
            'welcome_code' => $welcomeCode,
        ];

        if ($textContent) {
            $params['text'] = ['content' => $textContent];
        }

        if ($attachments) {
            $params['attachments'] = $attachments;
        }

        $res = self::sendRequest('post', $sendWelcomeMsgUrl, ['json' => $params]);

        // Log::info(json_encode($res, JSON_UNESCAPED_UNICODE));

        if ($res['errcode'] != 0 && $res['errcode'] != 41051) {
            throw new Exception($res['errmsg']);
        }
    }

    /**
     * 获取配置了客户联系功能的成员列表
     *
     * @return array
     * @throws Exception
     */
    public function getFollowUserList(): array
    {
        $getFollowUserListUrl = sprintf(
            self::GET_FOLLOW_USER_LIST_URL,
            $this->_token
        );

        $res = self::sendRequest('get', $getFollowUserListUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['follow_user'];
    }

    /**
     * 根据unionId获取订单数据
     *
     * @param string $unionId 客户唯一标识
     * @param int $searchBeginTime 搜索开始时间
     * @param int $searchEndTime 搜索结束时间
     * @param int $orderPlatform 订单归属 0-珠宝 1-用户运营中心
     * @return array
     * @throws Exception
     */
    public function getMediaOrderList(
        string $unionId,
        int $searchBeginTime = 0,
        int $searchEndTime = 0,
        int $orderPlatform = 0
    ): array {
        $getMediaOrderUrl = sprintf(
            self::GET_MEDIA_ORDER_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getMediaOrderUrl);

        if ($res['status'] != 1) {
            return ['error' => $res['msg']];
        }

        $newOrderList = [];

        foreach ($res['result'] as $order) {
            if (
                $order['add_time'] > $searchBeginTime
                && $order['add_time'] < $searchEndTime
                && $order['order_platform'] == $orderPlatform
            ) {
                $newOrderList[] = $order;
            }
        }

        return $newOrderList;
    }

    /**
     * 根据unionId获取平台订单数据
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getPlatformOrderList(string $unionId): array
    {
        $getPlatformOrderUrl = sprintf(
            self::GET_MEDIA_ORDER_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getPlatformOrderUrl);

        if ($res['status'] != 1) {
            Log::info('getPlatformOrderList-' . $unionId . '-' . $res['msg']);
            return ['error' => $res['msg']];
        }

        [
            $lastWeekBeginTime, // 上周一
            $lastWeekEndTime,   // 本周一
        ] =
        [
            strtotime('-2 sunday +1 day'),
            strtotime('this week Monday'),
        ];

        $lastWeekBuyCount = $lastWeekFromGroupBuyCount =
        $lastWeekBuyCountPlatformOne = $lastWeekFromGroupBuyCountPlatformOne
            = [];

        foreach ($res['result'] as $order) {
            if (
                $order['add_time'] >= $lastWeekBeginTime
                && $order['add_time'] <=  $lastWeekEndTime
                && in_array($order['order_status'], [1, 2, 4])
            ) {
                // 上周购买过
                $lastWeekBuyCount[] = $order;

                if ($order['from'] == 1008) { // 上周在群聊购买过
                    $lastWeekFromGroupBuyCount[] = $order;
                }

                // 上周在用户运营商品购买过
                if ($order['order_platform'] == 1) {
                    $lastWeekBuyCountPlatformOne[] = $order;

                    if ($order['from'] == 1008) { // 上周用户运营商品群聊购买过
                        $lastWeekFromGroupBuyCountPlatformOne[] = $order;
                    }
                }
            }
        }

        return [
            'last_week_buy_count'                  => $lastWeekBuyCount,
            'last_week_buy_count_group'            => $lastWeekFromGroupBuyCount,
            'last_week_buy_count_platform_1'       => $lastWeekBuyCountPlatformOne,
            'last_week_buy_count_platform_1_group' => $lastWeekFromGroupBuyCountPlatformOne,
        ];
    }

    /**
     * 从珠宝获取用户的地址
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getUserAddress(string $unionId): array
    {
        $getUserAddressUrl = sprintf(
            self::GET_USER_ADDRESS_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getUserAddressUrl);

        return [
            'province' => $res['result']['wx_province'] ?? '',
            'city'     => $res['result']['wx_city'] ?? '',
            'district' => $res['result']['wx_district'] ?? ''
        ];
    }

    /**
     * 从媒体获取用户的地址
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getAddressFromKo(string $unionId): array
    {
        $getAddressFromKoUrl = sprintf(
            self::GET_ADDRESS_FROM_KO_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getAddressFromKoUrl);

        return [
            'province' => $res['data']['province'],
            'city'     => $res['data']['city']
        ];
    }

    /**
     * 获取用户来源
     *
     * @return array
     * @throws Exception
     */
    public function getFromInfo(): array
    {
        $res = self::sendRequest('get', self::GET_FROM_INFO_URL);

        if ($res['status'] != 1) {
            return [];
        }

        return $res['result'];
    }

    /**
     * 获取当前客户消费价格区间
     *
     * @param string $mobile
     * @return array|mixed
     * @throws Exception
     */
    public function getConsumeSegment(string $mobile)
    {
        $params = [
            'json' => [
                'mobile' => $mobile
            ]
        ];

        $res = self::sendRequest('post', self::GET_ERP_CONTACT_CONSUME_SEGMENT, $params);

        if ($res['returnCode'] != 200) {
            send_msg_to_wecom('获取当前客户消费价格区间出错！' . $mobile);
            return [];
        }

        return $res['returnData'];
    }

    /**
     * 获取当前客户是否有指定类型消费
     *
     * @param string $unionId
     * @return array|mixed
     * @throws Exception
     */
    public function getConsumeInfo(string $unionId)
    {
        $getConsumeInfoUrl = sprintf(
            self::GET_CONSUME_INFO,
            $unionId
        );

        $res = self::sendRequest('get', $getConsumeInfoUrl);

        return $res['data'] ?? [];
    }

    /**
     * 根据unionId判断是否有支付订单
     *
     * @param string $unionId 客户唯一标识
     * @return bool
     * @throws Exception
     */
    public function getIsConsume(string $unionId): bool
    {
        $getMediaOrderUrl = sprintf(
            self::GET_MEDIA_ORDER_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getMediaOrderUrl);

        if ($res['status'] != 1) {
            return false;
        }

        if ($res['result']) {
            foreach ($res['result'] as $order) {
                if ($order['pay_status'] > 0 && $order['order_status'] != 3) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 往用户中心添加和更新用户信息
     *
     * @param int $autoId 自增ID
     * @param string $unionId 客户唯一标识
     * @param string $nickName 客户昵称
     * @param string $avatar 客户头像
     * @param int $gender 客户性别
     * @return bool
     * @throws Exception
     */
    public function addUserCenterData(int $autoId, string $unionId, string $nickName, string $avatar, int $gender): bool
    {
        $userInfo = [
            'app_user_id' => $autoId
        ];

        if ($gender != 0) {
            $userInfo['gender'] = $gender;
        }

        if ($avatar != '') {
            $userInfo['avatar'] = $avatar;
        }

        if ($nickName != '') {
            $userInfo['nickname'] = $nickName;
        }

        $params = [
            'app_id'     => 4,
            'refresh'    => 1,
            'unique_key' => $unionId,
            'user_info'  => $userInfo
        ];

        $res = self::sendRequest('post', self::ADD_USER_CENTER_DATA_URL, ['json' => $params]);

        if ($res['code'] != 200) {
            exception('往用户中心添加和更新用户信息失败，code：' . $res['code']);
            return false;
        }

        return true;
    }

    /**
     * 获取首次关注公众号和授权小程序的时间
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getFirstAuthorizeTime(string $unionId): array
    {
        $getFirstAuthorizeTimeUrl = sprintf(
            self::FIRST_AUTHORIZE_URL,
            $unionId
        );

        $res = self::sendRequest('get', $getFirstAuthorizeTimeUrl);

        return [
            'gzh' => $res['data']['gzh'],
            'xxx' => $res['data']['xxx']
        ];
    }
}
