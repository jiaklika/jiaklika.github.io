<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;

/**
 * 客户联系「联系我」管理
 *
 * Class ContactWayHttpDao
 * @package app\api\dao\http\contact
 */
class ContactWayHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 配置客户联系「联系我」方式
    public const ADD_CONTACT_WAY_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/add_contact_way?access_token=%s';
    // 获取企业已配置的「联系我」方式
    public const GET_CONTACT_WAY_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_contact_way?access_token=%s';
    // 删除企业已配置的「联系我」方式
    public const DEL_CONTACT_WAY_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/del_contact_way?access_token=%s';

    /**
     * ContactWayHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 配置客户联系「联系我」方式
     *
     * @param mixed  $state 企业自定义的state参数，用于区分不同的添加渠道
     * @param array  $user  使用该联系方式的用户userID列表
     * @param int    $scene 场景，1-在小程序中联系，2-通过二维码联系
     * @param int    $style 在小程序中联系时使用的控件样式
     * @return array
     * @throws Exception
     */
    public function addContactWay(
        $state,
        array $user,
        int $scene,
        int $style = 2
    ): array {
        if (empty($user) || !in_array($scene, [1,2])) {
            throw new Exception('参数错误！');
        }

        $userCount = count($user);

        if ($userCount > 100) {
            throw new Exception('每个联系方式最多配置100个使用成员！');
        }

        $addContactWayUrl = sprintf(
            self::ADD_CONTACT_WAY_URL,
            $this->_token
        );

        $type = $userCount > 1 ? 2 : 1;

        $params = [
            'type'        => $type,  // 联系方式类型,1-单人, 2-多人
            'scene'       => $scene, // 场景，1-在小程序中联系，2-通过二维码联系
            'skip_verify' => true,   // 外部客户添加时是否无需验证
            'state'       => $state,
            'user'        => $user   // 使用该联系方式的用户userID列表，在type为1时为必填，且只能有一个
        ];

        if ($scene == 1) {
            $params['style'] = $style;
        }

        $res = self::sendRequest('post', $addContactWayUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'config_id' => $res['config_id'],
            'qr_code'   => $res['qr_code'] ?? ''
        ];
    }

    /**
     * 获取企业已配置的「联系我」方式
     *
     * @param string $configId
     * @return array
     * @throws Exception
     */
    public function getContactWay(string $configId): array
    {
        $getContactWayUrl = sprintf(
            self::GET_CONTACT_WAY_URL,
            $this->_token
        );

        $params = [
            'config_id' => $configId
        ];

        $res = self::sendRequest('post', $getContactWayUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['contact_way'];
    }

    /**
     * 删除企业已配置的「联系我」方式
     *
     * @param string $configId
     * @return int
     * @throws Exception
     */
    public function delContactWay(string $configId): int
    {
        $getContactWayUrl = sprintf(
            self::DEL_CONTACT_WAY_URL,
            $this->_token
        );

        $params = [
            'config_id' => $configId
        ];

        $res = self::sendRequest('post', $getContactWayUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['errcode'];
    }
}
