<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * Class ContactTransferHttpDao
 * @package app\api\dao\http\contact
 */
class ContactTransferHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 分配成员的客户
    public const TRANSFER_CONTACT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/transfer?access_token=%s';
    // 查询客户接替结果
    public const GET_TRANSFER_RESULT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_transfer_result?access_token=%s';
    // 获取离职成员的客户列表
    public const GET_UNASSIGNED_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_unassigned_list?access_token=%s';
    // 离职成员的群再分配
    public const GROUP_CHAT_TRANSFER_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/groupchat/transfer?access_token=%s';

    /**
     * ContactTransferHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 分配成员的客户
     *
     * @param string $externalUserId 外部联系人的userid
     * @param string $handoverUserId 原跟进成员的userid
     * @param string $takeoverUserId 接替成员的userid
     * @param string $transferSuccessMsg 转移成功后发给客户的消息，最多200个字符，不填则使用默认文案，目前只对在职成员分配客户的情况生效
     * @return bool
     * @throws Exception
     */
    public function transferContact(
        string $externalUserId,
        string $handoverUserId,
        string $takeoverUserId,
        string $transferSuccessMsg = ''
    ): bool {
        $transferContactUrl = sprintf(
            self::TRANSFER_CONTACT_URL,
            $this->_token
        );

        $params = [
            'external_userid' => $externalUserId,
            'handover_userid' => $handoverUserId,
            'takeover_userid' => $takeoverUserId
        ];

        if ($transferSuccessMsg) {
            $params['transfer_success_msg'] = $transferSuccessMsg;
        }

        $res = self::sendRequest('post', $transferContactUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($externalUserId . $res['errmsg']);
        }

        return true;
    }


    /**
     * 查询客户接替结果
     *
     * @param string $externalUserId 外部联系人的userid
     * @param string $handoverUserId 原跟进成员的userid
     * @param string $takeoverUserId 接替成员的userid
     * @return array
     * @throws Exception
     */
    public function getTransferResult(
        string $externalUserId,
        string $handoverUserId,
        string $takeoverUserId
    ): array {
        $getTransferResultUrl = sprintf(
            self::GET_TRANSFER_RESULT_URL,
            $this->_token
        );

        $params = [
            'external_userid' => $externalUserId,
            'handover_userid' => $handoverUserId,
            'takeover_userid' => $takeoverUserId
        ];

        $res = self::sendRequest('post', $getTransferResultUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'status'        => $res['status'],
            'takeover_time' => $res['takeover_time']
        ];
    }
}
