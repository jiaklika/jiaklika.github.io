<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;

/**
 * 客户标签管理
 *
 * Class ContactTagHttpDao
 * @package app\api\dao\http\contact
 */
class ContactTagHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取企业标签库
    public const GET_CONTACT_TAG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_corp_tag_list?access_token=%s';
    // 添加企业客户标签
    public const ADD_CONTACT_TAG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/add_corp_tag?access_token=%s';
    // 编辑企业客户标签
    public const EDIT_CONTACT_TAG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/edit_corp_tag?access_token=%s';
    // 删除企业客户标签
    public const DEL_CONTACT_TAG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/del_corp_tag?access_token=%s';
    // 编辑客户的企业标签
    public const MARK_TAG_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/mark_tag?access_token=%s';

    /**
     * ContactTagHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 获取企业标签库
     *
     * @param array $tagIdArr 要查询的标签id数组，如果不填则获取该企业的所有客户标签，目前暂不支持标签组id
     * @return array
     * @throws Exception
     */
    public function getContactTag(array $tagIdArr = []): array
    {
        $getTagUrl = sprintf(
            self::GET_CONTACT_TAG_URL,
            $this->_token
        );

        $params = $tagIdArr
            ? ['tag_id' => $tagIdArr]
            : [];

        $res = self::sendRequest('post', $getTagUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception(
                sprintf(
                    '标签id-%s-%s',
                    json_encode($tagIdArr),
                    $res['errmsg']
                )
            );
        }

        return $res['tag_group'];
    }

    /**
     * 添加企业客户标签
     *
     * @param array  $tagIdArr   标签的名称和次序数组
     * @param string $groupId    标签组id，如果要向指定的标签组下添加标签，需要填写group_id参数
     * @param string $groupName  标签组名称
     * @param int    $groupOrder 标签组次序值
     * @return array
     * @throws Exception
     */
    public function addContactTag(
        array $tagIdArr,
        string $groupId = '',
        string $groupName = '',
        int $groupOrder = 0
    ): array {
        $getTagUrl = sprintf(
            self::ADD_CONTACT_TAG_URL,
            $this->_token
        );

        $params = [
            'group_id' => $groupId,
            'tag'      => [$tagIdArr],
        ];

        if ($groupName) {
            $params['group_name'] = $groupName;
        }

        if ($groupOrder) {
            $params['order'] = $groupOrder;
        }

        $res = self::sendRequest('post', $getTagUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['tag_group'];
    }

    /**
     * 编辑企业客户标签
     *
     * @param string $tagId   标签或标签组的id
     * @param string $tagName 新的标签或标签组名称，最长为30个字符
     * @param int $tagOrder   标签/标签组的次序值
     * @return bool
     * @throws Exception
     */
    public function editContactTag(string $tagId, string $tagName, int $tagOrder): bool
    {
        $getTagUrl = sprintf(
            self::EDIT_CONTACT_TAG_URL,
            $this->_token
        );

        $params = [
            'id'    => $tagId,
            'name'  => $tagName,
            'order' => $tagOrder
        ];

        $res = self::sendRequest('post', $getTagUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }

    /**
     * 删除企业客户标签
     *
     * @param array $tagIdArr   标签的id列表
     * @param array $groupIdArr 标签组的id列表
     * @return bool
     * @throws Exception
     */
    public function delContactTag(array $tagIdArr = [], array $groupIdArr = []): bool
    {
        if (!$tagIdArr && !$groupIdArr) {
            throw new Exception('标签ID和标签组ID不能同时为空！');
        }

        $getTagUrl = sprintf(
            self::DEL_CONTACT_TAG_URL,
            $this->_token
        );

        $params = [];

        if ($tagIdArr) {
            $params['tag_id'] = $tagIdArr;
        }

        if ($groupIdArr) {
            $params['group_id'] = $groupIdArr;
        }

        $res = self::sendRequest('post', $getTagUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }

    /**
     * 编辑客户的企业标签，可同时添加与移除，但添加的不能和移除的相同
     *
     * @param string $userId         添加外部联系人的userId
     * @param string $externalUserId 外部联系人的userId
     * @param array  $addTag         要标记的标签列表
     * @param array  $removeTag      要移除的标签列表
     * @return bool
     * @throws Exception
     */
    public function markTag(
        string $userId,
        string $externalUserId,
        array $addTag = [],
        array $removeTag = []
    ): bool {
        $markTagUrl = sprintf(
            self::MARK_TAG_URL,
            $this->_token
        );

        $params = [
            'userid'          => $userId,
            'external_userid' => $externalUserId
        ];

        if ($addTag) {
            $params['add_tag'] = $addTag;
        }

        if ($removeTag) {
            $params['remove_tag'] = $removeTag;
        }

        $res = self::sendRequest('post', $markTagUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($externalUserId . '-' . $res['errmsg']);
        }

        return true;
    }
}
