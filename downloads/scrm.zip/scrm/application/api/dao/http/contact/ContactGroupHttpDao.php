<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;

/**
 * 客户群管理
 *
 * Class ContactGroupHttpDao
 * @package app\api\dao\http\contact
 */
class ContactGroupHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取客户群列表
    public const GET_CONTACT_GROUP_CHAT_LIST_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/groupchat/list?access_token=%s';
    // 获取客户群详情
    public const GET_CONTACT_GROUP_CHAT_DETAIL_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/groupchat/get?access_token=%s';
    // 客户群opengid转换
    public const GET_OPENGID_TO_CHATID_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/opengid_to_chatid?access_token=%s';

    /**
     * ContactGroupHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 获取客户群列表
     *
     * @param int $offset        分页，偏移量。默认为0
     * @param int $limit         分页，预期请求的数据量，取值范围1~1000
     * @param array $userIdList  用户ID列表。最多100个
     * @param array $partyIdList 部门ID列表。最多100个
     * @param int $status_filter 群状态过滤。0-所有列表 1-离职待继承 2-离职继承中 3-离职继承完成，默认未0
     * @return array
     * @throws Exception
     */
    public function getContactGroupList(
        int $offset = 0,
        int $limit = 1000,
        array $userIdList = [],
        array $partyIdList = [],
        int $status_filter = 0
    ): array {
        $getContactGroupListUrl = sprintf(
            self::GET_CONTACT_GROUP_CHAT_LIST_URL,
            $this->_token
        );

        $params = [
            'status_filter' => $status_filter,
            'owner_filter'  => [ // 群主过滤。如果不填，表示获取全部群主的数据
                'userid_list'  => $userIdList,
                'partyid_list' => $partyIdList
            ],
            'offset'        => $offset,
            'limit'         => $limit,
        ];

        $res = self::sendRequest('post', $getContactGroupListUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['group_chat_list'];
    }

    /**
     * 获取客户群详情
     *
     * @param string $chatId 客户群ID
     * @param int $needName 是否需要返回群成员的名字group_chat.member_list.name 0-不返回；1-返回。默认不返回
     * @return array
     * @throws Exception
     */
    public function getContactGroupDetail(string $chatId, int $needName = 0): array
    {
        $getContactGroupDetailUrl = sprintf(
            self::GET_CONTACT_GROUP_CHAT_DETAIL_URL,
            $this->_token
        );

        $params = [
            'chat_id'   => $chatId,
            'need_name' => $needName
        ];

        $res = self::sendRequest('post', $getContactGroupDetailUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['group_chat'];
    }

    /**
     * 客户群opengid转换
     *
     * @param string $openGid 小程序在微信获取到的群ID
     * @return string
     * @throws Exception
     */
    public function openGidToChatId(string $openGid): string
    {
        $getOpenGidToChatIdUrl = sprintf(
            self::GET_OPENGID_TO_CHATID_URL,
            $this->_token
        );

        $params = [
            'opengid' => $openGid
        ];

        $res = self::sendRequest('post', $getOpenGidToChatIdUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['chat_id'];
    }
}
