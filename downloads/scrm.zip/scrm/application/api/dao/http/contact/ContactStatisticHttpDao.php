<?php

declare(strict_types=1);

namespace app\api\dao\http\contact;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * Class ContactStatisticHttpDao
 * @package app\api\dao\http\contact
 */
class ContactStatisticHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取联系客户统计数据
    public const GET_USER_BEHAVIOR_DATA_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_user_behavior_data?access_token=%s';

    /**
     * ContactHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 获取联系客户统计数据
     *
     * @param array $userId    成员ID列表
     * @param array $partyId   部门ID列表
     * @param int   $startTime 数据起始时间
     * @param int   $endTime   数据结束时间
     * @return array
     * @throws Exception
     */
    public function getUserBehaviorData(
        array $userId,
        array $partyId,
        int $startTime,
        int $endTime
    ): array {
        if (!$userId && !$partyId) {
            throw new Exception('userid和partyid不可同时为空');
        }

        $getBehaviorDataUrl = sprintf(
            self::GET_USER_BEHAVIOR_DATA_URL,
            $this->_token
        );

        $params = [
            'userid'     => $userId,
            'partyid'    => $partyId,
            'start_time' => $startTime,
            'end_time'   => $endTime
        ];

        $res = self::sendRequest('post', $getBehaviorDataUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['behavior_data'];
    }
}
