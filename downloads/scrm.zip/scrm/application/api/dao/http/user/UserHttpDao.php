<?php

declare(strict_types=1);

namespace app\api\dao\http\user;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;

/**
 * 通讯录管理
 *
 * Class UserHttpDao
 * @package app\api\dao\http\user
 */
class UserHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 获取部门列表
    public const DEPARTMENT_URL = 'https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token=%s&id=%d';
    // 获取部门成员
    public const DEPARTMENT_MEMBER_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?access_token=%s&department_id=%d&fetch_child=%d';
    // 获取部门成员详情
    public const USER_DETAIL_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/user/list?access_token=%s&department_id=%d&fetch_child=%d';
    // 读取成员
    public const GET_USER_URL = 'https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=%s&userid=%s';
    // 更新成员
    public const UPDATE_USER_URL = 'https://qyapi.weixin.qq.com/cgi-bin/user/update?access_token=%s';
    // 获取访问用户身份
    public const GET_USER_INFO_URL = 'https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=%s&code=%s';

    /**
     * UserHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::USER_INDEX);
    }

    /**
     * 获取部门列表
     *
     * @param int|null $departmentId 部门id。获取指定部门及其下的子部门（以及及子部门的子部门等等，递归）。如果不填，默认获取全量组织架构。
     * @return array
     * @throws Exception
     */
    public function getDepartmentList(?int $departmentId): array
    {
        $departmentUrl = sprintf(
            self::DEPARTMENT_URL,
            $this->_token,
            $departmentId ?: ''
        );

        $res = self::sendRequest('get', $departmentUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['department'] ?? [];
    }

    /**
     * 获取部门成员列表
     *
     * @param int|null $departmentId 部门id
     * @param int|null $fetchChild 是否递归获取子部门下面的成员：1-递归获取，0-只获取本部门
     * @return array
     * @throws Exception
     */
    public function getUserList(?int $departmentId, ?int $fetchChild): array
    {
        $departmentMemberUrl = sprintf(
            self::DEPARTMENT_MEMBER_URL,
            $this->_token,
            $departmentId ?: '',
            $fetchChild
        );

        $res = self::sendRequest('get', $departmentMemberUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['userlist'] ?? [];
    }

    /**
     * 获取部门成员详情
     *
     * @param int|null $departmentId 部门id
     * @param int|null $fetchChild 1/0：是否递归获取子部门下面的成员
     * @return array
     * @throws Exception
     */
    public function getUserDetail(?int $departmentId, ?int $fetchChild): array
    {
        $userDetailUrl = sprintf(
            self::USER_DETAIL_URL,
            $this->_token,
            $departmentId ?: '',
            $fetchChild
        );

        $res = self::sendRequest('get', $userDetailUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['userlist'] ?? [];
    }

    /**
     * 读取成员
     *
     * @param string $userId 用户ID
     * @return array
     * @throws Exception
     */
    public function getUser(string $userId): array
    {
        $getUserUrl = sprintf(
            self::GET_USER_URL,
            $this->_token,
            $userId
        );

        $res = self::sendRequest('get', $getUserUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return $res;
    }

    /**
     * 更新成员
     *
     * @param string $userId 用户ID
     * @param array $updateFields 更新字段
     * @return bool
     * @throws Exception
     */
    public function updateUser(string $userId, array $updateFields): bool
    {
        $updateUserUrl = sprintf(
            self::UPDATE_USER_URL,
            $this->_token
        );

        $params = array_merge(['userid' => $userId], $updateFields);

        $res = self::sendRequest('post', $updateUserUrl, ['json' => $params]);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }


    /**
     * 获取访问用户身份
     *
     * @param string $code 通过成员授权获取到的code，最大为512字节。每次成员授权带上的code将不一样，code只能使用一次，5分钟未被使用自动过期。
     * @return array
     * @throws Exception
     */
    public function getUserInfo(string $code): array
    {
        $getUserInfoUrl = sprintf(
            self::GET_USER_INFO_URL,
            $this->_token,
            $code
        );

        $res = self::sendRequest('get', $getUserInfoUrl);

        if ($res['errcode'] != 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'UserId' => $res['UserId'] ?? '',
            'OpenId' => $res['OpenId'] ?? ''
        ];
    }
}
