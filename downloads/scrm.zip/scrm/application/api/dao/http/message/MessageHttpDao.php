<?php

declare(strict_types=1);

namespace app\api\dao\http\message;

use app\api\dao\http\BaseHttpDao;
use app\api\util\TokenManager;
use app\api\util\HttpClient;
use Exception;

/**
 * 发送应用消息
 *
 * Class MessageHttpDao
 * @package app\api\dao\http\message
 */
class MessageHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 发送应用消息
    public const SEND_MESSAGE_URL = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s';
    // 创建群聊会话
    public const CREATE_GROUP_CHAT_URL = 'https://qyapi.weixin.qq.com/cgi-bin/appchat/create?access_token=%s';
    // 发送消息到群聊会话
    public const SEND_GROUP_CHAT_MESSAGE_URL = 'https://qyapi.weixin.qq.com/cgi-bin/appchat/send?access_token=%s';

    /**
     * MessageHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::APP_INDEX);
    }

    /**
     * 发送应用消息
     *
     * @param string $msgType               消息类型
     * @param array $extraParam             消息类型对应参数
     * @param array $toUser                 指定接收消息的成员
     * @param array $toParty                指定接收消息的部门
     * @param array $toTag                  指定接收消息的标签
     * @param int $agentId                  企业应用的id
     * @param int $safe                     是否是保密消息
     * @param int $enableIdTrans            是否开启id转译
     * @param int $enableDuplicateCheck     是否开启重复消息检查
     * @param int $duplicateCheckInterval   是否重复消息检查的时间间隔
     * @return bool
     * @throws Exception
     */
    public function sendMessage(
        string $msgType,
        array $extraParam,
        //array $toUser = ['@all'],
        array $toUser = ['chebin'],
        array $toParty = [],
        array $toTag = [],
        int $agentId = 0,
        int $safe = 0,
        int $enableIdTrans = 0,
        int $enableDuplicateCheck = 0,
        int $duplicateCheckInterval = 1800
    ): bool {
        $sendMessageUrl = sprintf(
            self::SEND_MESSAGE_URL,
            $this->_token
        );

        if (!$toUser && !$toParty && $toTag) {
            throw new Exception('touser、toparty、totag不能同时为空');
        }

        $params = [
            'touser'                   => $toUser ? implode('|', $toUser) : '',
            'toparty'                  => $toParty ? implode('|', $toParty) : '',
            'totag'                    => $toTag ? implode('|', $toTag) : '',
            'agentid'                  => $agentId ? : config('workweixin.agent_id'),
            'msgtype'                  => $msgType,
            "{$msgType}"               => $extraParam,
            'safe'                     => $safe,
            'enable_id_trans'          => $enableIdTrans,
            'enable_duplicate_check'   => $enableDuplicateCheck,
            'duplicate_check_interval' => $duplicateCheckInterval
        ];

        $res = self::sendRequest('post', $sendMessageUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }

    /**
     * 创建群聊会话
     *
     * @param string $name    群聊名
     * @param string $owner   指定群主的id
     * @param array $userList 群成员id列表。至少2人，至多2000人
     * @param string $chatId  群聊id
     * @return string
     * @throws Exception
     */
    public function createGroupChat(
        string $name,
        string $owner,
        array $userList,
        string $chatId = ''
    ): string {
        $createGroupChatUrl = sprintf(
            self::CREATE_GROUP_CHAT_URL,
            $this->_token
        );

        $params = [
            'name'     => $name,
            'owner'    => $owner,
            'userlist' => $userList,
            'chatid'   => $chatId
        ];

        $res = self::sendRequest('post', $createGroupChatUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return $res['chatid'];
    }

    /**
     * 发送消息到群聊会话
     *
     * @param string $chatId     群聊id
     * @param string $msgType    消息类型
     * @param array  $extraParam 消息类型对应的参数
     * @param int $safe
     * @return bool
     * @throws Exception
     */
    public function sendGroupChatMessage(
        string $chatId,
        string $msgType,
        array $extraParam,
        int $safe = 0
    ): bool {
        $sendGroupChatMessageUrl = sprintf(
            self::SEND_GROUP_CHAT_MESSAGE_URL,
            $this->_token
        );

        $params = [
            'chatid'     => $chatId,
            'msgtype'    => $msgType,
            "{$msgType}" => $extraParam,
            'safe'       => $safe
        ];

        $res = self::sendRequest('post', $sendGroupChatMessageUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return true;
    }
}
