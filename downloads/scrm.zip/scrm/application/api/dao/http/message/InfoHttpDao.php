<?php

declare(strict_types=1);

namespace app\api\dao\http\message;

use app\api\util\HttpClient;
use Exception;

/**
 * Class InfoHttpDao
 * @package app\api\dao\http\message
 */
class InfoHttpDao
{
    use HttpClient;

    // 知乎日报
    public const ZHI_HU_DAILY_NEWS_URL = 'https://news-at.zhihu.com/api/4/news/latest';

    /**
     * 获取知乎日报数据
     *
     * @return array
     * @throws Exception
     */
    public function getZhiHuDailyNews()
    {
        return self::sendRequest('get', self::ZHI_HU_DAILY_NEWS_URL);
    }
}
