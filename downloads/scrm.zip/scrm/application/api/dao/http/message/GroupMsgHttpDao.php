<?php

declare(strict_types=1);

namespace app\api\dao\http\message;

use app\api\dao\http\BaseHttpDao;
use app\api\util\HttpClient;
use app\api\util\TokenManager;
use Exception;

/**
 * 企业群发
 *
 * Class GroupMsgHttpDao
 * @package app\api\dao\http\message
 */
class GroupMsgHttpDao extends BaseHttpDao
{
    use HttpClient;

    // 创建企业群发
    public const ADD_MSG_TEMPLATE_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/add_msg_template?access_token=%s';

    // 获取群发记录列表
    public const GET_GROUP_MSG_LIST =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_groupmsg_list_v2?access_token=%s';

    // 获取群发成员发送任务列表
    public const GET_GROUP_MSG_TASK_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_groupmsg_task?access_token=%s';

    // 获取企业群发成员执行结果
    public const GET_GROUP_MSG_SEND_RESULT_URL =
        'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get_groupmsg_send_result?access_token=%s';

    /**
     * @var string 发送给客户
     */
    public const SINGLE = 'single';

    /**
     * @var string 发送给客户群
     */
    public const GROUP = 'group';

    /**
     * ContactMessageHttpDao constructor.
     * @throws Exception
     */
    public function __construct()
    {
        parent::__construct(TokenManager::CONTACT_INDEX);
    }

    /**
     * 创建企业群发
     *
     * @param string $chatType 群发任务的类型
     * @param array $externalUserIdArr 客户的外部联系人id列表
     * @param string $sender 发送企业群发消息的成员userid
     * @param string $textContent 消息文本内容
     * @param string $msgType 第2条消息类型
     * @param array $typeData 第2条消息内容
     * @return array
     * @throws Exception
     */
    public function addMessageTemplate(
        string $chatType,
        array $externalUserIdArr,
        string $sender = '',
        string $textContent = '',
        string $msgType = '',
        array $typeData = []
    ): array {

        $addMessageTemplateUrl = sprintf(
            self::ADD_MSG_TEMPLATE_URL,
            $this->_token
        );

        $params = [
            'chat_type'       => $chatType,
            'external_userid' => $externalUserIdArr,
            'sender'          => $sender
        ];

        if ($sender) {
            $params['sender'] = $sender;
        }

        if ($textContent) {
            $params['text']['content'] = $textContent;
        }

        if ($msgType) {
            $params["{$msgType}"] = $typeData;
        }

        $res = self::sendRequest('post', $addMessageTemplateUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg'], $res['errcode']);
        }

        return [
            'fail_list' => $res['fail_list'],
            'msg_id'    => $res['msgid']
        ];
    }

    /**
     * 获取群发成员发送任务列表
     *
     * @param string $msgId 群发消息的id
     * @param int $limit 返回的最大记录数
     * @param string $cursor 用于分页查询的游标
     * @return array
     * @throws Exception
     */
    public function getGroupMsgTask(string $msgId, int $limit = 50, string $cursor = ''): array
    {
        $getGroupMsgTaskUrl = sprintf(
            self::GET_GROUP_MSG_TASK_URL,
            $this->_token
        );

        $params = [
            'msgid'  => $msgId,
            'limit'  => $limit,
            'cursor' => $cursor
        ];

        $res = self::sendRequest('post', $getGroupMsgTaskUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'next_cursor' => $res['next_cursor'],
            'task_list'   => $res['task_list']
        ];
    }

    /**
     * 获取群发记录列表
     *
     * @param string $creator 群发任务创建人企业账号id
     * @param int $startTime 群发任务记录开始时间
     * @param int $endTime 群发任务记录结束时间
     * @param string $chatType 群发任务的类型，默认为single，表示发送给客户，group表示发送给客户群
     * @param int $filterType 创建人类型。0：企业发表 1：个人发表 2：所有，包括个人创建以及企业创建，默认情况下为所有类型
     * @param int $limit 返回的最大记录数，整型，最大值100，默认值50，超过最大值时取默认值
     * @param string $cursor 用于分页查询的游标
     * @return array
     * @throws Exception
     */
    public function getGroupMsgList(
        string $creator,
        int $startTime,
        int $endTime,
        string $chatType = 'single',
        int $filterType = 2,
        int $limit = 100,
        string $cursor = ''
    ): array {
        $getGroupMsgListUrl = sprintf(
            self::GET_GROUP_MSG_LIST,
            $this->_token
        );

        $params = [
            'chat_type'   => $chatType,
            'start_time'  => $startTime,
            'end_time'    => $endTime,
            'creator'     => $creator,
            'filter_type' => $filterType,
            'limit'       => $limit,
            'cursor'      => $cursor
        ];

        $res = self::sendRequest('post', $getGroupMsgListUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'next_cursor'    => $res['next_cursor'],
            'group_msg_list' => $res['group_msg_list']
        ];
    }

    /**
     * 获取企业群发成员执行结果
     *
     * @param string $msgId 群发消息的id
     * @param string $userId 发送成员userid
     * @param int $limit 返回的最大记录数，最大值1000
     * @param string $cursor 用于分页查询的游标
     * @return array
     * @throws Exception
     */
    public function getGroupMsgSendResult(string $msgId, string $userId, int $limit = 1000, string $cursor = ''): array
    {
        $getGroupMsgSendResultUrl = sprintf(
            self::GET_GROUP_MSG_SEND_RESULT_URL,
            $this->_token
        );

        $params = [
            'msgid'  => $msgId,
            'userid' => $userId,
            'limit'  => $limit
        ];

        if ($cursor) {
            $params['cursor'] = $cursor;
        }

        $res = self::sendRequest('post', $getGroupMsgSendResultUrl, ['json' => $params]);

        if ($res['errcode'] !== 0) {
            throw new Exception($res['errmsg']);
        }

        return [
            'next_cursor' => $res['next_cursor'],
            'send_list'   => $res['send_list']
        ];
    }
}
