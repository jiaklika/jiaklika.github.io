<?php

namespace app\api\behavior;

use app\api\common\Constant;
use app\api\common\Response;
use think\Cache;
use think\Request;

/**
 * 自定义行为
 * /config/tags.php
 * 'app_begin'=>['app\\api\\behavior\\Auth']
 *
 * Class Auth
 * @package app\api\behavior
 */
class Auth
{
    // 大后台用户登录数据缓存名称
    public const ADMIN_INFO_CACHE_NAME = 'admin:login:token:%s';
    // 大后台用户数据所在Redis数据库
    public const REDIS_DB = 'redis3';

    public function run(&$param)
    {
        // 首页不需要验证
        if (Request::instance()->url() == '/') {
            return true;
        }

        // 不要登录的操作
        $checkArr = [
            'callback'      => [], // 所有的回调都不需要
            'kefu_callback' => [],
            'contact'     => [
                'getDetail',  // H5不需要
                'getConfig',
                'exportChannelContactList', // 导出不需要
                'exportWayContactList',
                'exportAllContactList',
                'markTag',
                'exportContact2',
                'getStatisticsData',
                'orderInfo',
                'isFriend',
                'isJoinGroup',
                'isContactOrGroupMember',
                'isYuanyuanFriend',
                'isZhaoweiStranger',
                'isFeiyueGroupMember',
                'isZhaoweiFriend',
                'getSourceChannel',
                'isInZhaoweiGroup',
                'isFeiyueFriend',
                'getRelationshipRecord',
                'deleteFriend',
                'deleteGroup',
                'getContactGroup',
                'exportExcel',
                'isPureStranger',
                'savePushFans',
                'addFriendTime',
                'getFriendQRCode',
                'getAllContactList',
                'getFriendsName',
                'isRecruitingOfficerFriend',
                'getArrayRecord'
            ],
            'contact_way' => [
                'downloadQrCode', // 下载图片
                'getConfigType',
                'detail',
                'getChannelList'
            ],
            'test'        => [], // 测试不需要
            'contact_tag'  => [
                'changeYanzhiTag',
                'markFirstOrderTag',
                'markNewCustomerTag'
            ],
            'message' => [
                'sendMsg',
                'sendFile'
            ],
            'live_data' => [
                'storeLiveData',
                'storeLiveAudienceData',
                'handleLiveFirstOrderData',
                'storeVideoLiveTask'
            ],
            'group' => [
                'getGroupCount',
                'isInKeyWordGroup',
                'getAllGroupList'
            ],
            'contact_group' => [
                'transferOpenGid'
            ],
            'user' => [
                'getCustomerServiceList'
            ],
            'contact_fission' => [
                'getInvitationCode',
                'changeEndTime'
            ],
            'kefu' => [
                'getReceptionRule',
                'addWechatRecord',
                'getLink',
                'getJewelryLink',
                'isConsult'
            ],
            'external' => []
        ];

        $requestInfo = $param[$param['type']];

        if (count($requestInfo) != 3) {
            Response::error(Constant::HTTP_ERROR);
        }

        [
            $module,     // 当前模块
            $controller, // 当前控制器
            $action      // 当前方法
        ] =
        [
            $requestInfo[0],
            strtolower($requestInfo[1]),
            $requestInfo[2]
        ];

        if ($module == 'web') {
            return true;
        }

        if (
            isset($checkArr[$controller])
            && (empty($checkArr[$controller])
                || in_array($action, $checkArr[$controller]))
        ) {
                return true;
        }

        $token = Request::instance()->header('token');

        if (empty($token)) {
            Response::custom(Constant::ADMIN_TOKEN_EMPTY);
        }

        $key = sprintf(self::ADMIN_INFO_CACHE_NAME, $token);
        $adminInfo = Cache::store(self::REDIS_DB)->get($key);

        $data = $adminInfo ? json_decode($adminInfo, true) : false;

        if (empty($data)) {
            Response::custom(Constant::ADMIN_NO_LOGIN);
        }

        $logData = [
            'token'      => $token,
            'module'     => $module,
            'controller' => $controller,
            'action'     => $action
        ];

        // 绑定数据
        Request::instance()->bind('admin', $data);
        Request::instance()->bind('log', $logData);
    }
}
