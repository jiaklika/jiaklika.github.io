<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\message\impl\MessageServiceImpl;

/**
 * Class Message
 * @package app\api\controller
 */
class Message extends Base
{
    /**
     * Message constructor.
     * @param MessageServiceImpl $service
     */
    public function __construct(MessageServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 发送知乎日报消息
     */
    public function sendZhiHuDailyNews()
    {
        $this->service->sendZhiHuDailyNews(['chebin']);
    }

    /**
     *
     */
    public function sendBehaviorData()
    {
        $this->service->sendBehaviorData(['chebin']);
    }

    /**
     *
     */
    public function sendStatisticsData()
    {
        //$res = $this->service->sendStatisticsData(['jiamin', 'zhongyongping']);
        // $res = $this->service->sendStatisticsData(['chebin', 'wangbin']);
        //$res = $this->service->sendStatisticsData(['chebin', 'peiyonghao']);
        // Response::success('success', $res);
    }

    /**
     * Excel数据进入redis
     *
     * return void
     */
    public function excelDataToRedis()
    {
        $res = $this->service->excelDataToRedis();

        Response::success('success', $res);
    }

    /**
     * 汇总Excel数据进入redis
     *
     * return void
     */
    public function summaryExcelDataToRedis()
    {
        $res = $this->service->summaryExcelDataToRedis();

        Response::success('success', $res);
    }


    /**
     * 发送Excel
     *
     * return void
     */
    public function sendExcel()
    {
        // $res = $this->service->sendExcel(['chebin']);

        // 多肉，茶花
        $res = $this->service->sendExcel(['chebin','zhaowei', 'zhongyongping', 'zhujing',]);

        // $res = $this->service->sendExcel(['chebin', 'feiyue']);

        Response::success('success', $res);
    }

    /**
     * 发送汇总Excel
     *
     * return void
     */
    public function sendSummaryExcel()
    {
        // $res = $this->service->sendSummaryExcel(['chebin']);

        $res = $this->service->sendSummaryExcel(
            [
                'chebin', 'zhaowei', 'zhongyongping',
                'lvjunyan','xuliang','zhujing',
            ],
            1
        );

        $res = $this->service->sendSummaryExcel(['chebin', 'peiyonghao', 'lvjunyan'], 2);

        Response::success('success', $res);
    }

    /**
     * 指定群购买率进入Redis
     *
     * return void
     */
    public function specialGroupDataToRedis()
    {
        $res = $this->service->specialGroupDataToRedis();
        Response::success('success', $res);
    }

    /**
     * 发送指定群汇总购买率
     *
     * return void
     */
    public function sendSpecialGroupData()
    {
        // $res = $this->service->sendSpecialGroupData(['chebin']);

        // 贾敏、赵蔚、山茶花、费月
        $res = $this->service->sendSpecialGroupData([
            'chebin', 'jiamin','zhaowei','lvjunyan',
            'zhongyongping','feiyue','zhujing',
        ]);

        Response::success('success', $res);
    }

    /**
     * return void
     */
    public function sendMsg()
    {
         $res = $this->service->sendMsg(['chebin']);
         //$res = $this->service->sendMsg([
        //'chebin', 'lvjunyan', 'jiamin', 'zhongyongping' ,'wangbin', 'zhangji', 'feiyue', 'zhaowei'
        //]);
        Response::success('success', $res);
    }

    /**
     * 1、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过个人号和进过其他群的人数；
    2、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过阳阳、阳阳1个人号和进过阳阳、阳阳1其他群的人数；
     */
    public function sendGroupData10()
    {
        $res = $this->service->sendGroupData10();
        Response::success('success', $res);
    }

    /**
     * 公司社群统计
     */
    public function allGroupWriteToRedis()
    {
        $res = $this->service->allGroupWriteToRedis();
        Response::success('success', $res);
    }

    /**
     * 公司社群发送
     */
    public function sendAllGroupData()
    {
        // $res = $this->service->sendAllGroupData(['chebin']);
        $res = $this->service->sendAllGroupData([
            'chebin','lvjunyan','jiamin','feiyue','liyin','zhaowei',
            'zhangji','zhongyongping','xuliang','zhujing',
        ]);
        Response::success('success', $res);
    }

    /**
     * 发送文件
     */
    public function sendFile()
    {
        $file = $this->request->file('file_entity');

        if (!$file) {
            Response::error('请选择上传文件！');
        }

        $toUsers = [
            'chebin',
            'zhongming',
            'lvjunyan',
            'xuliang',
            'liyin'
        ];

        [$status, $sendRes] = $this->service->sendFile($file, $toUsers);

        if ($status) {
            Response::success('发送成功！', $sendRes);
        }

        Response::error($sendRes);
    }
}
