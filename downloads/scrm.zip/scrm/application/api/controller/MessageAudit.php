<?php

namespace app\api\controller;

use app\api\service\message\impl\MessageServiceImpl;

/**
 * Class MessageAudit
 * @package app\api\controller
 */
class MessageAudit extends Base
{
    /**
     * Message constructor.
     * @param MessageServiceImpl $service
     */
    public function __construct(MessageServiceImpl $service)
    {
        parent::__construct($service);
    }

    public function init()
    {
        try {
            $obj = new \WxworkFinanceSdk("wwd08coe7d775abaaa", "zJ6k0naVVQ--gt9PUSSEvs03zW_nlDVmjAkPOTAfrew", [
                "proxy_password" => "world",
                "timeout" => -2,
            ]);
// 私钥地址
            $privateKey = file_get_contents('private.pem');

            $chats = json_decode($obj->getChatData(0, 100), true);
            var_dump($chats);
            foreach ($chats['chatdata'] as $val) {
                $decryptRandKey = null;
                openssl_private_decrypt(
                    base64_decode($val['encrypt_random_key']),
                    $decryptRandKey,
                    $privateKey,
                    OPENSSL_PKCS1_PADDING
                );
                //$obj->downloadMedia($sdkFileId, "/tmp/download/文件新名称.后缀");
            }
        } catch (\WxworkFinanceSdkException $e) {
            var_dump($e->getMessage(), $e->getCode());
        }
    }
}
