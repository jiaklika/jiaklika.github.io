<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\service\contactTag\impl\ContactTagServiceImpl;
use Exception;
use think\Db;
use think\Log;

/**
 * Class ContactTag
 * @package app\api\controller
 */
class ContactTag extends Base
{
    /**
     * ContactTag constructor.
     * @param ContactTagServiceImpl $service
     */
    public function __construct(ContactTagServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 获取企业标签库并写入数据表
     */
    public function initContactTag()
    {
        $res = $this->service->initCorpTag();

        if ($res) {
            Response::success('获取企业标签库成功！');
        }

        Response::error('获取企业标签库失败！');
    }

    /**
     * 获取企业标签库
     */
    public function getCorpTagList()
    {
        $res = $this->service->getCorpTagList();

        Response::success('获取企业标签库成功！', $res);
    }

    /**
     * 添加企业客户标签
     */
    public function addCorpTag()
    {
        $res = $this->service->addCorpTag();

        if ($res) {
            Response::success('添加企业标签库成功！');
        }

        Response::error('添加企业标签库失败！');
    }

    /**
     * 编辑企业标签库
     */
    public function editContactTag()
    {
        $res = $this->service->editContactTag();

        if ($res) {
            Response::success('编辑企业标签库成功！');
        }

        Response::error('编辑企业标签库失败！');
    }

    /**
     * 删除企业标签库
     */
    public function delContactTag()
    {
        $res = $this->service->delContactTag();

        if ($res) {
            Response::success('删除企业标签库成功！');
        }

        Response::error('删除企业标签库失败！');
    }

    /**
     * 给客户打标签
     *
     */
    public function markTag()
    {
        $this->service->markTag();
    }

    /**
     * 给客户打标签
     *
     */
    public function markTag123()
    {
        $this->service->markTag123();
    }

    /**
     * 给客户打新的累计消费标签
     *
     */
    public function markNewConsumeTag()
    {
        $this->service->markNewConsumeTag();
    }

    /**
     * 阳阳1、阳阳、费月的6个号
     * 不在宝姐家优享群、宝姐家新粉福利群、进群看群公告、宝姐家珠宝知识视频分享群的
     *
     * 1、不在群内的铁杆及以上的宝迷，打标签"周五宣传"
     * 2、不在群内的忠实宝迷，打标签"周六宣传"
     */
    public function markPropagandaTag()
    {
        $this->service->markPropagandaTag();
    }

    /**
     * 对外接口，实时更改颜值标签
     */
    public function changeYanzhiTag()
    {
        // Log::info('接收请求-' . json_encode($this->request->get()));
        [
            $unionId,
            $levelId
        ] =
        [
            $this->request->get('union_id'),
            $this->request->get('level_id')
        ];

        if (!$unionId || !in_array($levelId, [1,2,3])) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->changeYanzhiTag($unionId, $levelId);

        // Log::info('返回结果-' . $msg);

        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 获取标签组
     */
    public function getTagGroup()
    {
        $keyword = $this->request->get('keyword');

        Response::success('success', $this->service->getTagGroup($keyword));
    }

    /**
     * 获取标签组下的标签
     */
    public function getTag()
    {
        $requestData = $this->request->get();
        if (!isset($requestData['group_id']) || !$requestData['group_id']) {
            Response::error('参数错误！');
        }

        Response::success('success', $this->service->getTag($requestData));
    }

    /**
     * 唯一化标签
     *
     * @throws Exception
     */
    public function distinctTag()
    {
        $contactTagHttpDao = new ContactTagHttpDao();

        $sql = "select `tag_id`,`external_userid`,`userid` 
from scrm_contact_tag_map a
where (a.tag_id,a.external_userid) in 
(select tag_id,external_userid from scrm_contact_tag_map GROUP BY tag_id,external_userid HAVING count(*)>1) 
and tag_id = 'et5b2CBwAA2cgsL4ILL4sLZZs8CYJT7Q'";

        $repeatTag = Db::name('contact_tag_map')->query($sql);

        $assoc_unique = function ($arr, $key) {
            $tmp_arr = [];

            foreach ($arr as $k => $v) {
                if (in_array($v[$key], $tmp_arr)) {//搜索$v[$key]是否在$tmp_arr数组中存在，若存在返回true
                    unset($arr[$k]);
                } else {
                    $tmp_arr[] = $v[$key];
                }
            }

            sort($arr); //sort函数对数组进行排序

            return $arr;
        };

        $uniqueTagArr = $assoc_unique($repeatTag, 'external_userid');

        /*
        foreach ($repeatTag as $tag)
        {
            // 移除标签
            $removeRes = $contactTagHttpDao->markTag(
                $tag['userid'],
                $tag['external_userid'],
                [],
                ['et5b2CBwAA2cgsL4ILL4sLZZs8CYJT7Q']
            );

            if (!$removeRes)
                Log::error($tag['external_userid'].'-移除意向客户标签失败');
            else
                echo $tag['external_userid'].'-success';
        }

        Response::success('移除完毕');
        */

        foreach ($uniqueTagArr as $tag) {
            // 添加标签
            $addTagRes = $contactTagHttpDao->markTag(
                $tag['userid'],
                $tag['external_userid'],
                ['et5b2CBwAA2cgsL4ILL4sLZZs8CYJT7Q']
            );

            if (!$addTagRes) {
                Log::error($tag['external_userid'] . '-添加意向客户标签失败');
            } else {
                echo $tag['external_userid'] . '-success';
            }
        }

        Response::success('添加完毕');
    }

    /**
     * 初始化来源渠道标签
     */
    public function initChannelTag()
    {
        [$res, $msg] = $this->service->initChannelTag();

        if ($res) {
            Response::success('初始化来源渠道标签成功！');
        }

        Response::error($msg);
    }

    /**
     * 初始化累计消费标签
     */
    public function initConsumeTag()
    {
        [$res, $msg] = $this->service->initConsumeTag();

        if ($res) {
            Response::success('初始化累计消费标签成功！');
        }

        Response::error($msg);
    }

    /**
     * 修复累计消费标签
     */
    public function fixConsumeTag()
    {
        [$res, $msg] = $this->service->fixConsumeTag();

        if ($res) {
            Response::success('修复累计消费标签成功！');
        }

        Response::error($msg);
    }

    /**
     * 修复标签映射表
     */
    public function fixTagMap()
    {
        [$res, $msg] = $this->service->fixTagMap();

        if ($res) {
            Response::success('修复标签映射表成功！');
        }

        Response::error($msg);
    }

    /**
     * 首单客户-送首饰盒
     */
    public function markFirstOrderTag()
    {
        if (!$unionId = $this->request->get('union_id')) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->markFirstOrderTag($unionId);

        if ($res) {
            Response::success('打标签成功！');
        }

        Response::error($msg);
    }

    /**
     * 给客户打"颜值加价购推广"标签
     */
    public function markYanzhiTag()
    {
        $this->service->markYanzhiTag();
    }

    /**
     * 给客户打"7.30继承"标签
     */
    public function mark730Inherit()
    {
        $this->service->mark730Inherit();
    }

    /**
     * 给客户打"0802抽奖活动"标签
     */
    public function mark0802LuckDraw()
    {
        $this->service->mark0802LuckDraw();
    }

    /**
     * 给客户打"大拍画册"标签
     */
    public function markAuctionPictureAlbum()
    {
        $this->service->markAuctionPictureAlbum();
    }

    /**
     * 首单新客
     */
    public function markNewCustomerTag()
    {
        [
            $tagType,
            $unionId
        ] =
        [
            $this->request->get('tag_type'),
            $this->request->get('union_id')
        ];

        if (
            !$unionId
            || !in_array($tagType, [1,2,3])
        ) {
            Response::error('参数错误！');
        }

        $res = $this->service->markNewCustomerTag($unionId, $tagType);

        if ($res) {
            Response::success('打标签成功！');
        }

        Response::error('打标签失败！');
    }

    /**
     * 给客户打"拼团10.15"标签
     */
    public function groupPurchasing1015()
    {
        $this->service->groupPurchasing1015();
    }

    /**
     * 给客户打"10.23群享价活动"标签
     */
    public function groupPurchasing1023()
    {
        $this->service->groupPurchasing1023();
    }

    /**
     * 给客户打商品偏好标签
     */
    public function goodsPreference()
    {
        $this->service->goodsPreference();
    }

    /**
     * 双11通知
     */
    public function double11()
    {
        $this->service->double11();
    }

    /**
     * 转粉
     */
    public function transferFans1()
    {
        $this->service->transferFans1();
    }

    /**
     * 转粉2
     */
    public function transferFans2()
    {
        $this->service->transferFans2();
    }

    /**
     * 给客户打"朋友圈推广"标签
     */
    public function markMomentTag()
    {
        $this->service->markMomentTag();
    }

    /**
     * 给朋友圈客户打"11.26~12.11珍珠加粉定向"标签
     */
    public function markPearlTag()
    {
        $this->service->markPearlTag();
    }

    /**
     * 打"12.16珍珠广告加粉"标签
     */
    public function mark1216PearlTag()
    {
        $this->service->mark1216PearlTag();
    }

    /**
     * 打"秒杀30群客户转移"标签
     */
    public function markSecKillTag()
    {
        $this->service->markSecKillTag();
    }

    /**
     * 打"小红书"标签
     */
    public function markRedBookTag()
    {
        $this->service->markRedBookTag();
    }

    /**
     * 宝姐家秀秀号
     */
    public function markXiuxiuTag()
    {
        $this->service->markXiuxiuTag();
    }

    /**
     * 翡翠手绳活动邀请
     */
    public function markJadeiteTag()
    {
        $this->service->markJadeiteTag();
    }

    /**
     * "彩宝1"标签
     */
    public function markGemstone1Tag()
    {
        $this->service->markGemstone1Tag();
    }

    /**
     * "翡翠多宝吊坠"标签
     */
    public function markPendantTag()
    {
        $this->service->markPendantTag();
    }

    /**
     * "企微裂变种子用户"标签
     */
    public function markFissionTag()
    {
        $this->service->markFissionTag();
    }

    /**
     * "2月26日企微裂变"标签
     */
    public function mark0226FissionTag()
    {
        $this->service->mark0226FissionTag();
    }

    /**
     * "麦穗珍珠胸针活动"标签
     */
    public function markBroochTag()
    {
        $this->service->markBroochTag();
    }

    /**
     * "3.7彩宝1添加个微"标签
     */
    public function markStone1Tag()
    {
        $this->service->markStone1Tag();
    }

    /**
     * "3.7珍珠老添加个微"标签
     */
    public function markPearlOldTag()
    {
        $this->service->markPearlOldTag();
    }

    /**
     * "3.7群发邀请添加个微"标签
     */
    public function markAddWechatTag()
    {
        $this->service->markAddWechatTag();
    }

    /**
     * "企微裂变2.0"标签
     */
    public function markFissionChannelTag()
    {
        $this->service->markFissionChannelTag();
    }

    /**
     * "延发"标签
     */
    public function markDelayTag()
    {
        $this->service->markDelayTag();
    }

    /**
     * "KOC"标签
     */
    public function markKocTag()
    {
        $this->service->markKocTag();
    }

    /**
     * 移除标签
     */
    public function removeTag()
    {
        $this->service->removeTag();
    }
}
