<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\liveData\impl\LiveDataServiceImpl;

/**
 * 获取企微直播数据并发送
 *
 * Class LiveData
 * @package app\api\controller
 */
class LiveData extends Base
{
    /**
     * Contact constructor.
     * @param LiveDataServiceImpl $service
     */
    public function __construct(LiveDataServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 存储直播场次信息
     */
    public function storeLiveData()
    {
        $liveData = $this->request->post();

        $storeRes = $this->service->storeLiveData($liveData);

        if ($storeRes) {
            Response::success('存储直播场次信息成功！');
        }

        Response::error('存储直播场次信息失败！');
    }

    /**
     * 存储直播观众信息
     */
    public function storeLiveAudienceData()
    {
        $liveAudienceData = $this->request->post();

        $storeRes = $this->service->storeLiveAudienceData($liveAudienceData);

        if ($storeRes) {
            Response::success('存储直播观众信息成功！');
        }

        Response::error('存储直播观众信息失败！');
    }

    /**
     * 处理直播观众新客信息
     */
    public function handleLiveFirstOrderData()
    {
        $liveFirstOrderData = $this->request->post();

        $storeRes = $this->service->handleLiveFirstOrderData($liveFirstOrderData);

        if ($storeRes) {
            Response::success('处理直播观众新客信息成功！');
        }

        Response::error('处理直播观众新客信息失败！');
    }

    /**
     * 处理直播观众新客信息
     */
    public function storeVideoLiveTask()
    {
        $videoLiveData = $this->request->post();

        $storeRes = $this->service->storeVideoLiveTask($videoLiveData);

        if ($storeRes) {
            Response::success('存储视频号直播信息成功！');
        }

        Response::error('存储视频号直播信息失败！');
    }
}
