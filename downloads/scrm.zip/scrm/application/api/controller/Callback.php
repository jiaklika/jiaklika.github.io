<?php

namespace app\api\controller;

use app\api\service\callback\impl\ApprovalCallbackServiceImpl;
use app\api\service\callback\impl\ContactCallbackServiceImpl;
use app\api\service\callback\impl\MsgCallbackServiceImpl;
use app\api\service\callback\impl\UserCallbackServiceImpl;
use Exception;

/**
 * 回调处理
 *
 * Class Callback
 * @package app\api\controller
 */
class Callback extends Base
{
    /**
     * Callback constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 客户变更事件回调
     *
     * @param ContactCallbackServiceImpl $service
     * @throws Exception
     */
    public function contactEvent(ContactCallbackServiceImpl $service)
    {
        $contactCallback = config('callback.contact_callback');

        $service->setSecret(
            $contactCallback['contact_encodingAesKey'],
            $contactCallback['contact_token']
        );
        $this->verifyAndDecrypt($service);
    }

    /**
     * 通讯录变更事件回调
     *
     * @param UserCallbackServiceImpl $service
     * @throws Exception
     */
    public function userEvent(UserCallbackServiceImpl $service)
    {
        $userCallback = config('callback.user_callback');

        $service->setSecret(
            $userCallback['user_encodingAesKey'],
            $userCallback['user_token']
        );

        $this->verifyAndDecrypt($service);
    }

    /**
     * 接收消息与事件
     *
     * @param MsgCallbackServiceImpl $service
     * @throws Exception
     */
    public function msgEvent(MsgCallbackServiceImpl $service)
    {
        $msgCallback = config('callback.msg_callback');

        $service->setSecret(
            $msgCallback['msg_encodingAesKey'],
            $msgCallback['msg_t noken']
        );

        $this->verifyAndDecrypt($service);
    }

    /**
     * 审批申请状态变化回调通知
     *
     * @param ApprovalCallbackServiceImpl $service
     * @throws Exception
     */
    public function approvalEvent(ApprovalCallbackServiceImpl $service)
    {
        $approvalCallback = config('callback.approval_callback');

        $service->setSecret(
            $approvalCallback['msg_encodingAesKey'],
            $approvalCallback['msg_token']
        );

        $this->verifyAndDecrypt($service);
    }

    /**
     * 验证和解密数据
     *
     * @param object $service 处理数据的service
     * @return void
     * @throws Exception
     */
    private function verifyAndDecrypt($service)
    {
        [
            $sReqMsgSig,
            $sReqTimeStamp,
            $sReqNonce,
        ] = [
            $this->request->get('msg_signature'),
            $this->request->get('timestamp'),
            $this->request->get('nonce'),
        ];

        if ($this->request->isGet()) {
            $sVerifyEchoStr = $this->request->get('echostr');
            $service->VerifyURL($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sVerifyEchoStr);
            exit();
        }

        if ($this->request->isPost()) {
            // 密文
            $sReqData = $this->request->getContent();

            $callbackUrl = $this->request->url();

            $decryptData = $service->decryptMsg($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sReqData);

            $logId = $service->addCallbackLog($sReqData, $decryptData, $callbackUrl);

            if (!empty($decryptData)) {
                $service->handleData($logId, xmlToArray($decryptData));
            }
        }

        echo 'success';
        exit();
    }
}
