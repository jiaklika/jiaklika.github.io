<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\groupMsg\impl\GroupMsgServiceImpl;
use app\api\validate\GroupMsgValidate;
use app\api\validate\PaginationValidate;
use Exception;

/**
 * Class groupMsg
 * @package app\api\controller
 */
class GroupMsg extends Base
{
    /**
     * ContactWay constructor.
     * @param GroupMsgServiceImpl $service
     */
    public function __construct(GroupMsgServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 新建群发
     *
     * @param GroupMsgValidate $validate
     */
    public function add(GroupMsgValidate $validate)
    {
        $msgData = $this->request->post();

        if (!$validate->scene('add')->check($msgData)) {
            Response::error($validate->getError());
        }

        if ($this->service->add($msgData)) {
            // write_manager_log('新建群发。任务名：' . $msgData['task_name']);
            Response::success('新建成功！');
        }

        Response::error('新建失败！');
    }

    /**
     * 编辑群发
     *
     * @param GroupMsgValidate $validate
     */
    public function edit(GroupMsgValidate $validate)
    {
        $msgData = $this->request->post();

        if (!$validate->scene('edit')->check($msgData)) {
            Response::error($validate->getError());
        }

        if ($this->service->edit($msgData)) {
            write_manager_log('编辑群发。ID：' . $msgData['template_id']);
            Response::success('编辑成功！');
        }

        Response::error('编辑失败！');
    }

    /**
     * 获取群发列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function getList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $groupMsgList = $this->service->getList($requestData);

        Response::success('success', $groupMsgList);
    }

    /**
     * 获取标签列表
     */
    public function getTagList()
    {
        $tagList = $this->service->getTagList();

        Response::success('success', $tagList);
    }

    /**
     * 获取查看详情的标签列表
     */
    public function getChooseTagList()
    {
        $templateId = $this->request->get('template_id');

        if (!$templateId) {
            Response::error('缺少参数！');
        }

        $tagList = $this->service->getChooseTagList($templateId);

        Response::success('success', $tagList);
    }

    /**
     * 获取群发消息详情
     *
     * @return void
     */
    public function getDetail()
    {
        $templateId = $this->request->get('template_id');

        if (!$templateId) {
            Response::error('缺少参数！');
        }

        $msgDetail = $this->service->getDetail($templateId);

        Response::success('success', $msgDetail);
    }

    /**
     * 查看群发消息执行结果
     *
     * @param PaginationValidate $pageValidate
     */
    public function getSendResult(PaginationValidate $pageValidate)
    {
        $searchInfo = $this->request->get();

        if (!$pageValidate->check($searchInfo)) {
            Response::error($pageValidate->getError());
        }

        if (
            !isset($searchInfo['template_id'])
            || !$searchInfo['template_id']
        ) {
            Response::error('参数错误！');
        }

        $sendResult = $this->service->getSendResult($searchInfo);

        Response::success('success', $sendResult);
    }

    /**
     * 发送提醒
     *
     * @return void
     */
    public function sendRemind()
    {
        if (!$templateId = $this->request->get('template_id')) {
            Response::error('缺少参数！');
        }

        if ($this->service->sendRemind($templateId)) {
            Response::success('发送提醒成功！');
        }

        Response::error('发送提醒失败！');
    }

    /**
     * 删除任务
     *
     * @return void
     */
    public function delete()
    {
        if (!$templateId = $this->request->get('template_id')) {
            Response::error('缺少参数！');
        }

        [$deleteRes, $msg] = $this->service->delete($templateId);

        if (!$deleteRes) {
            Response::error($msg);
        }

        write_manager_log('删除群发任务。ID：' . $templateId);
        Response::success($msg);
    }

    /**
     * 获取发送顾问列表
     *
     * @return void
     */
    public function getSenderList()
    {
        if (!$templateId = $this->request->get('template_id')) {
            Response::error('缺少参数！');
        }

        $keyword = $this->request->get('keyword');

        $senderList = $this->service->getSenderList($templateId, $keyword);

        Response::success('success', $senderList);
    }
}
