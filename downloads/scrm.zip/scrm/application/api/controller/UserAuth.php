<?php

namespace app\api\controller;

use app\api\service\userAuth\impl\UserAuthServiceImpl;

/**
 * Class UserAuth
 * @package app\api\controller
 */
class UserAuth extends Base
{
    /**
     * UserAuth constructor.
     * @param UserAuthServiceImpl $service
     */
    public function __construct(UserAuthServiceImpl $service)
    {
        parent::__construct($service);
    }


    /**
     *
     */
    public function callback()
    {
        [
            $code,
            $state
        ] =
        [
            $this->request->get('code'),
            $this->request->get('state')
        ];

        $this->service->handleCallback($code, $state);
    }
}
