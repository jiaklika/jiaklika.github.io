<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\kefu\impl\KefuServiceImpl;
use app\api\validate\KefuValidate;
use app\api\validate\PaginationValidate;

/**
 * 企微客服
 *
 * Class Kefu
 * @package app\api\controller
 */
class Kefu extends Base
{
    /**
     * Contact constructor.
     * @param KefuServiceImpl $service
     */
    public function __construct(KefuServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 上传临时素材
     */
    public function uploadMedia()
    {
        $file = $this->request->file('media');

        if (!$file) {
            Response::error('请选择上传文件！');
        }

        $fileName = explode('.', $file->getInfo('name'));
        $suffix = $fileName[1];
        if ($suffix == 'amr') {
            $type = 'audio';
        } else {
            $fileType = $file->getInfo('type');
            $type = substr($fileType, 0, strpos($fileType, '/'));
        }

        if (!in_array($type, ['image', 'video'])) {
            $type = $type == 'audio' ? 'voice' : 'file';
        }

        $res = $this->service->uploadMedia($type, $file);

        if ($res) {
            Response::success('上传成功！', $res);
        }

        Response::error('上传失败！', $res);
    }

    /**
     * 搜索员工
     */
    public function searchUser()
    {
        $keyword = $this->request->get('keyword');

        $userList = $this->service->searchUser($keyword);

        Response::success('success', $userList);
    }

    /**
     * 创建客服账号
     *
     * @param KefuValidate $validate
     */
    public function addAccount(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('add')->check($requestData)) {
            Response::error($validate->getError());
        }

        if ($this->service->addAccount($requestData)) {
            Response::success('创建客服账号成功！');
        }

        Response::success('创建客服账号失败！');
    }

    /**
     * 编辑客服账号
     *
     * @param KefuValidate $validate
     */
    public function editAccount(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('edit')->check($requestData)) {
            Response::error($validate->getError());
        }

        if ($this->service->editAccount($requestData)) {
            Response::success('编辑客服账号成功！');
        }

        Response::error('编辑客服账号失败！');
    }

    /**
     * 获取客服账号列表
     */
    public function getAccountsList()
    {
        $accountsList = $this->service->getAccountsList();

        Response::success('success', $accountsList);
    }

    /**
     * 获取客服账号详情
     */
    public function getAccountInfo()
    {
        $requestData = $this->request->get();

        if (!isset($requestData['open_kfid']) || !$requestData['open_kfid']) {
            Response::error('参数错误！');
        }

        $accountsList = $this->service->getAccountInfo($requestData);

        Response::success('success', $accountsList);
    }

    /**
     * 新建客服链接
     */
    public function addContactWay()
    {
        $requestData = $this->request->get();

        if ($res = $this->service->addContactWay($requestData)) {
            Response::success('生成客服链接成功！', $res);
        }

        Response::error('生成客服链接失败！');
    }

    /**
     * 删除客服账号
     */
    public function delAccount()
    {
        $openKfId = $this->request->get('open_kfid');

        if ($this->service->delAccount($openKfId)) {
            Response::success('删除客服账号成功！');
        }

        Response::error('删除客服账号失败！');
    }

    /**
     * 获取聊天列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function chatList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['open_kfid'])
            || !$requestData['open_kfid']
        ) {
            Response::error('参数错误！');
        }

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $accountsList = $this->service->chatList($requestData);

        Response::success('success', $accountsList);
    }

    /**
     * 初始化聊天记录
     */
    public function initChatRecords()
    {
        if ($this->service->initChatRecords()) {
            Response::success('初始化聊天记录成功！');
        }

        Response::error('初始化聊天记录失败！');
    }

    /**
     * 获取聊天记录
     */
    public function getChatRecords()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['chat_id'])
            || !$requestData['chat_id']
        ) {
            Response::error('参数错误！');
        }

        $accountsList = $this->service->getChatRecords($requestData);

        Response::success('success', $accountsList);
    }

    /**
     * 添加智能菜单
     */
    public function addMenu(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('add_menu')->check($requestData)) {
            Response::error($validate->getError());
        }


        if ($this->service->addMenu($requestData)) {
            Response::success('添加智能菜单成功！');
        }

        Response::error('添加智能菜单失败！');
    }

    /**
     * 编辑智能菜单
     */
    public function editMenu(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!isset($requestData['menu_id']) || !$requestData['menu_id']) {
            Response::error('参数错误！');
        }

        if (!$validate->scene('edit_menu')->check($requestData)) {
            Response::error($validate->getError());
        }
        [$res, $msg] = $this->service->editMenu($requestData);
        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 删除智能菜单
     */
    public function delMenu()
    {
        $menuId = $this->request->get('menu_id');

        if (!$menuId) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->delMenu($menuId);

        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 获取智能菜单详情
     */
    public function getMenuData()
    {
        $menuId = $this->request->get('menu_id');

        if (!$menuId) {
            Response::error('参数错误！');
        }

        $menuDetail = $this->service->getMenuData($menuId);

        Response::success('success', $menuDetail);
    }

    /**
     * 获取智能菜单列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function getMenuList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $menuList = $this->service->getMenuList($requestData);

        Response::success('success', $menuList);
    }

    /**
     * 添加关键词回复
     *
     * @param KefuValidate $validate
     */
    public function addKeywordReply(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('add_keyword')->check($requestData)) {
            Response::error($validate->getError());
        }

        [$res, $msg] = $this->service->addKeywordReply($requestData);

        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 编辑关键词回复
     *
     * @param KefuValidate $validate
     */
    public function editKeywordReply(KefuValidate $validate)
    {
        $requestData = $this->request->post();

        if (!isset($requestData['reply_id']) || !$requestData['reply_id']) {
            Response::error('参数错误！');
        }

        if (!$validate->scene('edit_keyword')->check($requestData)) {
            Response::error($validate->getError());
        }

        [$res, $msg] = $this->service->editKeywordReply($requestData);
        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 删除关键词回复
     */
    public function delKeywordReply()
    {
        $replyId = $this->request->get('reply_id');

        if (!$replyId) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->delKeywordReply($replyId);
        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 获取关键词回复详情
     */
    public function getKeywordReplyInfo()
    {
        $replyId = $this->request->get('reply_id');

        if (!$replyId) {
            Response::error('参数错误！');
        }
        $replyInfo = $this->service->getKeywordReplyInfo($replyId);
        Response::success('success', $replyInfo);
    }

    /**
     * 关键词列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function keywordList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $keywordList = $this->service->keywordList($requestData);

        Response::success('success', $keywordList);
    }

    /**
     * 智能菜单用关键词列表搜索
     */
    public function keywordListForSelect()
    {
        $query = $this->request->get('query');

        $keywordList = $this->service->keywordListForSelect($query);

        Response::success('success', $keywordList);
    }

    /**
     * 关键词用智能菜单列表搜索
     */
    public function menuListForSelect()
    {
        $query = $this->request->get('query');

        $keywordList = $this->service->menuListForSelect($query);

        Response::success('success', $keywordList);
    }

    /**
     * 获取分配方式
     */
    public function getReceptionRule()
    {
        $platform = $this->request->get('platform');

        if (!in_array($platform, [1,2,3])) {
            Response::error('参数错误！');
        }

        $receptionRule = $this->service->getReceptionRule($platform);

        Response::success('success', $receptionRule);
    }

    /**
     * 开启或关闭关键词
     */
    public function openReply()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['id'], $requestData['is_open_reply'])
            || empty($requestData['id'])
            || $requestData['is_open_reply'] == ''
        ) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->openReply($requestData);

        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 开启或关闭菜单
     */
    public function openMenu()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['id'], $requestData['is_open'])
            || empty($requestData['id'])
            || $requestData['is_open'] == ''
        ) {
            Response::error('参数错误！');
        }

        [$res, $msg] = $this->service->openMenu($requestData);

        if ($res) {
            Response::success($msg);
        }

        Response::error($msg);
    }

    /**
     * 记录添加个微
     */
    public function addWechatRecord()
    {
        $userId = $this->request->get('userId');
        if (!$userId) {
            send_msg_to_wecom('客服已加个微获取userId为空！');
            Response::error('未获取到客户信息！');
        }

        [$res, $msg] = $this->service->addWechatRecord($userId);
        if ($res) {
            Response::success($msg);
        }
        Response::error($msg);
    }

    /**
     * 获取企微客服链接
     */
    public function getLink()
    {
        $unionId = $this->request->get('union_id');

        Response::success('success', $this->service->getLink($unionId));
    }

    /**
     * 获取企微客服链接
     */
    public function getJewelryLink()
    {
        Response::success('success', $this->service->getJewelryLink());
    }

    /**
     * 是否咨询过
     */
    public function isConsult()
    {
        $requestData = $this->request->post();

        Response::success('success', $this->service->isConsult($requestData));
    }

    /**
     * 所有账号列表
     */
    public function getAllAccountSelectList()
    {
        Response::success('success', $this->service->getAllAccountSelectList());
    }
}
