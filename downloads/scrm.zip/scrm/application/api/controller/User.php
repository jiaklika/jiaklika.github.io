<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\user\impl\UserServiceImpl;
use app\api\validate\PaginationValidate;
use Exception;
use think\Log;

/**
 * 通讯录管理
 *
 * Class UserHttpDao
 * @package app\api\controller
 */
class User extends Base
{
    /**
     * User constructor.
     * @param UserServiceImpl $service
     */
    public function __construct(UserServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 读取并写入所有的部门
     *
     * @return void
     */
    public function initDepartmentList()
    {
        $insertRes = $this->service->getDepartmentList();

        if ($insertRes) {
            Response::success('读取并写入所有部门成功！');
        }

        Response::error('读取并写入所有部门失败！');
    }

    /**
     * 读取并写入所有的员工信息
     *
     * @throws Exception
     * @return void
     */
    public function initDepartmentMemberDetail()
    {
        $insertRes = $this->service->getDepartmentMemberDetail();

        if ($insertRes) {
            Response::success('读取并写入所有用户成功！');
        }

        Response::error('读取并写入所有用户失败！');
    }

    /**
     * 读取并更新所有配置了客户联系功能的员工
     *
     * @throws Exception
     * @return void
     */
    public function initFollowUserList()
    {
        $updateRes = $this->service->updateFollowUserList();

        if ($updateRes) {
            Response::success('更新配置了客户联系功能的员工成功！');
        }

        Response::error('更新配置了客户联系功能的员工失败！');
    }

    /**
     * 更新员工信息
     *
     * @throws Exception
     */
    public function updateUser()
    {
        /*$externalProfileParam = [
            [
                'type' => 2,
                'name' => '查看款式',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/pages/webview/index?id=1314',
                    'title'    => '👍比市面99%的款都好看'
                ]
            ],
            [
                'type' => 2,
                'name' => '新人有礼',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/pages/webview/index?id=1316',
                    'title'    => '🧧先领券，再购买，更划算'
                ]
            ],
            [
                'type' => 2,
                'name' => '每日秒杀',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/shop/seckill/index?fromId=10304',
                    'title'    => '🎁每天上午10点，拼手速'
                ]
            ],
            [
                'type' => 1,
                'name' => '服务保障',
                'web' => [
                    'url'   => 'https://mp.weixin.qq.com/s?__biz=MjM5NDMxMjU5Ng%3D%3D&mid=310235207&idx=1&sn=262feac227d05db536c515df463b2416',
                    'title' => '👌权威证书七天无理由退换'
                ]
            ]
        ];*/

        $externalProfileParam = [
            [
                'type' => 2,
                'name' => '新客必买',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/pages/webview/index?id=1314',
                    'title'    => '😍价格同百万级VIP一致'
                ]
            ],
            [
                'type' => 2,
                'name' => '每日秒杀',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/shop/seckill/index?fromId=10330',
                    'title'    => '🎁每天上午10点，拼手速'
                ]
            ],
            [
                'type' => 1,
                'name' => '服务保障',
                'web' => [
                    'url'   => 'https://mp.weixin.qq.com/s?__biz=MzAwNjIxODQxNw==&mid=502952379&idx=1&sn=982323ec2a84ad0d31ef5aaa802e70c4',
                    'title' => '👍权威证书七天无理由退换'
                ]
            ],
            [
                'type' => 2,
                'name' => '关于我们',
                'miniprogram' => [
                    'appid'    => 'wxf07cf3fb7e470a92',
                    'pagepath' => 'subpackage/pages/webview/webview?type=3',
                    'title'    => '🌹专注高端彩色宝石领域'
                ]
            ],
            [
                'type' => 2,
                'name' => '新人有礼',
                'miniprogram' => [
                    'appid'    => 'wx3378cc5758d57fb2',
                    'pagepath' => 'subpackage/pages/webview/index?id=1316',
                    'title'    => '🧧先领券，再购买，更划算'
                ]
            ]
        ];

        $userServiceImpl = new UserServiceImpl();
        /*$zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $zhaoweiAccounts = array_diff($zhaoweiAccounts, ['yangyang2','baojiejiayangyang9']);*/

        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        $feiyueAccounts = ['aning', 'xiaoqiao', 'baojiezhubaoguwenxiaoyu2'];

        foreach ($feiyueAccounts as $accountValue) {
            $updateRes = $this->service->updateUser($accountValue, $externalProfileParam);

            if ($updateRes) {
                Log::info(sprintf('更新员工%s信息成功！', $accountValue));
            } else {
                Log::error(sprintf('更新员工%s信息失败！', $accountValue));
            }
        }
        Response::success('更新员工信息执行完毕');
    }

    /**
     * 获取用户绑定列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function getUserBindList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $bindList = $this->service->getUserBindList($requestData);

        Response::success('success', $bindList);
    }

    /**
     * 获取用户绑定企微账号详情
     */
    public function getUserBindDetail()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['user_id'])
            || !$requestData['user_id']
        ) {
            Response::error('参数错误！');
        }

        $bindDetail = $this->service->getUserBindDetail($requestData['user_id']);

        Response::success('success', $bindDetail);
    }

    /**
     * 用户绑定企微账号
     */
    public function bindAccount()
    {
        $requestData = $this->request->post();

        if (
            !isset($requestData['account'])
            || !$requestData['account']
        ) {
            Response::error('请选择企微账号！');
        }

        [$bindRes, $bindMsg] = $this->service->bindAccount($requestData);

        if ($bindRes) {
            write_manager_log('用户绑定企微账号。账号：' . $requestData['user_id']);
            Response::success($bindMsg);
        }

        Response::error($bindMsg);
    }

    /**
     * 获取对外客服列表
     */
    public function getCustomerServiceList()
    {
        if ($customerServiceList = $this->service->getCustomerServiceList()) {
            Response::success('获取对外客服列表成功！', $customerServiceList);
        }
        Response::error('获取对外客服列表失败');
    }
}
