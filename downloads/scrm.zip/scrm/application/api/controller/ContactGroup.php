<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\message\GroupMsgHttpDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\service\contactGroup\impl\ContactGroupServiceImpl;
use app\common\model\ContactGroupMembers;
use Carbon\Carbon;
use Exception;
use think\Db;
use think\Log;

/**
 * Class ContactGroup
 * @package app\api\controller
 */
class ContactGroup extends Base
{
    /**
     * ContactGroup constructor.
     * @param ContactGroupServiceImpl $service
     */
    public function __construct(ContactGroupServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 初始化所有客户群列表
     */
    public function initContactGroupList()
    {
        $initRes = $this->service->initContactGroupList();

        if ($initRes) {
            Response::success('初始化所有客户群列表成功！');
        }

        Response::error('初始化所有客户群列表失败！');
    }

    /**
     * 初始化所有客户群成员信息
     */
    public function initContactGroupDetail()
    {
        $initRes = $this->service->initContactGroupDetail();

        if ($initRes) {
            Response::success('初始化所有客户群成员信息成功！');
        }

        Response::error('初始化所有客户群成员信息失败！');
    }

    /**
     * 初始化所有客户群列表和详情（不包括成员）
     */
    public function initContactGroupListAndDetail()
    {
        $initRes = $this->service->initContactGroupListAndDetail();

        if ($initRes) {
            Response::success('初始化所有客户群列表和详情（不包括成员）成功！');
        }

        Response::error('初始化所有客户群列表和详情（不包括成员）失败！');
    }

    /**
     * 初始化单个群的成员信息
     */
    public function initSingleGroupMember()
    {
        $chatId = $this->request->get('chat_id');

        $initRes = $this->service->initSingleGroupMember($chatId);

        if ($initRes) {
            Response::success('初始化群' . $chatId . '的成员信息成功！');
        }

        Response::error('初始化群' . $chatId . '的成员信息成功！');
    }

    /**
     * @throws Exception
     */
    public function downloadGroupExcel()
    {
        // Excel文件名
        $excelTitle = '宝姐新粉直播群6';

        $contactHttpDao = new ContactHttpDao();

        $chatId = 'wr5b2CBwAATfNUP4rexplW9TYpnvhxng';

        $groupMemberList = ContactGroupMembersDao::getAllList(
            [
                'unionid'
            ],
            [
                'chat_id'    => $chatId,
                'type'       => ContactGroupMembers::EXTERNAL_USER,
                'is_deleted' => 0
            ]
        );

        $unionIdArr = array_column($groupMemberList, 'unionid');

        $allContactData = [];

        foreach ($unionIdArr as $unionId) {
            $contactInfo = Db::name('contact_follow_user')
                ->alias('follow')
                ->field([
                    'contact.name',
                    'contact.gender'
                ])
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where([
                    'contact.unionid' => $unionId
                ])
                ->find();

            $contactData = [
                'name'    => $contactInfo['name'] ?? '',
                'gender'  => $contactInfo['gender'] ?? 0,
                'unionid' => $unionId
            ];

            $userCenterInfo = $contactHttpDao->getUserCenter($unionId);
            $liveRank = $contactHttpDao->getLiveRank($unionId);
            $yanzhiInfo = $contactHttpDao->getYanzhi($unionId);
            $appLastLogin = $contactHttpDao->getAppLastLoginTime($unionId);

            $userCenterData = [
                'nickname'             => $userCenterInfo['nickname'],
                'gender_center'        => $userCenterInfo['gender'],
                'birthday'             => $userCenterInfo['birthday'] ?: 0,
                'province'             => $userCenterInfo['province'],
                'city'                 => $userCenterInfo['city'],
                'user_level_name'      => $userCenterInfo['user_level_name'],
                'live_rank'            => $liveRank['level'],
                'yanzhi_total'         => $yanzhiInfo['yanzhi_total'],
                'score'                => $userCenterInfo['score'] ?? 0,
                'assistant_name'       => $userCenterInfo['assistant_name'],
                'first_consume_date'   => $userCenterInfo['first_consume_date'],
                'first_consume_amount' => $userCenterInfo['first_consume_amount'],
                'last_consume_date'    => $userCenterInfo['last_consume_date'],
            ];


            // 比较获取最后登录应用
            if (
                empty($yanzhiInfo['last_login'])
                && empty($liveRank['last_login'])
                && empty($appLastLogin['app_last_login'])
            ) {
                $userCenterData['last_login_time'] = $userCenterData['last_login_name'] = '暂无';
            } else {
                // 获取最后登录的应用
                $lastLoginArr = array_filter([
                    '宝姐家小程序'  => $yanzhiInfo['last_login'],
                    '宝姐珠宝小程序' =>  $liveRank['last_login'] ?? 0,
                    '宝姐家APP'    => $appLastLogin['app_last_login']
                ]);

                asort($lastLoginArr);

                $userCenterData['last_login_time'] = Carbon::createFromTimestamp(end($lastLoginArr))
                    ->toDateTimeString();

                $userCenterData['last_login_name'] = key($lastLoginArr);
            }

            $allContactData[] = array_merge($contactData, $userCenterData);
        }

        downloadExcelToLocal($excelTitle, function ($spreadsheet) use ($allContactData) {

            $cellValueMap = [
                'A1' => '昵称',
                'B1' => '性别',
                'C1' => '年龄',
                'D1' => '地域',
                'E1' => '会员等级',
                'F1' => '直播等级',
                'G1' => '颜值积分',
                'H1' => '宝币积分',
                'I1' => '销售助理',
                'J1' => '首单消费',
                'K1' => '最近消费',
                'L1' => '最近登录',
                'M1' => 'unionID',
            ];

            $cellValueFunc = function ($cellValueMap, $index) use ($spreadsheet) {
                foreach ($cellValueMap as $cellKey => $cellValue) {
                    $spreadsheet->setActiveSheetIndex($index)->setCellValue($cellKey, $cellValue);
                }
            };

            $cellValueFunc($cellValueMap, 0);

            // 重命名worksheet
            $spreadsheet->setActiveSheetIndex(0)->setTitle('群成员画像');

            foreach ($allContactData as $contactKey => $contact) {
                $excelKey = $contactKey + 2;

                $gender = '未知';

                if (isset($contact['gender'])) {
                    switch ($contact['gender']) {
                        case 0:
                        default:
                            break;

                        case 1:
                            $gender = '男';
                            break;

                        case 2:
                            $gender = '女';
                            break;
                    }
                }

                $name = '';

                if (isset($contact['name']) && !empty($contact['name'])) {
                    $name = $contact['name'];
                } else {
                    if (isset($contact['nickname']) && !empty($contact['nickname'])) {
                        $name = $contact['nickname'];
                    }
                }

                if (
                    !empty($name)
                    && $name == '=_='
                ) {
                    $name = '~_~';
                }

                if ($gender == '未知') {
                    if (isset($contact['gender_center']) && !empty($contact['gender_center'])) {
                        $gender = $contact['gender_center'];
                    }
                }

                // sheet0
                $sheet0ValueMap = [
                    'A' . $excelKey => $name,
                    'B' . $excelKey => $gender,
                    'C' . $excelKey => isset($contact['birthday']) ? getAge((int)$contact['birthday']) : '未知',
                    'D' . $excelKey => isset($contact['province']) ? $contact['province'] . $contact['city'] : '未知',
                    'E' . $excelKey => $contact['user_level_name'] ?? '新人',
                    'F' . $excelKey => $contact['live_rank'] ?? '',
                    'G' . $excelKey => $contact['yanzhi_total'] ?? '',
                    'H' . $excelKey => $contact['score'] ?? '',
                    'I' . $excelKey => $contact['assistant_name'] ?? '',
                    'J' . $excelKey => $contact['first_consume_amount']
                        ? $contact['first_consume_amount'] . '元 ' . $contact['first_consume_date']
                        : '',
                    'K' . $excelKey => $contact['last_consume_date'] ?? '', //  最近消费
                    'L' . $excelKey => $contact['last_login_name'] . $contact['last_login_time'],
                    'M' . $excelKey => $contact['unionid'] ?? '',
                ];

                $cellValueFunc($sheet0ValueMap, 0);
            }

            $columnFormat = [
                'A' => 12,
                'J' => 23,
                'K' => 20,
                'L' => 30,
                'M' => 30
            ];

            $columnFormatFunc = function ($columnFormat) use ($spreadsheet) {
                foreach ($columnFormat as $columnKey => $columnWidth) {
                    $spreadsheet->getActiveSheet()
                        ->getColumnDimension($columnKey)
                        ->setWidth($columnWidth);
                }
            };

            $columnFormatFunc($columnFormat);
        });
    }

    /**
     * 客户群opengid转换
     *
     */
    public function transferOpenGid()
    {
        $requestInfo = $this->request->post();

        if (
            !isset($requestInfo['open_gid'])
            || !isset($requestInfo['open_time'])
            || !isset($requestInfo['program_type'])
            || !isset($requestInfo['path'])
        ) {
            Response::error('参数错误！');
        }

        $transferRes = $this->service->transferOpenGid($requestInfo);

        if ($transferRes) {
            Response::success('转换成功！');
        }

        Response::error('转换失败！');
    }

    /**
     * @throws Exception
     */
    public function countJoinGroup()
    {
        [
            $creator,
            $beginTime,
            $endTime
        ] = [
            'yangyang2',
            strtotime('2021-12-10 12:32:00'),
            strtotime('2021-12-16 10:00:00')
        ];
        $groupMsgHttpDao = new GroupMsgHttpDao();

        $groupMsgListArr = $groupMsgHttpDao->getGroupMsgList(
            $creator,
            $beginTime,
            $endTime
        );

        if ($groupMsgList = $groupMsgListArr['group_msg_list']) {
            foreach ($groupMsgList as $value) {
                $sendResult = $groupMsgHttpDao->getGroupMsgSendResult(
                    $value['msgid'],
                    $creator
                );

                if ($sendList = $sendResult['send_list']) {
                    $sendTime = array_unique(array_column($sendList, 'send_time'));
                    $externalUserIdArr = array_column($sendList, 'external_userid');
                    $joinGroupCount = ContactGroupMembersDao::getCount([
                        'userid'    => ['in', $externalUserIdArr],
                        'join_time' => ['>', $sendTime[0]]
                    ]);
                    $quitGroupCount = ContactGroupMembersDao::getCount([
                        'userid'    => ['in', $externalUserIdArr],
                        'join_time' => ['>', $sendTime[0]],
                        'is_deleted' => 1
                    ]);
                    Log::info(count($externalUserIdArr) . '进群：' . $joinGroupCount . '；退群：' . $quitGroupCount);
                }
            }
        }
    }
}
