<?php

namespace app\api\controller;

use app\api\common\Response;
use Exception;
use think\Db;
use think\Log;
use think\Queue;

/**
 * Class ContactTransfer
 * @package app\api\controller
 */
class ContactTransfer extends Base
{
    /**
     * 转移客户
     *
     * @throws Exception
     */
    public function transferContact()
    {
        $followUserArr = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'unionid',
                'follow.external_userid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => 'fuliguan',
                'status' => 0
            ])
            ->limit(0, 500)
            ->select();

        // 队列名
        $jobQueue = 'transfer_contact_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\TransferContactJob';

        foreach ($followUserArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('success');
    }
}
