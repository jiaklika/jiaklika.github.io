<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\living\impl\LivingServiceImpl;
use app\api\service\message\impl\MessageServiceImpl;
use think\cache\driver\Redis;

/**
 * Class Living
 * @package app\api\controller
 */
class Living extends Base
{
    /**
     * Living constructor.
     * @param LivingServiceImpl $service
     */
    public function __construct(LivingServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     *
     */
    public function initUserLivingInfo()
    {
        $res = $this->service->initUserLivingInfo('yangyang123');

        if ($res) {
            Response::success('初始化成功！');
        }

        Response::error('初始化失败！');
    }
}
