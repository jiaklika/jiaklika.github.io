<?php

declare(strict_types=1);

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\moment\impl\MomentServiceImpl;
use app\api\validate\MomentValidate;
use app\api\validate\PaginationValidate;

/**
 * Class Moment
 * @package app\api\controller
 */
class Moment extends Base
{
    /**
     * Moment constructor.
     * @param MomentServiceImpl $service
     */
    public function __construct(MomentServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 创建发表任务
     */
    public function addMomentTask(MomentValidate $validate)
    {
        $momentData = $this->request->post();

        /*if (!$validate->scene('add')->check($momentData)) {
            Response::error($validate->getError());
        }*/

        if ($this->service->addMomentTask($momentData)) {
            //write_manager_log('新建朋友圈群发。任务名：' . $momentData['task_name']);
            Response::success('新建朋友圈群发任务成功！');
        }

        Response::error('新建朋友圈群发任务失败！');
    }

    /**
     * 获取朋友圈群发任务列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function getMomentTaskList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $momentTaskList = $this->service->getMomentTaskList($requestData);

        Response::success('success', $momentTaskList);
    }

    /**
     * 获取朋友圈群发任务详情
     *
     * @return void
     */
    public function getMomentTaskDetail()
    {
        $momentTaskId = $this->request->get('moment_task_id');

        if (!$momentTaskId) {
            Response::error('缺少参数！');
        }

        $momentTaskDetail = $this->service->getMomentTaskDetail((int)$momentTaskId);

        Response::success('success', $momentTaskDetail);
    }

    /**
     * 初始化获取所有朋友圈
     */
    public function initAllMoment()
    {
        $res = $this->service->initAllMoment();

        if ($res) {
            Response::success('初始化成功！');
        }

        Response::error('初始化失败！');
    }

    /**
     * 获取查看详情的标签列表
     */
    public function getChooseTagList()
    {
        $momentTaskId = $this->request->get('moment_task_id');

        if (!$momentTaskId) {
            Response::error('缺少参数！');
        }

        $tagList = $this->service->getChooseTagList((int)$momentTaskId);

        Response::success('success', $tagList);
    }

    /**
     *
     */
    public function uploadAttachment()
    {
        $file = $this->request->file('moment_file');

        if (!$file) {
            Response::error('请选择上传文件！');
        }

        $fileType = $file->getInfo('type');

        $type = substr($fileType, 0, strpos($fileType, '/'));

        if (!in_array($type, ['image', 'video'])) {
            Response::error('只允许上传图片或视频！');
        }

        $fileType = $this->request->post('file_type');

        if (!in_array($fileType, ['image', 'video'])) {
            Response::error('只允许上传图片和视频！');
        }

        $res = $this->service->uploadAttachment($file, $fileType);

        if ($res) {
            Response::success('上传成功！', $res);
        }
        Response::error('上传失败！');
    }

    /**
     * 删除任务
     *
     * @return void
     */
    public function delete()
    {
        if (!$momentTaskId = $this->request->get('moment_task_id')) {
            Response::error('缺少参数！');
        }

        [$deleteRes, $msg] = $this->service->delete((int)$momentTaskId);

        if (!$deleteRes) {
            Response::error($msg);
        }

        // write_manager_log('删除朋友圈群发任务。ID：' . $momentTaskId);
        Response::success($msg);
    }
}
