<?php

declare(strict_types=1);

namespace app\api\controller;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\http\contactFission\ContactFissionHttpDao;
use app\api\dao\http\kefu\KefuHttpDao;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFissionRecordsDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\data\PushFansDao;
use app\api\dao\mysql\data\StatisticalDataDao;
use app\api\dao\mysql\kefu\KefuAccountsDao;
use app\api\dao\mysql\kefu\KefuChatListDao;
use app\api\dao\mysql\kefu\KefuChatRecordsDao;
use app\api\dao\mysql\kefu\KefuKeywordMapDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyAttachmentsDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyDao;
use app\api\dao\mysql\kefu\KefuKeywordUserMapDao;
use app\api\dao\mysql\kefu\KefuMsgLogDao;
use app\api\dao\mysql\kefu\KefuMsgMenuDao;
use app\api\dao\mysql\kefu\KefuServiceRecordsDao;
use app\api\dao\mysql\kefu\KefuServicerMapDao;
use app\api\dao\mysql\log\MqLogsDao;
use app\api\dao\mysql\user\UserDao;
use app\api\dao\mysql\way\ChannelWelcomeMsgDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\dao\mysql\way\WayUserMapDao;
use app\api\service\contactFission\impl\ContactFissionServiceImpl;
use app\api\service\user\impl\UserServiceImpl;
use app\api\util\FileManager;
use app\api\util\HttpClient;
use app\common\model\CallbackLogs;
use app\common\model\ContactChannels;
use app\common\model\ContactFissionRecords;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactTags;
use app\common\model\ExternalContact;
use app\common\model\groupMsg\GroupMsgTemplates;
use app\common\model\kefu\KefuChatList;
use app\common\model\kefu\KefuChatRecords;
use app\common\model\TemporaryMedia;
use Carbon\Carbon;
use Closure;
use ReflectionClass;
use think\Cache;
use think\Db;
use think\Exception;
use think\File;
use think\Log;
use think\Queue;

class Test
{
    public function testSql()
    {
        $userService    = new UserServiceImpl();

        $feiyueAccounts  = (array)$userService->getSpecificUserAccount('feiyue', false);

        $allUnionId = ['owTq1jsYlWnjgrdW0jwYZ1AKZZFk'];

        $where = [
            'b.owner'      => ['in', $feiyueAccounts],
            'a.is_deleted' => ContactGroups::NOT_DELETED,
            'b.is_deleted' => ContactGroupMembers::NOT_DELETED
        ];

        $where['unionid'] = $allUnionId ? ['in', $allUnionId] : null;

        $a = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'left')
            ->field([
                'unionid'
            ])
            ->where($where)
            ->group('unionid')
            ->select();

        echo Db::name('contact_group_members')->getLastSql();

        print_r($a);
        die;

        $a = 1;

        switch ($a) {
            case 1:
                foreach ([10,20,30] as $value) {
                    echo $value;
                    echo '--';
                    if ($value == 20) {
                        break;
                    }
                }
                echo '123456';
                break;

            case 2:
                echo 123;
                break;
        }

        die;

        $a = 0;

        if ($a !== '') {
            echo '哈哈';
        } else {
            echo '呼呼';
        }

        die;

        /*$joinTaskGroupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'    => ['like', '%宝姐家颜值铜粉%'],
                'chat_id' => ['<>', 'wr5b2CBwAAYX6DdzqEaTp0Pu-wsbORSQ'] // 宝姐家颜值铜粉26群
            ]
        );

        print_r($joinTaskGroupList);*/

        if (
            Db::name('contact_group_members')
            ->alias('member')
            ->field(['member.id'])
            ->join(
                'scrm_contact_groups group',
                'member.chat_id = group.chat_id',
                'LEFT'
            )
            ->where([
                'member.unionid'    => 'owTq1jvAwXcPuienKlJp_JTMwrxQ',
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
            ])
            ->select()
        ) {
            echo 123;
        } else {
            echo 456;
        }
        die;

        $joinTaskGroupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'    => ['like', '%宝姐家颜值铜粉%'],
                'chat_id' => ['<>', 'wr5b2CBwAAkOhe2wgTIELAE69DDV0lMA'], // 宝姐家颜值铜粉30群
                'owner'   => 'xixi'
            ]
        );

        print_r($joinTaskGroupList);
    }

    public function testException()
    {
        $a = 10;
        try {
            if ($a  > 1) {
                throw new Exception('hahah');
            }
        } catch (\Exception $e) {
            print_r($e->getTraceAsString());
        }
    }

    /**
     * 测试MQ
     *
     */
    public function testMQ()
    {
        /*$a = '{"id":69796,"mobile":"18636726596","type":1,"user_level":3,"user_level_name":"\u94c1\u6746\u5b9d\u8ff7","contract_amount_tag":"(5000,\u221e"}';*/

        /*$a = '{"id":69796,"mobile":"18636726596","type":2,"user_level":3,"user_level_name":"\u94c1\u6746\u5b9d\u8ff7","contract_amount_tag":"(5000,\u221e"}';*/

        $a = '{"id":69703,
        "mobile":"13612365622,13531262171",
        "type":1,"user_level":2,
        "user_level_name":"\u5fe0\u5b9e\u5b9d\u8ff7",
        "contract_amount_tag":"(5000,\u221e"}';

        $arrA = json_decode($a, true);

        $messages = [$arrA];

        /*$getNewTagArrClosure = function ($groupId, $otherField) {
            $fields = ['tag_id'];
            array_push($fields, $otherField);
            $tagArr = ContactTagsDao::getAllList($fields, [
                'group_id' => $groupId
            ]);

            $newTagArr = [];

            foreach ($tagArr as $tag) {
                $newTagArr[$tag[$otherField]] = $tag['tag_id'];
            }
            return $newTagArr;
        };

        [
            $contactTagHttpDao,
            $contactHttpDao,
            $levelTagArr,
            $consumeTagArr
        ] =
        [
            new ContactTagHttpDao(),
            new ContactHttpDao(),
            $getNewTagArrClosure('et5b2CBwAAkSMm5yU8poo265T8Ctpc6w', 'tag_order'),
            $getNewTagArrClosure('et5b2CBwAAm6Vyw5uJwhrHyMtrsvZ_qw', 'tag_name')
        ];

        foreach ($messages as $messageData) {
            if ($messageData['mobile']) {
                $mobileArr = explode(',', $messageData['mobile']);

                foreach ($mobileArr as $mobile) {
                    $userCenterData = $contactHttpDao->getUserCenterByMobile($mobile);

                    if ($userCenterData['unionId']) {
                        // 这个客户目前的客服
                        $followUserArr = Db::name('contact_follow_user')
                            ->alias('follow')
                            ->field([
                                'contact.external_userid',
                                'follow.userid'
                            ])
                            ->join(
                                'scrm_external_contact contact',
                                'follow.external_userid = contact.external_userid',
                                'LEFT'
                            )
                            ->where([
                                'unionid' => $userCenterData['unionId'],  // 当前客户
                                'status'  => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]
                            ])
                            ->select();



                        if ($followUserArr) {
                            $allUserIdArr = array_column((array)$followUserArr, 'userid');


                            if ($messageData['type'] == 1) { // 用户等级变化
                                $removeTags = array_values($levelTagArr);

                                $addTag = $levelTagArr[$messageData['user_level']];


                                // 更改等级
                                $contactUpdateRes = ContactDao::updateData(
                                    [
                                        'user_level_id' => $messageData['user_level']
                                    ],
                                    [
                                        'unionid' => $userCenterData['unionId']
                                    ]
                                );

                                if ($contactUpdateRes === false) {
                                    send_msg_to_wecom(
                                        sprintf(
                                            '%s-修改等级为-%s-失败',
                                            $userCenterData['unionId'],
                                            $messageData['user_level']
                                        )
                                    );
                                }
                            } else {
                                $removeTags = array_values($consumeTagArr);

                                $addTag = $consumeTagArr[$messageData['contract_amount_tag']];
                            }

                            $removeTagRes = $addTagRes = false;
                            $insertTagData = [];
                            // 一个客户的所有客服的标签都要变
                            foreach ($followUserArr as $followUser) {
                                // 移除
                                $removeTagRes = $contactTagHttpDao->markTag(
                                    $followUser['userid'],
                                    $followUser['external_userid'],
                                    [],
                                    $removeTags
                                );
                                // 添加
                                $addTagRes = $contactTagHttpDao->markTag(
                                    $followUser['userid'],
                                    $followUser['external_userid'],
                                    [$addTag]
                                );
                                // 删除旧的,新的入表
                                $insertTagData[] = [
                                    'tag_id'          => $addTag,
                                    'external_userid' => $followUser['external_userid'],
                                    'userid'          => $followUser['userid']
                                ];
                            }
                            if ($removeTagRes && $addTagRes) {
                                $deleteRes = ContactTagMapDao::hardDelete([
                                    'external_userid' => $followUserArr[0]['external_userid'],
                                    'tag_id'          => ['in', $removeTags],
                                    'userid'          => ['in', $allUserIdArr]
                                ]);

                                $addRes = ContactTagMapDao::addBatchData($insertTagData);

                                if ($deleteRes === false || !$addRes) {
                                    send_msg_to_wecom('更改表失败!');
                                }
                            }
                        }
                    }
                }
            }
        }*/
    }


    public function testTag()
    {
        $processingSender = Db::name('group_msg_id_map')
            ->field([
                'template_id',
                'sender_user_id'
            ])
            ->where([
                'template_id'   => ['in', [1,2,3]],
                'is_get_result' => 0
            ])
            ->group('sender_user_id')
            ->select();

        $newProcessingSender = [];

        foreach ($processingSender as $senderVal) {
            $newProcessingSender[$senderVal['template_id']][] = $senderVal['sender_user_id'];
        }

        print_r($processingSender);
        die;


        $a = '';
        $b = 'hahah';

        $c = array_filter([$a, $b]);

        print_r($c);
    }

    public function testGroup()
    {
        $joinTaskGroupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'    => ['like', '%宝姐家颜值铜粉%'],
                'chat_id' => ['<>', 'wr5b2CBwAAkOhe2wgTIELAE69DDV0lMA'], // 宝姐家颜值铜粉30群
                'owner'   => 'xixi'
            ]
        );

        $member['join_scene'] = 3;
        $member['unionid']  = 'owTq1jiM_5fqKsWcxjltHOrJbHr8';

        $joinTaskGroupIdArr = array_column($joinTaskGroupList, 'chat_id');

        $chatId = 'wr5b2CBwAAqrZgMo0BMHBB23NNfm_5gw';

        if (
            isset($member['unionid'])
            && in_array($chatId, $joinTaskGroupIdArr)
            && $member['join_scene'] == ContactGroupMembers::SCAN_QRCODE
        ) {
            send_msg_to_wecom($member['unionid'] . '-进群了');
            //$webHookHttpDao = new WebHookHttpDao();
            //$webHookHttpDao->noticeKoContactEvent($member['unionid']);
        }
    }

    public function testNum()
    {
        $a = [
            'group_id' => 'et5b2CBwAAhdxSELLTK9WEjrqPaoi8Cg',
            'tag' => [[
                'name' => 'ceshi'
            ]]
        ];

        $json = json_encode($a);

        echo $json;
        die;


        $a = null;

        if ($a < 99) {
            echo 'null小于99';
        } else {
            echo 'null大于99';
        }

        $ninetyDaysAgo = strtotime(date('Y-m-d', strtotime('-3 months')));
        echo $ninetyDaysAgo;

        /*if(Db::name('contact_group_members')
            ->alias('member')
            ->field(['member.id'])
            ->join('scrm_contact_groups group',
                'member.chat_id = group.chat_id',
                'LEFT')
            ->where([
                'member.unionid'    => 'owTq1jnlCdPA-F3rsItkj5rFasYw123',
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
            ])
            ->select())
            echo '进群了';
        else
            echo '没进群';*/
        $a = 0.0;

        if ($a != 0) {
            echo '0.0不等于0';
        } else {
            echo '0.0等于0';
        }
    }

    public function testDownload()
    {
        $mediaHttpDao = new MediaHttpDao();
        /*$mediaHttpDao->downloadMedia('WWCISP_7e1I_242Jt5ssnMYeM842N703PkAVR2KO8DVphB1M87ghFpLvRbDZN17ioZFZnrW1YStiGt8s2bkeWHOJYU52Tzxkq0KFKEsdxBThAn3MQMUBTnv0GcqHfGijKVehYoIRUgwYr_qE1beJwjzewdNTSWhFcC1duqGUafGVmZ0vJ3lKw9uHRX2VlLW3qguEZsKHgrieVWD5Q5nSfXQVsCCCW0jahrgYYwqr5fPWVNFYIT7tjekA6JORGxZeBVkL_53A_nvB-g_Jiuev3JNYlbg_qSmdv3DiwGsACUWiR6nnWsEdFr4PTsjFmU2TCo9kJqcdVLOTbM_XskIEKw0ktvC6asnoG5kAQ8XKin4rMTyYP1-dWsrtCdzOekQtZ4gnCDleHwm3t9ZyyeOhD9Fp7CXEOBvH3uAxtYsRMnCgyDK2FNhnHa3flCp-uG8zPeKLElzyxQwVbT-RQv4oimDoORcygteafwEtNSn1N-AO2GqVDnUbF93iEOV9u8JCCquEc-A58zbLcLfP0CjrLCzS57_TtX5pHEnHLa7y2WbDJmKBVhzwzwUq9mEeINmV60JqgF4Oa2jWtYqmmDVVmefgjRN5i4lgsewY4pAQs-NDYDTNSYWwEVCo_MZO1KHTsqcHQ58UA3rcf6OQz9krx9CZnzD-_p9sGZOAKty4xmj4VajJ3UunI2yV9CDaSoh5VTeE44M1Ex9j-J41taxjo8IGVcip2gGEaC3PStjV-UfgI72oz0', 'mp4');*/
    }

    public function transferData()
    {
        $wayList = ContactWaysDao::getAllList(
            [
                'id as way_id',
                'user_id',
            ]
        );

        print_r($wayList);


        WayUserMapDao::addBatchData($wayList);
    }

    public function testData()
    {
        /*$redis = Cache::store()->handler();

        $newGroupClosure = function ($groupId, $groupName) use ($redis) {
            $tagMap = [];
            $groupTagData = ContactTagsDao::getAllList(['tag_order', 'tag_id'], [
                'group_id'       => $groupId,
                'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
            ]);

            foreach ($groupTagData as $tag) {
                $tagMap[$tag['tag_order']] = $tag['tag_id'];
            }

            $redis->hset(ContactTags::CALLBACK_REDIS_SET_KEY, $groupName, json_encode($tagMap));

            return $tagMap;
        };

        $getDataFromRedis = function ($name) use ($redis) {
            return ($json = $redis->hget(ContactTags::CALLBACK_REDIS_SET_KEY, $name)) ? json_decode($json, true) : '';
        };

        $getTagArr = function ($groupId, $groupName) use ($getDataFromRedis, $newGroupClosure) {
            return $getDataFromRedis($groupName) ? : $newGroupClosure($groupId, $groupName);
        };

        [
            $levelTagMap,
            $yanzhiTagMap,
            $consumeTagMap
        ] =
        [
            $getTagArr('et5b2CBwAAkSMm5yU8poo265T8Ctpc6w', 'level'),
            $getTagArr('et5b2CBwAA2psCik_tcO25trr6X49JJw', 'yanzhi'),
            $getTagArr('et5b2CBwAAm6Vyw5uJwhrHyMtrsvZ_qw', 'consume')
        ];


        print_r($yanzhiTagMap);*/
    }

    public function testHash()
    {
        $dataArr = Db::name('group_msg_receive_map')
            ->field([
                'user_id',
                'external_userid'
            ])
            ->where([
                'template_id' => 1,
                'user_id'     => ['in', ['chebin','yuqing','yangyang1']]
            ])
            ->select();

        $newArr = [];
        foreach ($dataArr as $k => $val) {
            $newArr[$val['user_id']][] = $val['external_userid'];
        }

        print_r($newArr);
        die;
    }

    public function testQueue()
    {
        $where = [
            'tag.tag_id'    => ['in', ['et5b2CBwAAzhWXt799W2O4ADt4lwK-sw']],
            'follow.userid' => ['in', ['chebin']],
            'follow.status' => 0
        ];

        $a = Db::name('contact_follow_user')
            ->alias('follow')
            ->join('scrm_contact_tag_map tag', 'follow.external_userid = tag.external_userid', 'LEFT')
            ->field([
                'follow.id',
                'follow.userid',
                'follow.external_userid'
            ])
            ->where($where)
            ->chunk(1, function ($results) {
                if (!$results) {
                    return false;
                }

                echo 123;
                return true;
            }, 'follow.id');
        print_r($a);
        die;

        try {
            Queue::push('app\api\job\TestJob', ['hello' => 123], 'test_queue');
        } catch (\Exception $e) {
            file_put_contents('1.txt', $e->getMessage() . PHP_EOL, FILE_APPEND);
        }
    }

    public function testReturn()
    {
        $a = [];
        for ($i = 1; $i < 100; $i++) {
            $a[] = $i;
        }

        print_r($a);
        $b = [];

        foreach ($a as $item) {
            if ($a > 20) {
                $b[] = $a;
                return true;
            }
        }

        print_r($b);
    }

    public function testMerge()
    {
        /*$a = [10 => 2,3,4,5,6,7,8];
        $b = [1 => 9,'f','g','e','cvf'];

        $c = array_merge($a, $b);

        print_r($c);
        die;*/

        $tagMapArr = Db::name('contact_tag_map')
            ->alias('a')
            ->join('contact_tags b', 'a.tag_id = b.tag_id', 'LEFT')
            ->field([
                'b.tag_name'
            ])
            ->where([
                'a.external_userid' => 'wm5b2CBwAAPYJEZtEiyDVYFpwmA975Ng',
                'b.group_id'        => ContactTags::GROUP_ID_MAP[ContactTags::SOURCE_CHANNEL]
            ])
            ->select();

        $tagNameArr = array_column((array)$tagMapArr, 'tag_name');

        if ($tagNameArr > 0) {
            $tagNameArr = array_values(array_filter($tagNameArr, function ($val) {
                if ($val !== '未知渠道') {
                    return true;
                } else {
                    return false;
                }
            }));
        }

        $tagName = $tagNameArr[0] ?? '未知渠道';
        print_r($tagNameArr);
        die;
    }

    public function testConsumeTag()
    {
        $newConsumeTagMap = [];
        $groupTagData = ContactTagsDao::getAllList(['tag_order', 'tag_id', 'tag_name'], [
            'group_id'       => 'et5b2CBwAAAKGgQ-AvbuCAoR6XR2xGXQ',
            'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
        ]);

        foreach ($groupTagData as $tag) {
            $newConsumeTagMap[$tag['tag_name']] = $tag['tag_id'];
        }

        var_export($newConsumeTagMap);
    }

    public function testJoinGroup()
    {
        $contactArr = [

        ];

        $insertBatchData = [];

        foreach ($contactArr as $contact) {
            $isWeixin = Db::name('contact_group_members')
                ->field([
                    'id'
                ])
                ->where([
                    'unionid' => $contact,
                    'is_deleted' => 0
                ])
                ->find();


            $isSpecialGroupMemberClosure = function (string $groupName) use ($contact) {
                $isSpecialGroupMember = Db::name('contact_group_members')
                    ->alias('a')
                    ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                    ->field([
                        'a.id'
                    ])
                    ->where([
                        'b.name'       => ['like', "%{$groupName}%"],
                        'a.is_deleted' => 0,
                        'b.is_deleted' => 0,
                        'a.unionid'    => $contact
                    ])
                    ->find();

                return $isSpecialGroupMember ? '是' : '否';
            };

            $insertBatchData[] = [
                'unionid'       => $contact,
                'is_weixin'     => $isWeixin ? '是' : '否',
                'is_new_fans'   => $isSpecialGroupMemberClosure('新粉福利'),
                'is_good_stuff' => $isSpecialGroupMemberClosure('好物优享')
            ];
        }

        Db::name('join_group')->insertAll($insertBatchData);

        die;
    }

    public function testVideo()
    {
        $fileManager = new FileManager();

        $file = request()->file('file1');


        // $fileManager->uploadMedia('mp4', $file);
    }

    /**
     * 发送欢迎语
     *
     * @throws \Exception
     */
    public function sendWelcomeMsg()
    {

        $channelFields = [
            'id',
            'is_open_welcome',    // 是否开启欢迎语 0-否 1-是
            'is_distinguish_time' // 是否区分时段 0-否 1-是
        ];

        $channelWhere = [
            'id'         => 58,
            'is_deleted' => ContactChannels::NOT_DELETE
        ];

        // 从渠道表找出预置的欢迎语
        $channelInfo = ContactChannelsDao::getDetail($channelFields, $channelWhere);

        // 渠道存在且开启了欢迎语
        if ($channelInfo && $channelInfo['is_open_welcome'] == 1) {
            // 寻找当前时间段的欢迎语
            $welcomeMsgFields = [
                'id',
                'welcome_text',
                'attachments'
            ];

            $welcomeMsgWhere = [
                'channel_id' => $channelInfo['id'],
            ];

            // 区分时段就添加时段搜索条件
            /*if ($channelInfo['is_distinguish_time']) {
                $welcomeMsgWhere['is_working_time'] = is_work_time(123);
            }*/

            $welcomeMsgData = ChannelWelcomeMsgDao::getDetail($welcomeMsgFields, $welcomeMsgWhere);


            $newAttachmentsJson = [];
            if ($attachmentsJson = $welcomeMsgData['attachments']) {
                $attachmentsArr = json_decode($attachmentsJson, true);

                $fileManager = new FileManager();

                foreach ($attachmentsArr as $key => $attachment) {
                    switch ($attachment['welcome_type']) {
                        case 1:
                            $fileData = [
                                'id'          => $welcomeMsgData['id'],
                                'key'         => $key,
                                'create_time' => $attachment['miniprogram_pic_create_time'],
                                'media_url'   => $attachment['miniprogram_pic_url'],
                                'media_id'    => $attachment['miniprogram_pic_media_id']
                            ];

                            $suffix = substr(
                                $attachment['miniprogram_pic_url'],
                                strrpos($attachment['miniprogram_pic_url'], '.') + 1
                            );

                            $newAttachmentsJson[$key]['msgtype'] = 'miniprogram';
                            $newAttachmentsJson[$key]['miniprogram'] = [
                                'title'        => $attachment['miniprogram_title'],
                                'pic_media_id' => $this->getMediaId(
                                    'image',
                                    $fileData,
                                    $suffix,
                                    $attachmentsArr,
                                    $fileManager
                                ),
                                'appid'        => $attachment['miniprogram_appid'],
                                'page'         => $attachment['miniprogram_page']
                            ];
                            break;

                        case 2:
                            $newAttachmentsJson[$key]['msgtype'] = 'image';
                            $newAttachmentsJson[$key]['image'] = [
                                'pic_url' => $attachment['image_pic_url'],
                            ];
                            break;

                        case 3:
                            $newAttachmentsJson[$key]['msgtype'] = 'link';
                            $newAttachmentsJson[$key]['link'] = [
                                'title'  => $attachment['link_title'],
                                'picurl' => $attachment['link_pic_url'],
                                'desc'   => $attachment['link_desc'],
                                'url'    => $attachment['link_url']
                            ];
                            break;

                        case 4:
                            $fileData = [
                                'id'          => $welcomeMsgData['id'],
                                'key'         => $key,
                                'create_time' => $attachment['video_create_time'],
                                'media_url'   => $attachment['video_url'],
                                'media_id'    => $attachment['video_media_id']
                            ];
                            $newAttachmentsJson[$key]['msgtype'] = 'video';
                            $newAttachmentsJson[$key]['video'] = [
                                'media_id' => $this->getVideoMediaId(
                                    'video',
                                    $fileData,
                                    $attachmentsArr,
                                    $fileManager
                                )
                            ];
                            break;
                    }
                }
            }
            $contactHttpDao = new ContactHttpDao();
            $contactHttpDao->sendWelcomeMsgToContact(
                'CALLBACK_CODE',
                '文本消息内容',
                $newAttachmentsJson
            );

            die;
        }
    }

    /**
     * 获取小程序的media_id
     *
     * @param string $mediaType 文件类型
     * @param array $fileData 渠道欢迎语表的字段
     * @param string $suffix
     * @param array $attachments
     * @param FileManager $fileManager
     * @return mixed
     * @throws \Exception
     */
    private function getMediaId(
        string $mediaType,
        array $fileData,
        string $suffix,
        array $attachments,
        FileManager $fileManager
    ) {
        $updateFunc = function ($fileData, $uploadRes) use ($attachments) {

            foreach ($attachments as $key => &$singleAttachment) {
                if ($key == $fileData['key']) {
                    $singleAttachment['miniprogram_pic_media_id'] = $uploadRes['media_id'];
                    $singleAttachment['miniprogram_pic_create_time'] = $uploadRes['created_at'];
                    break;
                }
            }

            return ChannelWelcomeMsgDao::updateData(
                [
                    'attachments' => json_encode($attachments, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia($mediaType, $suffix, $fileData, $updateFunc);
    }

    /**
     * 获取小程序的media_id
     *
     * @param string $mediaType 文件类型
     * @param array $fileData 渠道欢迎语表的字段
     * @param array $attachments
     * @param FileManager $fileManager
     * @return mixed
     * @throws \Exception
     */
    private function getVideoMediaId(
        string $mediaType,
        array $fileData,
        array $attachments,
        FileManager $fileManager
    ) {
        $updateFunc = function ($fileData, $uploadRes) use ($attachments) {
            foreach ($attachments as $key => &$singleAttachment) {
                if ($key == $fileData['key']) {
                    $singleAttachment['video_media_id'] = $uploadRes['media_id'];
                    $singleAttachment['video_create_time'] = $uploadRes['created_at'];
                    break;
                }
            }

            return ChannelWelcomeMsgDao::updateData(
                [
                    'attachments' => json_encode($attachments, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia($mediaType, 'mp4', $fileData, $updateFunc);
    }

    /**
     *
     */
    public function test1()
    {
        $redis = Cache::store()->handler();

        // 从表里查找
        $newGroupClosure = function ($groupId, $groupName, $keyName) use ($redis) {
            $tagMap = [];
            $groupTagData = ContactTagsDao::getAllList(['tag_order', 'tag_id', 'tag_name'], [
                'group_id'       => $groupId,
                'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
            ]);

            foreach ($groupTagData as $tag) {
                $tagMap[$tag[$keyName]] = $tag['tag_id'];
            }

            $redis->hset(ContactTags::CALLBACK_REDIS_SET_KEY, $groupName, json_encode($tagMap));

            return $tagMap;
        };

        // redis是否有值
        $getDataFromRedis = function ($name) use ($redis) {
            return ($json = $redis->hget(ContactTags::CALLBACK_REDIS_SET_KEY, $name)) ? json_decode($json, true) : '';
        };

        // redis没值就从表里取
        $getTagArr = function ($groupId, $groupName, $keyName) use ($getDataFromRedis, $newGroupClosure) {
            return $getDataFromRedis($groupName) ? : $newGroupClosure($groupId, $groupName, $keyName);
        };

        $newConsumeTagMap = $getTagArr(
            ContactTags::GROUP_ID_MAP['new_contract_amount'],
            ContactTags::NEW_CONTRACT_AMOUNT,
            'tag_name'
        );

        print_r($newConsumeTagMap);
        die;
    }

    public function test134()
    {
        $userServiceImpl = new UserServiceImpl();
        $accountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $accountsGroupArr = ContactGroupDao::getAllList(['chat_id'], [
            'owner'      => ['in', $accountsArr],
            'is_deleted' => ContactGroups::NOT_DELETED
        ]);

        $nowGroupArr = ContactGroupMembersDao::getAllList(['chat_id'], [
            'userid'     => '123',
            'is_deleted' => ContactGroupMembers::NOT_DELETED
        ]);

        if (array_intersect(array_column($nowGroupArr, 'chat_id'), array_column($accountsGroupArr, 'chat_id'))) {
            return '';
        }

        return ContactTags::NOT_IN_GROUP_TAG['zhaowei'];
    }

    public function firstAdd()
    {
        $allUnionId = [
            0 => 'owTq1jg2rO9Yh0O5tzeJhMwrraMc',
            1 => 'owTq1jg_ODejORpXeDvrXq3hd9AA',
            2 => 'owTq1jhFxfiLI0tEHnoHu1ATTeoo',
            3 => 'owTq1jhwqXgZiPtRKimaSRUjXL4k',
            4 => 'owTq1ji0VKtmF_xeM7SnWZ0yr3Q4',
            5 => 'owTq1jiM98bgSTfr9WO0f4J-pCu0',
            6 => 'owTq1jjdaatrT55vgdXP9WX1JHug',
            7 => 'owTq1jjeL5uSwRL7d1OSQ1iSFecQ',
            8 => 'owTq1jjOMD4xTnrppoOdMCkzOcec',
            9 => 'owTq1jkgUNyyxeU6_8gSidqk6_4M',
            10 => 'owTq1jkOpbG_gvRuTbuaDcSkzlSw',
            11 => 'owTq1jksbFLTQoFp9fVBIlzHGgOY',
            12 => 'owTq1jkXjlepTps1j62iq1DAhViM',
            13 => 'owTq1jlxSVKYz_YYwzd3gBaLOXJo',
            14 => 'owTq1jm5CD9zOl0e8gdTjIwtmq0I',
            15 => 'owTq1jmDd9I9W-ApDqXFwbrllx7Q',
            16 => 'owTq1jn8m0yxLcIWWhxyX_tVtfvs',
            17 => 'owTq1jnZsN-Vc-wHknCLN2oa_oZE',
            18 => 'owTq1jo81N2GdIDYJYhEs3NN1Sk0',
            19 => 'owTq1joaZiirkY2uP7vDb7Olf2eQ',
            20 => 'owTq1joplhA4r5n9V10CoahGt10g',
            21 => 'owTq1joThxoNAqy8poVm8ca9Pm5I',
            22 => 'owTq1jqbNBenQP2HH8_0PEGbixQU',
            23 => 'owTq1jqS4foiXU-MhiU6Wkrm_F6Q',
            24 => 'owTq1jqUaHsloo9dxlHwthE2qoRs',
            25 => 'owTq1jreoehuYt0KfX_ppO-BF4Mg',
            26 => 'owTq1jspY1VDRTYZDUZbCIR079UM',
            27 => 'owTq1jtLY2tue6YZ1lEMKV3eouWw',
            28 => 'owTq1jtW0R3sV4rkwG6bXpVHDuBk',
            29 => 'owTq1juiJdT2jPJ2AaowaEQ7nQts',
            30 => 'owTq1juunVVvVbMBxxC4onH4wFe4',
            31 => 'owTq1juYdMpvQS-6A_RjZg5ulSH4',
            32 => 'owTq1jv3KJyhCRBXDWtAOD-ui2oc',
            33 => 'owTq1jvosmCvU2F_LCq1tec_uxew',
            34 => 'owTq1jvTDckpH81bzWTMF2UDYuYM',
        ];

        $getExternalContactArr = function (array $where = []) use ($allUnionId) {
            $externalContactArr = (array)Db::name('contact_follow_user')
                ->alias('a')
                ->join(
                    'external_contact b',
                    'a.external_userid = b.external_userid',
                    'left'
                )
                ->field([
                    'unionid'
                ])
                ->where(array_merge([
                    'unionid' => ['in', $allUnionId],
                    'status'  => ContactFollowUser::NORMAL
                ], $where))
                ->group('unionid')
                ->select();

            return array_column($externalContactArr, 'unionid');
        };

        // 当场直播首次添加企微的人
        $nowAddExternalContactUnionIdArr = $getExternalContactArr([
            //'state'         => ['in', [147]],
            'createtime'    => ['>', 1622804400],
            'b.update_time' => null
        ]);

        print_r($nowAddExternalContactUnionIdArr);
        die;
    }

    public function test234()
    {

        $a = (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field(['a.unionid'])
            ->where(function ($query) {
                $query->where('a.is_deleted', 0)->where('b.is_deleted', 0);
            })->whereOr(function ($query) {
                $query->where('b.name', 'like', "%好物优享%")
                    ->whereOr('b.name', 'like', "%新粉福利%")
                    ->whereOr('b.name', 'like', "%饰界福利秒杀%")
                    ->whereOr('b.name', 'like', "%优享福利%")
                    ->whereOr('b.name', 'like', "%周一至周五%")
                    ->whereOr('b.name', 'like', "%周一至五%");
            })
            ->group('a.unionid')
            ->select();

        echo Db::name('contact_group_members')->getLastSql();
        die;
        return $a;
    }

    /**
     *
     */
    public function test1234()
    {
        $a = ['owTq1jlb9ed-vGAOlzI6AZMlOxIo',
        'owTq1jkxQBVoL6ymn7J233z_-VhM',
        'owTq1jgDSubTzsPdFLOkCZEAfuvw',
        'owTq1jmmU87kFo0WhUXl6GwYN4QQ',
        'owTq1jvXNWVZ7YXlvAvIjkA0YM3o',
        'owTq1jgogg0zCEQrVQm7DZDFl-kE',
        'owTq1jgj07XvXo4YMN7rM-NZsFek',
        'owTq1jj_K05yor5ONdWARKD3X0wg',
        'owTq1jpfXVCb149qDx9Kf0XpYy14',
        'owTq1jtsz-odKSeN4Jr8u4-YUUnQ',
        'owTq1jrAMrLQeTw6n--Y3C3pqKeY',
        'owTq1jh-H4pu6I6tmah8oeHSEcig',
        'owTq1jnRfGSXVAGaleWJxv2a6kR0',
        'owTq1ji3tYOFX1LH2IYb5DCx2UW0',
        'owTq1jkbBeDjGeK4s43d6zVbVI4o',
        'owTq1jtbGKctIkuaTyEMAl8Yp7yY',
        'owTq1jmR505zz2ARj1W_rJkgFSE0',
        'owTq1jrUTDRAsYo4tpecjlqUDosI',
        'owTq1jucbG0CTyBohLRT1-1m-H98',
        'owTq1jun3lBSPa9fOkAugKTQQqyA',
        'owTq1jm8fJOlBK1Qkg4JVQRqXQWU',
        'owTq1jpUe7sVKThseQadJTDgz79A',
        'owTq1jiQOA2Sk4ytJZxRMUhA2asY',
        'owTq1jhVy1CGlpmim7NBCFdC7Q10',
        'owTq1jigmTjr8tKfN8X1Oe9konuw',
        'owTq1jk6ZjaOOwAsHILfkJbAsSwQ',
        'owTq1jva1EtGsDB2ThAJg3RHAvg4',
        'owTq1jpoZO-DvPEefsujxiHwtB2w',
        'owTq1jr2WS5zeuqRDUAZMUlXUrXg',
        'owTq1jjVIHeHMMZ013BE5by4Ut8E',
        'owTq1jqd5vdQWX9Egr9LUR4Nx7KI',
        'owTq1jnC7mgT_Yfc2IoKc3ZdUpkE',
        'owTq1jkXsjbXF8su4n216LKLot5E',
        'owTq1jhgdU-Rljf-Mba9UnTUyhAE',
        'owTq1jixzq139kkUQy-YPZyKNOoM',
        'owTq1jrcpjQlNvwK26LhF13hb-oE',
        'owTq1jtWycIdb8LmESMuQRbk5Eak',
        'owTq1jn5qMJ8-JmMAuABjUjUxRpI',
        'owTq1jlOOyPFtQ3koSWKho-t_2jY',
        'owTq1jh6eH8A2hlECy5GIajkrigg',
        'owTq1jqNsmLoqTCYN_FPe9j2QgbQ',
        'owTq1jjL5L0K_44vfHz8VSWiDjcs',
        'owTq1jlccZQKvxpdS--fQ4ZdghZY',
        'owTq1jksn_7PWU_mV0Pps0fm18qM',
        'owTq1juRZk27TqkFR5nbPw1e41NE',
        'owTq1jt5Q3V7dC7nBdAVEMSnDn5w',
        'owTq1jmiBsMER6oNK83qi-CVOaLI',
        'owTq1jkq6y4vSB2bda47_K8kA8s8',
        'owTq1jjlYrofIYh2rtG-liITpZfg',
        'owTq1jvitqJRd7jo34tCuwBuZjZA',
        'owTq1jhjqRQi2TJN5V_AMEl451rc',
        'owTq1joO6Ak0gS16VT0WCN5kJItc',
        'owTq1jlJ9f56FdXSIgLa10OO7RG0',
        'owTq1jvjo23d-e0xFGLH7IX37f-A',
        'owTq1jiYI8c6zH2awT3NtzUStEkQ',
        'owTq1jmgDdeoxbQ_Y2NwwAsYkOns',
        'owTq1jpWfyC4g-Unuz8uRDNoDDJU',
        'owTq1jpwRGyPkphm4luk8-BPf5xk',
        'owTq1jgGuWiXVs-u3HcV7kcyBjQI',
        'owTq1jlrwGAwXeD783hZ3-E2jXag',
        'owTq1jqlBrbPnjquo_Xqj27d2mVs',
        'owTq1jjd9dNwEeda1QSopQNi96Ko',
        'owTq1jgd6VQTy9R6-y2JV_YUOpGo',
        'owTq1jiX1-a4kuE_UOD_w4a0GMDs',
        'owTq1jjHxcJpooKqtBuLgR7N2mqk',
        'owTq1jh652Tqa1QP3ZHVFyPsi2_g',
        'owTq1ju_RMh5Xit16N0gC6dgMFCg',
        'owTq1jpJDaGdSeJjjTA-WHgCOs8g',
        'owTq1jnxc71_24lAGTNOP3rhbFm4',
        'owTq1jhA2uIog4nUv4V0tiIuEXc8',
        'owTq1jmctK7UyuRAWM5Dab-i5Wbo',
        'owTq1jkOBDegnh_XSU0qi5uq-_4g',
        'owTq1jpOyirBx1KgYQ0hmzCkLm1A',
        'owTq1jp9Y4cyS5x_1W5r4gTZygeI',
        'owTq1jsPsCcFr0ruZTPW1JKJ-cb4',
        'owTq1jmSFX3gSYwSO3yujyg2JB9g',
        'owTq1jnMBUY4Ovi-7K7J3Uv3BTK0',
        'owTq1jrEd0MksawfPaftIow4i2sc',
        'owTq1jrGOplrRWe68OlsIj4DpUrk',
        'owTq1jv2IbBcaq6BXf-DhdyIkftA',
        'owTq1jvJuyPhBMxZ5aGdY81eVL54',
        'owTq1jlq2dl7jUjv_qDBJlfbY44g',
        'owTq1jvnF9Rr67L0JbP0mrPkdX14',
        'owTq1jktb4BeQh5w8RVhgTzBOsjI',
        'owTq1jggNvz0eVBRCfI6iz1NBVqk',
        'owTq1juzu-QEoLI4ZtNgjSnPay0A',
        'owTq1jpzV749EipuLEFOEngojeI0',
        'owTq1jrOjdRCyZ0cAIjTgprocD7U',
        'owTq1jlylJUhosYrCwAsZSxnjrlo',
        'owTq1jj9pINgCdwD1urqqt4-tEYA',
        'owTq1jqdLKarLszFL5_hcMXSeDVc',
        'owTq1jkQLpsk4p1emzer5pImZiR4',
        'owTq1jsWvF8Wm4XmSF1DX9EGez_s',
        'owTq1juC-9v9rmePqxDC4EWdzoK8',
        'owTq1jqdWTPMNOQboUTbPTqjzuDk',
        'owTq1jgpJLc33YGk3A9ViDzEY-Ew',
        'owTq1jqbJJUhG8hPNhH6yNFAVMAM',
        'owTq1jtHZvkOWjuJEa1xOImzMzLk',
        'owTq1jtpGPMzXivbgWO5LJ_ITSgg',
        'owTq1juFyLGwUcVkEo3k2zLCmbxk',
        'owTq1jgw0f9fBV3_DoN1n2Wjn80A',
        'owTq1jg1fl6ScHOdp-1P2a3YKZ5I',
        'owTq1jvoS4BlfO4NB3Eyqou4LMKY',
        'owTq1jgsDMoQ126G5Ee3van8rzbw',
        'owTq1jkRtxK7XZNoXWYaqc-RbLbw',
        'owTq1jtOTl2BXzFh-gbXWd4utTWA',
        'owTq1ji9ROXhJ4-PjABodsQdN99c',
        'owTq1joDAt7S_mXNYku93fdXPosk',
        'owTq1jkio__WLWDJC3B43QFzRBn0',
        'owTq1jtMOw2YxoDuzkSMDqQD00Lo',
        'owTq1jngjY8vkdSixCvZSAfp_TDw',
        'owTq1jhdYsGAO4RnQHO9vH855CDQ',
        'owTq1jnF2g9RMue3hHDWhrbUMbFI',
        'owTq1jqgwVHCsmGkhi2eKPqnPDdY',
        'owTq1jhmJbmgOZxik_0OioDOg-X0',
        'owTq1jootaXf5pot0AFQ_umbtvl4',
        'owTq1jmzRjMX_wkCX1uIxoYv8VCk',
        'owTq1jljKhCxfRWrPJF7WY9Szu_E',
        'owTq1jqJLx15os9wIF3CAH0fCxlo'];


       /* foreach ($a as $unionId) {
            $res = Db::name('contact_group_members')
                ->alias('a')
                ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field([
                    'a.id'
                ])
                ->where([
                    'b.owner'      => ['in', ['yangyang123','yangyang1','yangyang4','yangyang3','yangyang5']],
                    'b.is_deleted' => 0,
                    'a.is_deleted' => 0,
                    'a.unionid'    => $unionId
                ])
                ->find();

            if ($res){
                echo $unionId.PHP_EOL;
            }
        }*/

        echo '------';

        foreach ($a as $value) {
            $res1 = Db::name('contact_follow_user')
                ->alias('follow')
                ->field(
                    [
                        'contact.unionid'
                    ]
                )
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where(
                    [
                        'status'  => ContactFollowUser::NORMAL, // 仍互为好友
                        'unionid' => $value
                    ]
                )
                ->find();

            if ($res1) {
                echo $value . PHP_EOL;
            }
        }
    }

    public function test456()
    {
        $purchaseData['union_id'] = [
            'owTq1jsvl8uA2VqgAmEbUn7DDjN0',
            'owTq1jkpUWWtey499QuoR4YNIpLs',
            'owTq1jvNQwydybLh7pJIXu8JYcDI',
            'owTq1juKl49q_qk4SiKpSwhR1SgM',
            'owTq1ji9ROXhJ4-PjABodsQdN99c',
            'owTq1jq6RWBo-b0OtBlAxqpLCiG4',
            '123',
            '3456',
            '5678',
            'owTq1jjuQq29YPhCHcLKX8Z4hgqQ'
        ];

        $beginTimeDate = date('Y-m-d 12:00:00');
        $beginTime     = strtotime($beginTimeDate);

        $allContact = ContactDao::getAllList(
            ['unionid'],
            [
                'unionid'     => ['in', $purchaseData['union_id']],
                'create_time' => ['<', $beginTimeDate]
            ]
        );

        $allContactUnionIdArr = array_column($allContact, 'unionid');

        $notContactUnionIdArr = array_diff($purchaseData['union_id'], $allContactUnionIdArr);

        $notContactCount = count($notContactUnionIdArr);

        $allGroupMemberCount = ContactGroupMembersDao::getCount([
            'unionid'   => ['in', $notContactUnionIdArr],
            'join_time' => ['<', $beginTime]
        ]);

        $newbieCount = $notContactCount - $allGroupMemberCount;

        print_r($newbieCount);
        die;
    }

    public function demo123()
    {
        $str = '{
	"errcode": 0,
	"errmsg": "ok",
	"next_cursor": "4gw7MepFLfgF2VC5nou",
	"msg_list": [{
		"msgid": "4Wizt8gDmUNeMPdj6upaAk9ef7XuV2gC6u8sdxEU5eSh",
		"send_time": 1634269523,
		"origin": 4,
		"msgtype": "event",
		"event": {
			"event_type": "enter_session",
			"scene": "",
			"open_kfid": "wk5b2CBwAAxYgo705Q_bKc0GWmA1Lt7A",
			"external_userid": "wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw",
			"welcome_code": "iXtddVREEhFQeOEx8Es2zVVKxWVF7Iqu4zn-tT1Hpp4"
		}
	}, {
		"msgid": "7ZAT5Pe9eJWeN9TtCC5LBHsGMAEc9Je5ueqfLQhySQa4",
		"send_time": 1634276661,
		"origin": 4,
		"msgtype": "event",
		"event": {
			"event_type": "enter_session",
			"scene": "",
			"open_kfid": "wk5b2CBwAAxYgo705Q_bKc0GWmA1Lt7A",
			"external_userid": "wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw",
			"welcome_code": "rmVbBxBBxJuzxGTDv1BXd8LK9wpKAXd0PQKqxrFBz0Q"
		}
	}, {
		"msgid": "4aiZ5rgzzN1J3sNu5RLAE4c6AGqMqCKPFt2zhWFjEcWE",
		"send_time": 1634277568,
		"origin": 4,
		"msgtype": "event",
		"event": {
			"event_type": "enter_session",
			"scene": "",
			"open_kfid": "wk5b2CBwAAxYgo705Q_bKc0GWmA1Lt7A",
			"external_userid": "wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw",
			"welcome_code": "1njtI2w42YnVYTz8E0Z0E4JCUJNN4zBCM3lhAD_Lukw"
		}
	}, {
		"msgid": "7pnxvRtZJQLNRTSP4RPyZKEjbjTVHxLStcyinhsFQbsG",
		"send_time": 1634277803,
		"origin": 4,
		"msgtype": "event",
		"event": {
			"event_type": "enter_session",
			"scene": "",
			"open_kfid": "wk5b2CBwAAxYgo705Q_bKc0GWmA1Lt7A",
			"external_userid": "wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw",
			"welcome_code": "JknAzugxocLPb51JuneE5hUVz21XmixvGd5yfNv15w0"
		}
	}],
	"has_more": 0
}';
        print_r(json_decode($str, true));
        die;
        // $todayZero = Carbon::now(-1)->startOfDay()->getTimestamp();

        $todayZero = strtotime(date('Y-m-d', strtotime('-1 days')));

        $totalGroupMembersArrClosure = function (array $ownerArr = []) use ($todayZero) {
            $originalWhere = [
                'a.join_time'  => ['<', $todayZero],
                'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'b.is_deleted' => ContactGroups::NOT_DELETED,
                'a.type'       => ContactGroupMembers::EXTERNAL_USER // 外部联系人
            ];

            $where = $ownerArr ? array_merge($originalWhere, [
                'b.owner' => ['in', $ownerArr]
            ]) : $originalWhere;

            $sql = (array)Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->field(['a.userid'])
                ->where($where)
                ->group('userid')
                ->select();

            echo Db::name('contact_group_members')->getLastSql();
            die;
            return $sql;
        };

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $a = $totalGroupMembersArrClosure($zhaoweiAccounts);

        $c = count($a);

        print_r($c);
        die;

        define("WAY_ID", 268);
        echo WAY_ID;
        die;
        $a = [

        ];


        $level0 = $level1 = $level2 = $level3 = $level4 = $level5 = $level6 = 0;
        $contactHttpDao = new ContactHttpDao();
        foreach ($a as $value) {
            $userCenterInfo = $contactHttpDao->getUserCenter($value);
            switch ($userCenterInfo['user_level_id']) {
                case 0:
                    $level0 += 1;
                    break;

                case 1:
                    echo $value . '~~';
                    $level1 += 1;
                    break;

                case 2:
                    $level2 += 1;
                    break;

                case 3:
                    $level3 += 1;
                    break;

                case 4:
                    $level4 += 1;
                    break;

                case 5:
                    $level5 += 1;
                    break;

                case 6:
                    $level6 += 1;
                    break;
            }
        }

        echo $level0 . '--';
        echo $level1 . '--';
        echo $level2 . '--';
        echo $level3 . '--';
        echo $level4 . '--';
        echo $level5 . '--';
        echo $level6 . '--';

        die;

        /*Db::name('contact_follow_user')
            ->field([
                'external_userid'
            ])
            ->where([
                'createtime' => ['<', 1625068800],
                'status'     => ContactFollowUser::NORMAL
            ])
            ->group('external_userid')
            ->select();*/

        /*Db::name('contact_follow_user')
            ->where(
                [
                    'status'     => ContactFollowUser::NORMAL,
                    'createtime' => ['<', 1625068800]
                ]
            )
            ->count('distinct external_userid');*/

        // echo Db::name('contact_follow_user')->getLastSql();

        $a = ContactFollowUserDao::getCount([
            'external_userid' => 'wm5b2CBwAALVuLuUQ1gvSxYGQoHvHP6g123'
        ]);

        echo $a;

        die;

        $insertBatchData = [
            [
                'feiyue_history_contacts_count'      => '197934',
                'company_history_contacts_count'     => '227241',
                'zhaowei_history_contacts_count'     => '35600',
                'company_group_members_count'        => '32222',
                'feiyue_group_members_count'         => '26363',
                'zhaowei_group_members_count'        => '7177',
            ],

            [
                'company_history_contacts_count'     => '227241',
                'feiyue_history_contacts_count'      => '197934',
                'zhaowei_history_contacts_count'     => '35600',
                'company_group_members_count'        => '32222',
                'feiyue_group_members_count'         => '26363',
                'zhaowei_group_members_count'        => '7177',
            ],
            [
                'company_history_contacts_count'     => '227241',
                'feiyue_history_contacts_count'      => '197934',
                'zhaowei_history_contacts_count'     => '35600',
                'company_group_members_count'        => '32222',
                'feiyue_group_members_count'         => '26363',
                'zhaowei_group_members_count'        => '7177'
            ]

        ];

        try {
            StatisticalDataDao::addBatchData($insertBatchData);
        } catch (\Exception $e) {
            print_r($e->getMessage());
        }

        die;

        echo date('Y-m-d 00:00:00', strtotime('-1 days')),
        die;


        // 上周一时间戳
        $lastWeekMondayTime = Carbon::now()->subWeek()->startOfWeek()->getTimestamp();
        // 上周日时间戳
        $lastWeekSundayTime = Carbon::now()->subWeek()->endOfWeek()->getTimestamp();
        $userServiceImpl = new UserServiceImpl();
        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        $userAllContact = function ($beginTime, $endTime, array $userAccounts) {
            $getUniqueContactClosure = function ($extraWhere = [], $isSpecialUser = true) use ($userAccounts) {

                $where = $isSpecialUser ? [
                    'userid' => ['in', $userAccounts]
                ] : [];

                if ($extraWhere) {
                    $where = array_merge($where, $extraWhere);
                }

                $uniqueContactArr = (array)Db::name('contact_follow_user')
                    ->field([
                        'createtime',
                        'external_userid'
                    ])
                    ->where($where)
                    ->group('external_userid')
                    ->select();

                return $uniqueContactArr;
            };

            $nowContactIdArr = $getUniqueContactClosure([
                // 添加时间
                'createtime' => ['between', [$beginTime, $endTime]],
            ]);

            $nowExternalUserIdArr = array_column($nowContactIdArr, 'external_userid');

            $previousContactIdArr = $getUniqueContactClosure([
                // 添加时间
                'createtime'      => ['<', $beginTime],
                'external_userid' => ['in', $nowExternalUserIdArr],
            ], false);

            $previousExternalUserIdArr = array_column($previousContactIdArr, 'external_userid');
            // 借助redis
            print_r($previousExternalUserIdArr);
            die;

            return array_diff($nowExternalUserIdArr, $previousExternalUserIdArr);
        };

        // 每周进群率
        $feiyueLastWeekContactIdArr = $userAllContact($lastWeekMondayTime, $lastWeekSundayTime, $feiyueAccounts);

        print_r($feiyueLastWeekContactIdArr);
        die;
        $zhaoweiLastWeekContactIdArr = $userAllContact($lastWeekMondayTime, $lastWeekSundayTime, $zhaoweiAccounts);

        $feiyueLastWeekUserCount = count($feiyueLastWeekContactIdArr);
        $zhaoweiLastWeekUserCount = count($zhaoweiLastWeekContactIdArr);




        die;
        $now = time();
        $beginTimeDate = date('Y-m-d 13:00:00');
        $beginTime = strtotime($beginTimeDate);
        $passMinutes = round(($now - $beginTime) / 60);

        echo $passMinutes;

        die;


        [
            $yesterdayDate, // 昨天日期
            $yesterdayZero, // 昨日零点
            $todayZero      // 今日零点
        ]
        =
        [
            date('Y-m-d', strtotime('-1 days')),
            strtotime(date('Y-m-d', strtotime('-1 days'))),
            strtotime(date('Y-m-d'))
        ];

        $userServiceImpl = new UserServiceImpl();
        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        $userAllContact = function ($beginTime, $endTime, array $userAccounts) {
            $getUniqueContactClosure = function ($extraWhere = []) use ($userAccounts) {
                $where = [
                    'userid' => ['in', $userAccounts]
                ];

                if ($extraWhere) {
                    $where = array_merge($where, $extraWhere);
                }

                $uniqueContactArr = Db::name('contact_follow_user')
                                    ->field([
                                        'createtime',
                                        'external_userid'
                                    ])
                                    ->where($where)
                                    ->group('external_userid')
                                    ->select();

                $newUniqueContactArr = [];

                foreach ($uniqueContactArr as $value) {
                    $newUniqueContactArr[$value['createtime']] = $value['external_userid'];
                }

                return $newUniqueContactArr;
            };

            $nowContactIdArr = $getUniqueContactClosure([
                // 添加时间
                'createtime' => ['between', [$beginTime, $endTime]],

            ]);

            $previousContactIdArr = $getUniqueContactClosure([
                // 添加时间
                'createtime'      => ['<', $beginTime],
                'external_userid' => ['in', $nowContactIdArr],
            ]);

            return array_diff($nowContactIdArr, $previousContactIdArr);
        };

        // 昨日
        $yesterdayAllMemberCount = $userAllContact($yesterdayZero, $todayZero, $feiyueAccounts);
        print_r($yesterdayAllMemberCount);
        die;
        echo count($yesterdayAllMemberCount);

        die;

        $getInGroupRateClosure = function ($beginTime, $endTime, array $userIdArr, array $userAccounts) {
            $joinGroupCount = Db::name('contact_group_members')
                ->alias('a')
                ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
                ->where([
                    'a.userid'     => ['in', $userIdArr],
                    'a.join_time'  => [
                        'between',
                        [
                            $beginTime,
                            $endTime
                        ]
                    ],
                    'b.is_deleted' => ContactGroups::NOT_DELETED,
                    'b.owner'      => ['in', $userAccounts]
                ])
                ->count();

            return get_rate($joinGroupCount, count($userIdArr));
        };

        echo $getInGroupRateClosure($yesterdayZero, $todayZero, $yesterdayAllMemberCount, $feiyueAccounts);
    }

    /**
     * @throws Exception
     */
    public function whereRaw()
    {
        if (0 != '') {
            echo 123;
        }
        die;

        $updateRes = ContactDao::updateData(
            [
                'is_consume' => ExternalContact::IS_CONSUME
            ],
            [
                'unionid' => 'owTq1jt6wpo5eWpfNUKirJS7GNAc'
            ]
        );
        print_r($updateRes);
        die;
        if ($updateRes !== false) {
            echo 123;
        }

        die;

        $b = 0;
        if ($b !== 0) {
            echo 345;
        }

        die;
        $a = 0;
        if ($a === 'fsdf') {
            echo 123;
        }

        die;
        $createtime = 1525779812;
        $createDate = date('Y-m-d', $createtime);
        print_r($createDate);
        die;

        $redis = Cache::store()->handler();

        $tagArr = [
            'et5b2CBwAAGEM3h6pr0Z0IVFbF0jLatg',
            'et5b2CBwAA9-FmA2KwZuruIl88-TjFaw',
            'et5b2CBwAAyMGdASNykxatMK8FHRaENw',
            'et5b2CBwAApoBsNUYArAS4PmqCYNrBsw',
            'et5b2CBwAA3aU2bL8NYvYva2qgfkW2Qg',
            'et5b2CBwAAy9O_FmNeY9tpBmBc8O62FA',
            'et5b2CBwAA8QjTIqsKAfQWV_5WehcfBQ'
        ];

        $tagGroupArr = ContactTagsDao::getAllList(
            [
                'group_id',
                'tag_id'
            ],
            [
                'tag_id' => ['in', $tagArr]
            ]
        );

        $res = []; //想要的结果
        foreach ($tagGroupArr as $k => $v) {
            $res[$v['group_id']][] = $v['tag_id'];
        }

        $a = array_values($res);

        /*array_map(function ($value) {
            return $value['']
        }, $tagGroupArr);*/

        print_r($a);
        die;

        $where     = [
            'status' => ContactFollowUser::NORMAL
        ];
        $senderArr = ['yangyang123', 'yangyang1'];
        $where     = array_merge(
            [
                'follow.userid' => ['in', $senderArr]
            ],
            $where
        );


        $templateId = 10;
        $range      = 3;


        foreach ($tagArr as $key => $tagValue) {
            Db::name('contact_follow_user')
                ->alias('follow')
                ->join(
                    'scrm_contact_tag_map map',
                    'follow.external_userid = map.external_userid',
                    'LEFT'
                )
                ->field([
                    'follow.id',
                    'follow.userid',
                    'follow.external_userid'
                ])
                ->where($where)
                ->where([
                    'tag_id' => ['in', $tagValue]
                ])
                ->chunk(10000, function ($results) use ($redis, $templateId, $key) {
                    if (!$results) {
                        return false;
                    }

                    try {
                        $redis->pipeline();

                        foreach ($results as $contact) {
                            $redis->sadd(
                                sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $key),
                                $contact['external_userid']
                            );
                        }
                        $redis->exec();

                        return true;
                    } catch (Exception $e) {
                        send_msg_to_wecom('群发数据刷进Redis出错！' . $e->getMessage());
                        return false;
                    }
                }, 'follow.id');
        }
        $redis->sadd('hhaha', '');

        foreach ($tagArr as $key => $tagValue) {
            if ($key == 0) {
                $redis->sUnionStore('hhaha', 'hhaha', sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $key));
            }


            $redis->sInterStore('hhaha', 'hhaha', sprintf(GroupMsgTemplates::REDIS_GROUP_MSG_HASH_KEY_NAME, $key));
        }

        echo Db::name('contact_follow_user')->getLastSql();
        die;
    }

    /**
     *
     */
    public function test789()
    {
        $pushFansData = PushFansDao::getDetail(
            [
                'id',
                'is_tag',
                'create_time'
            ],
            [
                'unionid' => 'owTq1jhj5sQW0q3ISHxMxl3rKwNY',
            ]
        );
        if (
            isset($pushFansData['is_tag'])
            && $pushFansData['is_tag'] == 0
        ) {
            $year  = date('Y', strtotime($pushFansData['create_time']));
            $month = date('m', strtotime($pushFansData['create_time']));
            $day   = date('d', strtotime($pushFansData['create_time']));
            $date = Carbon::create($year, $month, $day);
            $createDate = $date->startOfWeek()->toDateString();

            $tagData = ContactTagsDao::getDetail(
                [
                    'tag_id'
                ],
                [
                    'group_id' => ContactTags::PUSH_FANS_GROUP_TAG,
                    'tag_name' => ['like', "%{$createDate}%"]
                ]
            );
            PushFansDao::updateData(
                [
                    'is_tag'   => 1,
                    'tag_time' => time()
                ],
                [
                    'id' => $pushFansData['id']
                ]
            );
        }
        echo 133;
        die;


        $a = 4010 * 4 + 4030 * 3 + 4040 * 2 + 4050 * 1;
        echo $a;// 40260
        die;
        $carryData = [
            'ExternalUserID' => 'wm5b2CBwAAPWaUlzu7rzFiUV035PzT-g',
            'UserID'         => 'yangyang3',
            'State'          => '347',
            'ChangeType'     => 'add_external_contact',
            'random_index'   => 0
        ];

        $redis = Cache::store()->handler();
        // 当天
        $todayDate = date('Y-m-d');

        $contactHttpDao = new ContactHttpDao();

        // 通过企业微信接口获取外部联系人详情并存表
        try {
            $contactDetailArr = $contactHttpDao->getContactDetail($carryData['ExternalUserID'], false);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
            return false;
        }

        [
            $externalContactArr,    // 外部联系人通用信息
            $followUserArr,         // 添加了此外部联系人的企业成员各自信息
            $followUserInsertData,  // 第一次添加就增加
            $followUserUpdateData,  // 删除后再次添加就修改
            $followRes,
            $isSuccess
        ] =
            [
                $contactDetailArr['external_contact'],
                $contactDetailArr['follow_user'],
                [],
                [],
                false,
                0
            ];

        $contactHttpDao = new ContactHttpDao();

        try {
            // 事务必须写在try catch里
            Db::startTrans();

            // 获取客户等级
            if (
                isset($externalContactArr['unionid']) && !empty($externalContactArr['unionid'])
            ) {
                if ($userCenterArr = $contactHttpDao->getUserCenter($externalContactArr['unionid'])) {
                    $externalContactArr['user_level_id'] = $userCenterArr['user_level_id'] ? : 0;
                }

                $externalContactArr['is_consume'] = $contactHttpDao->getIsConsume($externalContactArr['unionid'])
                    ? ExternalContact::IS_CONSUME
                    : ExternalContact::NO_CONSUME;
            }

            // 1个客户可以添加多个助理
            // 每添加一个新助理，此条数据都会返回
            // 先判断客户是否已经存在，不存在再入表
            if (!ContactDao::isExistById(0, ['external_userid' => $externalContactArr['external_userid']])) {
                // 仅当联系人类型是企业微信用户时有此字段
                if (
                    isset($externalContactArr['external_profile'])
                    && !empty($externalContactArr['external_profile'])
                ) {
                    $externalContactArr['external_profile'] = json_encode(
                        $externalContactArr['external_profile'],
                        JSON_UNESCAPED_UNICODE
                    );
                }
                $contactRes = ContactDao::addData($externalContactArr);
            } else // 存在就更新，因为客户可能改了自己的名字和头像，用户等级也可能变化了
            {
                $updateData = [
                    'name'      => $externalContactArr['name'],
                    'avatar'    => $externalContactArr['avatar'],
                    'is_friend' => ExternalContact::IS_FRIEND
                ];

                if (
                    isset($externalContactArr['unionid'])
                    && !empty($externalContactArr['unionid'])
                ) {
                    $updateData['user_level_id'] = $externalContactArr['user_level_id'] ?? 0;
                }

                $contactRes = ContactDao::updateData(
                    $updateData,
                    [
                        'external_userid' => $externalContactArr['external_userid']
                    ]
                );
            }


            // 返回多个followUsers列表，找到当前添加的助理
            foreach ($followUserArr as $followUser) {
                if ($followUser['userid'] == $carryData['UserID']) {
                    // 不存在就添加，存在就更新
                    if (
                        !ContactFollowUserDao::isExistById(
                            0,
                            [
                                'external_userid' => $externalContactArr['external_userid'],
                                'userid'          => $carryData['UserID']
                            ]
                        )
                    ) {
                        $followUserInsertData = $followUser;
                    } else { // 互相删除之后表里仍有记录
                        // 删了之后再加
                        $followUserUpdateData = $followUser;
                    }

                    break;
                }
            }

            /**
             * 谁发起的添加
             *
             * @param $followUserData
             * @return int
             */
            $getAddType = function ($followUserData) use ($carryData) {
                if (isset($followUserData['oper_userid'])) {
                    switch ($followUserData['oper_userid']) {
                        case $carryData['UserID']:
                            $addType = 1;
                            break;

                        case $carryData['ExternalUserID']:
                            $addType = 2;
                            break;

                        default:
                            $addType = 3;
                            break;
                    }
                } else {
                    $addType = 0;
                }
                return $addType;
            };

            $addWay = $state = 0;

            // 首次添加客户
            if ($followUserInsertData) {
                // 是否首次添加
                $followUserInsertData['is_first_add'] = ContactFollowUserDao::getCount([
                    'external_userid' => $externalContactArr['external_userid']
                ]) == 0 ? 1 : 0;

                $followUserInsertData['add_type'] = $getAddType($followUserInsertData);

                $followUserInsertData['external_userid'] = $externalContactArr['external_userid'];

                // 第一次添加没有标签，描述和备注手机号码，直接unset掉
                unset(
                    $followUserInsertData['description'],
                    $followUserInsertData['tags'],
                    $followUserInsertData['remark_mobiles']
                );

                // state可能不是数字，转换下
                if (isset($followUserInsertData['state'])) {
                    if ($followUserInsertData['state'] === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                        $followUserInsertData['add_way'] = ContactFollowUser::MOMENT_ADD_WAY;
                        $followUserInsertData['state'] = ContactFollowUser::MOMENT_TRANSFER_STATE;
                    }

                    $state = $followUserInsertData['state'];
                    $followUserInsertData['state'] = intval($followUserInsertData['state']);
                }

                $followUserInsertData['create_date'] = date('Y-m-d', $followUserInsertData['createtime']);
                $followUserInsertData['random_index'] = $carryData['random_index'] ?? 0;

                $followRes = ContactFollowUserDao::addData($followUserInsertData);
                $addWay = $followUserInsertData['add_way'] ?? 0;
            }

            // 删除后再次添加客户
            if ($followUserUpdateData) {
                $addWay = $followUserUpdateData['add_way'] ?? 0;

                if (
                    isset($followUserUpdateData['state'])
                    && $followUserUpdateData['state'] === ContactFollowUser::MOMENT_ORIGIN_STATE
                ) {
                    $followUserUpdateData['state'] = ContactFollowUser::MOMENT_TRANSFER_STATE;
                    $addWay = ContactFollowUser::MOMENT_ADD_WAY;
                }

                $followRes = ContactFollowUserDao::updateData(
                    [
                        'status'           => 0, // 再次添加
                        'remark'           => $followUserUpdateData['remark'] ?? '',
                        'description'      => $followUserUpdateData['description'] ?? '',
                        'createtime'       => $followUserUpdateData['createtime'] ?? 0,
                        'create_date'      => isset($followUserUpdateData['createtime'])
                            ? date('Y-m-d', $followUserUpdateData['createtime'])
                            : 0,
                        'add_way'          => $addWay,
                        'oper_userid'      => $followUserUpdateData['oper_userid'] ?? '',
                        'add_type'         => $getAddType($followUserUpdateData),
                        'state'            => $followUserUpdateData['state'] ?? 0,
                        'random_index'     => $carryData['random_index'] ?? 0,
                        'tags'             => (isset($followUserUpdateData['tags'])
                            && !empty($followUserUpdateData['tags']))
                            ? json_encode($followUserUpdateData['tags'], JSON_UNESCAPED_UNICODE) : null,
                        'remark_corp_name' => $followUserUpdateData['remark_corp_name'] ?? '',
                        'remark_mobiles'   => (isset($followUserUpdateData['remark_mobiles'])
                            && !empty($followUserUpdateData['remark_mobiles']))
                            ? implode(',', $followUserUpdateData['remark_mobiles']) : '',
                        // 'del_time'         => null, // 删除时间仍旧记录下来
                    ],
                    [
                        'external_userid' => $externalContactArr['external_userid'],
                        'userid'          => $carryData['UserID']
                    ]
                );
                $addWay = $followUserUpdateData['add_way'] ?? 0;
                $state = $followUserUpdateData['state'] ?? 0;
            }
            // contact和follow表都正确写入
            if ($contactRes !== false && $followRes !== false) {
                $isSuccess = 1;
                Db::commit();
                // 根据客户的条件打标签
                // 该外部联系人是企业微信用户时，没有unionid
                if (
                    isset($externalContactArr['unionid'])
                    && !empty($externalContactArr['unionid'])
                ) {
                    try {
                        $contacts = [
                            'unionid'         => $externalContactArr['unionid'],
                            'external_userid' => $externalContactArr['external_userid'],
                            'state'           => $carryData['State'] ?? 0, // 用于打"来源渠道"标签
                            'userid'          => $carryData['UserID']
                        ];
                        // 推送到队列
                        Queue::push(
                            ExternalContact::CALLBACK_TAG_JOB_HANDLER,
                            $contacts,
                            ExternalContact::CALLBACK_TAG_QUEUE
                        );
                    } catch (Exception $e) {
                        send_msg_to_wecom('进入回调打标签队列出错：' . $e->getMessage());
                    }

                    // 添加指定微信号后发送请求
                    // if (in_array($this->userId, User::KO_USER_MAP)) {
                    $webHookHttpDao = new WebHookHttpDao();
                    $webHookHttpDao->noticeKoContactEvent($externalContactArr['unionid']);
                    //}

                    // 添加赵蔚的企微账号后通知宝姐珠宝
                    $userServiceImpl = new UserServiceImpl();

                    $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

                    if (in_array($carryData['UserID'], $zhaoweiAccounts)) {
                        $webHookHttpDao->noticeBaojieAddContact($externalContactArr['unionid']);
                    }
                    if ($addWay != 202) { // 管理员/负责人分配
                        // 人数统计，写进redis的hash
                        $riskRes = $webHookHttpDao->getRiskRank($externalContactArr['unionid']);
                        $registerRiskRank = $riskRes['data']['register_risk_rank'];
                        $redis->hSet("register-risk:{$todayDate}", $externalContactArr['unionid'], $registerRiskRank);

                        $marketRiskRank = $riskRes['data']['market_risk_rank'];
                        $redis->hSet("market-risk:{$todayDate}", $externalContactArr['unionid'], $marketRiskRank);
                    }
                    // 发送朋友圈广告企微用户给宝姐家
                    if (isset($carryData['State']) && $carryData['State'] === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                        $webHookHttpDao->sendMomentUnionId($externalContactArr['unionid']);
                    }

                    try {
                        if (
                            isset($externalContactArr['unionid'])
                        ) {
                            $contactInfo = ContactDao::getDetail(['id', 'name', 'avatar', 'gender'], [
                                'unionid' => $externalContactArr['unionid']
                            ]);

                            if ($contactInfo) {
                                $contactHttpDao->addUserCenterData(
                                    $contactInfo['id'],
                                    $externalContactArr['unionid'],
                                    $contactInfo['name'],
                                    $contactInfo['avatar'],
                                    $contactInfo['gender']
                                );
                            }
                        }
                    } catch (Exception $e) {
                        send_msg_to_wecom($e->getMessage());
                    }
                }
            } else {
                Db::rollback();
            }
        } catch (Exception $e) {
            echo 123;
            die;
            Db::rollback();
            send_msg_to_wecom(json_encode($carryData) . $e->getMessage());
            return false;
        }

        die;

        $state = 'wxad_button';
        $channelTag = '456';

        if ($state === ContactFollowUser::MOMENT_ORIGIN_STATE) {
            $a = (isset($channelTag) && $channelTag)
                ? $channelTag
                : ContactTags::CHANNEL_UNKNOWN_TAG_ID;
        }
        print_r($a);
        die;
        $user = 'qingqing';
        /*$getTagId = function (int $channelId): string {
            $tagIdInfo = ContactChannelsDao::getDetail(
                ['tag_id'],
                [
                    'id'         => $channelId,
                    'is_deleted' => 0
                ]
            );
            return $tagIdInfo['tag_id'] ?? '';
        };*/
        $channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);

        if (in_array($user, $channelMap)) {
            print_r(search_two_dimensional_array($user, ContactChannels::MOMENT_CHANNEL_MAP));
           // $channelTag = $getTagId(search_two_dimensional_array($user, ContactChannels::MOMENT_CHANNEL_MAP));
        }


        die;


        $authTime['gzh'] = 1642564900;
        $authTime['xxx'] = 1642565900;
        $beginTime = 1642564800;

        if ($authTime['gzh'] == false && $authTime['xxx'] == false) {
            echo 1;
        }
        if ($authTime['gzh'] < $beginTime && $authTime['xxx'] < $beginTime) {
            echo 0;
        }
        if ($authTime['gzh'] > $beginTime && $authTime['xxx'] > $beginTime) {
            echo 1;
        }
        echo 0;
        die;


        $a = [
            [
                'test' => 123,
                'hha'   => 'a',
            ],
            [
                'test' => 2345,
                'hha'   => 'b',
            ]
        ];

        $b = [
            [
                'test' => 'fdgfd',
                'hha'   => 'c',
            ],
            [
                'test' => 'ghjh',
                'hha'   => 'd',
            ]
        ];

        $d = [];

        $c = array_merge($a, $d);
        print_r($c);
        die;

        $unionIdArr = array (

        );
        $originWhere = [
            'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
            'b.is_deleted' => ContactGroups::NOT_DELETED,
            'unionid'      => ['in', $unionIdArr]
        ];

        $a =  (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field(['unionid'])
            ->where($originWhere)
            ->group('unionid')
            ->select();

        echo Db::name('contact_group_members')->getLastSql();
        die;

        $restUnionIdArr = ['owTq1jhgJG0J4FzsYY4jiIYc_qpA', 'owTq1jhW6PN4FD--BZ6om2thO5LE', 'efsgdfgf', 'owTq1jsU03Bhe0uhMtyOgimTxMhs', 'owTq1jn4eoOj6-Ve2qkJpGBDpLQQ'];
        $contactHttpDao = new ContactHttpDao();
        $beginTime = 1641484800;
        $filterUnionIdArr = array_filter($restUnionIdArr, function ($v) use ($contactHttpDao, $beginTime) {
            $authTime = $contactHttpDao->getFirstAuthorizeTime($v);
            if ($authTime['gzh'] == false && $authTime['xxx'] == false) {
                return true;
            }
            if ($authTime['gzh'] < $beginTime && $authTime['xxx'] < $beginTime) {
                return false;
            }
            if ($authTime['gzh'] > $beginTime || $authTime['xxx'] > $beginTime) {
                return true;
            }
            return false;
        });

        print_r($filterUnionIdArr);
        die;

        $channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);
        print_r($channelMap);
        die;

        /*$contactInfo = ContactDao::getDetail(['id', 'name', 'avatar', 'gender'], [
            'unionid' => 'owTq1jgp3eftyuYqaO4bAiV3rtkU'
        ]);
        print_r($contactInfo);
        die;
        $contactHttpDao = new ContactHttpDao();
        $contactHttpDao->addUserCenterData();
        die;

        $a = [
            [
                'unionid' => 'owTq1joF737y_OneS9wWaPkSx7_0',
                'external_userid' => 'wm5b2CBwAAgqyEaZdzywa1PGriSWFQkQ'
            ],
            [
                'unionid' => 'owTq1jm5B8215t--8Xgc1sZfgPA8',
                'external_userid' => 'wm5b2CBwAAqsvC6bHBfBkR3qCvuoF75Q'
            ],
            [
                'unionid' => 'owTq1ji5V53ptacW-TUT5nJ6QCs8',
                'external_userid' => 'wm5b2CBwAAkg7R7kKuRfcKAlR4vRMGwQ'
            ],
            [
                'unionid' => 'owTq1jvk53UC1lCPMlxm_KQye4q4',
                'external_userid' => 'wm5b2CBwAA7zpe8cKlomNBh4KvN7s-BA'
            ],
            [
                'unionid' => 'owTq1jmc78CfL6FrJ5K8pxCVowf4',
                'external_userid' => 'wm5b2CBwAA_TVImnyXjey7WB5H1zmdBw'
            ],
            [
                'unionid' => 'owTq1jiG95Lio3LY-E_U7IeBPHww',
                'external_userid' => 'wm5b2CBwAAcNTzNrBPA6nZfPWNY2UwGw'
            ],
            [
                'unionid' => 'owTq1jlwBrTU_WGWIRLxeoWxMf34',
                'external_userid' => 'wm5b2CBwAANvZBGoGKB_-A4jU0Az3VvA'
            ],
            [
                'unionid' => 'owTq1jishSJZ-qFvmL0Ir6n5D-i0',
                'external_userid' => 'wm5b2CBwAAMymXq2swwL-ek70iq0mszg'
            ],
            [
                'unionid' => 'owTq1jnEttmD9Xlt0ds5UM5ImO1M',
                'external_userid' => 'wm5b2CBwAAlXz2xajV7_gPqpeF9kpyMA'
            ],
            [
                'unionid' => 'owTq1jtuv5GYlAd6y0y4E9goeMYs',
                'external_userid' => 'wm5b2CBwAAtewiJvF5kFWSo5ySGyuRoQ'
            ]
        ];

        foreach ($a as $value) {
            try {
                $contacts = [
                    'unionid'         => $value['unionid'],
                    'external_userid' => $value['external_userid'],
                    'state'           => 10146,
                    'userid'          => 'baojiejiayangyang9'
                ];
                // 推送到队列
                Queue::push(
                    ExternalContact::CALLBACK_TAG_JOB_HANDLER,
                    $contacts,
                    ExternalContact::CALLBACK_TAG_QUEUE
                );
            } catch (Exception $e) {
                send_msg_to_wecom('进入回调打标签队列出错：' . $e->getMessage());
            }
        }


        die;*/

        $a = '123';
        $b = json_decode($a, true);
        $bArr = $b['external_userid'];


        $c = ContactFollowUserDao::getAllList(['external_userid'], [
            'userid' => 'yangyang3',
            //'status' => ['<>', ContactFollowUser::DEL_FOLLOW_USER]
        ]);

        $d = array_column($c, 'external_userid');

        $h = array_diff($bArr, $d);
        print_r($h);
        die;

        $carryData['userid'] = 'joyee';
        $redBookUserId = 'joyee';
        if ($carryData['userid'] === $redBookUserId) {
            $isFirstAddRedBook = ContactFollowUserDao::getDetail(
                [
                    'is_first_add',
                ],
                [
                    'external_userid' => 'wm5b2CBwAAPH5AYuOgvN7iMy5NyC-A1Q',
                    'userid'          => 'joyee'
                ]
            );

            if (
                !empty($isFirstAddRedBook)
                && $isFirstAddRedBook['is_first_add'] == 1
            ) {
                echo 123;
            }
        }
        die;


        if (
            !ContactGroupMembersDao::getDetail(
                ['id'],
                [
                    'userid' => 'wm5b2CBwAAYLOBkUmxVFnjC9LSf_qaeQ',
                    'chat_id' => ['<>', 'wr5b2CBwAADxnIZmUowyJraD5d1Harag']
                ]
            )
        ) {
            echo  123;
        }

        die;

        if (!ContactGroupMembersDao::getDetail(['id'], ['userid' => 'wm5b2CBwAA98RuOp4r89lVCtNZsCCwKA123'])) {
            echo 123;
        }
        die;

        $a = [1,2,3,4,5,6];
        $b = [2,3];

        $d = array_unique(array_merge($a, $b));
        print_r($d);
        die;

        $c = count(array_diff($a, $b));
        print_r($c);
        die;

        $miniprogramPage = 'subpackage/pages/webview/index';

        if (strpos($miniprogramPage, '?')) {
            $miniprogramPage .= '&scrm=1';
        } else {
            $miniprogramPage .= '?scrm=1';
        }

        print_r($miniprogramPage);
        die;

        $b = Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field(['a.id'])
            ->where([
                'a.unionid'    => 'owTq1joCFW8UTHkSqT1LQzdbwkEA',
                'a.is_deleted' => 0,
                'b.is_deleted' => 0
            ])
            ->find();
        print_r($b);
        die;



        if (
            ContactGroupMembersDao::getCount([
            'unionid'    => 'owTq1joCFW8UTHkSqT1LQzdbwkEA',
            'is_deleted' => 0
            ])  == 0
        ) {
            ContactDao::updateData(['is_in_group' => 0], ['unionid' => 'owTq1joCFW8UTHkSqT1LQzdbwkEA']);
        }

        die;

        $randomIndexData = ChannelWelcomeMsgDao::getAllList(['random_index'], ['channel_id' => 74]);

        $randomIndexArr = array_column($randomIndexData, 'random_index');
        $welcomeMsgWhere['random_index'] = $randomIndexArr[array_rand($randomIndexArr)];
        print_r($welcomeMsgWhere);
        die;


        $channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);

        print_r($channelMap);
        die;
    }

    public function test012()
    {
        /*$a =  urldecode('http://bojem-scrm.oss-cn-shanghai.aliyuncs.com/file/%E7%8F%A0%E5%AE%9D%E4%BF%9D%E5%85%BB%E6%8C%87%E5%8D%97.pdf');
        echo $a;
        die;
        $redis = Cache::store()->handler();
        $unionId  = 'owTq1jhIAPqGPDYK1FBFmBYWUNrQ';
        if ($redis->sIsMember('allUnionId', $unionId )) {
            echo 123;
        } else {
            echo 34567;
        }

        die;
        $a = $redis->get(ContactFissionRecords::REDIS_KEY_FISSION_END_TIME);
        echo $a;

        $b = strtotime($a);
        echo $b;
        die;
        $mediaUrl = 'https://ossscrm.bojem.com/file/%E7%8F%A0%E5%AE%9D%E4%BF%9D%E5%85%BB%E6..%8C%87%E5%8D%97.pdf';

        $lastStr = strrchr($mediaUrl, '.');

        $suffix = substr($lastStr, 1, strlen($lastStr) - 1);

        echo $suffix;

        die;
        $kefuHttpDao = new KefuHttpDao();
        $kefuHttpDao->sendFansHelp(
            'dsfsdfsdfsd',
            'rhjukf;k',
            time(),
            'ghjjkhjk'
        );
        die;

        $a = [
            'id'       => 10,
            'role'     => 1,
            'msg_time' => date('Y-m-d H:i:s', time() + 90),
            'avatar'   => 123,
            'msg_type' => 'msgmenu',
            'msgmenu'    => [
                'head_content' => '是所发生的方式的',
                'list'         => [
                    [
                        'type' => 'click',
                        'click' => [
                            'id' => '101',
                            'content' => '满意',
                        ]
                    ],
                    [
                        'type' => 'view',
                        'view' => [
                            'url' => 'https://work.weixin.qq.com',
                            'content' => '点击跳转到自助查询页面',
                        ]
                    ],
                    [
                        'type' => 'miniprogram',
                        'miniprogram' => [
                            'appid' => 'wx3378cc5758d57fb2',
                            'pagepath' => 'subpackage/shopping/zero/index',
                            'content' => '满意',
                        ]
                    ],
                ],
                'tail_content' => '欢迎再次光临',
            ]
        ];
        $b = json_encode($a, JSON_UNESCAPED_UNICODE);

        print_r($b);
            die;


        $state = '1';
        if (strlen($state) > 20) {
            echo  134;
        }
        echo 4567;
            die;

        $randomIndex = 0;
        $getSendMsg = function (int $channelId) use (&$randomIndex): array {

            $channelFields = [
                'id',
                'is_open_welcome',     // 是否开启欢迎语 0-否 1-是
                'is_distinguish_time', // 是否区分时段 0-否 1-是
                'is_random'            // 是否随机发送欢迎语
            ];

            $channelWhere = [
                'id'         => $channelId,
                'is_deleted' => ContactChannels::NOT_DELETE
            ];

            // 从渠道表找出预置的欢迎语
            $channelInfo = ContactChannelsDao::getDetail($channelFields, $channelWhere);

            // 渠道存在且开启了欢迎语
            if ($channelInfo && $channelInfo['is_open_welcome'] == 1) {
                $newAttachmentsArr = [];
                // 寻找当前时间段的欢迎语
                $welcomeMsgFields = [
                    'id',
                    'welcome_text',
                    'attachments'
                ];

                $welcomeMsgWhere = [
                    'channel_id' => $channelInfo['id'],
                ];

                // 区分时段就添加时段搜索条件
                if ($channelInfo['is_distinguish_time']) {
                    $welcomeMsgWhere['is_working_time'] = is_work_time(2345);
                }
                // 开启了随机发送欢迎语
                if ($channelInfo['is_random']) {
                    $randomIndexData = ChannelWelcomeMsgDao::getAllList(
                        [
                            'random_index'
                        ],
                        [
                            'channel_id' => $channelInfo['id']
                        ]
                    );
                    $randomIndexArr = array_column($randomIndexData, 'random_index');

                    $welcomeMsgWhere['random_index'] = $randomIndex = $randomIndexArr[array_rand($randomIndexArr)];
                }

                $welcomeMsgData = ChannelWelcomeMsgDao::getDetail($welcomeMsgFields, $welcomeMsgWhere);

                if ($attachmentsJson = $welcomeMsgData['attachments']) {
                    $attachmentsArr = json_decode($attachmentsJson, true);

                    $fileManager = new FileManager();

                    foreach ($attachmentsArr as $key => $attachment) {
                        switch ($attachment['welcome_type']) {
                            case 1:
                                $fileData = [
                                    'id'          => $welcomeMsgData['id'],
                                    'key'         => $key,
                                    'create_time' => $attachment['miniprogram_pic_create_time'],
                                    'media_url'   => $attachment['miniprogram_pic_url'],
                                    'media_id'    => $attachment['miniprogram_pic_media_id']
                                ];

                                $suffix = substr(
                                    $attachment['miniprogram_pic_url'],
                                    strrpos($attachment['miniprogram_pic_url'], '.') + 1
                                );

                                $newAttachmentsArr[$key]['msgtype'] = 'miniprogram';
                                $miniprogramPage = $attachment['miniprogram_page'];
                                if (strpos($miniprogramPage, '?')) {
                                    $miniprogramPage .= '&scrm=1';
                                } else {
                                    $miniprogramPage .= '?scrm=1';
                                }
                                $newAttachmentsArr[$key]['miniprogram'] = [
                                    'title'        => $attachment['miniprogram_title'],
                                    'pic_media_id' => $this->getMediaId(
                                        'image',
                                        $fileData,
                                        $suffix,
                                        $attachmentsArr,
                                        $fileManager
                                    ),
                                    'appid'        => $attachment['miniprogram_appid'],
                                    'page'         => $miniprogramPage
                                ];
                                break;

                            case 2:
                                $newAttachmentsArr[$key]['msgtype'] = 'image';
                                $newAttachmentsArr[$key]['image'] = [
                                    'pic_url' => $attachment['image_pic_url'],
                                ];
                                break;

                            case 3:
                                $newAttachmentsArr[$key]['msgtype'] = 'link';
                                $newAttachmentsArr[$key]['link'] = [
                                    'title'  => $attachment['link_title'],
                                    'picurl' => $attachment['link_pic_url'],
                                    'desc'   => $attachment['link_desc'],
                                    'url'    => $attachment['link_url']
                                ];
                                break;

                            case 4:
                                $fileData = [
                                    'id'          => $welcomeMsgData['id'],
                                    'key'         => $key,
                                    'create_time' => $attachment['video_media_create_at'],
                                    'media_url'   => $attachment['video_media_url'],
                                    'media_id'    => $attachment['video_media_id']
                                ];

                                $newAttachmentsArr[$key]['msgtype'] = 'video';
                                $newAttachmentsArr[$key]['video'] = [
                                    'media_id' => $this->getVideoMediaId(
                                        'video',
                                        $fileData,
                                        $attachmentsArr,
                                        $fileManager
                                    )
                                ];
                                break;
                        }
                    }
                }
                return [$welcomeMsgData['welcome_text'], $newAttachmentsArr];
            }

            return ['', []];
        };

        [$welcomeText, $newAttachmentsArr] = $getSendMsg(106);

        $a =  new ContactFissionServiceImpl();
        $url = $a->generateInvitationCode('12345');

        array_unshift(
            $newAttachmentsArr,
            [
                'msgtype' => 'image',
                'image' => [
                    'pic_url' => $url
                ]
            ]
        );
        print_r($newAttachmentsArr);


        die;
        $background_path = './234.png';
        $new_code_path = './code2.png';
        $merge_path = './merge1.png';
        merge_two_images($background_path, $new_code_path, $merge_path, 115, 120);

        die;*/

//案例一：将活动背景图片和动态二维码图片合成一张图片
//图片一
        $background_path = './back.png';

//图片二
        $code_path = './code.png';
        $new_code_path = './code2.png';

        list($width, $height) = getimagesize($code_path);

        $new_width = 400;

        $new_height = 400;

        $image_p = imagecreatetruecolor($new_width, $new_height);

        $image = imagecreatefrompng($code_path);

        imagecopyresampled($image_p, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);

        imagepng($image_p, $new_code_path);

//创建图片对象
        $dst_im = imagecreatefrompng($background_path);
        $dst_info = getimagesize($background_path);
        $src_im = imagecreatefrompng($new_code_path);
        $src_info = getimagesize($new_code_path);

        $alpha = 100;


//合成图片
//imagecopymerge ( resource $dst_im , resource $src_im , int $dst_x , int $dst_y , int $src_x , int $src_y , int $src_w , int $src_h , int $pct )---拷贝并合并图像的一部分
//将 src_im 图像中坐标从 src_x，src_y 开始，宽度为 src_w，高度为 src_h 的一部分拷贝到 dst_im 图像中坐标为 dst_x 和 dst_y 的位置上。两图像将根据 pct 来决定合并程度，其值范围从 0 到 100。当 pct = 0 时，实际上什么也没做，当为 100 时对于调色板图像本函数和 imagecopy() 完全一样，它对真彩色图像实现了 alpha 透明。
        /*imagecopymerge($background, $code, 0, 0, 0, 0, imagesx($code), imagesy($code), 100);*/

        imagecopymerge(
            $dst_im,
            $src_im,
            $dst_info[0] - $src_info[0] - 500,
            $dst_info[1] - $src_info[1] - 152,
            0,
            0,
            $src_info[0],
            $src_info[1],
            $alpha
        );
// 输出合成图片

        var_dump(imagepng($dst_im, './merge.png'));//bool(true)
    }

    public function posterOldConsumer()
    {
        /*$a = ContactFissionRecordsDao::getAllList(['unionid'], [
            'id' => ['<', 1000]
        ]);
        $redis = Cache::store()->handler();

        $contactFissionHttpDao = new ContactFissionHttpDao();

        foreach ($a as $value) {
            if (!$contactFissionHttpDao->bojemIsNewContact($value['unionid'])) {
                $redis->sadd('old123', $value['unionid']);
            }
        }*/

        /*$a = '{
            "msgtype" : "text",
   "text" : {
            "content" : "hello world",
        "menu_id" : "101"
   }
}';
        $b = json_decode($a, true);
        print_r($b);
        die;*/

        /*$redis = Cache::store()->handler();

        $gender = 2;
        $isDistinguishGender = $redis->get(ContactFissionRecords::IS_DISTINGUISH_GENDER);
        // 区分性别
        if (
            ($isDistinguishGender == 1 && $gender != 1)
            || $isDistinguishGender == 0
        ) {
            echo 123;
        }*/
        /*$a = '{"errcode":0,"errmsg":"ok","next_cursor":"HHFq49uYHoiCuZRv9VeZ","msg_list":[{"msgid":"5XY51m1mLWQNQ62jRJWDcxqDo6jajJG3s1ws8NEjP4kc","open_kfid":"wk5b2CBwAAsKVFoUZiVBVxrwh7lahFEg","external_userid":"wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw","send_time":1646205230,"origin":5,"servicer_userid":"chebin","msgtype":"text","text":{"content":"can i help"}}],"has_more":0}';
        $b = json_decode($a, true);


        var_export($b);*/

        /*$welcomeInfo = KefuAccountsDao::getDetail(
            [
                'is_open_welcome',
                'welcome_type',
                'welcome_text',
                'welcome_menu_id'
            ],
            [
                'open_kfid' => 'wk5b2CBwAAc_tkGG8UCxAYELebrytF8g'
            ]
        );
        if (!$welcomeInfo['is_open_welcome']) {
            return;
        }

        $kefuHttpDao = new KefuHttpDao();

        if ($welcomeInfo['welcome_type'] == 1) {
            $welcomeType = 'text';
            $welcomeContent['content'] = $welcomeInfo['welcome_text'];
        } else {
            $welcomeType = 'msgmenu';
            $menuData = KefuMsgMenuDao::getDetail(
                [
                    'head_content',
                    'menu_list',
                    'tail_content'
                ],
                [
                    'id' => $welcomeInfo['welcome_menu_id']
                ]
            );
            $welcomeContent = [
                'head_content' => $menuData['head_content'],
                'list'         => json_decode($menuData['menu_list'], true),
                'tail_content' => $menuData['tail_content'],
            ];
        }

        $kefuHttpDao->sendMsgOnEvent(
            '234567',
            $welcomeType,
            $welcomeContent
        );*/

        $kefuHttpDao = new KefuHttpDao();

        $latestMsg['text']['content']  = '退货';

        if ($keyword = $latestMsg['text']['content']) {
            // 寻找关键词对应的回复内容
            $replyIdInfo = KefuKeywordMapDao::getDetail(
                ['reply_id'],
                [
                    'keyword' => ['like', "%{$keyword}%"]
                ]
            );
            $replyJsonData = KefuKeywordReplyDao::getDetail(
                ['reply_json'],
                [
                    'id' => $replyIdInfo['reply_id']
                ]
            );

            $replyArr = json_decode($replyJsonData['reply_json'], true);

            foreach ($replyArr as &$reply) {
                if (in_array($reply['msgtype'], ['image', 'voice', 'video', 'file', 'link', 'miniprogram'])) {
                    // 获取最新文件
                    /*$mediaId = $this->getNewestMediaId($reply[$reply['msgtype']]);
                    unset($reply['media_url'], $reply['media_create_at']);
                    $reply['media_id'] = $mediaId;*/
                }
                // 1个个发送
                $kefuHttpDao->sendMsg(
                    '1234',
                    '4567',
                    $reply['msgtype'],
                    $reply[$reply['msgtype']]
                );
            }
        }
    }

    public function isJoinGroup()
    {
        /*$allUserIdArr = ContactTagMapDao::getAllList([
            'external_userid'
        ], [
            'tag_id' => 'et5b2CBwAAjW57qMrPj19OQ3GPDbM2gw'
        ]);
        $allUserId = array_column($allUserIdArr, 'external_userid');

        $a = ContactGroupMembersDao::getAllList(
            ['id'],
            [
                'userid'     => ['in', $allUserId],
                //'is_deleted' => 0
            ]
        );
        print_r($a);*/

        /*$redBookChatIdArr = ContactGroupDao::getAllList(
            ['chat_id'],
            [
                'name' => ['like', "%小红书%"]
            ]
        );
        $redBookChatId = array_column($redBookChatIdArr, 'chat_id');
        print_r($redBookChatId);*/

        /*$a = '{
    "returnCode": 200,
    "returnMsg": "操作成功！",
    "returnData": {
        {
            "all": {
                "palyFrom": "整体",
                "newCount": 60,
                "convertCont": 18,
                "newAmt": 34915.20,
                "convertAmt": 7449.90
            },
            "pearl_old": {
                "palyFrom": "珍珠老",
                "newCount": 19,
                "convertCont": 0,
                "newAmt": 11759.90,
                "convertAmt": 0.00
            },
            "stone1": {
                "palyFrom": "彩宝1",
                "newCount": 30,
                "convertCont": 16,
                "newAmt": 13566.50,
                "convertAmt": 7251.90
            },
            "stone2": {
                "palyFrom": "彩宝2",
                "newCount": 2,
                "convertCont": 0,
                "newAmt": 1672.00,
                "convertAmt": 0.00
            },
            "pearl_new": {
                "palyFrom": "珍珠新",
                "newCount": 9,
                "convertCont": 2,
                "newAmt": 7916.80,
                "convertAmt": 198.00
            }
        }
    }
}';
        $b = json_decode($a, true);
        print_r($b);die;

        $a = 'test.png';
        $b = urlencode($a);
        print_r($b);die;

        $c = '%E7%9B%B4%E5%8D%87%E6%9C%BA.png';
        $d = urldecode($c);
        print_r($d);*/

        // echo Carbon::now()->subWeek()->startOfWeek()->getTimestamp();

        /*$channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);
        print_r($channelMap);die;

        if (in_array('yanyan', $channelMap)) {
            echo 133;
        }

        print_r(122);*/

        /*$previousServiceArr = KefuServicerMapDao::getAllList(
            [
                'userid'
            ],
            [
                'open_kfid' => 'wk5b2CBwAAZaNfaMqO1ES1RYJy5AJyGg'
            ]
        );
        $previousUserIdArr = array_column($previousServiceArr, 'userid');

        // 现在的接待人员
        $nowUserIdArr = ['chebin', 'yangyang123', 'yangyang1', 'zhongming'];

        $addUserId = array_diff($nowUserIdArr, $previousUserIdArr);

        print_r($addUserId);

        $reduceUserId = array_diff($previousUserIdArr, $nowUserIdArr);

        print_r($reduceUserId);

        die;*/

        /*$a = '{
    "errcode": 0,
    "errmsg": "ok",
    "result_list": [
        {
            "userid": "zhangsan",
            "errcode": 0,
            "errmsg": "success"
        },
        {
            "userid": "lisi",
            "errcode": 0,
            "errmsg": "ignored"
        }
    ]
}';
        print_r(json_decode($a, true));*/

        /*$kefuHttpDao = new KefuHttpDao();

        $customerInfo = $kefuHttpDao->getCustomerInfo(['wm5b2CBwAAhKav0EMYYvtjnCD03nZjgw']);
        print_r($customerInfo);*/

        /*$a = 'good-12';
        $b = urldecode($a);
        print_r($b);*/
        /*$sceneParamStr = 'good-12';
        $sceneParamArr = explode('-', $sceneParamStr);
        $channel = array_search($sceneParamArr[0], KefuChatList::CHANNEL_MAP);
        print_r($channel);*/

        /*$fileManager = new FileManager();
        $fileManager->downloadMediaUploadOss('3TAQvO3r-bwUaXj8VwwJ9mG6pQ7YVrNCk8g8SFqhtUoFW8lWAWS5xBUpgoeD7mLj8');*/

        /*$followUserArr = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.external_userid',
                'follow.userid',
                'contact.unionid',
                'follow.state'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => ['in',['yangyang3', 'youyou', 'yanyan', 'yangyang123', 'yiyi', 'yangyang2', 'BaoJieZhuBaoGuWenNiNi']],
                'follow.create_time' => ['>', '2022-03-10 17:46:12']
            ])
            ->select();

        // 队列名
        $jobQueue = 'callback_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\CallbackMarkTagJob';

        foreach ($followUserArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
            }
        }*/

        /*$cursorData = KefuMsgLogDao::getDetail(
            [
                'next_cursor',
            ],
            [
            ],
            'id desc'
        );
        print_r($cursorData);
        die;*/

        /*$res = $this->recursionGetMsg('ENCAaEdehukP9cFNN6ZVZUVWv3cqqTUaih4D4jquw8sYCvL', 'HHFq49uYHoiCuZRv9R1M');

        print_r($res);*/
        /*$a = false;
        $b = '1626582010';
        if ($a < $b) {
            echo 23456;
        }*/

        /*$carryData['createtime'] = 1645848334;
        $contactHttpDao = new ContactHttpDao();

        $authTime = $contactHttpDao->getFirstAuthorizeTime('owTq1jrLDwyVJE5zB0PORVBAHvbE');

        if ($authTime['gzh'] !== false && $authTime['xxx'] !== false) {
            if (
                $authTime['gzh'] < $carryData['createtime']
                || $authTime['xxx'] < $carryData['createtime']
            ) {
                echo 'dsfdf';
            }
        }
        echo 123;*/

        /*$a = [
            'owTq1jhgdU-Rljf-Mba9UnTUyhAE',
            'owTq1jlmbwhVV8fs4i6dAXFXzZzc',
            'owTq1jnpU8U_Fa0OzliR_enqsJVs',
            'owTq1jt7kAZc8XifZDJMNj1CU3G8',
            'owTq1jgMpaX0MysHx3cb5iS_BVJI',
            'owTq1joMywssTFvwIBvnG-id79v0',
            'owTq1jkhD1lUpGsi6zbZrB_gLzy4',
            'owTq1jnmdsxt_8kDWLYAz3lEqMmE',
            'owTq1jlZcvLlak53f9w9acBgE2iM',
            'owTq1joBiutk2aNLKb0s6WOmyElc',
            'owTq1jkQ9mcWRiteOywbAalMIjDU',
            'owTq1jrymlXe6lZqDWg9_1TV0GAw',
            'owTq1jlxSVKYz_YYwzd3gBaLOXJo',
            'owTq1jrymlXe6lZqDWg9_1TV0GAw',
            'owTq1jnMpsRAK3h7cbUARixTuUpk',
            'owTq1jgUdO1F1hBXmUKOMwpL-72E',
            'owTq1jkISHhVVlDFDjJES11g4Nm8',
            'owTq1jgs2liJyTF8ukfusSaIKhx4',
            'owTq1js6gSsjsEbrHwodPhyG3IPQ',
            'owTq1jgTQsr5eGEY_Y-tyCkZsAVM',
            'owTq1jm1tREWS6Zr-qiD48p1yYUw',
            'owTq1jtRMa_NxJceOMWhf-LnarKQ',
            'owTq1jquAtN6TOtFMDoOtRDuaUMQ',
            'owTq1jnmXv3YNEWqQsLGW4NOwErg',
            'owTq1jtvMPD0QQUVeZ0xwFXdtgL0',
            'owTq1jngTrJ99FIqWB68fhgLG_as',
            'owTq1joQZb_XTdZww1oh5BTkYl5M',
            'owTq1jp0R_Vh1eSQPo776RengsIU',
            'owTq1jk3BDok9Eqp8w8dkwwNG_A4',
            'owTq1juyPxgqgbh0ZIiKDCO_e7QI',
            'owTq1jiB_SPKROuhnvVoZ7bB96X0',
            'owTq1jiHuXUBbvcs1jIr-20aFtdk',
            'owTq1ju6h2F8cckDw6HM1is-YjCk',
            'owTq1jsEgCvb2wIT4ya9jzsXdP9g',
            'owTq1jjAPlRqibUvrS2x18k9XjN4',
            'owTq1jiY0t4pVMq2L49nBG31cNqc',
            'owTq1jg57g7O7VZnXz1EcSzvd7Nw',
            'owTq1joYQukpjzZ8OEvNopjcGiag',
            'owTq1jl3yiFSb-Tsoz8QWvkvTjOo',
            'owTq1jiuZycbyuxgn8QzBLIcgwvo',
            'owTq1juMhuPk_ZPSNSM5aCgTe94g',
            'owTq1jikgGy6nzzsyxmwcjVRR_Ek',
            'owTq1jkarI6L3_cxTtKwzQddLIbo',
            'owTq1jimQs52a0j8Ju8nyIoWswo4',
            'owTq1jm0lHOlywCsu6bhcpZlF3xc',
            'owTq1joylBONhwU0KPIzgfAbQ4_Y',
            'owTq1jl-JvhJDsUDRpD4UMXWN4F4',
            'owTq1jswGDRWHfLNZZXVVe1aM-xg',
            'owTq1jtr3bDg3wcWh3wGeIJbnQ4g',
            'owTq1jpYlQYW8GDrryLu49wSdbng',
            'owTq1jk5R5JP_8sx6bwdkvjq0K5M',
            'owTq1jhjoBHF3xaa-UT454Fuct4g',
            'owTq1jh6gDuGkpTwPv8M4EnO0YQI',
            'owTq1jnk7-nBR9kXPMHs8K3YEwuA',
            'owTq1jjcib8vOhTZQHR8Jl96neCY',
            'owTq1jj-k9XsmHePv12TeR4idxEM',
            'owTq1jvmC4YElY2ey-IYmAPem6CA',
            'owTq1jm0daEjgEFFIxI6myVkO_XI',
            'owTq1jlrHU_XpfR4BMtNWZFogt1I',
            'owTq1jkZA6Rb5AjMg29YBI7jKt9s',
            'owTq1jgyChrNA2ydzl3a4Md2W7Qw',
            'owTq1jlNaoFidmKToOYNkQce6TCA',
            'owTq1jlKko5wJ0Dl0t5d3wTjboCQ',
            'owTq1joHv6FdZT8GtaU5qtt_j2_U',
            'owTq1jqU3X6EULOXBHeRIbOZigB8',
            'owTq1jrw9hPuSmkhkIwEdtCfCliU',
            'owTq1jt9LgZfz2LTLzBr0NAEay4o',
            'owTq1jjMFnnam_s9_zT_NN8CPdds',
            'owTq1jpc9LsI-5B_Vb2OUHy53v5k',
            'owTq1joY3DOYoxfmNyutF1gXblBE',
            'owTq1jrdFlQhXUKavH2t1ES8rIXw',
            'owTq1jio1BtzkZQWazYy9IL7zyZw',
            'owTq1joOP-xd1E1DCgP9RVTDgkJw'
        ];

        $b = [
            'owTq1jh7PZ8V11wPD23xtQrnE1J8',
            'owTq1jnUxp4KaEUhhlZ-J7JBrcEE',
            'owTq1jt3db40e3OI5aaskr_mtsNI',
            'owTq1jjZ2Sk5KrgItQLOAsvOSTKc',
            'owTq1ju6_uYY8HAiURMw4T7kNqwI',
            'owTq1jmzyeDBjY5JOvCsW3VnT4Jk',
            'owTq1ji3tYOFX1LH2IYb5DCx2UW0',
            'owTq1jt7kAZc8XifZDJMNj1CU3G8',
            'owTq1jrIiHhSmAJGzQdEeBZ6W0Ps',
            'owTq1jtRMa_NxJceOMWhf-LnarKQ',
            'owTq1jjkyPxv7XPZhZ3F8Ul8Z4Y8',
            'owTq1jhav1do70L5GwvEdu54bmnA',
            'owTq1jt51tsWcyFqQOv7W2ypW28k',
            'owTq1jnRC2pgZSmUty0m9OwMhPsw',
            'owTq1jimQs52a0j8Ju8nyIoWswo4',
            'owTq1jpUJQItOaPlDcS02wMYv6jc',
            'owTq1jguIqcfOqPRY3SK4V2kR5Hw',
            'owTq1jlgpHbiuwnoKPP3Lkgr2pcE',
            'owTq1jpUcR1b_oNXOxZWFTD8Jng4',
            'owTq1jmCsY1RP2UemNHP9lvBaPKg',
            'owTq1jqRd1ea7x16SoVukDENCsoo',
            'owTq1jju4E7BQPCMcRUVSQpc_uG8',
            'owTq1jpgN0DlIAcVFDBLNvLJbFmU',
            'owTq1jiOiaMMVnpyU5PdPbw5UjzM',
            'owTq1jluTmgF6_-tRLGZy6R8tXew',
            'owTq1juRQd8_CJB547NhnADwiR80',
            'owTq1jsNWe0zplxL_WMRutbth4Hc',
            'owTq1jtj_AwzRYtX47bpwCmGcYDQ',
            'owTq1jvkPes_f6jyhpEFt7t1M8m0',
            'owTq1jqS0KZI_bp_49igGzSxfiYU',
            'owTq1jvxK8mgIP4LVAwmnU-Zx--U',
            'owTq1jjnzP87iwj4yHjqkmYtPqbk',
            'owTq1jhzJgKUzDghQZoZnNcUMXgA',
            'owTq1jqMuw8ezuqNWMqVoCTVO0ss',
            'owTq1jlhftvJbfm94Q0LWilJu2nU',
            'owTq1jh1mfgVccY1IJHWC2oOkEHA',
            'owTq1jkQH5mX6TScyhRAGr494ckc',
            'owTq1ji0DkCGNtBzsEw1IN98cg_w',
            'owTq1jqFvL8nhMyA0N0gz_g5OSSE',
            'owTq1jtw7nPjrIBSrYb3J_FtAUqA',
            'owTq1jtNUMYF8rfHvbD6-5GG0o9U',
            'owTq1jr-l2BZLTePSAU0ERo49V2U',
            'owTq1jp43vr2klXo58Wllgm7c7u4',
            'owTq1jlGtNX_DeGhQRkqqW_j_nU0',
            'owTq1jgsjzVyM8x6HemqWwl3oAWU',
            'owTq1jhTPrSRGW9ynDtldLwhbKzk',
            'owTq1juol9GQHHKcqZBKJ9kB6z2k',
            'owTq1jjAHYoQotyJHwPFeBNSFXwY',
            'owTq1juMhuPk_ZPSNSM5aCgTe94g',
            'owTq1jt4zA7k5HD_mOdAjvWN5wa4',
            'owTq1jh5eqYsemE1NjZv5D7Wul8Y',
            'owTq1jpN-4pVsNxJhxHNOH5GUpB4',
            'owTq1jivxGJgNHwHvJrrBTElzYFY',
            'owTq1jnfc898S35iqt6cY0WIp7hI',
            'owTq1jkiNqbXIIgzsUEC_QVLXxRs',
            'owTq1jrSosqwcC5uPhaQ0t6mMta8',
            'owTq1jkRo3W3BQh6cYG5mtOBMvyw',
            'owTq1jub59CurGRhpciHX79MbUEQ',
            'owTq1jgNUmt-LUgGRbCTj07xCsbM',
            'owTq1jlRqHJQBcK0vT517du4ydIs',
            'owTq1jgA0k1Kp2jteULsWYBWzzCc',
            'owTq1jmXyxgCQ9Ri_Eme6HRrph1c',
            'owTq1jtuWRdpkv5gGJpp-ezJzDrA'
        ];

        $c = array_intersect($a, $b);
        var_export($c);
        die;*/

        /*$nowTime = strtotime(date('23:01:23'));
        echo $nowTime;*/

        /*$fileManager = new FileManager();
        $fileManager->downloadMediaUploadOss('1lxSaMZEZOC_tVH00xqmjZi0diFRfmKSIqwHY_ABAN5HPxl571zJXkrUzPe8UmEUO');*/
        /*$successAddArr = ['chebin', 'zhongming', 'a', 'b', 'c'];


        foreach ($successAddArr as $key => $userId) {
            $mapInsertData[] = [
                'open_kfid' => '2345',
                'userid'    => $userId,
                'is_next'   => $key == 0 ? 1 : 0
            ];

        }
        print_r($mapInsertData);die;*/

        /*$a = $this->getSimilarKeyword(['翡翠13'], 60);
        print_r($a);die;*/

        /*$menuData = KefuMsgMenuDao::getDetail(
            [
                'head_content',
                'menu_list',
                'tail_content'
            ],
            [
                'id' => 39
            ]
        );

        $menuListArr = json_decode($menuData['menu_list'], true);

        $content = [
            'head_content' => $menuData['head_content'],
            'list'    => $menuListArr,
            'tail_content' => $menuData['tail_content'],
        ];
        print_r($content);*/

        /*$openKfId = 'wk5b2CBwAAfHuH5BH50H6g0uBgsbsn8w';
        $findIdleService = function () use ($openKfId) {
            $allKefuArr = KefuServicerMapDao::getAllList(
                ['userid'],
                [
                    'open_kfid' => $openKfId,
                ]
            );
            $allUserIdArr = array_column($allKefuArr, 'userid');
            $newCountArr = [];
            foreach ($allUserIdArr as $userId) {
                $count = KefuServiceRecordsDao::getCount(
                    [
                        'open_kfid'      => $openKfId,
                        'service_userid' => $userId,
                        'service_state'  => 3
                    ]
                );
                $newCountArr[$count] = $userId;
            }
            print_r($newCountArr);
            ksort($newCountArr);
            print_r($newCountArr);die;
            return array_shift($newCountArr);
        };

        $a = $findIdleService();
        print_r($a);*/

        /*$keyword = '黄金1111';
        $allKeywordArr = KefuKeywordMapDao::getAllList(['reply_id','keyword']);

        $replyId = 0;
        foreach ($allKeywordArr as $singeKeyword) {
            if (!$singeKeyword) {
                continue;
            }
            if ($keyword == $singeKeyword['keyword']) {
                $replyId = $singeKeyword['reply_id'];
                break;
            }

        }

        if (!$replyId) {
            foreach ($allKeywordArr as $singeKeyword) {
                if (strpos($keyword, $singeKeyword['keyword']) !== false) {
                    $replyId = $singeKeyword['reply_id'];
                    break;
                }
            }
        }


        print_r($replyId);die;*/

        /*$this->keywordReply('你好你好123', 'wm5b2CBwAAwGj9ZmrbH9t6AOXuFk8nPw', '车斌', 'wk5b2CBwAAfHuH5BH50H6g0uBgsbsn8w', 8);*/

        /*$attachmentsArr = json_decode('[]', true);
        print_r($attachmentsArr);die;*/

        /*$fileManager = new FileManager();
        $a = $fileManager->downloadMediaUploadOss('1TOQyHA1Guf3qaFQHlptrBSDXVtDscVxTX_qpgW3wd7e43WfbHg8WLzNyCrla3aNI');
        print_r($a);*/

        /*$reply['attachment'] = '{"url":"https:\/\/mp.weixin.qq.com\/s\/ZDFQW3HvpEuuUQqwmZU_KA","title":"宝姐欢迎你","media_url":"https:\/\/ossscrm.bojem.com\/image\/157855546450080948.png","media_id":"3JhGCxvxxFZq4-MKb9Xc2A8eaVe2IzcMiu85MSbsQPbABrB9rowWS6Y1ZvT_sljdW","media_create_at":1647672735}';

        $content = json_decode($reply['attachment'], true);

        $mediaData = [
            'media_url'       => $content['media_url'],
            'media_id'        => $content['media_id'],
            'media_create_at' => $content['media_create_at']
        ];
        $updateId = 204;
        // 更新临时素材id和创建时间
        $linkUpdateFunc = function ($fileData, $uploadRes) use ($updateId) {
            $content['media_url'] = $fileData['media_url'];
            $content['media_id'] = $uploadRes['media_id'];
            $content['media_create_at'] = $uploadRes['created_at'];

            return KefuKeywordReplyAttachmentsDao::updateData(
                [
                    'attachment' => json_encode($content, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $updateId
                ]
            );
        };

        $mediaId = $this->getLinkNewestMediaId($mediaData, $linkUpdateFunc);
        $content['pic_url'] = $content['media_url'];
        unset($content['media_url'], $content['media_id'], $content['media_create_at']);
        $content['thumb_media_id'] = $mediaId;
        $saveChatRecordData = $content;*/
        /*$a = 'a%3D1%26b%3D2';
        $b = urldecode($a);
        print_r($b);
        die;

        // 附件
        $latestMsgJson = '{"msgid":"MXbuYYJYGqC7TXxW3jEsjh8Zu7VMPruJySov7mnoQ","open_kfid":"wk5b2CBwAAURSO-sDBUu4sQr4c_k8C7g","external_userid":"wm5b2CBwAAUgkCzPK3xHEGcFEeAlhwzQ","send_time":1648612584,"origin":3,"msgtype":"text","text":{"content":"回电话"}}';
        $nickName = 'ceshi';
        $latestMsg = json_decode($latestMsgJson, true);
        $attachments = [];
        $platForm = $chatId = 0;
        $channel = '';
        // 获取客服名
        $getUserName = function (string $userId) {
            $userInfo = UserDao::getDetail(['name'], ['userid' => $userId]);
            return $userInfo['name'] ?? $userId;
        };
        // 事件
        if ($latestMsg['msgtype'] == 'event') {
            switch ($latestMsg['event']['event_type']) {
                case 'enter_session': // 用户进入会话事件
                    $attachments = [
                        'content' => $nickName . '进入会话',
                    ];
                    $platForm = $latestMsg['event']['scene'];
                    if (isset($latestMsg['event']['scene_param'])) {
                        $sceneParamArr = explode('-', $latestMsg['event']['scene_param']);
                        if (in_array($sceneParamArr[0], [1,2])) {
                            $channel = $sceneParamArr[1];
                        } else {
                            $channel = $sceneParamArr[0];
                        }
                    }
                    break;

                case 'msg_send_fail': // 消息发送失败事件
                    switch ($latestMsg['event']['fail_type']) {
                        case 0:
                        default:
                            $failContent = '未知原因';
                            break;

                        case 1:
                            $failContent = '客服账号已删除';
                            break;

                        case 2:
                            $failContent = '应用已关闭 ';
                            break;

                        case 4:
                            $failContent = '会话已过期，超过48小时';
                            break;

                        case 5:
                            $failContent = '会话已关闭';
                            break;

                        case 6:
                            $failContent = '超过5条限制';
                            break;

                        case 7:
                            $failContent = '未绑定视频号';
                            break;

                        case 8:
                            $failContent = '主体未验证';
                            break;

                        case 9:
                            $failContent = '未绑定视频号且主体未验证';
                            break;

                        case 10:
                            $failContent = '用户拒收';
                            break;
                    }
                    $attachments = [
                        'content' => '发送失败-' . $failContent,
                    ];
                    break;

                case 'servicer_status_change': // 接待人员接待状态变更事件
                    $status = $latestMsg['event']['status'] == 1 ? '接待中' : '停止接待';
                    $attachments = [
                        'content' => $getUserName($latestMsg['event']['servicer_userid']) . $status,
                    ];
                    break;

                case 'session_status_change':
                    $oldUserName = $newUserName = '';
                    if (isset($latestMsg['event']['new_servicer_userid'])) {
                        $oldUserName = $getUserName($latestMsg['event']['new_servicer_userid']);
                    }

                    if (isset($latestMsg['event']['old_servicer_userid'])) {
                        $newUserName = $getUserName($latestMsg['event']['old_servicer_userid']);
                    }

                    switch ($latestMsg['event']['change_type']) {
                        case 1:
                        default:
                            $changeContent = '从接待池接入会话';
                            $userName = $newUserName;
                            break;

                        case 2:
                            $changeContent = '转接会话';
                            $userName = $oldUserName;
                            break;

                        case 3:
                            $changeContent = '结束会话';
                            $userName = $oldUserName;
                            break;

                        case 4:
                            $changeContent = '重新接入已结束/已转接会话';
                            $userName = $newUserName;
                            break;
                    }
                    $attachments = [
                        'content' => $userName . $changeContent,
                    ];
                    break;
            }
        } else {
            $attachments = $latestMsg[$latestMsg['msgtype']];
        }

        try {

            // 单个聊天记录
            $chatRecordData = [
                'msg_id'          => $latestMsg['msgid'],
                'servicer_userid' => $latestMsg['servicer_userid'] ?? '',
                'send_time'       => $latestMsg['send_time'],
                'origin'          => $latestMsg['origin'],
                'msg_type'        => $latestMsg['msgtype'],
                'attachments'     => json_encode($attachments, JSON_UNESCAPED_UNICODE)
            ];
            $openKfId = 'wk5b2CBwAAURSO-sDBUu4sQr4c_k8C7g';
            $externalUserId = 'wm5b2CBwAAUgkCzPK3xHEGcFEeAlhwzQ';
            // 聊天列表
            $chatListData = KefuChatListDao::getDetail(
                [
                    'id',
                    'platform',
                    'channel'
                ],
                [
                    'open_kfid'       => $openKfId,
                    'external_userid' => $externalUserId
                ]
            );
            if ($chatListData) { // 存在就更新最近聊天时间
                $chatId = $chatListData['id'];
                $updateData = [
                    'external_userid' => $externalUserId
                ];
                if ($platForm != 0) {
                    $updateData['platform'] = $platForm;
                }
                if ($channel) {
                    $updateData['channel'] = $channel;
                }
                KefuChatListDao::updateData(
                    $updateData,
                    [
                        'id' => $chatId
                    ]
                );
            } else { // 不存在就存储列表和记录
                $chatListData = [
                    'open_kfid'       => $openKfId,
                    'external_userid' => $externalUserId,
                    'platform'        => $platForm,
                    'channel'         => $channel
                ];
                $chatId = KefuChatListDao::addData($chatListData, true);
            }

            $chatRecordData['chat_id'] = $chatId;

            KefuChatRecordsDao::addData($chatRecordData);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }

        return $chatId;*/
    }


    /**
     * 关键词回复
     *
     * @param string $keyword 关键词
     * @param string $externalUserid 咨询的客户
     * @param string $nickName 咨询客户的昵称
     * @param string $openKfId 客服账号
     * @param int $chatId 聊天列表id
     */
    public function keywordReply(
        string $keyword,
        string $externalUserid,
        string $nickName,
        string $openKfId,
        int $chatId
    ) {
        try {
            // 寻找关键词对应的回复内容
            $allKeywordArr = KefuKeywordMapDao::getAllList(['reply_id','keyword']);

            $replyId = 0;
            foreach ($allKeywordArr as $singeKeyword) {
                if (!$singeKeyword) {
                    continue;
                }
                if ($keyword == $singeKeyword['keyword']) {
                    $replyId = $singeKeyword['reply_id'];
                    break;
                }
            }

            if (!$replyId) {
                foreach ($allKeywordArr as $singeKeyword) {
                    if (strpos($keyword, $singeKeyword['keyword']) !== false) {
                        $replyId = $singeKeyword['reply_id'];
                        break;
                    }
                }
            }

            if (!$replyId) {
                return;
            }
            $replyData = KefuKeywordReplyDao::getDetail(
                [
                    'keyword_title',
                    'is_open_reply',
                    'is_push_to_group',
                    'webhook_url'
                ],
                [
                    'id' => $replyId
                ]
            );

            // 触发数+1
            if ($replyData['is_open_reply']) {
                Db::name('kefu_keyword_reply')
                    ->where([
                        'id' => $replyId
                    ])
                    ->setInc('trigger_count');
            }

            if (!$replyData['is_open_reply']) {
                return;
            }

            if ($replyData['is_push_to_group']) {
                $webHookHttpDao = new WebHookHttpDao();
                $sendContent    = sprintf('用户：《%s》正在咨询《%s》', $nickName, $replyData['keyword_title']);
                $webHookHttpDao->sendKefuMsg($replyData['webhook_url'], $sendContent);
            }

            $replyArr = KefuKeywordReplyAttachmentsDao::getAllList(
                [
                    'id',
                    'msg_type',
                    'attachment'
                ],
                [
                    'reply_id' => $replyId
                ]
            );
            echo $replyId;
            print_r($replyArr);
            die;

            $chatRecordBatchData = [];
            foreach ($replyArr as $reply) {
                $updateId = $reply['id'];
                $msgType = $reply['msg_type'];
                $content = $attachmentArr = json_decode($reply['attachment'], true);
                if (in_array($msgType, ['image', 'voice', 'video', 'file'])) {
                    // 更新临时素材id和创建时间
                    $updateFunc = function ($fileData, $uploadRes) use ($updateId) {
                        $keywordAttachments = [
                            'media_url'       => $fileData['media_url'],
                            'media_id'        => $uploadRes['media_id'],
                            'media_create_at' => $uploadRes['created_at']
                        ];

                        return KefuKeywordReplyAttachmentsDao::updateData(
                            [
                                'attachment' => json_encode($keywordAttachments, JSON_UNESCAPED_UNICODE)
                            ],
                            [
                                'id' => $updateId
                            ]
                        );
                    };
                    $mediaId = $this->getSingleNewestMediaId($msgType, $attachmentArr, $updateFunc);
                    $content = [
                        'media_id' => $mediaId
                    ];
                }
                if (in_array($msgType, ['link', 'miniprogram'])) {
                    $content = json_decode($reply['attachment'], true);

                    $mediaData = [
                        'media_url'       => $content['media_url'],
                        'media_id'        => $content['media_id'],
                        'media_create_at' => $content['media_create_at']
                    ];
                    // 更新临时素材id和创建时间
                    $linkUpdateFunc = function ($fileData, $uploadRes) use ($updateId) {
                        $content['media_url'] = $fileData['media_url'];
                        $content['media_id'] = $uploadRes['media_id'];
                        $content['media_create_at'] = $uploadRes['created_at'];

                        return KefuKeywordReplyAttachmentsDao::updateData(
                            [
                                'attachment' => json_encode($content, JSON_UNESCAPED_UNICODE)
                            ],
                            [
                                'id' => $updateId
                            ]
                        );
                    };

                    $mediaId = $this->getLinkNewestMediaId($mediaData, $linkUpdateFunc);
                    unset($content['media_url'], $content['media_id'], $content['media_create_at']);
                    $content['thumb_media_id'] = $mediaId;
                }

                if ($msgType == 'msgmenu') {
                    $menuId = $reply['msgmenu']['menu_id'];

                    $menuData = KefuMsgMenuDao::getDetail(
                        [
                            'head_content',
                            'menu_list',
                            'tail_content'
                        ],
                        [
                            'id' => $menuId
                        ]
                    );

                    $menuListArr = json_decode($menuData['menu_list'], true);

                    $content = [
                        'head_content' => $menuData['head_content'],
                        'list'         => $menuListArr,
                        'tail_content' => $menuData['tail_content'],
                    ];
                }
                // 1个1个发送
                /*$msgId = self::$kefuHttpDao->sendMsg(
                    $externalUserid,
                    $openKfId,
                    $msgType,
                    $content
                );*/

                // 加入聊天记录
                $chatRecordData = [
                    'msg_id'          => $msgId,
                    'servicer_userid' => '',
                    'send_time'       => time(),
                    'origin'          => KefuChatRecords::SERVICE,
                    'msg_type'        => $msgType,
                    'attachments'     => json_encode($reply[$msgType], JSON_UNESCAPED_UNICODE)
                ];

                $chatRecordData['chat_id'] = $chatId;
                $chatRecordBatchData[] = $chatRecordData;
            }
            if ($chatRecordBatchData) {
                KefuChatRecordsDao::addBatchData($chatRecordBatchData);
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }
    }

    /**
     * 获取最新的media_id
     *
     * @param string $msgType
     * @param array $fileInfo
     * @param Closure $closure
     * @return mixed
     * @throws Exception
     */
    private function getSingleNewestMediaId(string $msgType, array $fileInfo, Closure $closure)
    {
        $fileManager = new FileManager();

        return $fileManager->updateKefuTemporaryMedia($msgType, $fileInfo, $closure);
    }

    /**
     * 获取小程序和图文的最新media_id
     *
     * @param array $fileInfo
     * @param Closure $closure
     * @return mixed
     * @throws \Exception
     */
    private function getLinkNewestMediaId(array $fileInfo, Closure $closure)
    {
        $fileManager = new FileManager();

        return $fileManager->updateKefuTemporaryMedia('image', $fileInfo, $closure);
    }

    public function test123()
    {
        /*$inAuctionData = [
            [
                'status' => 2,
                'id' => 100,
            ],
            [
                'status' => 2,
                'id' => 106,
            ],
            [
                'status' => 2,
                'id' => 108,
            ],
            [
                'status' => 1,
                'id' => 200,
            ],
            [
                'status' => 1,
                'id' => 300,
            ],
        ];

        $inAuctionStatusArr = array_column($inAuctionData, 'status', 'id');
        $a = array_keys($inAuctionStatusArr, 2);
        if (in_array(2, $inAuctionStatusArr)) {
            print_r($a);
        }*/

        /*$isShowShareBubble = mt_rand(8, 12) * 0.1;

        print_r($isShowShareBubble);*/
        /*$endTime = 1650361608;

        $minutesEndTime = date('Y-m-d H:i', $endTime);
        print_r($minutesEndTime);*/

        /*$contactHttpDao = new ContactHttpDao();
        $a = $contactHttpDao->getContactDetail('wm5b2CBwAA4gHpOmlmkQZ6omQOIMqsZQ', false);

        $followUserArr = $a['follow_user'];

        foreach ($followUserArr as $followUser) {
            if ($followUser['userid'] == 'youyou') {
                // $wechatSource = $followUser['wechat_channels']['source'];
                if (isset($followUser['wechat_channels'])) {
                    $key = array_search($followUser['wechat_channels']['nickname'], ContactChannels::WECHAT_VIDEO_MAP);

                }
            }
        }*/

        /*if (
            in_array(
                198,
                array_merge(
                    array_keys(ContactChannels::MOMENT_CHANNEL_MAP),
                    array_keys(ContactChannels::WECHAT_VIDEO_MAP),
                    [
                        ContactChannels::YANGYANG5_CHANNEL_ID,
                        ContactChannels::YANGYANG2_CHANNEL_ID
                    ]
                )
            )
        ) {
            echo 123;
        }*/
        /*$a = Db::name('group_msg_receive_map')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->join(
                'scrm_contact_follow_user c',
                'b.external_userid = c.external_userid',
                'LEFT'
            )
            ->join(
                'scrm_contact_group_members d',
                'd.userid = a.external_userid',
                'LEFT'
            )
            ->field([
                'a.external_userid',
                'a.user_id',
                'a.status',
                'b.name',
                'b.avatar',
                'b.is_in_group',
                'c.status as friend_status'
            ])
            ->where([
                'chat_id' => 'wr5b2CBwAATJ7XgSeDJHLuMeHGfipgMA'
            ])
            ->page(1, 10)
            ->group('a.external_userid')
            ->select();

        print_r($a);

        die;*/

        /*$groupInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => '123',
                'b.chat_id'    => ['not in',
                    [
                        'wr5b2CBwAAJ54n4U3V4zC_Vv7hMnhLCw',
                        'wr5b2CBwAAStoYO3f3zLPPtPZOnNvFOA'
                    ]
                ]
            ])
            ->where(
                'b.name',
                'like',
                [
                    '%宝姐家好物专享%',
                ],
                'OR'
            )
            ->find();

        echo Db::name('contact_group_members')->getLastSql();
        die;*/

        $a = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.unionid'    => 'owTq1jtp256XFzlnULbO6kwTpEak',
                'b.chat_id'    => ['in',
                    [
                        'wr5b2CBwAAStoYO3f3zLPPtPZOnNvFOA',
                        'wr5b2CBwAAJ54n4U3V4zC_Vv7hMnhLCw'
                    ]
                ]
            ])
            ->find();



        print_r($a);
        die;


        $a = new WebHookHttpDao();

        $a->joinSharerCallback('owTq1jt6wpo5eWpfNUKirJS7GNAc');

        /*$a = Db::name('contact_follow_user')
            ->alias('follow')
            ->join(
                'scrm_contact_tag_map map',
                'follow.external_userid = map.external_userid',
                'LEFT'
            )
            ->field([
                'follow.id',
                'map.userid',
                'follow.external_userid'
            ])
            ->where([
                'status' => ContactFollowUser::NORMAL,
                'follow.external_userid' => 'wm5b2CBwAAjEvkFxezzScuxVkJOIcKsw',
                'tag_id' => ['in', 'et5b2CBwAAYzhdzNc4trORrjbfXZFTWQ'],
                'map.userid' => ['in', ['yangyang5']]
            ])
            ->select();

        $redis = Cache::store()->handler();

        foreach ($a as $value) {
            $redis->hset(
                'adcd',
                $value['external_userid'],
                $value['userid']
            );
        }*/
        /*$a = $this->getChannelTag('wxad_button', 'yangyang5');
        print_r($a);*/
    }

    private function getChannelTag($state, $user): string
    {
        if ($state !== 0) {
            /**
             * 获取渠道对应的标签ID
             *
             * @param int $channelId 渠道ID
             * @return string
             * @throws Exception
             */
            $getTagId = function (int $channelId): string {
                $tagIdInfo = ContactChannelsDao::getDetail(
                    ['tag_id'],
                    [
                        'id'         => $channelId,
                        'is_deleted' => 0
                    ]
                );
                return $tagIdInfo['tag_id'] ?? '';
            };

            if ($state === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                $channelMap = merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP);

                if (in_array($user, $channelMap)) {
                    $channelTag = $getTagId(search_two_dimensional_array($user, ContactChannels::MOMENT_CHANNEL_MAP));
                }
            } else {
                if (
                    $wayInfo = ContactWaysDao::getDetail(
                        ['channel_id'],
                        [
                            'id' => $state
                        ]
                    )
                ) {
                    $channelTag = $getTagId($wayInfo['channel_id']);
                }
            }
        }

        return (isset($channelTag) && $channelTag)
            ? $channelTag
            : ContactTags::CHANNEL_UNKNOWN_TAG_ID;
    }

    public function isInGroup()
    {
        /*$a = Db::name('mq_logs')
            ->field([
                'mobile'
            ])
            ->where([
                'is_contact' => 1,
                'create_time' => ['>', '2022-07-20 15:50:00']
            ])
            ->order('create_time')
            ->select();

        $b = new ContactHttpDao();

        foreach ($a as $value) {
            $res = $b->getUserCenterByMobile($value['mobile']);
            $consumeAmount = $res['consume_amount'];
            if ($consumeAmount > 0) {
                ContactDao::updateData([
                    'actual_consume_amount' => $consumeAmount
                ], [
                    'unionid' => $res['unionId']
                ]);
            }
        }*/
        $a = ContactGroupDao::getAllList(['name','chat_id'], [
            'name' => ['like', "%捡漏%"],
            'is_deleted' => 0,
            'chat_id' => 'wr5b2CBwAA9meXG2LXK7sJ1CaeWhrqog'
        ]);
        $c = new ContactHttpDao();
        foreach ($a as $value) {
            $b = ContactGroupMembersDao::getAllList(['unionid'], [
                'chat_id' => $value['chat_id'],
                'is_deleted' => 0,
                'type' => 2
            ]);
            foreach ($b as $unionId) {
                $d = $c->getUserCenter($unionId['unionid']);
                if (isset($d['consume_amount']) && $d['consume_amount'] > 0) {
                    Log::info($unionId['unionid']);
                }
            }
        }
    }

    public function testJob()
    {
        $a = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.external_userid',
                'follow.userid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => 'owTq1jlYbOC9XH8FnxMhjJo24-_w',
                'status'  => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT] // 不是被客服删除
            ])
            ->select();
        print_r($a);
        die;

        $a = search_two_dimensional_array(
            'yangyang3',
            ContactChannels::MOMENT_CHANNEL_MAP
        );
        print_r($a);
        die;


        $logArr = Db::name('mq_logs')
            ->field([
                'mobile'
            ])
            ->where([
                'update_time' => ['between' , ['2022-07-22 14:00:00', '2022-07-22 19:10:00']],
            ])
            ->group('mobile')
            ->select();


        // 队列名
        $jobQueue = 'test_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\TestJob';

        /*$a = ContactTagMapDao::getAllList(['external_userid', 'userid'], [
            'tag_id' => 'et5b2CBwAA26VR0bM06ESYfsHpv6_AKA'
        ]);*/


        foreach ($logArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
            }
        }
    }

    public function test0930()
    {
        $a = ContactDao::getAllList(['unionid'], [
            'is_consume' => 1,
            'actual_consume_amount' => 0
        ]);

        $contactHttpDao = new ContactHttpDao();

        foreach ($a as $value) {
            $res = $contactHttpDao->getUserCenter($value['unionid']);
            if ($res['consume_amount'] != 0) {
                ContactDao::updateData(
                    ['actual_consume_amount' => $res['consume_amount']],
                    [
                        'unionid' => $value['unionid']
                    ]
                );
            }
        }
    }
}
