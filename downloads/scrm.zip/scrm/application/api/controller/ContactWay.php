<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\way\impl\ContactWayServiceImpl;
use app\api\validate\ContactWayValidate;
use app\api\validate\PaginationValidate;
use app\common\model\ContactChannels;
use Exception;

/**
 * Class ContactWay
 * @package app\api\controller
 */
class ContactWay extends Base
{
    /**
     * ContactWay constructor.
     * @param ContactWayServiceImpl $service
     */
    public function __construct(ContactWayServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 获取联系我路径列表
     *
     * @param PaginationValidate $pageValidate
     * @param ContactWayValidate $validate
     */
    public function index(PaginationValidate $pageValidate, ContactWayValidate $validate)
    {
        $searchInfo = $this->request->get();

        if (!$pageValidate->check($searchInfo)) {
            Response::error($pageValidate->getError());
        }

        if (!$validate->scene('select')->check($searchInfo)) {
            Response::error($validate->getError());
        }


        $wayList = $this->service->index($searchInfo);

        Response::success('success', $wayList);
    }

    /**
     * 获取单个联系我路径信息
     *
     * @param ContactWayValidate $validate
     */
    public function detail(ContactWayValidate $validate)
    {
        $requestData = $this->request->get();

        if (!$validate->scene('show')->check($requestData)) {
            Response::error($validate->getError());
        }

        $wayData = $this->service->detail($requestData['way_id']);

        Response::success('success', $wayData);
    }

    /**
     * 添加联系我路径
     *
     * @param ContactWayValidate $validate
     */
    public function add(ContactWayValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('add')->check($requestData)) {
            Response::error($validate->getError());
        }

        if (
            in_array(
                $requestData['channel_id'],
                array_merge([
                    ContactChannels::YANGYANG3_CHANNEL_ID,
                    ContactChannels::MENGMENG_CHANNEL_ID
                ], merge_two_dimensional_array(ContactChannels::MOMENT_CHANNEL_MAP))
            )
        ) {
            Response::error('不能绑定此渠道');
        }

        [$addRes, $message] = $this->service->add($requestData);

        if ($addRes) {
            write_manager_log('添加联系我路径。名称：' . $requestData['way_name']);
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 更新联系我路径
     *
     * @param ContactWayValidate $validate
     */
    public function update(ContactWayValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('edit')->check($requestData)) {
            Response::error($validate->getError());
        }

        [$updateRes, $message] = $this->service->update($requestData);

        if ($updateRes) {
            write_manager_log('更新联系我路径。ID：' . $requestData['way_id']);
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 删除联系我路径
     *
     * @param ContactWayValidate $validate
     */
    public function delete(ContactWayValidate $validate)
    {
        $requestData = $this->request->post();

        if (!$validate->scene('del')->check($requestData)) {
            Response::error($validate->getError());
        }

        $wayId = $requestData['way_id'];

        [$deleteRes, $message] = $this->service->delete($wayId);

        if ($deleteRes) {
            write_manager_log('删除联系我路径。ID：' . $wayId);
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 咨询助理列表
     *
     * @throws Exception
     */
    public function getUserList()
    {
        $keyword = $this->request->get('keyword');

        $userData = $this->service->getUserList($keyword);

        Response::success('success', $userData);
    }

    /**
     * 可选的渠道列表
     *
     * @throws Exception
     */
    public function getChannelList()
    {
        $keyword = $this->request->get('keyword');

        $channelData = $this->service->getChannelList($keyword);

        Response::success('success', $channelData);
    }

    /**
     * 下载活码
     *
     * @param ContactWayValidate $validate
     */
    public function downloadQrCode(ContactWayValidate $validate)
    {
        $requestData = $this->request->get();

        if (!$validate->scene('download')->check($requestData)) {
            Response::error($validate->getError());
        }

        $this->service->downloadQrCode($requestData['way_id']);
    }

    /**
     * 根据配置ID返回联系我类型
     */
    public function getConfigType()
    {
        $configId = $this->request->get('config_id');

        if (!$configId) {
            Response::error('配置ID不能为空！');
        }

        $res = $this->service->getConfigType($configId);

        if (isset($res['error_msg'])) {
            Response::error($res['error_msg']);
        }

        Response::success('success', $res);
    }
}
