<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\dao\http\group\GroupWelcomeTemplateHttpDao;
use Exception;

/**
 * Class GroupWelcomeTemplate
 * @package app\api\controller
 */
class GroupWelcomeTemplate extends Base
{
    /**
     * @throws Exception
     */
    public function add()
    {
        $groupWelcomeTemplateHttpDao = new GroupWelcomeTemplateHttpDao();
        $content = "宝迷姐姐们大家好🎉
👏欢迎来到【宝姐珠宝好物专享群】！

这是首次为各位新宝迷单独创立的好物专享群，群内享受百万级VIP会员同等优惠力度！！！😍😍群内每日分享高定好物、不定时红包🧧🧧！这是我们双十一活动页面，宝迷们可以点击进入抢购心仪的珠宝！";
        $miniprogramAttachment = [
            'title'        => 'BOJEM（宝姐）珠宝官方商城',
            'pic_media_id' => '3HglZs773En_n__WOY9rCAS0Nn3tZWr_rriGK8Xfs65LzZEWlpOaYfq0fHSuHZIgz',
            'appid'        => 'wxf07cf3fb7e470a92',
            'page'         => 'pages/DoubleEleven/DoubleEleven?from=10189'
        ];
        $groupWelcomeTemplateHttpDao->addGroupWelcomeTemplate($content, $miniprogramAttachment);
    }

    /**
     * @throws Exception
     */
    public function edit()
    {
        $templateId = 'msg5b2CBwAAKJA5xC9agmbozNaGOhjcCw';
        $groupWelcomeTemplateHttpDao = new GroupWelcomeTemplateHttpDao();
        $content = "宝迷姐姐们大家好🎉
👏欢迎来到【宝姐珠宝好物专享群】！

这是首次为各位新宝迷单独创立的好物专享群，群内享受百万级VIP会员同等优惠力度！！！😍😍群内每日分享高定好物、不定时红包🧧🧧！";
        $miniprogramAttachment = [
            'title'        => 'BOJEM（宝姐）珠宝官方商城',
            'pic_media_id' => '3EfTb85YwRwDaVKRQn-xsEHdjK3-npMe4axhUr4Kcs2XdtkAYdTStmdMVi2T0gPkf',
            'appid'        => 'wxf07cf3fb7e470a92',
            'page'         => '/pages/allType/allType'
        ];
        $res = $groupWelcomeTemplateHttpDao->editGroupWelcomeTemplate($templateId, $content, $miniprogramAttachment);

        if ($res) {
            Response::success('编辑成功！');
        }
    }
}
