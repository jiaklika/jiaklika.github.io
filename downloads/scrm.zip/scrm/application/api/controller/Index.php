<?php

namespace app\api\controller;

/**
 * Class Index
 * @package app\api\controller
 */
class Index
{
    public function index()
    {
        header("Location: https://www.bojem.com");
    }
}
