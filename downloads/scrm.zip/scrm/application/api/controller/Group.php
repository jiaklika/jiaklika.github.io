<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\group\impl\GroupServiceImpl;
use app\api\validate\PaginationValidate;

/**
 * Class Group
 * @package app\api\controller
 */
class Group extends Base
{
    /**
     * Contact constructor.
     * @param GroupServiceImpl $service
     */
    public function __construct(GroupServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 获取群列表
     *
     * @param PaginationValidate $pageValidate
     */
    public function getGroupList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $groupList = $this->service->getGroupList($requestData);

        Response::success('success', $groupList);
    }

    /**
     * 获取群成员详情
     * @param PaginationValidate $pageValidate
     */
    public function getGroupDetail(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        if (!isset($requestData['group_id']) || empty($requestData['group_id'])) {
            Response::error('参数错误！');
        }

        $groupInfo = $this->service->getGroupDetail($requestData);

        if ($groupInfo) {
            Response::success('success', $groupInfo);
        }

        Response::error('此数据不存在或已删除');
    }

    /**
     * 获取群数量
     */
    public function getGroupCount()
    {
        $keyword = $this->request->get('keyword');

        if (!$keyword) {
            Response::error('参数错误！');
        }

        $groupCount = $this->service->getGroupCount($keyword);

        Response::success('success', $groupCount);
    }

    /**
     * 是否在关键词的群里
     */
    public function isInKeyWordGroup()
    {
        $requestData = $this->request->post();

        if (
            !isset($requestData['union_id'])
            || !isset($requestData['keyword'])
            || empty($requestData['union_id'])
            || empty($requestData['keyword'])
        ) {
            Response::error('参数错误！');
        }

        $isInKeyWordGroup = $this->service->isInKeyWordGroup($requestData);

        Response::success('success', $isInKeyWordGroup);
    }

    /**
     * 获取所有群成员列表
     * @param PaginationValidate $pageValidate
     */
    public function getAllGroupMemberList(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $allGroupMemberList = $this->service->getAllGroupMemberList($requestData);

        if ($allGroupMemberList) {
            Response::success('success', $allGroupMemberList);
        }

        Response::error('此数据不存在或已删除');
    }

    /**
     * 获取所有群列表
     */
    public function getAllGroupList()
    {
        $keyword = $this->request->get('keyword');

        Response::success('success', $this->service->getAllGroupList($keyword));
    }

    /**
     * 获取群的所有邀请者
     */
    public function getInvitorList()
    {
        $groupId = $this->request->get('group_id');

        if (!$groupId) {
            Response::error('参数错误！');
        }

        Response::success('success', $this->service->getInvitorList($groupId));
    }
}
