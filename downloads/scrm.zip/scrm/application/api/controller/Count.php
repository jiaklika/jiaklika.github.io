<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Exception;
use think\Cache;
use think\Db;
use think\Queue;

/**
 * Class Count
 * @package app\api\controller
 */
class Count extends Base
{
    /**
     * @var int 公司
     */
    private const COMPANY = 1;

    /**
     * @var int 个人
     */
    private const USER = 2;

    /**
     * 数据进入redis
     *
     * @throws Exception
     */
    public function countAll()
    {
        $type = request()->get('type');

        $lastWeekEndTime = strtotime('this week Monday');

        $where = [
            'status'     => ContactFollowUser::NORMAL,  // 当前客户
            'createtime' => ['<', $lastWeekEndTime]
        ];

        $model = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.unionid',
                'follow.userid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            );

        if ($type == self::COMPANY) {
            $followUserArr = $model->where($where)
                ->group('follow.external_userid')  //公司的需要去重，但是个人的不需要，因为个人去重后会丢失数据
                ->select();
        } else {
            $userServiceImpl = new UserServiceImpl();

            $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue', false);

            $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

            $where['userid'] = [
                'in',
                array_merge_recursive(
                    [
                        'baojiejoyee',
                        'taotao',
                        'fuliguan',
                        'xiuxiu',
                    ],
                    $feiyueAccountsArr,
                    $zhaoweiAccountsArr
                )
            ];

            $followUserArr = $model->where($where)->select();
        }

        // 队列名
        $jobQueue = 'count_all_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\CountAllJob';

        foreach ($followUserArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Response::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('进入队列');
    }

    /**
     * 统计用户颜值分布
     *
     * @throws Exception
     */
    public function countIntegral()
    {
        $redis = Cache::store()->handler();

        $userServiceImpl = new UserServiceImpl();

        $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $followUserArr = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.unionid',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => ['in', $feiyueAccountsArr],
                'status' => ContactFollowUser::NORMAL
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($followUserArr as $contact) {
            $redis->sAdd('feiyue_contact', $contact['unionid']);
        }

        $groupMemberArr = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'member.unionid'
            ])
            ->join(
                'scrm_contact_groups groups',
                'member.chat_id = groups.chat_id',
                'LEFT'
            )
            ->where([
                'owner'             => ['in', $feiyueAccountsArr],
                'groups.is_deleted' => ContactGroups::NOT_DELETED,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'member.type'       => ContactGroupMembers::EXTERNAL_USER
            ])
            ->group('member.unionid')
            ->select();

        foreach ($groupMemberArr as $groupMember) {
            $redis->sAdd('feiyue_group_contact', $groupMember['unionid']);
        }

        $allUnionIdArr = $redis->sUnion('feiyue_contact', 'feiyue_group_contact');

        // 队列名
        $jobQueue = 'integral_count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\IntegralCountJob';

        foreach ($allUnionIdArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Response::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('进入队列');
    }

    /**
     * feiyue名下的群里有多少人不在zhaowei群里面
     *
     * @throws Exception
     */
    public function countGroupMember()
    {
        $userServiceImpl = new UserServiceImpl();

        $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        $groupMemberArr = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'member.unionid'
            ])
            ->join(
                'scrm_contact_groups groups',
                'member.chat_id = groups.chat_id',
                'LEFT'
            )
            ->where([
                'owner'             => ['in', $feiyueAccountsArr],
                'groups.is_deleted' => ContactGroups::NOT_DELETED,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'member.type'       => ContactGroupMembers::EXTERNAL_USER
            ])
            ->group('member.unionid')
            ->select();

        // 队列名
        $jobQueue = 'count_group_member_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\CountGroupMemberJob';

        foreach ($groupMemberArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact['unionid'], $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Response::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('进入队列');
    }

    /**
     * 在群但不在号里的用户
     *
     * @throws Exception
     */
    public function inGroupNotFriend()
    {
        $groupMemberArr = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'member.unionid'
            ])
            ->join(
                'scrm_contact_groups groups',
                'member.chat_id = groups.chat_id',
                'LEFT'
            )
            ->where([
                'groups.is_deleted' => ContactGroups::NOT_DELETED,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'member.type'       => ContactGroupMembers::EXTERNAL_USER
            ])
            ->group('member.unionid')
            ->select();

        // 队列名
        $jobQueue = 'count_group_member_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\CountGroupMemberJob';

        foreach ($groupMemberArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact['unionid'], $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Response::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('进入队列');
    }

    /**
     * @throws Exception
     */
    public function updateCreateDate()
    {
        $contactsArr = (array)Db::name('contact_follow_user')
                    ->field([
                        'id',
                        'createtime'
                     ])
                    ->limit(300001, 100000)
                    ->select();

        // 队列名
        $jobQueue = 'create_date_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\syncData\CreateDateJob';

        foreach ($contactsArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Response::error('队列出错：' . $e->getMessage());
            }
        }
        Response::success('进入队列');
    }
}
