<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\contactFission\impl\ContactFissionServiceImpl;

/**
 * 企微裂变
 *
 * Class ContactFission
 * @package app\api\controller
 */
class ContactFission extends Base
{
    /**
     * Contact constructor.
     * @param ContactFissionServiceImpl $service
     */
    public function __construct(ContactFissionServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 生成邀请码
     */
    public function getInvitationCode()
    {
        if (!$unionId = $this->request->get('unionid')) {
            Response::error('参数unionid不能为空！');
        }

        $res = $this->service->getInvitationCode($unionId);

        Response::success('success', $res);
    }

    /**
     * 修改结束时间
     */
    public function changeEndTime()
    {
        if (!$endTime = $this->request->get('end_time')) {
            Response::error('参数不能为空！');
        }

        $this->service->changeEndTime($endTime);

        Response::success('success');
    }
}
