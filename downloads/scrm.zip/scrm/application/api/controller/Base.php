<?php

namespace app\api\controller;

use think\Controller;
use think\Request;

/**
 * Class Base
 * @package app\api\controller\v1
 */
class Base extends Controller
{
    /**
     * @var object|Request|null
     */
    public $request = null;

    /**
     * @var null
     */
    public $service = null;

    /**
     * Base constructor.
     * @param $service
     */
    public function __construct($service = null)
    {
        parent::__construct();

        header('Access-Control-Allow-Origin:*');
        //允许的请求头信息
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, Token");
        //允许的请求类型
        header('Access-Control-Allow-Methods: GET, POST, PUT,DELETE,OPTIONS,PATCH');
        //允许携带证书式访问（携带cookie）
        header('Access-Control-Allow-Credentials:true');

        $this->request = Request::instance();
        $this->service = $service;
    }
}
