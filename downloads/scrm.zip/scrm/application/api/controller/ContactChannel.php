<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\channel\impl\ContactChannelServiceImpl;
use app\api\validate\ContactChannelValidate;
use app\api\validate\PaginationValidate;
use app\common\model\ContactChannels;
use Exception;

/**
 * 渠道管理
 *
 * Class ContactChannel
 * @package app\api\controller
 */
class ContactChannel extends Base
{
    /**
     * ContactChannel constructor.
     * @param ContactChannelServiceImpl $service
     */
    public function __construct(ContactChannelServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 渠道列表
     *
     * @param PaginationValidate $pageValidate
     * @throws Exception
     */
    public function index(PaginationValidate $pageValidate)
    {
        $requestData = $this->request->get();

        if (!$pageValidate->check($requestData)) {
            Response::error($pageValidate->getError());
        }

        $channelList = $this->service->index($requestData);

        Response::success('success', $channelList);
    }

    /**
     * 获取渠道详情
     *
     * @throws Exception
     */
    public function detail()
    {
        $channelId = $this->request->get('channel_id');

        if (!$channelId) {
            Response::error('参数错误！');
        }

        $channelInfo = $this->service->detail($channelId);

        if ($channelInfo) {
            Response::success('success', $channelInfo);
        }

        Response::error('此数据不存在或已删除');
    }

    /**
     * 添加渠道
     *
     * @param ContactChannelValidate $validate
     */
    public function add(ContactChannelValidate $validate)
    {
        $channelData = $this->request->post();

        $channelCommonData = [
            'channel_name'    => $channelData['channel_name'],
            'is_open_welcome' => $channelData['is_open_welcome'],
        ];

        if ($channelData['is_open_welcome'] == 1) {
            // 时段验证
            $validateFunc = function ($channelData) use ($channelCommonData, $validate) {
                $channelAllData = array_merge(
                    $channelData,
                    $channelCommonData
                );

                if (!$validate->scene('add')->check($channelAllData)) {
                    Response::error($validate->getError());
                }

                if (
                    !$channelAllData['attachments']
                    && ( !isset($channelAllData['welcome_text'])
                        || $channelAllData['welcome_text'] == '')
                ) {
                    Response::error('文字欢迎语和附件不能同时为空！');
                }
            };

            if ($channelData['is_distinguish_time'] == 1) {
                $validateFunc($channelData['work_time_data']);
                $validateFunc($channelData['off_work_data']);
            }

            /*if (
                isset($channelData['is_random'])
                && $channelData['is_random'] == 1
            ) {
                $issetAndValidate = function ($index) use ($validateFunc, $channelData) {
                    if (isset($channelData[$index])) {
                        $validateFunc($channelData[$index]);
                    }
                };
                for ($i = 1; $i < 6; $i++) {
                    $issetAndValidate($i);
                }
            }*/

            if ($channelData['is_distinguish_time'] == 0) {
                if (
                    !isset($channelData['is_random'])
                    || $channelData['is_random'] == 0
                ) {
                    $validateFunc($channelData['normal_data']);
                }
            }
        } else {
            if (!$validate->scene('add')->check($channelCommonData)) {
                Response::error($validate->getError());
            }
        }

        $createRes = $this->service->add($channelData);

        if ($createRes) {
            write_manager_log('新建渠道。名称：' . $channelData['channel_name']);
            Response::success('新建渠道成功');
        }

        Response::error('新建渠道失败');
    }

    /**
     * 编辑渠道
     *
     * @param ContactChannelValidate $validate
     */
    public function update(ContactChannelValidate $validate)
    {
        $channelData = $this->request->post();

        $channelCommonData = [
            'channel_id'      => $channelData['channel_id'],
            'channel_name'    => $channelData['channel_name'],
            'is_open_welcome' => $channelData['is_open_welcome'],
        ];

        if ($channelData['is_open_welcome'] == 1) {
            // 时段验证
            $validateFunc = function ($channelData) use ($channelCommonData, $validate) {
                $channelAllData = array_merge(
                    $channelData,
                    $channelCommonData
                );

                if (!$validate->scene('edit')->check($channelAllData)) {
                    Response::error($validate->getError());
                }

                if (
                    !$channelAllData['attachments']
                    && ( !isset($channelAllData['welcome_text'])
                        || $channelAllData['welcome_text'] == '')
                ) {
                    Response::error('文字欢迎语和附件不能同时为空');
                }
            };

            if ($channelData['is_distinguish_time'] == 1) {
                $validateFunc($channelData['work_time_data']);
                $validateFunc($channelData['off_work_data']);
            }

            /*if (
                isset($channelData['is_random'])
                && $channelData['is_random'] == 1
            ) {
                $issetAndValidate = function ($index) use ($validateFunc) {
                    if (isset($channelData['"{$index}"'])) {
                        $validateFunc($channelData['"{$index}"']);
                    }
                };
                for ($i = 1; $i < 6; $i++) {
                    $issetAndValidate($i);
                }
            }*/
            if ($channelData['is_distinguish_time'] == 0) {
                if (
                    !isset($channelData['is_random'])
                    || $channelData['is_random'] == 0
                ) {
                    $validateFunc($channelData['normal_data']);
                }
            }
        } else {
            if (!$validate->scene('edit')->check($channelCommonData)) {
                Response::error($validate->getError());
            }
        }

        $updateRes = $this->service->update($channelData);

        if ($updateRes) {
            write_manager_log('编辑渠道。ID：' . $channelData['channel_id']);
            Response::success('编辑渠道成功');
        }

        Response::error('编辑渠道失败');
    }

    /**
     * 删除渠道
     *
     * @param ContactChannelValidate $validate
     */
    public function delete(ContactChannelValidate $validate)
    {
        $channelData = $this->request->post();

        if (!$validate->scene('del')->check($channelData)) {
            Response::error($validate->getError());
        }

        if (
            in_array(
                $channelData['channel_id'],
                array_merge(
                    array_keys(ContactChannels::MOMENT_CHANNEL_MAP),
                    array_keys(ContactChannels::WECHAT_VIDEO_MAP),
                    [
                        ContactChannels::YANGYANG5_CHANNEL_ID,
                        ContactChannels::YANGYANG2_CHANNEL_ID
                    ]
                )
            )
        ) {
            Response::error('此渠道禁止删除！');
        }

        $deleteRes = $this->service->delete($channelData['channel_id']);

        if ($deleteRes !== false) {
            write_manager_log('删除渠道。ID：' . $channelData['channel_id']);
            Response::success('删除成功');
        }

        Response::error('删除失败');
    }

    /**
     * 上传临时素材
     *
     * @throws Exception
     */
    public function uploadMedia()
    {
        $file = $this->request->file('welcome_media');

        if (!$file) {
            Response::error('请选择上传文件！');
        }

        $fileType = $file->getInfo('type');

        $type = substr($fileType, 0, strpos($fileType, '/'));

        if (!in_array($type, ['image', 'video'])) {
            $type = 'file';
        }

        $res = $this->service->uploadMedia($type, $file);

        if ($res) {
            Response::success('上传成功！', $res);
        }

        Response::error('上传失败！');
    }

    /**
     * 上传欢迎语图片
     *
     * @throws Exception
     */
    public function uploadImg()
    {
        $file = $this->request->file('welcome_image');

        if (!$file) {
            Response::error('请选择上传文件！');
        }

        [$status, $uploadRes] = $this->service->uploadImg($file);

        if ($status) {
            Response::success('上传成功！', $uploadRes);
        }

        Response::error($uploadRes);
    }

    /**
     * 小程序列表
     *
     * @return void
     */
    public function getMiniProgramAppId()
    {
        $miniProgramArr = ContactChannels::MINI_PROGRAM_APP_ID_MAP;

        $miniProgramAppInfo = [];

        foreach ($miniProgramArr as $miniProgramId => $miniProgramName) {
            $miniProgramAppInfo[] = [
                'name'  => $miniProgramName,
                'appId' => $miniProgramId
            ];
        }

        Response::success('success', $miniProgramAppInfo);
    }

    /**
     * 转换旧数据为json
     */
    public function changeDataToJson()
    {
        if ($this->service->changeDataToJson()) {
            Response::success('转换成功！');
        }

        Response::error('转换失败');
    }

    /**
     * 添加统一咨询管理员工
     */
    public function addUnifyService()
    {
        $requestData = $this->request->post();

        if (!isset($requestData['userid']) || !$requestData['userid']) {
            Response::error('参数错误！');
        }

        if ($this->service->addUnifyService($requestData['userid'])) {
            Response::success('添加成功！');
        }

        Response::error('添加失败！');
    }

    /**
     * 获取统一咨询员工
     */
    public function getUnifyService()
    {
        Response::success('success', $this->service->getUnifyService());
    }
}
