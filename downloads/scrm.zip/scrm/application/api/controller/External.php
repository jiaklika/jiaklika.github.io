<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\service\external\impl\ExternalServiceImpl;

/**
 * Class External
 * @package app\api\controller
 */
class External extends Base
{
    /**
     * 新人承接页需求，自动发送卡片数据
     */
    public function card()
    {
        $title = $this->request->get('title');
        $pic = $this->request->get('pic');
        $path = $this->request->get('path');
        $unionId = $this->request->get("union_id");

        $service = new ExternalServiceImpl();
        $service->card($unionId, $title, $pic, $path);

        Response::success('success');
    }
}
