<?php

namespace app\api\controller;

use app\api\service\callback\impl\ContactCallbackServiceImpl;
use app\api\service\callback\impl\KefuCallbackServiceImpl;
use Exception;

/**
 * 微信客服回调事件
 *
 * Class KefuCallback
 * @package app\api\controller
 */
class KefuCallback extends Base
{
    /**
     * KefuCallback constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 微信客服回调事件
     *
     * @param KefuCallbackServiceImpl $service
     * @throws Exception
     */
    public function kefuEvent(KefuCallbackServiceImpl $service)
    {
        $contactCallback = config('kefu_callback.kefu_callback');

        $service->setSecret(
            $contactCallback['kefu_encodingAesKey'],
            $contactCallback['kefu_token']
        );
        $this->verifyAndDecrypt($service);
    }

    /**
     * 验证和解密数据
     *
     * @param object $service 处理数据的service
     * @return void
     * @throws Exception
     */
    private function verifyAndDecrypt($service)
    {
        [
            $sReqMsgSig,
            $sReqTimeStamp,
            $sReqNonce,
        ] = [
            $this->request->get('msg_signature'),
            $this->request->get('timestamp'),
            $this->request->get('nonce'),
        ];

        if ($this->request->isGet()) {
            $sVerifyEchoStr = $this->request->get('echostr');
            $service->VerifyURL($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sVerifyEchoStr);
            exit();
        }

        if ($this->request->isPost()) {
            // 密文
            $sReqData = $this->request->getContent();

            $callbackUrl = $this->request->url();

            $decryptData = $service->decryptMsg($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sReqData);

            $logId = $service->addCallbackLog($sReqData, $decryptData, $callbackUrl);

            if (!empty($decryptData)) {
                $service->handleData($logId, xmlToArray($decryptData));
            }
        }

        echo 'success';
        exit();
    }
}
