<?php

namespace app\api\controller;

use app\api\common\Response;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\kefu\KefuCustomerInfoDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\contact\impl\ContactServiceImpl;
use app\api\service\user\impl\UserServiceImpl;
use app\api\validate\PaginationValidate;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Exception;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use think\Cache;
use think\Db;
use think\Log;
use think\Queue;
use think\Request;

/**
 * 对外联系人管理
 *
 * Class Contact
 * @package app\api\controller
 */
class Contact extends Base
{
    /**
     * Contact constructor.
     * @param ContactServiceImpl $service
     */
    public function __construct(ContactServiceImpl $service)
    {
        parent::__construct($service);
    }

    /**
     * 获取js-sdk的配置信息
     */
    public function getConfig()
    {
        if (!$url = $this->request->get('url')) {
            Response::error('参数url不能为空');
        }

        $res = $this->service->getConfig($url);

        Response::success('success', $res);
    }

    /**
     * H5跳转获取客户详情
     */
    public function getDetail()
    {
        // 外部联系人的userId
        $externalContactUserId = $this->request->get('userId');

        if (empty($externalContactUserId)) {
            Response::error('参数userId不能为空');
        }

        $returnData = $this->service->getDetail($externalContactUserId);

        Response::success('success', $returnData);
    }

    /**
     * 读取所有的外部联系人列表并入表
     */
    public function initContactList()
    {
        $res = $this->service->initContactList();

        if ($res) {
            Response::success('添加所有用户的对外联系人成功！');
        }

        Response::error('添加所有用户的对外联系人失败！');
    }

    /**
     * 获取所有对外联系人的详情步骤1
     * @throw Exception;
     */
    public function initContactDetailStep1()
    {
        [$status, $message] = $this->service->initContactDetail();

        if ($status) {
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 获取所有对外联系人的详情步骤2
     */
    public function initContactDetailStep2()
    {
        [$status, $message] = $this->service->getRedisData();

        if ($status) {
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 获取所有对外联系人的详情步骤3
     */
    public function initContactDetailStep3()
    {
        [$status, $message] = $this->service->updateUserLevel();

        if ($status) {
            Response::success($message);
        }

        Response::error($message);
    }

    /**
     * 统计实际的对外联系人数量
     */
    public function getActualContactCount()
    {
        return $this->service->getUserBehaviorData('BaoJieJiaKeFu');
    }

    /**
     * 获取宝姐客户等级列表
     *
     * @return void
     */
    public function getUserLevelList()
    {
        $userLevelList = $this->service->getUserLevelList();
        Response::success('success', $userLevelList);
    }

    /**
     * 获取路径的客户列表
     *
     * @param PaginationValidate $pagination
     */
    public function getWayContactList(PaginationValidate $pagination)
    {
        $searchInfo = $this->request->get();

        if (!$pagination->check($searchInfo)) {
            Response::error($pagination->getError());
        }

        if (
            !isset($searchInfo['way_id'])
            || empty($searchInfo['way_id'])
        ) {
            Response::error('参数错误！');
        }

        $contactList = $this->service->getWayContactList($searchInfo);

        Response::success('success', $contactList);
    }

    /**
     * 获取渠道的客户列表
     *
     * @param PaginationValidate $pagination
     */
    public function getChannelContactList(PaginationValidate $pagination)
    {
        $searchInfo = $this->request->get();

        if (!$pagination->check($searchInfo)) {
            Response::error($pagination->getError());
        }

        if (
            !isset($searchInfo['channel_id'])
            || empty($searchInfo['channel_id'])
        ) {
            Response::error('参数错误！');
        }

        $contactList = $this->service->getChannelContactList($searchInfo);

        Response::success('success', $contactList);
    }

    /**
     * 企微客户
     *
     * @param PaginationValidate $pagination
     */
    public function getAllContactList(PaginationValidate $pagination)
    {
        $searchInfo = $this->request->get();

        if (!$pagination->check($searchInfo)) {
            Response::error($pagination->getError());
        }

        $contactList = $this->service->getAllContactList($searchInfo);

        Response::success('success', $contactList);
    }

    /**
     * 获取添加形式选项
     */
    public function getAddWayList()
    {
        $addWayList = $this->service->getAddWayList();

        Response::success('success', $addWayList);
    }

    /**
     * 导出渠道客户列表Excel
     */
    public function exportChannelContactList()
    {
        $searchInfo = $this->request->get();

        if (
            !isset($searchInfo['channel_id'])
            || empty($searchInfo['channel_id'])
        ) {
            Response::error('参数错误！');
        }

        if (!$this->service->exportChannelContactList($searchInfo)) {
            Response::error('数据不存在！');
        }
    }

    /**
     * 导出路径客户列表Excel
     */
    public function exportWayContactList()
    {
        $searchInfo = $this->request->get();

        if (
            !isset($searchInfo['way_id'])
            || empty($searchInfo['way_id'])
        ) {
            Response::error('参数错误！');
        }

        if (!$this->service->exportWayContactList($searchInfo)) {
            Response::error('数据不存在！');
        }
    }

    /**
     * 导出企微客户列表Excel
     */
    public function exportAllContactList()
    {
        $searchInfo = $this->request->get();

        if (!$this->service->exportAllContactList($searchInfo)) {
            Response::error('数据不存在！');
        }
    }

    /**
     * 导出客户第一步
     */
    public function exportContact1()
    {
        $res = $this->service->exportContact1();

        if ($res) {
            Response::success('执行成功！');
        }

        Response::error('执行失败！');
    }

    /**
     * 导出客户第二步
     *
     * @throws Exception
     */
    public function exportContact2()
    {
        $this->service->exportContact2();
    }

    /**
     * 更新客户等级
     */
    public function updateUserLevel1()
    {
        $res = $this->service->updateUserLevel1();

        if ($res) {
            Response::success('执行成功！');
        }

        Response::error('执行失败！');
    }

    /**
     * 更新客户等级
     *
     * @throws Exception
     */
    public function updateUserLevel2()
    {
        $res = $this->service->updateUserLevel2();

        if ($res) {
            Response::success('更新成功！');
        }

        Response::error('更新失败！');
    }

    /**
     * 读取Excel
     *
     * @param Request $request
     * @throws Exception
     */
    public function readExcel(Request $request)
    {
        set_time_limit(0);
        $excel = $request->file('excel');

        if (!$excel) {
            Response::error('请选择一个Excel文件');
        }

        [$res, $msg] = uploadFile($excel, 10485760, ['xlsx']);

        if (!$res) {
            Response::error($msg);
        }

        $excelPath = $msg->getPathname();

        // $reader = new Xls();
        $reader = new Xlsx();

        $spreadsheet = $reader->load($excelPath);

        $sheet = $spreadsheet->getActiveSheet();

        /*$res = array();

        foreach ($sheet->getRowIterator(2) as $row) {

            $tmp = array();

            foreach ($row->getCellIterator() as $cell) {
                $tmp[] = $cell->getFormattedValue();
            }

            $res[$row->getRowIndex()] = $tmp;

        }*/

        $rows = $sheet->getHighestRow();

        $value = [];
        // 遍历，并读取单元格内容
        for ($i = 1; $i <= $rows; $i++) {
            $value[$i] = $sheet->getCell('A' . $i)->getValue();

            /*$timeStamp = $sheet->getCell('D' . $i)->getValue();
            $toTimestamp = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToTimestamp($timeStamp);
            $date = date("Y-m-d", $toTimestamp);
            $value[$i]['date'] = $date;*/
            /*$timeStamp = $sheet->getCell('J' . $i)->getValue();

            $toTimestamp = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToTimestamp($timeStamp);
            $date = date("Y-m-d", $toTimestamp);

            $value[$i]['year'] = substr($date, 0, 4);
            $value[$i]['month'] = substr($date, -5, 2);*/
        }

        // 关闭
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);

        @unlink($excelPath);

        // $unionIdArr = array_column($value, '0');

        $redis = Cache::store()->handler();
        foreach ($value as $item) {
            $redis->sadd('view', $item);
        }

        return;

        /*
        // 队列名
        $jobQueue = 'excel_count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\ExcelCountJob';
        */

        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\MarkPropagandaTagJob';

        /*$jobQueue = 'count_job_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\CountJob';*/
        foreach ($value as $item) {
            try {
                //$redis = Cache::store()->handler();
                // 去重
                /*if ($redis->sIsMember('all_contact', $item['unionid']) == false) {
                    $redis->sadd('all_contact', $item['unionid']);
                } else {
                    continue;
                }*/

                // 推送到队列
                $isPushed = Queue::push($jobHandler, $item, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }
    }

    /**
     * 读取json文件
     *
     * @param Request $request
     * @throws Exception
     */
    public function readJson(Request $request)
    {
        $jsonFile = $request->file('json_file');

        if (!$jsonFile) {
            Response::error('请选择一个json文件');
        }

        [$res, $msg] = uploadFile($jsonFile, 10485760, ['json']);

        if (!$res) {
            Response::error($msg);
        }

        $filePath = $msg->getPathname();
        ;

        $readJson = function () use ($filePath) {
            $handle = fopen($filePath, 'rb');

            while (feof($handle) === false) {
                yield fgets($handle);
            }

            fclose($handle);
        };

        $allUnionIdJson = '';

        foreach ($readJson() as $key => $value) {
            $allUnionIdJson .= $value;
        }

        $allUnionIdArr = json_decode($allUnionIdJson, true);

        $allUnionId = array_column($allUnionIdArr['RECORDS'], 'unionid');

        /*
        // 队列名
        $jobQueue = 'excel_count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\ExcelCountJob';
        */

        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\MarkPropagandaTagJob';

        foreach ($allUnionId as $item) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, ['unionid' => $item], $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }
    }

    /**
     * 获取单条统计数据
     */
    public function getSingleStatisticsData()
    {
        $userId = $this->request->get('user_id');

        $statisticsData = $this->service->getSingleStatisticsData($userId);

        Response::success('success', $statisticsData);
    }

    /**
     * 获取公司的统计数据
     */
    public function getCompanyStatisticsData()
    {
        $statisticsData = $this->service->getCompanyStatisticsData();

        Response::success('success', $statisticsData);
    }

    /**
     * 订单消息
     *
     * @throws Exception
     */
    public function orderInfo()
    {
        $unionIdArr = [
            'owTq1jkRd9kxkLNOckrRZTxbInfg',
        ];

        $contactHttpDao = new ContactHttpDao();

        $newOrderList = [];

        foreach ($unionIdArr as $unionId) {
            $orderList = $contactHttpDao->getMediaOrderList($unionId, 0, 0, 1);

            if ($orderList) {
                foreach ($orderList as $order) {
                    switch ($order['order_prom_type']) {
                        case 0:
                        default:
                            $typeName = '普通';
                            break;
                        case 1:
                            $typeName = '秒杀';
                            break;
                        case 4:
                            $typeName = '预售';
                            break;
                        case 8:
                            $typeName = '直播';
                            break;
                    }

                    $newOrderList[] = [
                        'unionid' => $unionId,
                        'type'    => $typeName,
                        'amount'  => $order['order_amount'],
                    ];
                }
            }
        }

        downloadExcel('一元兑换券消费', function ($spreadsheet) use ($newOrderList) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'unionID')
                ->setCellValue('B1', '订单类型')
                ->setCellValue('C1', '订单金额');

            foreach ($newOrderList as $key => $contact) {
                $excelKey = $key + 2;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['unionid'])
                    ->setCellValue('B' . $excelKey, $contact['type'])
                    ->setCellValue('C' . $excelKey, $contact['amount'] ? : '');
            }
        });
        die;
    }

    /**
     * 统计最近未登陆三端应用的人数
     *
     * @throws Exception
     */
    public function lastLoginCount()
    {
        $res = $this->service->lastLoginCount();
        Response::success('success', $res);
    }

    /**
     * 根据unionId判断是否是朋友
     */
    public function isFriend()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isFriend($unionId);

        Response::success('success', $res);
    }

    /**
     * 根据unionId判断是否是朋友和入群
     */
    public function isJoinGroup()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isJoinGroup($unionId);

        Response::success('success', $res);
    }


    /**
     * 用户是否在公司企业微信任意个人号中或社群中
     */
    public function isContactOrGroupMember()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isContactOrGroupMember($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否和媛媛互为好友
     */
    public function isYuanyuanFriend()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isYuanyuanFriend($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否和赵蔚名下的账号是陌生关系
     */
    public function isZhaoweiStranger()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isZhaoweiStranger($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否和赵蔚名下的账号是好友
     */
    public function isZhaoweiFriend()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isZhaoweiFriend($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否和费月名下的账号是好友
     */
    public function isFeiyueFriend()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isFeiyueFriend($unionId);

        Response::success('success', $res);
    }

    /**
     * 找出未打标签的客户
     * @throws Exception
     */
    public function findDiff(): bool
    {
        $redis = Cache::store()->handler();

        $tagIdArr = ContactTagsDao::getAllList(
            ['tag_id'],
            [
                'group_id' => 'et5b2CBwAAhdxSELLTK9WEjrqPaoi8Cg'
            ]
        );

        $newTagIdArr = array_column($tagIdArr, 'tag_id');

        $tagExternal = (array)Db::name('contact_tag_map')
            ->distinct(true)
            ->field(['external_userid'])
            ->where([
                'tag_id' => ['in', $newTagIdArr]
                //'tag_id' => 'et5b2CBwAAvg-hglO69MrESQnJM3a86w'
            ])
            ->select();

        $redis->pipeline();

        foreach ($tagExternal as $value) {
            $redis->sadd('tag_set', $value['external_userid']);
        }

        $redis->exec();

        $allExternal = (array)Db::name('contact_follow_user')
            ->distinct(true)
            ->field(['external_userid'])
            ->where([
                'status' => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT],
                'state' => 108
            ])
            ->select();

        $redis->pipeline();

        foreach ($allExternal as $val) {
            $redis->sadd('all_set', $val['external_userid']);
        }

        $redis->exec();

        $diffExternal = $redis->sDiff('all_set', 'tag_set');

        // 队列名
        $jobQueue = 'mark_tag123_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\OtherMarkTag123Job';

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid',
                'follow.state'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'follow.external_userid' => ['in', $diffExternal]
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 是否是费月名下的宝姐家粉丝颜值福利群的成员
     */
    public function isFeiyueGroupMember()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isFeiyueGroupMember($unionId);

        Response::success('success', $res);
    }

    /**
     * 获取来源渠道
     */
    public function getSourceChannel()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->getSourceChannel($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否在赵蔚的群中
     */
    public function isInZhaoweiGroup()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isInZhaoweiGroup($unionId);

        Response::success('success', $res);
    }

    /**
     * 是否有过加人记录，是否加群
     */
    public function getRelationshipRecord()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->getRelationshipRecord($unionId);

        Response::success('success', $res);
    }

    /**
     * 删除加好友记录
     */
    public function deleteFriend()
    {
        $unionId = $this->request->get('unionid');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        if ($this->service->deleteFriend($unionId)) {
            Response::success('删除加好友记录成功！');
        }

        Response::error('删除加好友记录失败！');
    }

    /**
     * 删除进群记录
     */
    public function deleteGroup()
    {
        $unionId = $this->request->get('unionid');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        if ($this->service->deleteGroup($unionId)) {
            Response::success('删除进群记录成功！');
        }

        Response::error('删除进群记录失败！');
    }

    /**
     * 首次添加，进入队列
     *
     * @throws Exception
     */
    public function allContactToRedis()
    {
        // 队列名
        /*$jobQueue = 'find_first_add_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\syncData\FindFirstAddJob';

        $allContact = ContactDao::getAllList(
            ['external_userid'],
            [
                'external_userid' => ['<>', '']
            ]
        );*/

        $jobQueue = 'update_consume_amount_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\syncData\UpdateIsConsumeJob';

        ContactDao::handleDataByChunk(
            [
                'id',
                'unionid',
                'external_userid'
            ],
            [
                'unionid' => ['<>', '']
            ],
            10000,
            function ($allContact) use ($jobHandler, $jobQueue) {
                if (!$allContact) {
                    return false;
                }

                foreach ($allContact as $contact) {
                    try {
                        // 推送到队列
                        $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                        if ($isPushed !== false) {
                            continue;
                        }
                    } catch (Exception $e) {
                        Log::error('队列出错：' . $e->getMessage());
                        Response::error('队列出错：' . $e->getMessage());
                    }
                }
                return true;
            }
        );

        Response::success('执行成功！');
    }

    /**
     * 读取和修改xlsx
     */
    public function readAndChangeExcel(Request $request)
    {
        ini_set('memory_limit', '520M');
        set_time_limit(0);
        $excel = $request->file('excel');

        if (!$excel) {
            Response::error('请选择一个Excel文件');
        }

        [$res, $msg] = uploadFile($excel, 10485760, ['xlsx']);

        if (!$res) {
            Response::error($msg);
        }

        $excelPath = $msg->getPathname();

        $reader = new Xlsx();

        $spreadsheet = $reader->load($excelPath);

        $sheet = $spreadsheet->getActiveSheet(0);

        /*$res = array();

        foreach ($sheet->getRowIterator(2) as $row) {

            $tmp = array();

            foreach ($row->getCellIterator() as $cell) {
                $tmp[] = $cell->getFormattedValue();
            }

            $res[$row->getRowIndex()] = $tmp;

        }*/

        $rows = $sheet->getHighestRow();

        $value = [];
        // 遍历，并读取单元格内容
        for ($i = 2; $i <= $rows; $i++) {
            $value[$i] = $sheet->getCell('B' . $i)->getValue();
        }

        // 关闭
        // $spreadsheet->disconnectWorksheets();
        // unset($spreadsheet);

        // @unlink($excelPath);

        $contactHttpDao = new ContactHttpDao();

        try {
            foreach ($value as $key => $unionId) {
                $userInfo = $contactHttpDao->getUserCenter($unionId);

                $isConsult = KefuCustomerInfoDao::getAllList(['id'], [
                    'unionid' => $unionId
                ]);

                $followInfo = (array)Db::name('contact_follow_user')
                    ->alias('follow')
                    ->join(
                        'external_contact contact',
                        'follow.external_userid = contact.external_userid',
                        'left'
                    )
                    ->field([
                        'contact.unionid'
                    ])
                    ->where([
                        'unionid' => $unionId,
                        'status'  => ContactFollowUser::NORMAL
                    ])
                    ->select();

                $groupInfo = (array)Db::name('contact_group_members')
                    ->alias('member')
                    ->field([
                        'unionid'
                    ])
                    ->join(
                        'scrm_contact_groups group',
                        'member.chat_id = group.chat_id',
                        'LEFT'
                    )
                    ->where([
                        'member.unionid'    => $unionId,
                        'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                        'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
                    ])
                    ->select();


                $excelKey = $key + 2;
                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('C' . $excelKey, $userInfo['user_level_name'] ? : '新人')
                    ->setCellValue('D' . $excelKey, $userInfo['consume_amount'] > 0 ? '是' : '否')
                    ->setCellValue('E' . $excelKey, $userInfo['consume_amount'] ? : 0)
                    ->setCellValue('G' . $excelKey, $isConsult ? '是' : '否')
                    ->setCellValue('H' . $excelKey, $followInfo ? '是' : '否')
                    ->setCellValue('I' . $excelKey, $groupInfo ? '是' : '否')
                    ->setCellValue('K' . $excelKey, $userInfo['first_consume_date']);
            }
        } catch (Exception $e) {
            print_r($e->getMessage());
        }

        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        try {
            $writer->save('3.xlsx');
        } catch (Exception $e) {
            print_r($e->getMessage());
        }
    }

    /**
     * 获取客户所在群名
     */
    public function getContactGroup()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->getContactGroup($unionId);

        Response::success('success', $res);
    }

    /**
     * 导出Excel
     *
     * @throws Exception
     */
    public function exportExcel()
    {
        $externalUserIdArr = ContactTagMapDao::getAllList(
            [
                'external_userid'
            ],
            [
                'tag_id' => 'et5b2CBwAA7-Flu64Kxdzq2xWr-En5LQ'
            ]
        );

        $pureExternalUserIdArr = array_column($externalUserIdArr, 'external_userid');

        $redis = Cache::store()->handler();

        foreach ($pureExternalUserIdArr as $value) {
            if (!$redis->sIsMember('a', $value)) {
                $redis->sAdd('a', $value);
            }
        }

        $userServiceImpl = new UserServiceImpl();

        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue');
        /*$newOrderList = DB::name('external_contact')
            ->alias('a')
            ->field([
                'a.unionid',
                'a.name as nick',
                'b.name',
                'a.user_level_id'
            ])
            ->join('scrm_contact_group_members c', 'a.unionid = c.unionid', 'left')
            ->join('scrm_contact_groups b', 'c.chat_id = b.chat_id', 'left')
            ->where([
                'a.external_userid' => ['in', $pureExternalUserIdArr]
            ])
            ->select();*/

        $newOrderList = (array)DB::name('external_contact')
            ->alias('a')
            ->field([
                'a.unionid',
                'a.name as nick',
                'b.userid',
                'a.user_level_id'
            ])
            ->join('scrm_contact_follow_user b', 'a.external_userid = b.external_userid', 'left')
            ->where([
                'a.external_userid' => ['in', $pureExternalUserIdArr],
                'b.status' => 0,
                'b.userid' => ['in', $feiyueAccounts]
            ])
            ->select();

        $userIdArr = array_column($newOrderList, 'userid');

        $userArr = UserDao::getAllList(['name','userid'], [
            'userid' => ['in', $userIdArr]
        ]);

        $newUserArr = [];
        foreach ($userArr as $user) {
            $newUserArr[$user['userid']] = $user['name'];
        }

        foreach ($newOrderList as &$value) {
            switch ($value['user_level_id']) {
                case 0:
                    $value['user_level_name'] = '新人';
                    break;
                case 1:
                    $value['user_level_name'] = '宝迷';
                    break;
                case 2:
                    $value['user_level_name'] = '忠实宝迷';
                    break;
                case 3:
                    $value['user_level_name'] = '铁杆宝迷';
                    break;
                case 4:
                    $value['user_level_name'] = '名媛';
                    break;
                case 5:
                    $value['user_level_name'] = '风尚名媛';
                    break;
                case 6:
                    $value['user_level_name'] = '至尊名媛';
                    break;
            }
        }

        downloadExcel('转粉', function ($spreadsheet) use ($newOrderList, $newUserArr) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'unionID')
                ->setCellValue('B1', '昵称')
                ->setCellValue('C1', '所在号')
                ->setCellValue('D1', '会员等级');

            foreach ($newOrderList as $key => $contact) {
                $excelKey = $key + 2;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['unionid'])
                    ->setCellValue('B' . $excelKey, $contact['nick'])
                    ->setCellValue('C' . $excelKey, $newUserArr[$contact['userid']])
                    ->setCellValue('D' . $excelKey, $contact['user_level_name'] ? : '');
            }
        });
    }

    /**
     * 是否从来没有加过企微（客服或群）
     */
    public function isPureStranger()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isPureStranger($unionId);

        Response::success('success', $res);
    }

    /**
     * 保存推粉数据
     */
    public function savePushFans()
    {
        $pushFansArr = $this->request->post();

        $res = $this->service->savePushFans($pushFansArr);

        Response::success('success', $res);
    }

    /**
     * 添加好友的时间
     */
    public function addFriendTime()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['way_id'])
            || empty($requestData['way_id'])
            || !isset($requestData['unionid'])
            || empty($requestData['unionid'])
        ) {
            Response::error('参数错误！');
        }

        $res = $this->service->addFriendTime($requestData);

        Response::success('success', $res);
    }

    /**
     * 获取企微二维码
     */
    public function getFriendQRCode()
    {
        $requestData = $this->request->get();

        if (
            !isset($requestData['unionid'])
            || empty($requestData['unionid'])
            || !isset($requestData['way_id'])
            || empty($requestData['way_id'])
        ) {
            Response::error('参数错误！');
        }

        $res = $this->service->getFriendQRCode($requestData);

        Response::success('success', $res);
    }

    /**
     * 获取好友名称
     */
    public function getFriendsName()
    {
        $unionIdArr = $this->request->post();

        if (!$unionIdArr) {
            Response::error('参数错误！');
        }

        $res = $this->service->getFriendsName($unionIdArr);

        Response::success('success', $res);
    }

    /**
     * 是否是招募官好友
     */
    public function isRecruitingOfficerFriend()
    {
        $unionId = $this->request->get('union_id');

        if (!$unionId) {
            Response::error('参数错误！');
        }

        $res = $this->service->isRecruitingOfficerFriend($unionId);

        Response::success('success', $res);
    }

    /**
     * 根据数组获取加人和加群记录
     */
    public function getArrayRecord()
    {
        $requestData = $this->request->post();

        Response::success('success', $this->service->getArrayRecord($requestData));
    }
}
