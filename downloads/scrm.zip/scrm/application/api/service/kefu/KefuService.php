<?php

declare(strict_types=1);

namespace app\api\service\kefu;

interface KefuService
{

}
