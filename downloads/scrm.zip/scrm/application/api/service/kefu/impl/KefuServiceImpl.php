<?php

namespace app\api\service\kefu\impl;

use app\api\dao\http\kefu\KefuHttpDao;
use app\api\dao\mysql\kefu\KefuAccountsDao;
use app\api\dao\mysql\kefu\KefuAccountUrlDao;
use app\api\dao\mysql\kefu\KefuChatRecordsDao;
use app\api\dao\mysql\kefu\KefuCustomerInfoDao;
use app\api\dao\mysql\kefu\KefuKeywordMapDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyAttachmentsDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyDao;
use app\api\dao\mysql\kefu\KefuMsgLogDao;
use app\api\dao\mysql\kefu\KefuMsgMenuDao;
use app\api\dao\mysql\kefu\KefuServicerMapDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\kefu\KefuService;
use app\api\service\user\impl\UserServiceImpl;
use app\api\util\FileManager;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\kefu\KefuAccounts;
use app\common\model\kefu\KefuAccountUrl;
use app\common\model\kefu\KefuChatList;
use app\common\model\User;
use Exception;
use think\Db;
use think\File;

/**
 * 微信客服
 *
 * Class KefuServiceImpl
 * @package app\api\service\kefu\impl
 */
class KefuServiceImpl implements KefuService
{
    /**
     * @var KefuHttpDao
     */
    private static $kefuHttpDao;

    /**
     * KefuServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$kefuHttpDao)) {
            self::$kefuHttpDao = new KefuHttpDao();
        }
    }

    /**
     * 上传临时文件
     *
     * @param string $type 文件类型
     * @param File $file
     * @return array
     * @throws Exception
     */
    public function uploadMedia(string $type, File $file): array
    {
        $fileManager = new FileManager();

        return $fileManager->uploadMedia($type, $file);
    }

    /**
     * 搜索员工
     *
     * @param string|null $keyword
     * @return array
     * @throws Exception
     */
    public function searchUser(?string $keyword): array
    {
        $where = [
            'is_deleted' => User::NOT_DELETED
        ];

        if ($keyword) {
            $where['name'] = ['like', "%{$keyword}%"];
        }

        return UserDao::getAllList(
            [
                'userid',
                'name'
            ],
            $where
        );
    }

    /**
     * 添加客服账号
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function addAccount(array $requestData): bool
    {
        // 添加客户账号
        if (
            $openKfId = self::$kefuHttpDao->addKefuAccount(
                $requestData['account_name'],
                $requestData['kf_media_id']
            )
        ) {
            $insertData = $this->handleAccountData($requestData, $openKfId);

            $insertData['open_kfid'] = $openKfId;

            // 添加接待人员
            $userIdArr = $requestData['userid'];
            $serviceMapRes = false;

            $mapInsertData = $this->addService($openKfId, $userIdArr);

            Db::startTrans();

            $accountRes = KefuAccountsDao::addData($insertData);
            if ($mapInsertData) {
                $serviceMapRes = KefuServicerMapDao::addBatchData($mapInsertData);
            }

            if ($accountRes && $serviceMapRes) {
                Db::commit();
                return true;
            } else {
                Db::rollback();
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 编辑客服账号
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function editAccount(array $requestData): bool
    {
        $openKfId = $requestData['open_kfid'];

        $editData = $this->handleAccountData($requestData);

        // 原来的名称和头像
        $previousAccountArr = KefuAccountsDao::getDetail(
            [
                'account_name',
                'kf_media_id'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        // 原来的接待人员
        $previousServiceArr = KefuServicerMapDao::getAllList(
            [
                'userid'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );
        $previousUserIdArr = array_column($previousServiceArr, 'userid');

        // 现在的接待人员
        $nowUserIdArr = $requestData['userid'];

        // 新添加的
        $addUserId = array_values(array_diff($nowUserIdArr, $previousUserIdArr));
        // 移除的
        $reduceUserId = array_values(array_diff($previousUserIdArr, $nowUserIdArr));

        try {
            if ($previousAccountArr['account_name'] != $requestData['account_name']) {
                self::$kefuHttpDao->updateKefuAccount(
                    $openKfId,
                    $requestData['account_name']
                );
            }

            if ($previousAccountArr['kf_media_id'] != $requestData['kf_media_id']) {
                self::$kefuHttpDao->updateKefuAccount(
                    $openKfId,
                    '',
                    $requestData['kf_media_id']
                );
            }

            $addMapRes = $delRes = true;
            Db::startTrans();

            if ($addUserId) {
                // 添加接待人员
                $mapInsertData = $this->addService($openKfId, $addUserId);
                if ($mapInsertData) {
                    $addMapRes = KefuServicerMapDao::addBatchData($mapInsertData);
                }
            }

            if ($reduceUserId) {
                // 移除接待人员
                $delServiceList = self::$kefuHttpDao->delKefuServicer($openKfId, $reduceUserId);
                $delUserIdArr = [];
                $delErrorStr = '';
                if ($delServiceList) {
                    foreach ($delServiceList as $delValue) {
                        if ($delValue['errmsg'] == 'success') {
                            $delUserIdArr[] = $delValue['userid'];
                        } else {
                            $delErrorStr .= $delValue['userid'] . '-' . $delValue['errmsg'];
                        }
                    }
                    if ($delUserIdArr) {
                        KefuServicerMapDao::hardDelete([
                            'open_kfid' => $openKfId,
                            'userid'    => ['in', $delUserIdArr]
                        ]);
                    }
                    if ($delErrorStr) {
                        send_msg_to_wecom($openKfId . '移除接待人员失败-' . $delErrorStr);
                    }
                }
            }

            $updateRes = KefuAccountsDao::updateData($editData, ['open_kfid' => $openKfId]);

            if ($addMapRes && $updateRes !== false) {
                Db::commit();
                return true;
            } else {
                Db::rollback();
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
            Db::rollback();
        }
        return false;
    }

    /**
     * 添加接待人员
     *
     * @param string $openKfId
     * @param array $userIdArr
     * @return array
     * @throws Exception
     */
    private function addService(string $openKfId, array $userIdArr): array
    {
        $addServiceRes = self::$kefuHttpDao->addKefuServicer($openKfId, $userIdArr);
        // 添加成功的
        $successAddArr = [];
        // 失败的
        $errAddStr = '';
        foreach ($addServiceRes as $addRes) {
            if ($addRes['errmsg'] == 'success') {
                $successAddArr[] = $addRes['userid'];
            } else {
                $errAddStr .= $addRes['userid'] . '-' . $addRes['errmsg'];
            }
        }

        $mapInsertData = [];
        // 一开始全部设置为下一个
        foreach ($successAddArr as $userId) {
            $mapInsertData[] = [
                'open_kfid' => $openKfId,
                'userid'    => $userId,
                'is_next'   => 1
            ];
        }

        if ($errAddStr) {
            send_msg_to_wecom($openKfId . '添加接待人员失败-' . $errAddStr);
        }

        return $mapInsertData;
    }

    /**
     * 处理数据
     *
     * @param array $requestData 请求数据
     * @return array
     */
    private function handleAccountData(array $requestData): array
    {
        $accountData = [
            'account_name'       => $requestData['account_name'],
            'kf_media_url'       => $requestData['kf_media_url'] ?? '',
            'kf_media_id'        => $requestData['kf_media_id'] ?? '',
            'kf_media_create_at' => $requestData['kf_media_create_at'] ?? '',
            'reception_rule'     => $requestData['reception_rule'],
            'money_threshold'    => $requestData['money_threshold'] ?? 0,
            'primary_openkfid'   => $requestData['primary_openkfid'] ?? '',
            'allocation_rule'    => $requestData['allocation_rule'],
            'previous_or_first'  => $requestData['previous_or_first'],
            'maximum_limit'      => $requestData['maximum_limit'],
            'service_period'     => $requestData['service_period'],
            'is_open_welcome'    => $requestData['is_open_welcome'],
            'welcome_type'       => $requestData['welcome_type'] ?? 1
        ];

        if (isset($requestData['welcome_type'])) {
            if ($requestData['welcome_type'] == 1) {
                $accountData['welcome_text'] = $requestData['welcome_text'] ?? '';
                $accountData['welcome_menu_id'] = 0;
            } else {
                $accountData['welcome_text'] = '';
                $accountData['welcome_menu_id'] = $requestData['welcome_menu_id'] ?? 0;
            }
        }

        if (isset($requestData['service_period'])) {
            if ($requestData['service_period'] == 2) {
                $accountData['service_time_start'] = $requestData['service_time_start'];
                $accountData['service_time_end'] = $requestData['service_time_end'];
                $accountData['rest_time_automatic_reply'] = $requestData['rest_time_automatic_reply'] ?? '';
            } else {
                $accountData['service_time_start'] = $accountData['service_time_end'] = 0;
                $accountData['rest_time_automatic_reply'] = '';
            }
        }

        return $accountData;
    }

    /**
     * 删除客服账号
     *
     * @param string $openKfId
     * @return bool
     * @throws Exception
     */
    public function delAccount(string $openKfId): bool
    {
        try {
            if (self::$kefuHttpDao->delKefuAccount($openKfId)) {
                return KefuAccountsDao::softDelete(
                    [
                        'open_kfid' => $openKfId
                    ]
                );
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getMessage());
        }
        return false;
    }

    /**
     * 新建客服链接
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function addContactWay(array $requestData): array
    {
        if (
            $accountUrlData = KefuAccountUrlDao::getDetail(
                [
                    'account_url'
                ],
                [
                    'open_kfid' => $requestData['open_kfid'],
                    'scene'     => $requestData['scene']
                ]
            )
        ) {
            return ['url' => $accountUrlData['account_url']];
        }

        $contactWayUrl = self::$kefuHttpDao->getKefuAddContactWay($requestData['open_kfid'], $requestData['scene']);

        if (
            !KefuAccountUrlDao::addData([
                'open_kfid'   => $requestData['open_kfid'],
                'scene'       => $requestData['scene'],
                'account_url' => $contactWayUrl
            ])
        ) {
            send_msg_to_wecom('客服链接入表失败！');
        }

        return ['url' => $contactWayUrl];
    }

    /**
     * 获取账号列表
     *
     * @throws Exception
     */
    public function getAccountsList()
    {
        $accountInfo = KefuAccountsDao::getAllList(
            [
                'account_name',
                'kf_media_url',
                'open_kfid'
            ],
            [
                'is_deleted' => 0
            ]
        );

        $openKdIdArr = array_column($accountInfo, 'open_kfid');

        $serviceArr = KefuServicerMapDao::getAllList(
            [
                'userid',
                'open_kfid'
            ],
            [
                'open_kfid' => ['in', $openKdIdArr]
            ]
        );

        $userIdArr = array_unique(array_column($serviceArr, 'userid'));

        $newUserData = $this->getUserInfo($userIdArr);

        $newServiceArr = [];
        foreach ($serviceArr as $service) {
            $newServiceArr[$service['open_kfid']][] = $newUserData[$service['userid']];
        }

        array_walk($accountInfo, function (&$val) use ($newServiceArr) {
            $val['userId'] = $newServiceArr[$val['open_kfid']];
        });

        return $accountInfo;
    }

    /**
     * 获取客服账号详情
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getAccountInfo(array $requestData): array
    {
        $openKfId = $requestData['open_kfid'];

        $accountInfo = KefuAccountsDao::getDetail([
            'account_name',
            'open_kfid',
            'kf_media_url',
            'kf_media_id',
            'kf_media_create_at',
            'reception_rule',
            'allocation_rule',
            'previous_or_first',
            'maximum_limit',
            'service_period',
            'service_time_start',
            'service_time_end',
            'rest_time_automatic_reply',
            'is_open_welcome',
            'welcome_type',
            'welcome_text',
            'welcome_menu_id',
            'money_threshold',
            'primary_openkfid'
        ], [
            'open_kfid'  => $openKfId,
            'is_deleted' => 0
        ]);

        if (!$accountInfo) {
            return [];
        }

        $serviceArr = KefuServicerMapDao::getAllList(
            [
                'userid'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        $userIdArr = array_column($serviceArr, 'userid');

        $newUserInfo = $this->getUserInfo($userIdArr);

        $userArr = [];
        foreach ($userIdArr as $userId) {
            $userArr[] = $newUserInfo[$userId];
        }
        $accountInfo['user_name'] = $userArr;
        $accountInfo['userid'] = $userIdArr;

        if ($accountInfo['welcome_menu_id']) {
            $msgMenuData = KefuMsgMenuDao::getDetail(['menu_name'], ['id' => $accountInfo['welcome_menu_id']]);
            if ($msgMenuData) {
                $accountInfo['welcome_menu_name'] = $msgMenuData['menu_name'];
            }
        }

        return $accountInfo;
    }

    /**
     * 获取用户数组
     *
     * @param array $userIdArr
     * @return array
     * @throws Exception
     */
    private function getUserInfo(array $userIdArr): array
    {
        $userData = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $userIdArr]]);

        $newUserData = [];
        foreach ($userData as $user) {
            $newUserData[$user['userid']] = $user['name'];
        }

        return $newUserData;
    }

    /**
     * 获取聊天记录列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function chatList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $fields = [
            'list.id',
            'open_kfid',
            'list.external_userid',
            'platform',
            'channel',
            'customer.nickname',
            'customer.avatar',
            'customer.gender'
        ];

        $where = [
            'open_kfid' => $requestData['open_kfid']
        ];

        if (
            isset($requestData['nickname'])
            && $requestData['nickname']
        ) {
            $where['customer.nickname'] = ['like', "%{$requestData['nickname']}%"];
        }

        if (
            isset($requestData['platform'])
            && $requestData['platform'] != 0
        ) {
            $where['list.platform'] = $requestData['platform'];
        }

        if (
            isset($requestData['start_time'])
            && !isset($requestData['end_time'])
            && !empty($requestData['start_time'])
        ) {
            $where['update_time'] = ['>', $requestData['start_time']];
        }

        if (
            isset($requestData['end_time'])
            && !isset($requestData['start_time'])
            && !empty($requestData['end_time'])
        ) {
            $where['update_time'] = ['<', $requestData['end_time']];
        }

        if (
            isset($requestData['start_time'])
            && isset($requestData['end_time'])
            && !empty($requestData['start_time'])
            && !empty($requestData['end_time'])
        ) {
            $where['update_time'] = ['between', [$requestData['start_time'], $requestData['end_time']]];
        }

        $chatList = (array)Db::name('kefu_chat_list')
            ->alias('list')
            ->join(
                'scrm_kefu_customer_info customer',
                'list.external_userid = customer.external_userid',
                'left'
            )
            ->field($fields)
            ->where($where)
            ->page($page, $limit)
            ->order('list.update_time desc, list.create_time desc')
            ->select();

        $count = Db::name('kefu_chat_list')
            ->alias('list')
            ->join(
                'scrm_kefu_customer_info customer',
                'list.external_userid = customer.external_userid',
                'left'
            )
            ->field($fields)
            ->where($where)
            ->count();

        array_walk($chatList, function (&$val) {
            switch ($val['platform']) {
                case 0:
                    $val['platform'] = '未知';
                    break;

                case 1:
                    $val['platform'] = '宝姐家小程序';
                    break;

                case 2:
                    $val['platform'] = '宝姐珠宝小程序';
                    break;

                case 3:
                    $val['platform'] = 'APP';
                    break;
            }

            switch ($val['gender']) {
                case 0:
                    $val['gender'] = '未知';
                    break;

                case 1:
                    $val['gender'] = '男';
                    break;

                case 2:
                    $val['gender'] = '女';
                    break;
            }
            $val['channel'] = KefuChatList::CHANNEL_MAP[$val['channel']] ?? '未知';
        });

        return [
            'list'  => $chatList,
            'count' => $count
        ];
    }

    /**
     * 初始化聊天记录
     *
     * @throws Exception
     */
    public function initChatRecords(): bool
    {
        $res = self::$kefuHttpDao->getSyncMsg('', 'HHFq49uYHoiCuZRv9QUT', 1000);
        $msgList = $res['msg_list'];

        $insertBatchData = [];
        foreach ($msgList as $msg) {
            $insertBatchData[] = [
                'msg_content' => json_encode($msg, JSON_UNESCAPED_UNICODE),
                'msg_type'    => $msg['msgtype'],
                'next_cursor' => $res['next_cursor']
            ];
        }
        if (KefuMsgLogDao::addBatchData($insertBatchData)) {
            return true;
        }

        return false;
    }

    /**
     * 获取聊天记录详情
     *
     * @param array $requestData
     * @return array[]
     * @throws Exception
     */
    public function getChatRecords(array $requestData): array
    {
        [
            $limit,
            $offset
        ] = [
            $requestData['limit'],
            $requestData['offset'],
        ];

        $where = [
            'chat_id' => $requestData['chat_id']
        ];

        $chatRecords = (array)Db::name('kefu_chat_records')
            ->field([
                'id',
                'servicer_userid',
                'msg_type',
                'origin',
                'send_time',
                'attachments',
            ])
            ->where($where)
            ->limit($offset, $limit)
            ->order('id desc')
            ->select();

        $count = KefuChatRecordsDao::getCount($where);

        $servicerUserId = array_column($chatRecords, 'servicer_userid');
        $userInfo = UserDao::getAllList(['name', 'userid'], ['userid' => ['in', $servicerUserId]]);
        $newUserInfo = [];

        foreach ($userInfo as $user) {
            $newUserInfo[$user['userid']] = $user['name'];
        }

        $contactInfo = Db::name('kefu_chat_list')
            ->alias('a')
            ->join(
                'scrm_kefu_customer_info b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->join(
                'scrm_kefu_accounts c',
                'a.open_kfid = c.open_kfid',
                'LEFT'
            )
            ->field([
                'kf_media_url',
                'nickname',
                'avatar'
            ])
            ->where([
                'a.id' => $requestData['chat_id']
            ])
            ->find();

        $returnData = [];
        $returnData['contact_name'] = $contactInfo['nickname'];
        $returnData['contact_avatar'] = $contactInfo['avatar'];
        $returnData['kefu_avatar'] = $contactInfo['kf_media_url'] ?? '';

        foreach ($chatRecords as $record) {
            $recordInfo = [
                'id'                => $record['id'],
                'origin'            => $record['origin'],
                'send_time'         => date('Y-m-d H:i:s', $record['send_time']),
                'msg_type'          => $record['msg_type'],
            ];

            if ($record['origin'] == 5) {
                if ($record['servicer_userid'] == '') {
                    $recordInfo['servicer_name'] = '自动回复';
                } else {
                    $recordInfo['servicer_name'] = $newUserInfo[$record['servicer_userid']] ?? '';
                }
            }

            $attachmentsArr = json_decode($record['attachments'], true);
            $recordInfo[$record['msg_type']] = $attachmentsArr;
            $returnData['record'][] = $recordInfo;
        }

        return [
            'count' => $count,
            'list'  => $returnData
        ];
    }

    /**
     * 添加智能菜单
     *
     * @param array $request
     * @return bool
     */
    public function addMenu(array $request): bool
    {
        $menuData = $this->handleMenuData($request);

        if (KefuMsgMenuDao::addData($menuData)) {
            return true;
        }

        return false;
    }

    /**
     * 编辑智能菜单
     *
     * @param array $request
     * @return array
     * @throws Exception
     */
    public function editMenu(array $request): array
    {
        $menuId = $request['menu_id'];

        if ($request['is_open'] == 0) {
            $keywordReplyArr = Db::name('kefu_keyword_reply')
                ->field([
                    'id'
                ])
                ->whereRaw("find_in_set({$menuId}, `menu_id`)")
                ->where([
                    'is_deleted' => 0
                ])
                ->find();
            if ($keywordReplyArr) {
                return [false, '此菜单正在被使用，不能关闭！'];
            }
        }

        if (
            $accountInfo = KefuAccountsDao::getDetail(
                ['account_name'],
                [
                    'welcome_menu_id' => $menuId,
                    'is_deleted'      => 0,
                    'is_open_welcome' => 1,
                    'welcome_type'    => 2
                ]
            )
        ) {
            return [false, '此菜单是客服账号"' . $accountInfo['account_name'] . '"的欢迎语，不能关闭！'];
        }

        $menuData = $this->handleMenuData($request);

        $updateRes = KefuMsgMenuDao::updateData($menuData, ['id' => $menuId]);

        if ($updateRes !== false) {
            return [true, '编辑智能菜单成功！'];
        }

        return [false, '编辑智能菜单失败！'];
    }

    /**
     * 处理菜单内容
     *
     * @param array $request
     * @return array
     */
    private function handleMenuData(array $request): array
    {
        $replyIdStr = '';
        foreach ($request['menu_list'] as &$menuList) {
            if ($menuList['type'] == 'click') {
                $menuList['click']['id'] = $menuList['click']['id'] ? : 0;
                $replyIdStr .= $menuList['click']['id'] . ',';
            }
            if ($menuList['type'] == 'miniprogram') {
                $menuList['miniprogram']['pagepath'] = addSuffix($menuList['miniprogram']['pagepath']);
            }
        }
        return [
            'menu_name'    => $request['menu_name'],
            'head_content' => $request['head_content'] ?? '',
            'menu_list'    => json_encode($request['menu_list'], JSON_UNESCAPED_UNICODE),
            'tail_content' => $request['tail_content'] ?? '',
            'is_open'      => $request['is_open'],
            'reply_id'     => trim($replyIdStr, ',')
        ];
    }

    /**
     * 删除智能菜单
     *
     * @param int $menuId
     * @return array
     * @throws Exception
     */
    public function delMenu(int $menuId): array
    {
        if (
            Db::name('kefu_keyword_reply')
            ->field(['id'])
            ->whereRaw("find_in_set({$menuId}, `menu_id`)")
            ->where([
                'is_deleted' => 0
            ])
            ->find()
        ) {
            return [false, '此菜单正在被使用，不能删除！'];
        }

        if (
            $accountInfo = KefuAccountsDao::getDetail(
                ['account_name'],
                [
                    'welcome_menu_id' => $menuId,
                    'is_deleted'      => 0,
                    'is_open_welcome' => 1,
                    'welcome_type'    => 2
                ]
            )
        ) {
            return [false, '此菜单是客服账号"' . $accountInfo['account_name'] . '"的欢迎语，不能删除！'];
        }

        if (KefuMsgMenuDao::softDelete(['id' => $menuId])) {
            return [true, '删除智能菜单成功！'];
        }

        return [false, '删除智能菜单失败'];
    }

    /**
     * 获取菜单详情
     *
     * @param int $menuId
     * @return array
     * @throws Exception
     */
    public function getMenuData(int $menuId): array
    {
        $menuData = KefuMsgMenuDao::getDetail(
            [
                'menu_name',
                'head_content',
                'menu_list',
                'tail_content',
                'is_open'
            ],
            [
                'id' => $menuId
            ]
        );

        $menuListArr = json_decode($menuData['menu_list'], true);

        array_walk($menuListArr, function (&$val) {
            if ($val['type'] == 'click') {
                $keywordReply = KefuKeywordReplyDao::getDetail(['keyword_title'], ['id' => $val['click']['id']]);
                $val['click']['list_content'] = $keywordReply['keyword_title'] ?? '';
            }
            if ($val['type'] == 'miniprogram') {
                $val['miniprogram']['miniprogram_content'] =
                    ContactChannels::MINI_PROGRAM_APP_ID_MAP[$val['miniprogram']['appid']];
            }
        });
        $menuData['menu_list'] = $menuListArr;

        return $menuData;
    }

    /**
     * 获取菜单列表
     *
     * @throws Exception
     */
    public function getMenuList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $where = [
            'is_deleted' => 0
        ];

        if (isset($requestData['menu_name']) && $requestData['menu_name']) {
            $where['menu_name'] = ['like', "%{$requestData['menu_name']}%"];
        }

        if (isset($requestData['is_open']) && $requestData['is_open'] != '') {
            $where['is_open'] = $requestData['is_open'];
        }

        $menuList = KefuMsgMenuDao::getPaginationList(
            [
                'id',
                'menu_name',
                'is_open'
            ],
            $where,
            $page,
            $limit,
            'id desc'
        );

        $count = KefuMsgMenuDao::getCount($where);

        /*array_walk($menuList, function (&$val) {
            $val['is_open'] = $val['is_open'] == 0 ? '否' : '是';
        });*/

        return [
            'list'  => $menuList,
            'count' => $count
        ];
    }

    /**
     * 添加关键词回复
     *
     * @param array $request
     * @return array
     * @throws Exception
     */
    public function addKeywordReply(array $request): array
    {
        $replyInsertData = $this->handleKeywordReply($request);

        if ($similarKeyword = $this->getSimilarKeyword($request['keyword'])) {
            return [false, '关键词：' . $similarKeyword . '重复'];
        }

        DB::startTrans();

        $replyJson = $replyInsertData['reply_json'];
        unset($replyInsertData['reply_json']);
        $replyId = KefuKeywordReplyDao::addData($replyInsertData, true);

        $attachmentRes = $this->handleAttachments($replyJson, $replyId);

        $mapInsertData = [];
        foreach ($request['keyword'] as $keyword) {
            $mapInsertData[] = [
                'reply_id' => $replyId,
                'keyword'  => $keyword
            ];
        }
        $mapAddRes = KefuKeywordMapDao::addBatchData($mapInsertData);

        if ($replyId && $mapAddRes && $attachmentRes) {
            Db::commit();
            return [true, '添加关键词回复成功！'];
        }

        Db::rollback();
        return [false, '添加关键词回复失败！'];
    }

    /**
     * 编辑关键词回复
     *
     * @param array $request
     * @return array
     * @throws Exception
     */
    public function editKeywordReply(array $request): array
    {
        $replyEditData = $this->handleKeywordReply($request);
        $replyId = $request['reply_id'];

        if ($similarKeyword = $this->getSimilarKeyword($request['keyword'], $replyId)) {
            return [false, '关键词：' . $similarKeyword . '重复'];
        }

        DB::startTrans();

        if ($request['is_open_reply'] == 0) {
            $menuArr = Db::name('kefu_msg_menu')
                ->field(['id'])
                ->whereRaw("find_in_set({$replyId}, `reply_id`)")
                ->where([
                    'is_deleted' => 0
                ])
                ->find();
            if ($menuArr) {
                return [false, '此关键词正在被使用，不能关闭！'];
            }
        }

        KefuKeywordReplyAttachmentsDao::hardDelete([
            'reply_id' => $replyId
        ]);

        $attachmentRes = $this->handleAttachments($replyEditData['reply_json'], $replyId);

        unset($replyEditData['reply_json']);
        $updateRes = KefuKeywordReplyDao::updateData($replyEditData, ['id' => $replyId]);

        $mapInsertData = [];
        foreach ($request['keyword'] as $keyword) {
            $mapInsertData[] = [
                'reply_id' => $replyId,
                'keyword'  => $keyword
            ];
        }
        KefuKeywordMapDao::hardDelete(['reply_id' => $replyId]);

        $mapAddRes = KefuKeywordMapDao::addBatchData($mapInsertData);

        if (
            $updateRes !== false
            && $mapAddRes
            && $attachmentRes
        ) {
            Db::commit();
            return [true, '编辑关键词回复成功！'];
        }

        Db::rollback();
        return [false, '编辑关键词回复失败！'];
    }

    /**
     * 处理关键词附件
     *
     * @param string $replyJson 附件json
     * @param int $replyId 关键词回复id
     * @return bool
     */
    private function handleAttachments(string $replyJson, int $replyId): bool
    {
        $attachmentRes = true;

        $attachmentsArr = json_decode($replyJson, true);

        if ($attachmentsArr) {
            $attachmentsInsertData = [];
            foreach ($attachmentsArr as $attachment) {
                $attachmentContent = $attachment[$attachment['msgtype']];
                if ($attachment['msgtype'] == 'miniprogram') {
                    $attachmentContent['pagepath'] = addSuffix($attachmentContent['pagepath']);
                }

                $attachmentsInsertData[] = [
                    'reply_id'   => $replyId,
                    'msg_type'   => $attachment['msgtype'],
                    'attachment' => json_encode($attachmentContent, JSON_UNESCAPED_UNICODE)
                ];
            }

            $attachmentRes = KefuKeywordReplyAttachmentsDao::addBatchData($attachmentsInsertData);
        }

        return $attachmentRes;
    }

    /**
     * 找到相似的关键词
     *
     * @param array $keywordArr
     * @param int $replyId
     * @return string
     * @throws Exception
     */
    private function getSimilarKeyword(array $keywordArr, int $replyId = 0): string
    {
        $hasExistKeyword = '';

        $extraWhere = [];

        if ($replyId) {
            $extraWhere = [
                'reply_id' => ['<>', $replyId]
            ];
        }
        foreach ($keywordArr as $keyword) {
            $keywordMapArr = KefuKeywordMapDao::getDetail(
                ['id'],
                array_merge([
                    'keyword' => ['like', "%{$keyword}%"],
                ], $extraWhere)
            );
            if ($keywordMapArr) {
                $hasExistKeyword .= $keyword . '-';
            }
        }
        return $hasExistKeyword;
    }

    /**
     * 删除关键词回复
     *
     * @param int $replyId
     * @return array
     * @throws Exception
     */
    public function delKeywordReply(int $replyId): array
    {
        $menuArr = Db::name('kefu_msg_menu')
            ->field(['id'])
            ->whereRaw("find_in_set({$replyId}, `reply_id`)")
            ->where([
                'is_deleted' => 0
            ])
            ->find();

        if ($menuArr) {
            return [false, '此关键词正在被使用，不能删除！'];
        }

        $keywordReplyDelRes = KefuKeywordReplyDao::softDelete(['id' => $replyId]);

        KefuKeywordMapDao::hardDelete(['reply_id' => $replyId]);

        KefuKeywordReplyAttachmentsDao::hardDelete(['reply_id' => $replyId]);

        if (
            $keywordReplyDelRes !== false
        ) {
            return [true, '删除关键词回复成功！'];
        }
        return [false, '删除关键词回复失败！'];
    }

    /**
     * 处理关键词回复
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    private function handleKeywordReply(array $requestData): array
    {
        $menuIdStr = '';

        foreach ($requestData['reply_json'] as &$value) {
            if ($value['msgtype'] == 'msgmenu') {
                $menuId = $value['msgmenu']['menu_id'];
                $value['msgmenu'] = [
                    'menu_id'      => $menuId,
                ];
                $menuIdStr .= $menuId . ',';
            }
        }

        return [
            'keyword_title'    => $requestData['keyword_title'],
            'is_open_reply'    => $requestData['is_open_reply'],
            'is_push_to_group' => $requestData['is_push_to_group'],
            'webhook_url'      => isset($requestData['webhook_url'])
                ? trim($requestData['webhook_url'])
                : '',
            'reply_json'       => json_encode($requestData['reply_json'], JSON_UNESCAPED_UNICODE),
            'menu_id'          => trim($menuIdStr, ','),
        ];
    }

    /**
     * 获取关键词回复详情
     *
     * @param int $replyId
     * @return array
     * @throws Exception
     */
    public function getKeywordReplyInfo(int $replyId): array
    {
        $replyInfo = KefuKeywordReplyDao::getDetail(
            [
                'keyword_title',
                'is_open_reply',
                'is_push_to_group',
                'webhook_url',
                'menu_id'
            ],
            [
                'id' => $replyId
            ]
        );
        if (!$replyInfo) {
            return [];
        }

        $newMsgMenuArr = $menuIdArr = [];
        if ($replyInfo['menu_id']) {
            $menuIdArr = explode(',', $replyInfo['menu_id']);
            $msgMenuArr = KefuMsgMenuDao::getAllList(
                [
                    'menu_name',
                    'id'
                ],
                [
                    'id' => ['in', $menuIdArr]
                ]
            );

            foreach ($msgMenuArr as $msgMenu) {
                $newMsgMenuArr[$msgMenu['id']] = $msgMenu['menu_name'];
            }
        }

        $replyArr = KefuKeywordReplyAttachmentsDao::getAllList(
            [
                'msg_type',
                'attachment'
            ],
            [
                'reply_id' => $replyId
            ]
        );

        $allAttachments = [];
        if ($replyArr) {
            foreach ($replyArr as $reply) {
                if ($reply['msg_type'] == 'msgmenu') {
                    unset($reply['msgmenu']);
                    $menuId = array_shift($menuIdArr);
                    $menuInfo = [
                        'menu_name' => $newMsgMenuArr[$menuId],
                        'menu_id'   => $menuId
                    ];
                    $allAttachments[] = [
                        'msgtype'          => $reply['msg_type'],
                        $reply['msg_type'] => $menuInfo
                    ];
                } elseif ($reply['msg_type'] == 'miniprogram') {
                    $miniprogramAttachmentArr = json_decode($reply['attachment'], true);
                    $miniprogramAttachmentArr['miniprogram_name'] =
                        ContactChannels::MINI_PROGRAM_APP_ID_MAP[$miniprogramAttachmentArr['appid']];
                    $reply['attachment'] = json_encode($miniprogramAttachmentArr, JSON_UNESCAPED_UNICODE);
                    $allAttachments[] = [
                        'msgtype'          => $reply['msg_type'],
                        $reply['msg_type'] => json_decode($reply['attachment'], true)
                    ];
                } else {
                    $allAttachments[] = [
                        'msgtype'          => $reply['msg_type'],
                        $reply['msg_type'] => json_decode($reply['attachment'], true)
                    ];
                }
            }
        }

        $replyInfo['reply_json'] = $allAttachments;

        $keywordArr = KefuKeywordMapDao::getAllList(['keyword'], ['reply_id' => $replyId]);

        $replyInfo['keyword'] = array_column($keywordArr, 'keyword');

        return $replyInfo;
    }


    /**
     * 关键词回复列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function keywordList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $where = [
            'is_deleted' => 0
        ];
        if (isset($requestData['keyword_title']) && $requestData['keyword_title']) {
            $where['keyword_title'] = ['like', "%{$requestData['keyword_title']}%"];
        }

        if (isset($requestData['is_open_reply']) && $requestData['is_open_reply'] != '') {
            $where['is_open_reply'] = $requestData['is_open_reply'];
        }

        $replyList = KefuKeywordReplyDao::getPaginationList(
            [
                'id',
                'keyword_title',
                'is_open_reply',
                'trigger_count',
                'user_count'
            ],
            $where,
            $page,
            $limit,
            'id desc'
        );

        $count = KefuKeywordReplyDao::getCount($where);

        $keywordArr = KefuKeywordMapDao::getAllList(
            [
                'reply_id',
                'keyword'
            ],
            [
                'reply_id' => ['in', array_column($replyList, 'id')]
            ]
        );
        $newKeywordArr = [];
        foreach ($keywordArr as $keyword) {
            $newKeywordArr[$keyword['reply_id']][] = $keyword['keyword'];
        }

        array_walk($replyList, function (&$val) use ($newKeywordArr) {
            //$val['is_open_reply'] = $val['is_open_reply'] == 0 ? '否' : '是';
            $val['keyword'] = implode('｜', $newKeywordArr[$val['id']]);
        });

        return [
            'list'  => $replyList,
            'count' => $count
        ];
    }

    /**
     * 智能菜单用关键词列表搜索
     *
     * @param string|null $query 关键词
     * @return array|mixed
     * @throws Exception
     */
    public function keywordListForSelect(?string $query)
    {
        $where = [
            'is_open_reply' => 1,
            'is_deleted'    => 0,
        ];

        if ($query) {
            $where['keyword_title'] = ['like', "%{$query}%"];
        }

        return KefuKeywordReplyDao::getAllList(
            [
                'id',
                'keyword_title',
            ],
            $where
        );
    }

    /**
     * 关键词用智能菜单列表搜索
     *
     * @param string|null $query 关键词
     * @return array|mixed
     * @throws Exception
     */
    public function menuListForSelect(?string $query)
    {
        $where = [
            'is_open'    => 1,
            'is_deleted' => 0,
        ];

        if ($query) {
            $where['menu_name'] = ['like', "%{$query}%"];
        }

        return KefuMsgMenuDao::getAllList(
            [
                'id',
                'menu_name',
            ],
            $where
        );
    }

    /**
     * 获取分配方式
     *
     * @param int $platform
     * @return array
     * @throws Exception
     */
    public function getReceptionRule(int $platform): array
    {
        if (config('app_status') == 'pro') {
            switch ($platform) {
                case 1: // 宝姐家小程序
                    $openKfId = 'wk5b2CBwAA_W-Vut0NDm_QYM8mQm0Aig';
                    break;

                case 2: // 宝姐珠宝小程序
                    $openKfId = 'wk5b2CBwAA8eCJbNF_-vuOOfLtmYHVbQ';
                    break;

                case 3: // APP
                    $openKfId = 'wk5b2CBwAA8eCJbNF_-vuOOfLtmYHVbQ';
                    break;
            }
        } else {
            switch ($platform) {
                case 1: // 宝姐家小程序
                    $openKfId = 'wk5b2CBwAA8cA3bJrP-hXWAnCOvaFtqA';
                    break;

                case 2: // 宝姐珠宝小程序
                    $openKfId = 'wk5b2CBwAAiswDTrhAACpMAb2qZ0fUYQ';
                    break;

                case 3: // APP
                    $openKfId = 'wk5b2CBwAA_peCNhiiAaXwQgPAJ9chng';
                    break;
            }
        }

        $receptionRuleArr = KefuAccountsDao::getDetail(
            [
                'reception_rule',
                'money_threshold',
                'primary_openkfid'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        if ($receptionRuleArr['reception_rule'] == 3) {
            $primaryAccountUrlArr = KefuAccountUrlDao::getDetail(
                ['account_url'],
                [
                    'open_kfid' => $receptionRuleArr['primary_openkfid'],
                    'scene'     => $platform
                ]
            );
        }

        $accountUrlArr = KefuAccountUrlDao::getDetail(
            ['account_url'],
            [
                'open_kfid' => $openKfId,
                'scene'     => $platform
            ]
        );

        return [
            'reception_rule'  => $receptionRuleArr['reception_rule'],
            'account_url'     => $accountUrlArr['account_url'] ?? '',
            'primary_url'     => $primaryAccountUrlArr['account_url'] ?? '',
            'money_threshold' => $receptionRuleArr['money_threshold'] ?? 0,
            'corpid'          => 'wxeac0444a4199b6fb'
        ];
    }

    /**
     * 开启或关闭关键词
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function openReply(array $requestData): array
    {
        if ($requestData['is_open_reply'] == 0) {
            $menuArr = Db::name('kefu_msg_menu')
                ->field(['id'])
                ->whereRaw("find_in_set({$requestData['id']}, `reply_id`)")
                ->where([
                    'is_deleted' => 0
                ])
                ->find();
            if ($menuArr) {
                return [false, '此关键词正在被使用，不能关闭！'];
            }
        }

        $updateRes = KefuKeywordReplyDao::updateData(
            [
                'is_open_reply' => $requestData['is_open_reply']
            ],
            [
                'id' => $requestData['id'],
            ]
        );

        if ($updateRes !== false) {
            return [true, '处理成功！'];
        }
        return [false, '处理失败！'];
    }

    /**
     * 开启或关闭智能菜单
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function openMenu(array $requestData): array
    {
        if ($requestData['is_open'] == 0) {
            $keywordReplyArr = Db::name('kefu_keyword_reply')
                ->field([
                    'id'
                ])
                ->whereRaw("find_in_set({$requestData['id']}, `menu_id`)")
                ->where([
                    'is_deleted' => 0
                ])
                ->find();
            if ($keywordReplyArr) {
                return [false, '此菜单正在被使用，不能关闭！'];
            }
        }

        $updateRes = KefuMsgMenuDao::updateData(
            [
                'is_open' => $requestData['is_open']
            ],
            [
                'id' => $requestData['id'],
            ]
        );

        if ($updateRes !== false) {
            return [true, '处理成功！'];
        }
        return [false, '处理失败！'];
    }

    /**
     * 记录添加个微
     *
     * @param string $userId
     * @return int|string
     * @throws Exception
     */
    public function addWechatRecord(string $userId): array
    {
        if (
            Db::name('kefu_customer_info')->field(['id'])->where([
                'external_userid' => $userId,
                'is_add_wechat'   => 1
            ])->find()
        ) {
            return [false, '该客户已标记过“已加个微”！'];
        } else {
            $updateRes = Db::name('kefu_customer_info')->where([
                'external_userid' => $userId
            ])->update([
                'is_add_wechat'      => 1,
                'record_wechat_time' => date('Y-m-d H:i:s')
            ]);

            if ($updateRes != false) {
                return [true, '“已加个微”标记成功！'];
            }
        }

        return [false, '“已加个微”标记失败！'];
    }

    /**
     * 获取企微客服链接
     *
     * @param string|null $unionId
     * @return array
     * @throws Exception
     */
    public function getLink(?string $unionId): array
    {
        if (config('app_status') != 'pro') {
            return [
                'account_url' =>
                    'https://work.weixin.qq.com/kfid/kfc3cf091653884b018?enc_scene=ENC72pec4FRATdqhWZZFX2Eyf'
            ];
        }

        $getAccountUrl = function (string $openKfId) {
            $accountUrlArr = KefuAccountUrlDao::getDetail(['account_url'], [
                'open_kfid' => $openKfId,
                'scene'     => KefuAccountUrl::BAOJIE_HOME
            ]);
            return $accountUrlArr['account_url'] ?? '';
        };
        if (!$unionId) {
            return [
                'account_url' => $getAccountUrl(KefuAccounts::PRIMARY_ADVISER)
            ];
        }

        // 该客户是否与赵蔚名下任一企微号互为好友
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $contactInfo = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.userid',
                'a.external_userid'
            ])
            ->where([
                'userid'  => ['in', $zhaoweiAccounts],
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->select();

        if (!$contactInfo) {
            $accountUrl = $getAccountUrl(KefuAccounts::PRIMARY_ADVISER);
        } else {
            $accountUrl = $getAccountUrl(KefuAccounts::BAOJIE_HOME_ADVISER);
        }

        return [
            'account_url' => $accountUrl
        ];
    }

    /**
     * 获取招募官客服链接
     *
     * @return string[]
     */
    public function getJewelryLink(): array
    {
        return [
            'account_url' => 'https://work.weixin.qq.com/kfid/kfc3cf091653884b018?enc_scene=ENC72pec4FRATdqhWZZFX2Eyf'
        ];
    }

    /**
     * 是否咨询过
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function isConsult(array $requestData): array
    {
        $unionIdArr = KefuCustomerInfoDao::getAllList(['unionid'], [
            'unionid' => ['in', $requestData]
        ]);

        return [
            'is_consult' => array_column($unionIdArr, 'unionid')
        ];
    }

    /**
     * 获取所有账号列表
     *
     * @return array|mixed
     * @throws Exception
     */
    public function getAllAccountSelectList()
    {
        return KefuAccountsDao::getAllList(['account_name', 'open_kfid'], ['is_deleted' => 0]);
    }
}
