<?php

declare(strict_types=1);

namespace app\api\service\channel;

use think\File;

/**
 * Interface ContactChannelService
 * @package app\api\service\channel
 */
interface ContactChannelService
{
    /**
     * 渠道列表
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function index(array $requestData): array;

    /**
     * 渠道详情
     *
     * @param int $channelId 渠道id
     * @return array
     */
    public function detail(int $channelId): array;

    /**
     * 添加渠道
     *
     * @param array $requestData 添加数据
     * @return bool
     */
    public function add(array $requestData): bool;

    /**
     * 更新渠道
     *
     * @param array $requestData 要更新的数据
     * @return bool
     */
    public function update(array $requestData): bool;

    /**
     * 删除渠道
     *
     * @param int $channelId 渠道id
     * @return bool
     */
    public function delete(int $channelId): bool;

    /**
     * 上传临时素材
     *
     * @param string $type 文件类型（image/video）
     * @param File $file
     * @return array
     */
    public function uploadMedia(string $type, File $file): array;

    /**
     * 上传图片
     *
     * @param File $file
     * @return array
     */
    public function uploadImg(File $file): array;
}
