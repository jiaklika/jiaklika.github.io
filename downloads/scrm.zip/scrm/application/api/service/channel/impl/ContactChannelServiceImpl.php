<?php

declare(strict_types=1);

namespace app\api\service\channel\impl;

use app\api\dao\mysql\user\UserDao;
use app\api\dao\mysql\way\ChannelWelcomeMsgDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\dao\mysql\way\UnifyServiceDao;
use app\api\service\channel\ContactChannelService;
use app\api\service\contactTag\impl\ContactTagServiceImpl;
use app\api\util\FileManager;
use app\common\model\ChannelWelcomeMsg;
use app\common\model\ContactChannels;
use app\common\model\ContactTags;
use Exception;
use think\Db;
use think\File;

/**
 * Class ContactChannelServiceImpl
 * @package app\api\service\channel\impl
 */
class ContactChannelServiceImpl implements ContactChannelService
{
    /**
     * 渠道列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function index(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $fields = [
            'id',
            'channel_name',
            'create_time'
        ];

        $where = [
            'is_deleted' => 0
        ];

        if (
            isset($requestData['channel_keyword'])
            && $requestData['channel_keyword'] !== ''
        ) {
            $where['channel_name|id'] = ['like', '%' . $requestData['channel_keyword'] . '%'];
        }

        if (
            isset($requestData['create_time_start'])
            && !isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
        ) {
            $where['create_time'] = ['>', $requestData['create_time_start']];
        }

        if (
            isset($requestData['create_time_end'])
            && !isset($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['create_time'] = ['<', $requestData['create_time_end']];
        }

        if (
            isset($requestData['create_time_start'])
            && isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['create_time'] = ['between', [$requestData['create_time_start'], $requestData['create_time_end']]];
        }

        $channelList = ContactChannelsDao::getPaginationList($fields, $where, (int)$page, (int)$limit, 'id DESC');

        $channelCount = ContactChannelsDao::getCount($where);

        if ($channelList) {
            array_walk($channelList, function (&$val) {
                // 总添加客户
                $wayInfo = ContactWaysDao::getAllList(['id'], ['channel_id' => $val['id']]);
                $wayIdArr = array_column($wayInfo, 'id');

                $val['total'] = 0;

                if ($wayIdArr) {
                    $val['total'] = ContactFollowUserDao::getCount(['state' => ['in', $wayIdArr]]) ? : 0;
                }

                if (in_array($val['id'], array_keys(ContactChannels::MOMENT_CHANNEL_MAP))) {
                    $countWhere = [
                        'add_way' => 100,
                        'state'   => $val['id']
                    ];

                    $val['total'] = ContactFollowUserDao::getCount(
                        $countWhere
                    ) ? : 0;
                }

                if (in_array($val['id'], array_keys(ContactChannels::WECHAT_VIDEO_STATE_MAP))) {
                    $countWhere = [
                        'state' => ContactChannels::WECHAT_VIDEO_STATE_MAP[$val['id']]
                    ];

                    $val['total'] = ContactFollowUserDao::getCount(
                        $countWhere
                    ) ? : 0;
                }
            });
        }

        return [
            'list'  => $channelList,
            'count' => $channelCount
        ];
    }

    /**
     * 渠道详情
     *
     * @param int $channelId 渠道ID
     * @return array
     * @throws Exception
     */
    public function detail(int $channelId): array
    {
        $channelInfo = ContactChannelsDao::getDetail(
            [
                'id',
                'channel_name',
                'is_open_welcome',
                'is_distinguish_time',
                'is_random'
            ],
            [
                'id'         => $channelId,
                'is_deleted' => ContactChannels::NOT_DELETE
            ]
        );

        if (empty($channelInfo)) {
            return [];
        }

        $getWelcomeInfo = function (array $extraWhere = []) use ($channelId) {
            $commonWhere = [
                'channel_id' => $channelId
            ];

            $where = $extraWhere ? array_merge($commonWhere, $extraWhere) : $commonWhere;

            $channelWelcomeMsgInfo = ChannelWelcomeMsgDao::getDetail(
                [
                    'is_working_time',
                    'welcome_text',
                    'attachments'
                ],
                $where
            );

            if ($channelWelcomeMsgInfo) {
                if ($channelWelcomeMsgInfo['attachments']) {
                    $channelWelcomeMsgInfo['attachments'] = json_decode($channelWelcomeMsgInfo['attachments'], true);
                }

                return $channelWelcomeMsgInfo;
            }

            return [];
        };

        if (
            $channelInfo['is_distinguish_time'] == 0
            && $channelInfo['is_random'] == 0
        ) {
            $channelInfo['normal_data'] = $getWelcomeInfo();
        }

        if ($channelInfo['is_distinguish_time'] == 1) {
            $channelInfo['work_time_data'] = $getWelcomeInfo([
                'is_working_time' => ChannelWelcomeMsg::IS_WORKING_TIME
            ]);
            $channelInfo['off_work_data'] = $getWelcomeInfo([
                'is_working_time' => ChannelWelcomeMsg::NOT_WORKING_TIME
            ]);
        }

        if ($channelInfo['is_random'] == 1) {
            for ($i = 1; $i < 6; $i++) {
                $channelInfo["{$i}"] = $getWelcomeInfo([
                    'random_index' => $i
                ]);
            }
        }

        return $channelInfo;
    }

    /**
     * 添加渠道
     *
     * @param array $requestData 渠道数据
     * @return bool
     * @throws Exception
     */
    public function add(array $requestData): bool
    {
        // 两个表，分成两部分
        [$channelData, $welcomeMsgData] = $this->handleRequestData($requestData);

        $addWelcomeRes = true;

        Db::startTrans();

        $channelId = ContactChannelsDao::addData($channelData, true);

        if ($welcomeMsgData) {
            foreach ($welcomeMsgData as $msg) { // 最多5个
                $msg['channel_id'] = $channelId;
                $msg['attachments'] = json_encode($msg['attachments'], JSON_UNESCAPED_UNICODE);
                $addWelcomeRes = ChannelWelcomeMsgDao::addData($msg);
            }
        }

        if ($channelId && $addWelcomeRes) {
            // 生成标签
            $contactTagService = new ContactTagServiceImpl();

            if (
                $tagInfo = $contactTagService->addCorpTag(
                    [
                        'name'  => $channelData['channel_name'],
                        'order' => $channelId
                    ],
                    ContactTags::GROUP_ID_MAP[ContactTags::SOURCE_CHANNEL]
                )
            ) {
                if (
                    ContactChannelsDao::updateData(
                        [
                            'tag_id' => $tagInfo['tag'][0]['id']
                        ],
                        [
                            'id' => $channelId
                        ]
                    ) !== false
                ) {
                    Db::commit();
                    return true;
                }
            }
            Db::commit();
            return true;
        }

        Db::rollback();
        return false;
    }

    /**
     * 更新渠道
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function update(array $requestData): bool
    {
        // 渠道旧数据
        $originalChannelInfo = ContactChannelsDao::getDetail(
            [
                'channel_name',
                'tag_id'
            ],
            [
                'id' => $requestData['channel_id']
            ]
        );

        // 两个表，分成两部分
        [$channelData, $welcomeMsgData] = $this->handleRequestData($requestData);

        $addWelcomeRes = true;

        Db::startTrans();

        $updateRes = ContactChannelsDao::updateData($channelData, ['id' => $requestData['channel_id']]);

        // 删除原先的所有欢迎语
        $deleteRes = ChannelWelcomeMsgDao::hardDelete(['channel_id' => $requestData['channel_id']]);

        if ($welcomeMsgData) {
            foreach ($welcomeMsgData as $msg) { // 最多两个
                $msg['channel_id'] = $requestData['channel_id'];
                $msg['attachments'] = json_encode($msg['attachments'], JSON_UNESCAPED_UNICODE);
                $addWelcomeRes = ChannelWelcomeMsgDao::addData($msg);
            }
        }

        if ($updateRes && $deleteRes !== false && $addWelcomeRes) {
            // 渠道名变更时才更改标签
            if ($originalChannelInfo['channel_name'] != $channelData['channel_name']) {
                // 更新渠道标签名称
                $contactTagService = new ContactTagServiceImpl();
                if (
                    !$contactTagService->editContactTag(
                        ContactTagServiceImpl::TAG,
                        $originalChannelInfo['tag_id'],
                        $channelData['channel_name'],
                        (int)$requestData['channel_id']
                    )
                ) {
                    Db::rollback();
                    return false;
                }
            }

            Db::commit();
            return true;
        }

        Db::rollback();
        return false;
    }

    /**
     * 处理请求数据用于添加和编辑
     *
     * @param array $requestData
     * @return array
     */
    private function handleRequestData(array $requestData): array
    {
        $channelAllData = [];

        // 渠道主表数据
        $channelAllData[] = [
            'channel_name'        => $requestData['channel_name'], // 渠道名称
            'is_open_welcome'     => $requestData['is_open_welcome'], // 是否启用欢迎语
            'is_distinguish_time' => $requestData['is_distinguish_time'] ?? 0, // 是否区分时段
            'is_random'           => $requestData['is_random'] ?? 0 // 是否是随机欢迎语
        ];

        // 欢迎语表数据
        $msgAllData = [];

        if ($requestData['is_open_welcome'] == 1) {
            $handleMsgFunc = function ($welcomeData, $index) use (&$msgAllData) {

                if (
                    empty($welcomeData['welcome_text'])
                    && empty($welcomeData['attachments'])
                ) {
                    return;
                }

                $msgData['welcome_text'] = $welcomeData['welcome_text'] ?? '';
                $msgData['attachments']  = $welcomeData['attachments'] ?? '';

                if (in_array($index, [0,1,2,3,4,5])) {
                    $msgData['random_index'] = $index;
                }
                if (in_array($index, [100, 101])) {
                    $msgData['is_working_time'] = $index == 100 ? 1 : 0;
                }

                $msgAllData[] = $msgData;
            };

            if (
                isset($requestData['is_distinguish_time'])
                && $requestData['is_distinguish_time'] == 1
            ) { // 区分时段
                $handleMsgFunc($requestData['work_time_data'], 100);
                $handleMsgFunc($requestData['off_work_data'], 101);
            }

            if (
                isset($requestData['is_random'])
                && $requestData['is_random'] == 1
            ) {
                $judgeAndVerify = function ($index) use ($handleMsgFunc, $requestData) {
                    if (isset($requestData[$index])) {
                        $handleMsgFunc($requestData[$index], $index);
                    }
                };
                for ($i = 1; $i < 6; $i++) {
                    $judgeAndVerify($i);
                }
            }

            if (
                $requestData['is_distinguish_time'] == 0
                && $requestData['is_random'] == 0
            ) {
                $handleMsgFunc($requestData['normal_data'], 0);
            }
        }

        // 合并两个表数据一起返回
        $channelAllData[] = $msgAllData;

        return $channelAllData;
    }

    /**
     * 删除渠道
     *
     * @param int $channelId 渠道ID
     * @return bool
     * @throws Exception
     */
    public function delete(int $channelId): bool
    {
        $deleteRes = ContactChannelsDao::deleteById($channelId);

        if ($deleteRes !== false) {
            // 渠道删除后用户的来源渠道标签依旧保留
            /*$tagInfo = ContactChannelsDao::getDetail(['tag_id'], [
                'id' => $channelId
            ]);
            // 删除标签
            if ($tagInfo['tag_id']) {
                $contactTagHttpDao = new ContactTagHttpDao();
                try {
                    $contactTagHttpDao->delContactTag([$tagInfo['tag_id']]);

                    if (
                        ContactTagsDao::updateData(['tag_is_deleted' => ContactTags::TAG_IS_DELETED], [
                        'tag_id' => $tagInfo['tag_id']
                        ]) === false
                    ) {
                        throw new Exception('删除标签操作表出错！');
                    }
                } catch (Exception $e) {
                    send_msg_to_wecom('删除标签出错！' . $e->getMessage());
                }
            }*/

            return true;
        }

        return false;
    }

    /**
     * 上传临时文件
     *
     * @param string $type 文件类型
     * @param File $file
     * @return array
     * @throws Exception
     */
    public function uploadMedia(string $type, File $file): array
    {
        $fileManager = new FileManager();

        return $fileManager->uploadMedia($type, $file);
    }

    /**
     * 上传图片
     *
     * @param File $file
     * @return array
     * @throws Exception
     */
    public function uploadImg(File $file): array
    {
        $fileManager = new FileManager();

        return $fileManager->uploadImg($file);
    }

    /**
     * 转换旧数据为json
     * @throws Exception
     */
    public function changeDataToJson(): bool
    {
        $allWelcomeMsg = ChannelWelcomeMsgDao::getAllList([
            'id',
            'welcome_type',
            'image_pic_url',
            'link_title',
            'link_pic_url',
            'link_desc',
            'link_url',
            'miniprogram_title',
            'miniprogram_pic_media_id',
            'miniprogram_pic_url',
            'miniprogram_pic_create_time',
            'miniprogram_appid',
            'miniprogram_page'
        ]);

        $updateBatchData = [];

        foreach ($allWelcomeMsg as $key => $singleWelcomeMsg) {
            switch ($singleWelcomeMsg['welcome_type']) {
                case 0:
                    $updateBatchData[$key]['attachments'] = null;
                    break;

                case 1:
                    $updateBatchData[$key]['attachments'] = json_encode([[
                        'welcome_type'                => 1,
                        'miniprogram_appid'           => $singleWelcomeMsg['miniprogram_appid'],
                        'miniprogram_name'            => ContactChannels::MINI_PROGRAM_APP_ID_MAP[
                        $singleWelcomeMsg['miniprogram_appid']
                        ],
                        'miniprogram_page'            => $singleWelcomeMsg['miniprogram_page'],
                        'miniprogram_title'           => $singleWelcomeMsg['miniprogram_title'],
                        'miniprogram_pic_url'         => $singleWelcomeMsg['miniprogram_pic_url'],
                        'miniprogram_pic_media_id'    => $singleWelcomeMsg['miniprogram_pic_media_id'],
                        'miniprogram_pic_create_time' => $singleWelcomeMsg['miniprogram_pic_create_time'],
                    ]], JSON_UNESCAPED_UNICODE);
                    break;

                case 2:
                    $updateBatchData[$key]['attachments'] = json_encode([[
                        'welcome_type'  => 2,
                        'image_pic_url' => $singleWelcomeMsg['image_pic_url']
                    ]], JSON_UNESCAPED_UNICODE);
                    break;

                case 3:
                    $updateBatchData[$key]['attachments'] = json_encode([[
                        'welcome_type' => 3,
                        'link_title'   => $singleWelcomeMsg['link_title'],
                        'link_pic_url' => $singleWelcomeMsg['link_pic_url'],
                        'link_desc'    => $singleWelcomeMsg['link_desc'],
                        'link_url'     => $singleWelcomeMsg['link_url']
                    ]], JSON_UNESCAPED_UNICODE);
                    break;
            }

            $updateBatchData[$key]['id'] = $singleWelcomeMsg['id'];
        }

        $updateRes = ChannelWelcomeMsgDao::updateBatchData(new ChannelWelcomeMsg(), $updateBatchData);

        if ($updateRes !== false) {
            return true;
        }

        return false;
    }

    /**
     * 添加统一咨询管理员工
     *
     * @param array $userIdArr 员工id数组
     * @throws Exception
     */
    public function addUnifyService(array $userIdArr): bool
    {
        UnifyServiceDao::hardDelete(['userid' => ['<>', '']]);

        $insertBatchData = [];
        foreach ($userIdArr as $userId) {
            $insertBatchData[] = [
                'userid' => $userId
            ];
        }

        if (UnifyServiceDao::addBatchData($insertBatchData)) {
            return true;
        }

        return false;
    }

    /**
     * @return array|mixed
     * @throws Exception
     */
    public function getUnifyService()
    {
        $unifyServiceArr = UnifyServiceDao::getAllList(['userid']);
        return ['userid' => array_column($unifyServiceArr, 'userid')];
    }
}
