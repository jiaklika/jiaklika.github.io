<?php

namespace app\api\service\liveData\impl;

use app\api\dao\mysql\liveData\LiveAudienceDataDao;
use app\api\dao\mysql\liveData\LiveDataDao;
use app\api\dao\mysql\liveData\VideoLiveTaskDao;
use app\api\service\liveData\LiveDataService;
use app\common\model\liveData\LiveAudienceData;
use Exception;

/**
 * Class LiveDataServiceImpl
 * @package app\api\service\liveData\impl
 */
class LiveDataServiceImpl implements LiveDataService
{
    /**
     * 存储直播场次信息
     *
     * @param array $liveData
     * @return bool
     * @throws Exception
     */
    public function storeLiveData(array $liveData): bool
    {
        $liveId = LiveDataDao::getDetail(
            [
                'live_id'
            ],
            [
                'live_id' => $liveData['live_id']
            ]
        );

        if ($liveId) {
            return !(LiveDataDao::updateData(
                [
                    'is_end' => $liveData['is_end']
                ],
                [
                    'live_id' => $liveId['live_id']
                ]
            ) === false);
        } else {
            return LiveDataDao::addData($liveData);
        }
    }

    /**
     * 存储直播观众信息
     *
     * @param array $liveAudienceData
     * @return bool
     */
    public function storeLiveAudienceData(array $liveAudienceData): bool
    {
        $audience = $liveAudienceData['audience'];

        $liveId = $liveAudienceData['live_id'];

        $insertData = array_map(function ($val) use ($liveId) {
            return [
                'live_id'      => $liveId,
                'unionid'      => $val['unionid'],
                'platform'     => $val['platform'],
                'is_luck_draw' => $val['is_luck_draw']
            ];
            /*return [
                'live_id' => $liveId,
                'unionid' => $val
            ];*/
        }, $audience);

        return LiveAudienceDataDao::addBatchData($insertData);
    }

    /**
     * 处理直播观众新客信息
     *
     * @param array $liveFirstOrderInfo
     * @return bool
     * @throws Exception
     */
    public function handleLiveFirstOrderData(array $liveFirstOrderInfo): bool
    {
        $consumerData = $liveFirstOrderInfo['consumer'];

        $liveId = $liveFirstOrderInfo['live_id'];

        $allAudienceArr = LiveAudienceDataDao::getAllList(
            [
                'unionid'
            ],
            [
                'live_id' => $liveId
            ]
        );

        $allAudienceUnionIdArr = array_column($allAudienceArr, 'unionid');

        $updateClosure = function (
            $unionIdData,
            array $updateCondition,
            bool $isFirstOrder = false
        ) use (
            $liveId,
            $allAudienceUnionIdArr
        ) {
            $allUnionIdArr = array_column($unionIdData, 'unionid');

            // 是否消费
            if (!$isFirstOrder) {
                // 可能不在观众里
                $insertUnionIdArr = array_diff($allUnionIdArr, $allAudienceUnionIdArr);

                if ($insertUnionIdArr) {
                    $insertBatchData = array_map(function ($val) use ($liveId) {
                        return [
                            'live_id'    => $liveId,
                            'unionid'    => $val,
                            'is_consume' => LiveAudienceData::IS_CONSUME
                        ];
                    }, $insertUnionIdArr);

                    if (!LiveAudienceDataDao::addBatchData($insertBatchData)) {
                        send_msg_to_wecom('添加消费信息失败！');
                    }
                }
            }

            return LiveAudienceDataDao::updateData(
                $updateCondition,
                [
                    'unionid' => ['in', $allUnionIdArr],
                    'live_id' => $liveId
                ]
            );
        };

        // 先更新是消费者
        $consumerRes = $updateClosure($consumerData, [
            'is_consume' => LiveAudienceData::IS_CONSUME,
        ]);

        // 再更新是首单
        $firstOrderArr = array_filter($consumerData, function ($val) {
            return $val['is_first_order'] == 1;
        });

        $firstOrderRes = $updateClosure($firstOrderArr, [
            'is_first_order' => LiveAudienceData::IS_FIRST_ORDER
        ], true);

        if ($consumerRes !== false && $firstOrderRes !== false) {
            return true;
        }
        return false;
    }

    /**
     * 存储视频号直播信息
     *
     * @param array $videoLiveData
     * @return bool
     * @throws Exception
     */
    public function storeVideoLiveTask(array $videoLiveData): bool
    {
        // 已经存在就更新
        if (VideoLiveTaskDao::isExistById(0, ['live_id' => $videoLiveData['live_id']])) {
            $liveId = $videoLiveData['live_id'];
            unset($videoLiveData['live_id']);
            return VideoLiveTaskDao::updateData($videoLiveData, ['live_id' => $liveId]);
        } else {
            return VideoLiveTaskDao::addData($videoLiveData);
        }
    }
}
