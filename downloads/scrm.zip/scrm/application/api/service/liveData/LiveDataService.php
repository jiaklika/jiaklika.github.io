<?php

declare(strict_types=1);

namespace app\api\service\liveData;

/**
 * 获取企微直播数据
 *
 * Interface LiveDataService
 * @package app\api\service\liveData
 */
interface LiveDataService
{
    /**
     * 存储直播场次信息
     *
     * @param array $liveData
     * @return bool
     */
    public function storeLiveData(array $liveData): bool;

    /**
     * 存储观看直播用户unionId
     *
     * @param array $liveAudienceData
     * @return bool
     */
    public function storeLiveAudienceData(array $liveAudienceData): bool;
}
