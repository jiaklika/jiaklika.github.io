<?php

declare(strict_types=1);

namespace app\api\service\groupMsg\impl;

use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\message\GroupMsgIdMapDao;
use app\api\dao\mysql\message\GroupMsgReceiveMapDao;
use app\api\dao\mysql\message\GroupMsgSenderMapDao;
use app\api\dao\mysql\message\GroupMsgTagMapDao;
use app\api\dao\mysql\message\GroupMsgTemplatesDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\groupMsg\GroupMsgService;
use app\api\util\FileManager;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactTags;
use app\common\model\groupMsg\GroupMsgIdMap;
use app\common\model\groupMsg\GroupMsgReceiveMap;
use app\common\model\groupMsg\GroupMsgTemplates;
use Exception;
use think\Db;
use think\Log;
use think\Queue;

/**
 * 分层群发
 *
 * Class GroupMsgServiceImpl
 * @package app\api\service\groupMsg\impl
 */
class GroupMsgServiceImpl implements GroupMsgService
{
    /**
     * 新建群发
     *
     * @param array $requestData 请求数据
     * @return bool
     * @throws Exception
     */
    public function add(array $requestData): bool
    {
        // 得到三表的数据
        [$senderArr, $tagArr, $insertData] = $this->organizeData($requestData);

        Db::startTrans();

        // 写入主表
        $templateId = GroupMsgTemplatesDao::addData($insertData, true);
        $requestData['template_id'] = $templateId;

        // 1个消息可能有多个发送者和发送标签。存储发送者和发送标签到映射表-begin
        [$senderInsertRes, $tagInsertRes] = $this->handleMapData($senderArr, $tagArr, $requestData, false);
        // 映射-end

        if ($templateId && $senderInsertRes && $tagInsertRes) {
            Db::commit();

            // 立即发送
            $requestData['miniprogram_pic_expire_time'] = $insertData['miniprogram_pic_expire_time'] ?? 0;
            if (!array_filter($requestData['sender'])) {
                $requestData['sender'] = $senderArr;
            }
            if ($requestData['is_plan'] == GroupMsgTemplates::NOT_PLAN) {
                $this->sendNow($requestData, (int)$templateId);
            }
            return true;
        }

        Db::rollback();
        return false;
    }

    /**
     * 编辑群发
     *
     * @param array $requestData 请求数据
     * @return bool
     * @throws Exception
     */
    public function edit(array $requestData): bool
    {
        [$senderArr, $tagArr, $updateData] = $this->organizeData($requestData);

        Db::startTrans();

        $templateUpdateRes = GroupMsgTemplatesDao::updateData($updateData, ['id' => $requestData['template_id']]);

        [
            $senderDeleteRes,
            $tagDeleteRes,
            $tagInsertRes,
            $senderInsertRes
        ] = $this->handleMapData($senderArr, $tagArr, $requestData);

        if ($senderDeleteRes && $tagDeleteRes  && $senderInsertRes && $tagInsertRes && $templateUpdateRes !== false) {
            Db::commit();

            // 立即发送
            if ($requestData['is_plan'] == GroupMsgTemplates::NOT_PLAN) {
                $this->sendNow($requestData, (int)$requestData['template_id']);
            }
            return true;
        }

        Db::rollback();
        return false;
    }

    /**
     * 组织数据
     *
     * @param array $requestData 请求数据
     * @return array
     * @throws Exception
     */
    private function organizeData(array $requestData): array
    {
        [
            $senderArr,  // 发送者数组
            $tagArr,     // 发送到标签数组
            $rangeOption // 发送范围 1-筛选 2-全部
        ] =
        [
            array_filter($requestData['sender']),
            array_filter($requestData['tag']),
            $requestData['range_option']
        ];

        $receiverRange = 0;

        if ($rangeOption == 1) { // 筛选
            if (!empty($senderArr) && !empty($tagArr)) {
                $receiverRange = GroupMsgTemplates::RECEIVER_SENDER_AND_TAG;
            }
            if (!empty($senderArr) && empty($tagArr)) {
                $receiverRange = GroupMsgTemplates::RECEIVER_ONLY_SENDER;
            }
            if (empty($senderArr) && !empty($tagArr)) {
                $receiverRange = GroupMsgTemplates::RECEIVER_ONLY_TAG;
            }
        } else { // 全部
            $userIdArr = Db::name('contact_follow_user')
                ->distinct('true')
                ->field(['userid'])
                ->where([
                    'status' => ContactFollowUser::NORMAL
                ])
                ->select();

            $senderArr = array_column((array)$userIdArr, 'userid');
        }

        // 主表数据
        $templateData = [
            'task_name'      => $requestData['task_name'],
            'creator'        => $requestData['creator'],
            'receiver_range' => $receiverRange,
            'content_text'   => $requestData['content_text'],
            'second_type'    => $requestData['second_type'],
            'is_plan'        => $requestData['is_plan'],
            'send_time'      => $requestData['plan_send_time'] ?? date('Y-m-d H:i:s')
        ];

        switch ($requestData['second_type']) {
            case 1:
                $msgData = [
                    'miniprogram_title'           => $requestData['miniprogram_title'],
                    'miniprogram_pic_media_id'    => $requestData['miniprogram_pic_media_id'],
                    'miniprogram_appid'           => $requestData['miniprogram_appid'],
                    'miniprogram_page'            => $requestData['miniprogram_page'],
                    'miniprogram_pic_url'         => $requestData['miniprogram_pic_url'],
                    'miniprogram_pic_create_time' => $requestData['miniprogram_pic_create_time'],
                    'miniprogram_pic_expire_time' => intval(
                        $requestData['miniprogram_pic_create_time'] + MediaHttpDao::MEDIA_EXPIRE_TIME
                    ),
                ];
                break;

            case 2:
                $msgData = [
                    'image_pic_url' => $requestData['image_pic_url'],
                ];
                break;

            case 3:
                $msgData = [
                    'link_title'   => $requestData['link_title'],
                    'link_pic_url' => $requestData['link_pic_url'] ?? '',
                    'link_desc'    => $requestData['link_desc'] ?? '',
                    'link_url'     => $requestData['link_url']
                ];
                break;

            default:
                $msgData = [];
                break;
        }
        // 返回senderMap表数据，tagMap表数据，主表数据
        return [$senderArr, $tagArr, array_merge($templateData, $msgData)];
    }

    /**
     * 处理发送者和标签两个映射表的数据
     *
     * @param array $senderArr 发送者数组
     * @param array $tagArr 标签数组
     * @param array $requestData 请求数据
     * @param bool $is_update 是否是更新 true-是 false-添加 默认true
     * @return array
     * @throws Exception
     */
    private function handleMapData(array $senderArr, array $tagArr, array $requestData, bool $is_update = true): array
    {
        $senderDeleteRes = $tagDeleteRes = $senderInsertRes = $tagInsertRes = true;

        if ($senderArr) {
            if ($is_update) {
                // 删除原有的数据
                $senderDeleteRes = GroupMsgSenderMapDao::hardDelete([
                    'template_id' => $requestData['template_id']
                ]);
            }

            // 添加新的数据
            $senderInsertData = [];
            foreach ($senderArr as $sender) {
                $senderInsertData[] = [
                    'template_id'    => $requestData['template_id'],
                    'sender_user_id' => $sender
                ];
            }
            $senderInsertRes = GroupMsgSenderMapDao::addBatchData($senderInsertData);
        }

        if ($tagArr) {
            if ($is_update) {
                // 删除原有的数据
                $tagDeleteRes = GroupMsgTagMapDao::hardDelete([
                    'template_id' => $requestData['template_id']
                ]);
            }

            // 添加新的数据
            $tagInsertData = [];
            foreach ($tagArr as $tag) {
                $tagInsertData[] = [
                    'template_id' => $requestData['template_id'],
                    'tag_id'      => $tag
                ];
            }
            $tagInsertRes = GroupMsgTagMapDao::addBatchData($tagInsertData);
        }
        // 映射-end

        if ($is_update) {
            return [$senderDeleteRes, $tagDeleteRes, $senderInsertRes,$tagInsertRes];
        }
        return [$senderInsertRes, $tagInsertRes];
    }

    /**
     * 立即发送
     *
     * @param array $requestData 新建群发提交数据
     * @param int $templateId 群发记录ID
     * @return void
     * @throws Exception
     */
    private function sendNow(array $requestData, int $templateId): void
    {
        [
            $senderArr, // 发送者
            $tagArr     // 发送标签
        ] =
        [
            array_filter($requestData['sender']),
            array_filter($requestData['tag'])
        ];

        [$msgType, $typeData] = $this->organizeSecondData($requestData);

        $originalData = [
            'template_id'  => $templateId, // 群发记录ID
            'content_text' => $requestData['content_text'], // 第一条内容
            'msg_type'     => $msgType, // 第二条类型
            'type_data'    => $typeData, // 第二条内容
            'sender'       => $senderArr,
        ];

        if ($requestData['range_option'] == 2) { // 全部客户
            $extraData = [
                'receiver_range' => 0,
            ];
        } else { // 筛选
            // 客户必选
            if (!$tagArr) { // 标签为空
                $extraData = [
                    'receiver_range' => 1,
                ];
            } else { // 客户和标签同时选中
                $extraData = [
                    'receiver_range' => 3,
                    'tags'           => $tagArr
                ];
            }
        }

        $carryData = array_merge($originalData, $extraData);

        try {
            // 推送到队列
            $isPushed = Queue::push(
                GroupMsgTemplates::JOB_HANDLER,
                $carryData,
                GroupMsgTemplates::JOB_QUEUE_NAME
            );

            if ($isPushed !== false) {
                GroupMsgTemplatesDao::updateData(['status' => 1], [
                    'id' => $templateId
                ]);
                return;
            }
        } catch (Exception $e) {
            send_msg_to_wecom('队列出错：' . $e->getMessage());
        }
    }

    /**
     * 组织群发第二条数据
     *
     * @param array $templateData 群发记录数据
     * @return array
     * @throws Exception
     */
    public function organizeSecondData(array $templateData): array
    {
        switch ($templateData['second_type']) {
            case 1:
                $msgType = 'miniprogram';
                $typeData = [
                    'title'        => $templateData['miniprogram_title'],
                    // 这个会过期
                    'pic_media_id' => $this->getNewestMediaId($templateData),
                    'appid'        => $templateData['miniprogram_appid'],
                    'page'         => $templateData['miniprogram_page']
                ];
                break;

            case 2:
                $msgType = 'image';
                $typeData = [
                    'pic_url' => $templateData['image_pic_url']
                ];
                break;

            case 3:
                $msgType = 'link';
                $typeData = [
                    'title'  => $templateData['link_title'],
                    'picurl' => $templateData['link_pic_url'] ?? '',
                    'desc'   => $templateData['link_desc'] ?? '',
                    'url'    => $templateData['link_url'],
                ];
                break;

            default:
                $msgType = '';
                $typeData = [];
                break;
        }

        return [$msgType, $typeData];
    }

    /**
     * 获取群发列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $fields = [
            'id',
            'task_name',
            'content_text',
            'status',
            'send_time',
            'creator'
        ];

        $where = [
            'is_deleted' => 0
        ];

        if (
            isset($requestData['task_name'])
            && $requestData['task_name'] !== ''
        ) {
            $where['task_name'] = ['like', '%' . $requestData['task_name'] . '%'];
        }

        if (
            isset($requestData['status'])
            && $requestData['status'] !== ''
        ) {
            $where['status'] = $requestData['status'];
        }

        if (
            isset($requestData['send_time_start'])
            && !isset($requestData['send_time_end'])
            && !empty($requestData['send_time_start'])
        ) {
            $where['send_time'] = ['>', $requestData['send_time_start']];
        }

        if (
            isset($requestData['send_time_end'])
            && !isset($requestData['send_time_start'])
            && !empty($requestData['send_time_end'])
        ) {
            $where['send_time'] = ['<', $requestData['send_time_end']];
        }

        if (
            isset($requestData['send_time_start'])
            && isset($requestData['send_time_end'])
            && !empty($requestData['send_time_start'])
            && !empty($requestData['send_time_end'])
        ) {
            $where['send_time'] = ['between', [$requestData['send_time_start'], $requestData['send_time_end']]];
        }

        if (
            isset($requestData['creator'])
            && $requestData['creator'] !== ''
        ) {
            $where['creator'] = ['like', '%' . $requestData['creator'] . '%'];
        }

        $msgTemplatesList = GroupMsgTemplatesDao::getPaginationList(
            $fields,
            $where,
            (int)$page,
            (int)$limit,
            'id DESC'
        );

        $msgTemplateCount = GroupMsgTemplatesDao::getCount($where);

        if ($msgTemplatesList) {
            $idArr = array_column($msgTemplatesList, 'id');

            // 进行中的客服数-begin
            /*$processingSender = Db::name('group_msg_id_map')
                ->field([
                    'template_id',
                    'sender_user_id'
                ])
                ->where([
                    'template_id'   => ['in', $idArr],
                    'is_get_result' => GroupMsgIdMap::NOT_GET_RESULT
                ])
                ->select();

            $newProcessingSender = [];

            foreach ($processingSender as $senderVal) {
                $newProcessingSender[$senderVal['template_id']][] = $senderVal['sender_user_id'];
            }
            // 进行中的客服数-end

            // 已结束的客服数-begin
            $senderCount = Db::name('group_msg_sender_map')
                ->field([
                    'template_id',
                    'count(1) as total'
                ])
                ->where([
                    'template_id' => ['in', $idArr]
                ])
                ->group('template_id')
                ->select();

            $newSenderCount = [];

            foreach ($senderCount as $v) {
                $newSenderCount[$v['template_id']] = $v['total'];
            }*/
            // 已结束的客服数-end

            // 已结束的客户数-begin
            /*$receiverCount = Db::name('group_msg_receive_map')
                ->field([
                    'template_id',
                    'count(1) as total'
                ])
                ->where([
                    'template_id' => ['in', $idArr],
                    'status'      => GroupMsgReceiveMap::STATUS_HAS_SEND
                ])
                ->group('template_id')
                ->select();

            $newReceiverCount = [];

            foreach ($receiverCount as $receiverInfo) {
                $newReceiverCount[$receiverInfo['template_id']] = $receiverInfo['total'];
            }*/
            // 已结束的客户数-end

            array_walk($msgTemplatesList, function (&$val) {
                $receiverCount = GroupMsgReceiveMapDao::getCount(
                    [
                        'template_id' => $val['id']
                    ]
                );

                $senderCount = GroupMsgSenderMapDao::getCount(
                    [
                        'template_id' => $val['id']
                    ]
                );

                switch ($val['status']) {
                    case 0:
                        $val['status_name'] = '未开始';
                        $val['process'] = '未到定时时间';
                        break;

                    case 1:
                        $val['status_name'] = '进行中';
                        /*$processingUserIdArr = $newProcessingSender[$val['id']] ?? [];
                        // 进行中的客户数-begin
                        $processingReceiverCount = Db::name('group_msg_receive_map')
                            ->field([
                                'template_id',
                                'count(1) as total'
                            ])
                            ->where([
                                'template_id' => $val['id'],
                                'user_id'     => ['in', $processingUserIdArr],
                                'status'      => GroupMsgReceiveMap::STATUS_NOT_SEND
                            ])
                            ->group('template_id')
                            ->select();

                        $newProcessingReceiverCount = [];

                        foreach ($processingReceiverCount as $receiverInfo) {
                            $newProcessingReceiverCount[$receiverInfo['template_id']] = $receiverInfo['total'];
                        }

                        // 进行中的客户数-end

                        $val['process'] = sprintf(
                            '待%d名成员发送给%d名客户',
                            isset($newProcessingSender[$val['id']])
                                ? count(array_unique($newProcessingSender[$val['id']]))
                                : 0,
                            $newProcessingReceiverCount[$val['id']] ?? 0
                        );*/
                        $val['process'] = sprintf(
                            '%d名成员发送给%d名客户',
                            $senderCount,
                            $receiverCount
                        );
                        break;

                    case 2: // 已结束的可以查Sender表
                        $val['status_name'] = '已结束';
                        $val['process'] = sprintf(
                            '%d名成员发送给%d名客户',
                            $senderCount,
                            $receiverCount
                        );
                        break;
                }
            });
        }

        return [
            'list'  => $msgTemplatesList,
            'count' => $msgTemplateCount
        ];
    }

    /**
     * 获取标签列表
     *
     * @return array
     * @throws Exception
     */
    public function getTagList(): array
    {
        $tagsArr = ContactTagsDao::getAllList(['group_name', 'tag_id', 'tag_name'], [
            'group_is_deleted' => ContactTags::GROUP_NOT_DELETED,
            'tag_is_deleted'   => ContactTags::TAG_NOT_DELETED
        ], 'tag_order desc');

        $newTagsArr = [];

        foreach ($tagsArr as $tag) {
            $newTagsArr[$tag['group_name']][] = [
                'tag_id'   => $tag['tag_id'],
                'tag_name' => $tag['tag_name']
            ];
        }

        $returnData = [];

        foreach ($newTagsArr as $key => $value) {
            $returnData[] = [
                'group_name' => $key,
                'tags'       => $value
            ];
        }

        return $returnData;
    }

    /**
     * 获取查看时的标签列表
     *
     * @param int $templateId
     * @return array
     * @throws Exception
     */
    public function getChooseTagList(int $templateId): array
    {
        $tagList = $this->getTagList();

        if (
            !$tagMapList = GroupMsgTagMapDao::getAllList(
                ['tag_id'],
                [
                    'template_id' => $templateId,
                ]
            )
        ) {
            return [];
        }

        $tadIdArr = array_column($tagMapList, 'tag_id');

        foreach ($tagList as &$val) {
            $count = 0;
            foreach ($val['tags'] as &$tagVal) {
                if (in_array($tagVal['tag_id'], $tadIdArr)) {
                    $tagVal['is_selected'] = 1;
                    $count += 1;
                } else {
                    $tagVal['is_selected'] = 0;
                }
            }
            $val['tag_selected_count'] = $count;
        }


        return $tagList;
    }

    /**
     * 获取群发消息详情
     *
     * @param int $templateId
     * @return array
     * @throws Exception
     */
    public function getDetail(int $templateId): array
    {
        $msgInfo = GroupMsgTemplatesDao::getDetail(
            [
                'task_name',
                'receiver_range',
                'content_text',
                'create_time',
                'second_type',
                'image_pic_url',
                'link_title',
                'link_pic_url',
                'link_desc',
                'link_url',
                'miniprogram_title',
                'miniprogram_appid',
                'miniprogram_page',
                'miniprogram_pic_url',
                'miniprogram_pic_media_id',
                'miniprogram_pic_create_time',
                'is_plan',
                'send_time'
            ],
            [
                'id' => $templateId
            ]
        );

        if (!$msgInfo) {
            return [];
        }

        if ($msgInfo['second_type'] == 1) {
            $msgInfo['miniprogram_name'] = ContactChannels::MINI_PROGRAM_APP_ID_MAP[$msgInfo['miniprogram_appid']];
        }

        $msgInfo['range_option'] = $msgInfo['receiver_range'] != 0 ? 1 : 2;

        // 添加人
        $senderMapArr =  GroupMsgSenderMapDao::getAllList(['sender_user_id'], ['template_id' => $templateId]);

        $msgInfo['sender'] = array_column($senderMapArr, 'sender_user_id');

        // 标签
        $tagMapArr =  GroupMsgTagMapDao::getAllList(['tag_id'], ['template_id' => $templateId]);

        $msgInfo['tags'] = array_column($tagMapArr, 'tag_id');

        unset($msgInfo['receiver_range']);

        return $msgInfo;
    }

    /**
     * 获取群发执行结果
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getSendResult(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $where = [
            'template_id' => $requestData['template_id']
        ];

        // 咨询助理
        if (
            isset($requestData['user_id'])
            && !empty($requestData['user_id'])
        ) {
            $where['user_id'] = $requestData['user_id'];
        }

        // 发送状态
        if (
            isset($requestData['status'])
            && $requestData['status'] !== ''
        ) {
            $where['a.status'] = $requestData['status'];
        }

        // 是否在群
        if (
            isset($requestData['is_in_group'])
            && $requestData['is_in_group'] !== ''
        ) {
            $where['is_in_group'] = $requestData['is_in_group'];
        }

        // 好友状态
        if (
            isset($requestData['friend_status'])
            && $requestData['friend_status'] !== ''
        ) {
            $where['c.userid'] = $requestData['user_id'];
            $where['c.status'] = $requestData['friend_status'];
        }

        $receiveList = (array)Db::name('group_msg_receive_map')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->join(
                'scrm_contact_follow_user c',
                'b.external_userid = c.external_userid',
                'LEFT'
            )
            ->field([
                'a.external_userid',
                'a.user_id',
                'a.status',
                'b.name',
                'b.avatar',
                'b.is_in_group',
                'c.status as friend_status'
            ])
            ->where($where)
            ->page($page, $limit)
            ->group('a.external_userid')
            ->select();

        $count = Db::name('group_msg_receive_map')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->join(
                'scrm_contact_follow_user c',
                'b.external_userid = c.external_userid',
                'LEFT'
            )
            ->where($where)
            ->group('a.external_userid')
            ->count();

        // 客服名称map
        $userIdArr = array_unique(array_column($receiveList, 'user_id'));

        $userInfo = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $userIdArr]]);

        $userIdNameMap = [];

        foreach ($userInfo as $user) {
            $userIdNameMap[$user['userid']] = $user['name'];
        }
        foreach ($receiveList as &$receiver) {
            $receiver['user_name'] = $userIdNameMap[$receiver['user_id']];
            switch ($receiver['status']) {
                case 0:
                    $receiver['status'] = '待发送';
                    break;

                case 1:
                    $receiver['status'] = '已发送';
                    break;

                case 2:
                    $receiver['status'] = '客户已拒收';
                    break;

                case 3:
                    $receiver['status'] = '因客户已经收到其他群发消息导致发送失败';
                    break;

                case 4:
                    $receiver['status'] = '无效或无法发送';
                    break;
            }

            switch ($receiver['friend_status']) {
                case 0:
                    $receiver['friend_status'] = '正常';
                    break;

                case 1:
                    $receiver['friend_status'] = '员工删除外部联系人';
                    break;

                case 2:
                    $receiver['friend_status'] = '外部联系人删除员工';
                    break;
            }

            $receiver['is_in_group'] = $receiver['is_in_group'] == 1 ? '是' : '否';
        }

        return [
            'list'  => $receiveList,
            'count' => $count
        ];
    }

    /**
     * 发送提醒
     *
     * @param int $templateId 群发记录ID
     * @return bool
     * @throws Exception
     */
    public function sendRemind(int $templateId): bool
    {
        $templateDetail = GroupMsgTemplatesDao::getDetail(
            [
                'content_text',
                'receiver_range',
                'second_type',
                'image_pic_url',
                'link_title',
                'link_pic_url',
                'link_desc',
                'link_url',
                'miniprogram_title',
                'miniprogram_appid',
                'miniprogram_page',
                'miniprogram_pic_url',
                'miniprogram_pic_create_time',
                'miniprogram_pic_expire_time'
            ],
            [
                'id'         => $templateId,
                'is_deleted' => 0
            ]
        );

        if (!$templateDetail) {
            return false;
        }

        [$msgType, $typeData] = $this->organizeSecondData($templateDetail);

        $senderUserIdArr = GroupMsgIdMapDao::getAllList(
            [
                'sender_user_id'
            ],
            [
                'template_id'   => $templateId,
                'is_get_result' => 0
            ]
        );

        $tagIdArr = GroupMsgTagMapDao::getAllList(['tag_id'], [
            'template_id' => $templateId,
        ]);

        $originalData = [
            'template_id'    => $templateId, // 群发记录ID
            'receiver_range' => $templateDetail['receiver_range'],
            'content_text'   => $templateDetail['content_text'], // 第一条内容
            'msg_type'       => $msgType, // 第二条类型
            'type_data'      => $typeData // 第二条内容
        ];

        $extraData = [];

        if (
            in_array(
                $templateDetail['receiver_range'],
                [
                    GroupMsgTemplates::RECEIVER_ONLY_SENDER,
                    GroupMsgTemplates::RECEIVER_SENDER_AND_TAG
                ]
            )
        ) {
            $extraData['sender'] = array_column($senderUserIdArr, 'sender_user_id');
        }

        if ($templateDetail['receiver_range'] == GroupMsgTemplates::RECEIVER_SENDER_AND_TAG) {
            $extraData['tags'] = array_column($tagIdArr, 'tag_id');
        }

        $carryData = $extraData ? array_merge($originalData, $extraData) : $originalData;

        // 因为是提醒，多加一个字段判断
        $carryData['is_remind'] = 1;
        try {
            // 推送到队列
            $isPushed = Queue::push(
                GroupMsgTemplates::JOB_HANDLER,
                $carryData,
                GroupMsgTemplates::JOB_QUEUE_NAME
            );

            if ($isPushed !== false) {
                return true;
            }
        } catch (Exception $e) {
            Log::error('队列出错：' . $e->getMessage());
        }

        return false;
    }

    /**
     * 获取小程序最新的media_id
     *
     * @param array $groupMsgData 群发记录数据
     * @return mixed
     * @throws Exception
     */
    private function getNewestMediaId(array $groupMsgData)
    {
        $fileManager = new FileManager();

        $updateFunc = function ($groupMsgData, $uploadRes) {
            return GroupMsgTemplatesDao::updateData(
                [
                    'miniprogram_pic_media_id'    => $uploadRes['media_id'],
                    'miniprogram_pic_create_time' => $uploadRes['created_at'],
                    'miniprogram_pic_expire_time' => intval($uploadRes['created_at'] + MediaHttpDao::MEDIA_EXPIRE_TIME)
                ],
                [
                    'id' => $groupMsgData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia('image', 'png', $groupMsgData, $updateFunc);
    }

    /**
     * 删除任务
     *
     * @param int $templateId
     * @return array
     * @throws Exception
     */
    public function delete(int $templateId): array
    {
        $templateDetail = GroupMsgTemplatesDao::getDetail(['status'], ['id' => $templateId, 'is_deleted' => 0]);

        if (!$templateDetail) {
            return [false, '此任务不存在或已删除！'];
        }

        if ($templateDetail['status'] != 0) {
            return [false, '只能删除"未开始"的任务！'];
        }

        if (GroupMsgTemplatesDao::deleteById($templateId) == false) {
            return [false, '删除失败！'];
        }

        return [true, '删除成功！'];
    }

    /**
     * 获取发送顾问列表
     *
     * @param int $templateId
     * @param string $keyword
     * @return array
     * @throws Exception
     */
    public function getSenderList(int $templateId, string $keyword = ''): array
    {
        $where['template_id'] = $templateId;

        if ($keyword != '') {
            $where['b.name'] = ['like', "%$keyword%"];
        }

        return (array)Db::name('group_msg_sender_map')
            ->alias('a')
            ->join('scrm_user b', 'a.sender_user_id = b.userid', 'LEFT')
            ->field([
                'a.sender_user_id as userid',
                'b.name'
            ])
            ->where($where)
            ->select();
    }
}
