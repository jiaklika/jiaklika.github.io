<?php

declare(strict_types=1);

namespace app\api\service\groupMsg;

/**
 * 分层群发
 *
 * Interface GroupMsgService
 * @package app\api\service\groupMsg
 */
interface GroupMsgService
{
    /**
     * 新建群发
     *
     * @param array $requestData
     * @return bool
     */
    public function add(array $requestData): bool;

    /**
     * 编辑群发
     *
     * @param array $requestData
     * @return bool
     */
    public function edit(array $requestData): bool;

    /**
     * 获取群发列表
     *
     * @param array $requestData
     * @return array
     */
    public function getList(array $requestData): array;

    /**
     * 获取标签列表
     *
     * @return array
     */
    public function getTagList(): array;

    /**
     * 获取查看详情时的标签列表
     *
     * @param int $templateId 群发记录id
     * @return array
     */
    public function getChooseTagList(int $templateId): array;

    /**
     * 获取群发详情
     *
     * @param int $templateId 群发记录id
     * @return array
     */
    public function getDetail(int $templateId): array;

    /**
     * 获取群发执行结果
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function getSendResult(array $requestData): array;
}
