<?php

declare(strict_types=1);

namespace app\api\service\living;

/**
 * Interface LivingService
 * @package app\api\service\living
 */
interface LivingService
{
    /**
     * 初始化成员直播信息
     *
     * @param string $userId
     * @return bool
     */
    public function initUserLivingInfo(string $userId): bool;
}
