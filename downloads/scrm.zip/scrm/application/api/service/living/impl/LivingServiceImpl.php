<?php

declare(strict_types=1);

namespace app\api\service\living\impl;

use app\api\dao\http\living\LivingHttpDao;
use app\api\dao\mysql\living\LivingDao;
use app\api\dao\mysql\living\LivingWatchStatDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\living\LivingService;
use app\common\model\LiveWatchStat;
use Exception;
use think\Db;

/**
 * Class LivingServiceImpl
 * @package app\api\service\living\impl
 */
class LivingServiceImpl implements LivingService
{
    /**
     * @var LivingHttpDao
     */
    private static $livingHttpDao;

    /**
     * LivingServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$livingHttpDao)) {
            self::$livingHttpDao = new LivingHttpDao();
        }
    }

    /**
     * 初始化成员直播信息
     *
     * @param string $userId
     * @return bool
     * @throws Exception
     */
    public function initUserLivingInfo(string $userId): bool
    {
        [
            $liveIdArr,
            $insertLiveData,
            $insertWatchUserData
        ] =
        [
            self::$livingHttpDao->getUserLivingId($userId, strtotime('2020-10-01'), time()),
            [],
            []
        ];

        foreach ($liveIdArr['livingid_list'] as $key => $liveId) {
            $insertLiveData[$key] = self::$livingHttpDao->getLivingInfo($liveId);
            $insertLiveData[$key]['living_id'] = $liveId;

            $allWatchUser = $this->getAllWatchUser($liveId);

            $internalUserArr = $externalUserArr = [];

            foreach ($allWatchUser as $userSection) {
                $internalUserArr = array_merge($userSection['users'], $internalUserArr);
                $externalUserArr = array_merge($userSection['external_users'], $externalUserArr);
            }

            foreach ($internalUserArr as $internalUser) {
                $insertWatchUserData[] = [
                    'living_id'     => $liveId,
                    'user_id'       => $internalUser['userid'],
                    'name'          => ($userInfo = UserDao::getDetail(['name'], [
                        'userid' => $internalUser['userid']
                    ]))
                        ? $userInfo['name']
                        : '',
                    'user_type'     => LiveWatchStat::USER,
                    'external_type' => LiveWatchStat::NOT_EXTERNAL,
                    'watch_time'    => $internalUser['watch_time'],
                    'is_comment'    => $internalUser['is_comment'],
                    'is_mic'        => $internalUser['is_mic']
                ];
            }

            foreach ($externalUserArr as $externalUser) {
                $insertWatchUserData[] = [
                    'living_id'     => $liveId,
                    'user_id'       => $externalUser['external_userid'],
                    'name'          => $externalUser['name'],
                    'user_type'     => LiveWatchStat::EXTERNAL_USER,
                    'external_type' => $externalUser['type'],
                    'watch_time'    => $externalUser['watch_time'],
                    'is_comment'    => $externalUser['is_comment'],
                    'is_mic'        => $externalUser['is_mic']
                ];
            }
        }
        Db::startTrans();

        [
            $liveInsertRes,
            $watchInsertRes
        ] =
        [
            LivingDao::addBatchData($insertLiveData),
            LivingWatchStatDao::addBatchData($insertWatchUserData)
        ];

        if ($liveInsertRes && $watchInsertRes) {
            Db::commit();
        } else {
            Db::rollback();
            return false;
        }

        return true;
    }

    /**
     * 获取看直播统计的所有观众信息
     *
     * @param string $liveId
     * @param string $nextKey
     * @return void
     * @throws Exception
     */
    private function getAllWatchUser(string $liveId, string $nextKey = '0'): void
    {
        static $stat_info;

        $watchStatRes = self::$livingHttpDao->getWatchStat($liveId, $nextKey);

        $stat_info[] = $watchStatRes['stat_info'];

        if ($watchStatRes['ending'] == 0) {
            $this->getAllWatchUser($liveId, $watchStatRes['next_key']);
        }
    }
}
