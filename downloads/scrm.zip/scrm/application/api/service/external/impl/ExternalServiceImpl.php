<?php

declare(strict_types=1);

namespace app\api\service\external\impl;

use app\api\service\external\ExternalService;
use think\Cache;

/**
 * Class ExternalServiceImpl
 * @package app\api\service\external\impl
 */
class ExternalServiceImpl implements ExternalService
{
    public function card($unionId, $title, $pic, $path)
    {
        $redis = Cache::store()->handler();
        $redis->hSet('external', $unionId, json_encode([
            'title' => $title,
            'pic' => $pic,
            'path' => $path,
        ]));
    }
}
