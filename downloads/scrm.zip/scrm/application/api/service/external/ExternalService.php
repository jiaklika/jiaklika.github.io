<?php

declare(strict_types=1);

namespace app\api\service\external;

use think\File;

/**
 * Interface ExternalService
 * @package app\api\service\external
 */
interface ExternalService
{
    public function card($unionId, $title, $pic, $path);
}
