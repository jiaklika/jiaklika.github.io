<?php

declare(strict_types=1);

namespace app\api\service\contact;

/**
 * Interface ContactService
 * @package app\api\service\contact
 */
interface ContactService
{
    /**
     * 获取js-sdk的配置信息
     *
     * @param string $url 当前访问的url
     * @return array
     */
    public function getConfig(string $url): array;

    /**
     * 获取客户详情
     *
     * @param string $externalContactUserId 外部联系人ID
     * @return array
     */
    public function getDetail(string $externalContactUserId): array;

    /**
     * 初始化所有客户入表
     *
     * @return bool
     */
    public function initContactList(): bool;

    /**
     * 初始化所有客户的详情
     *
     * @return array
     */
    public function initContactDetail(): array;

    /**
     * 获取路径客户列表
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function getWayContactList(array $requestData): array;

    /**
     * 获取渠道客户列表
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function getChannelContactList(array $requestData): array;

    /**
     * 获取企微客户
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function getAllContactList(array $requestData): array;

    /**
     * 获取宝姐客户等级列表
     *
     * @return array
     */
    public function getUserLevelList(): array;

    /**
     * 获取员工的客户统计数据
     *
     * @param array $userIdArr
     * @return array
     */
    public function getStatisticsData(array $userIdArr): array;

    /**
    * 获取公司的客户统计数据
    *
    * @return array
    */
    public function getCompanyStatisticsData(): array;
}
