<?php

declare(strict_types=1);

namespace app\api\service\contact\impl;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\data\PushFansDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\dao\mysql\user\UserDao;
use app\api\dao\mysql\way\UnifyServiceDao;
use app\api\dao\mysql\way\WayUserMapDao;
use app\api\service\contact\ContactService;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactWays;
use app\common\model\ExternalContact;
use app\common\model\User;
use Carbon\Carbon;
use Exception;
use League\Pipeline\Pipeline;
use LogicException;
use Redis;
use think\Cache;
use think\Db;
use think\Log;
use think\Queue;

/**
 * Class ContactServiceImpl
 * @package app\api\service\contact\impl
 */
class ContactServiceImpl implements ContactService
{
    /**
     * @var ContactHttpDao
     */
    private static $contactHttpDao;

    /**
     * ContactServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$contactHttpDao)) {
            self::$contactHttpDao = new ContactHttpDao();
        }
    }

    /**
     * 获取js-sdk的配置信息
     *
     * @param string $url
     * @return array
     * @throws Exception
     */
    public function getConfig(string $url): array
    {
        return self::$contactHttpDao->verifyAuth($url);
    }

    /**
     * 获取客户详情
     *
     * @param string $externalContactUserId 对外联系人的ID
     * @return array
     * @throws Exception
     */
    public function getDetail(string $externalContactUserId): array
    {
        $externalContactDetailArr = self::$contactHttpDao->getContactDetail($externalContactUserId);

        if (
            !isset($externalContactDetailArr['external_contact']['unionid'])
            || empty($unionId = $externalContactDetailArr['external_contact']['unionid'])
        ) {
            return [];
        }

        $externalContactDetail = $externalContactDetailArr['external_contact'];

        [
            $yanZhiInfo,  // 颜值
            $liveRank,    // 直播等级
            $userCenter,  // 用户中心
            $appLastLogin // APP端最后登录
        ] = [
            self::$contactHttpDao->getYanzhi($unionId),
            self::$contactHttpDao->getLiveRank($unionId),
            self::$contactHttpDao->getUserCenter($unionId),
            self::$contactHttpDao->getAppLastLoginTime($unionId)
        ];

        $city = '暂无';

        if ($userCenter['province'] == '') {
            // 宝姐珠宝的用户地址
            $userAddress = self::$contactHttpDao->getUserAddress($unionId);
            if ($userAddress['province']) {
                $city = $userAddress['province'] . $userAddress['city'];
            } else {
                $addressFromKo = self::$contactHttpDao->getAddressFromKo($unionId);
                if ($addressFromKo['province']) {
                    $city = $addressFromKo['province'] . $addressFromKo['city'];
                }
            }
        } else {
            $city = $userCenter['province'] . $userCenter['city'];
        }

        $returnData = [
            'name'                      => $externalContactDetail['name'],
            'avatar'                    => $externalContactDetail['avatar'],
            'gender'                    => $externalContactDetail['gender'],
            'unionid'                   => $externalContactDetail['unionid'],
            'yanzhi'                    => $yanZhiInfo['yanzhi_total'],
            'liveRank'                  => $liveRank['level'],
            'city'                      => $city,
            'user_level_name'           => $userCenter['user_level_name'] ?? '新人',
            'last_consume_date'         => $userCenter['last_consume_date'] ?? '暂无',
            'consume_amount'            => $userCenter['consume_amount']
                ? $userCenter['consume_amount'] . '元'
                : '暂无', // 累计消费，不包含退款
            'contract_amount'           => $userCenter['contractAmount']
                ? $userCenter['contractAmount'] . '元'
                : '暂无', // 累计消费，包含退款
            'score'                     => $userCenter['score'] ?? 0,
            'age'                       => isset($userCenter['birthday']) ? getAge((int)$userCenter['birthday']) : 0,
            'assistant_name'            => $userCenter['assistant_name'] ?? '未分配',
            'first_order_consume_money' => (isset($userCenter['first_consume_amount'])
                && $userCenter['first_consume_amount'] != 0)
                ? $userCenter['first_consume_amount'] . '元'
                : '暂无',
            'first_order_consume_date'  => $userCenter['first_consume_date'] ?? ''
        ];

        // 比较获取最后登录应用
        if (
            empty($yanZhiInfo['last_login'])
            && empty($liveRank['last_login'])
            && empty($appLastLogin['app_last_login'])
        ) {
            $returnData['last_login_time'] = $returnData['last_login_name'] = '暂无';
        } else {
            // 获取最后登录的应用
            $lastLoginArr = array_filter([
                '宝姐家小程序'   => $yanZhiInfo['last_login'],
                '宝姐珠宝小程序' =>  $liveRank['last_login'] ?? 0,
                '宝姐家APP'     => $appLastLogin['app_last_login']
            ]);

            asort($lastLoginArr);

            $returnData['last_login_time'] = Carbon::createFromTimestamp(end($lastLoginArr))->toDateTimeString();

            $returnData['last_login_name'] = key($lastLoginArr);
        }

        return $returnData;
    }

    /**
     * 初始化所有客户列表入表
     *
     * @return bool
     */
    public function initContactList(): bool
    {
        $allContact = $insertData = [];

        Db::name('user')
            ->field([
                'id',
                'userid'
            ])
            ->where([
                'is_follow_user' => User::IS_FOLLOW_USER
            ])
            ->chunk(4, function ($users) use (&$allContact) {

                if (!$users) {
                    return false;
                }

                foreach ($users as $user) {
                    $externalContactUserIdArr = self::$contactHttpDao->getContactList($user['userid']);
                    if ($externalContactUserIdArr) {
                        $allContact = array_merge(
                            $allContact,
                            $externalContactUserIdArr
                        );
                    }
                }

                return true;
            });

        // 去重
        $allContact = array_flip($allContact);
        $allContact = array_flip($allContact);

        foreach ($allContact as $contact) {
            $insertData[]['external_userid'] = $contact;
        }

        $addRes = ContactDao::addBatchData($insertData);

        if ($addRes) {
            return true;
        }

        return false;
    }

    /**
     * 初始化所有客户详情进入redis
     *
     * @return array
     */
    public function initContactDetail(): array
    {
        // 队列名
        $jobQueue = 'init_contact_detail_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\InitContactDetailJob';

        Db::name('external_contact')
            ->field([
                'id',
                'external_userid'
            ])
            ->where([
                'unionid' => null,
                'type'    => ExternalContact::WEIXIN_USER
            ])
            ->chunk(1, function ($contacts) use ($jobQueue, $jobHandler) {

                if (empty($contacts)) {
                    return false;
                }

                try {
                    // 推送到队列
                    $isPushed = Queue::push($jobHandler, $contacts, $jobQueue);

                    if ($isPushed !== false) {
                        return true;
                    }
                    return false;
                } catch (Exception $e) {
                    Log::error('队列出错：' . $e->getMessage());
                    return false;
                }
            });

        return [true, '执行完毕！'];
    }

    /**
     * 扫描redis中的客户数据进表
     *
     * @return array
     */
    public function getRedisData(): array
    {
        $externalContactModel = model('ExternalContact');

        // 获取redis实例
        $redis = Cache::store()->handler();

        $redis->setOption(Redis::OPT_SCAN, Redis::SCAN_RETRY);

        $contactIterator = $followIterator = null;

        // 客户信息
        try {
            while ($contacts = $redis->sScan('contact', $contactIterator, '*', 10)) {
                foreach ($contacts as $contact) {
                    $contactArr = json_decode($contact, true);

                    $externalContactModel->saveAll($contactArr);
                }
            }

            // 客户助理信息
            while ($follows = $redis->sScan('follow', $followIterator, '*', 10)) {
                foreach ($follows as $follow) {
                    $followArr = json_decode($follow, true);

                    ContactFollowUserDao::addBatchData($followArr);
                }
            }

            return [true, '执行成功'];
        } catch (Exception $e) {
            return [false, $e->getMessage()];
        }
    }

    /**
     * 更新用户等级
     * @throws Exception
     */
    public function updateUserLevel(): array
    {
        $updateData = [];

        ContactDao::handleDataByChunk(
            [
                'id',
                'unionid'
            ],
            [
                'id' => ['between', [164000, 166000]],
                'unionid' => ['not null', '']
            ],
            500,
            function ($contacts) use (&$updateData) {
                if (empty($contacts)) {
                    return false;
                }

                foreach ($contacts as $contact) {
                    $userCenterArr = self::$contactHttpDao->getUserCenter($contact['unionid']);

                    if ($userCenterArr && $userCenterArr['user_level_id'] != 0) {
                        $externalContactArr = [
                            'id'            => $contact['id'],
                            'user_level_id' => $userCenterArr['user_level_id']
                        ];

                        $updateData[] = $externalContactArr;
                    }
                }
                return true;
            }
        );

        ContactDao::updateBatchData(new ExternalContact(), $updateData);

        return [true, '执行完毕！'];
    }

    /**
     * 获取添加形式选项
     *
     * @return array
     */
    public function getAddWayList(): array
    {
        return [
            'add_way_list' =>
            [
                '全部',
                '咨询按钮',
                '活码',
                '普通扫码',
                '手机号添加（搜索手机号、手机通讯录）',
                '群聊',
                '来自微信的添加好友申请',
                '内部成员共享',
                '管理员/负责人分配',
                '视频号主页添加',
                '企微朋友圈广告',
                '未知来源',
                '名片分享',
                '微信联系人',
                '安装第三方应用时自动添加的客服人员',
                '搜索邮箱',
                '个微朋友圈广告'
            ]
        ];
    }

    /**
     * 获取路径的客户列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getWayContactList(array $requestData): array
    {
        [
            $limit,
            $page,
        ] = [
            (int)$requestData['limit'],
            (int)$requestData['page']
        ];

        $where = $this->wayWhere($requestData);

        // 客户列表
        $contactList = $this->handleChannelContactData($where, $page, $limit);

        // 客户总数
        $contactCount = ContactFollowUserDao::getContactCount($where);

        return [
            'list'  => $contactList,
            'count' => $contactCount
        ];
    }

    /**
     * 获取渠道的客户列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getChannelContactList(array $requestData): array
    {
        [
            $limit,
            $page,
            $channelId
        ] = [
            (int)$requestData['limit'],
            (int)$requestData['page'],
            $requestData['channel_id'],
        ];

        $wayInfo = [];

        if (in_array($channelId, array_keys(ContactChannels::MOMENT_CHANNEL_MAP))) {
            $where = $this->channelWhere($wayInfo, $requestData, $channelId);
        } elseif (in_array($channelId, array_keys(ContactChannels::WECHAT_VIDEO_STATE_MAP))) {
            $where = $this->channelWhere([[
                'id' => ContactChannels::WECHAT_VIDEO_STATE_MAP[$channelId]
            ]], $requestData);
        } else {
            $wayInfo = ContactWaysDao::getAllList(['id', 'scene'], [
                'channel_id' => $channelId,
            ]);

            if (!$wayInfo) {
                return [
                    'list'  => [],
                    'count' => 0
                ];
            }
            $where = $this->channelWhere($wayInfo, $requestData);
        }

        // 客户列表
        $contactList = $this->handleChannelContactData($where, $page, $limit);

        // 客户总数
        $contactCount = ContactFollowUserDao::getContactCount($where);

        return [
            'list'  => $contactList,
            'count' => $contactCount
        ];
    }

    /**
     * 获取所有的企微客户
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getAllContactList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            (int)$requestData['limit'],
            (int)$requestData['page']
        ];

        [$where, $extraWhere] = $this->commonWhere($requestData);

        // 客户列表
        $contactList = $this->handleChannelContactData($where, $page, $limit, $extraWhere);

        // 客户总数
        $contactCount = $where
            ? ContactFollowUserDao::getContactCount($where, $extraWhere)
            : Db::name('contact_follow_user')->count(1);

        return [
            'list'  => $contactList,
            'count' => $contactCount
        ];
    }

    /**
     * 渠道客户列表导出Excel
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function exportChannelContactList(array $requestData): bool
    {
        $channelId = $requestData['channel_id'];

        $wayInfo = [];

        if (in_array($channelId, array_keys(ContactChannels::MOMENT_CHANNEL_MAP))) {
            $where = $this->channelWhere($wayInfo, $requestData, $channelId);
        } else {
            $wayInfo = ContactWaysDao::getAllList(['id', 'scene'], [
                'channel_id' => $channelId,
            ]);

            if (!$wayInfo) {
                return false;
            }
            $where = $this->channelWhere($wayInfo, $requestData);
        }

        // 客户列表
        $contactList = $this->handleChannelContactData($where, 0, 0);

        $channelData = ContactChannelsDao::getDetail(['channel_name'], ['id' => $channelId]);

        if (!$channelData) {
            return false;
        }

        $title = sprintf('渠道-%s-客户列表-%s', $channelData['channel_name'], Carbon::now()->getTimestamp());

        downloadExcel($title, function ($spreadsheet) use ($contactList) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'ID')
                ->setCellValue('B1', '名称')
                ->setCellValue('C1', '头像')
                ->setCellValue('D1', '识别码')
                ->setCellValue('E1', '性别')
                ->setCellValue('F1', '会员等级')
                ->setCellValue('G1', '添加助理')
                ->setCellValue('H1', '添加形式')
                ->setCellValue('I1', '首次添加时间')
                ->setCellValue('J1', '状态');

            foreach ($contactList as $key => $contact) {
                $excelKey = $key + 2;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['id'])
                    ->setCellValue('B' . $excelKey, $contact['name'])
                    ->setCellValue('C' . $excelKey, $contact['avatar'] ? : '')
                    ->setCellValue('D' . $excelKey, $contact['unionid'] ? : '')
                    ->setCellValue('E' . $excelKey, $contact['gender'])
                    ->setCellValue('F' . $excelKey, $contact['user_level_name'])
                    ->setCellValue('G' . $excelKey, $contact['user_name'])
                    ->setCellValue('H' . $excelKey, $contact['scene_name'])
                    ->setCellValue('I' . $excelKey, $contact['createtime'])
                    ->setCellValue('J' . $excelKey, $contact['status']);
            }
        });
        return true;
    }

    /**
     * 路径客户列表导出Excel
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function exportWayContactList(array $requestData): bool
    {
        $where = $this->wayWhere($requestData);

        // 客户列表
        $contactList = $this->handleChannelContactData($where, 0, 0);

        $contactWayDetail = ContactWaysDao::getDetail(
            [
                'way_name',
                'scene'
            ],
            [
                'id' => $requestData['way_id']
            ]
        );

        $title = sprintf(
            '%s-%s-客户列表-%s',
            ContactWays::SCENE_MAP[$contactWayDetail['scene']],
            $contactWayDetail['way_name'],
            Carbon::now()->getTimestamp()
        );

        downloadExcel($title, function ($spreadsheet) use ($contactList) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'ID')
                ->setCellValue('B1', '名称')
                ->setCellValue('C1', '头像')
                ->setCellValue('D1', '识别码')
                ->setCellValue('E1', '性别')
                ->setCellValue('F1', '会员等级')
                ->setCellValue('G1', '咨询助理')
                ->setCellValue('H1', '首次添加时间')
                ->setCellValue('I1', '状态');

            foreach ($contactList as $key => $contact) {
                $excelKey = $key + 2;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['id'])
                    ->setCellValue('B' . $excelKey, $contact['name'])
                    ->setCellValue('C' . $excelKey, $contact['avatar'] ? : '')
                    ->setCellValue('D' . $excelKey, $contact['unionid'] ? : '')
                    ->setCellValue('E' . $excelKey, $contact['gender'])
                    ->setCellValue('F' . $excelKey, $contact['user_level_name'])
                    ->setCellValue('G' . $excelKey, $contact['user_name'])
                    ->setCellValue('H' . $excelKey, $contact['createtime'])
                    ->setCellValue('I' . $excelKey, $contact['status']);
            }
        });
        return true;
    }

    /**
     * 企微客户列表导出Excel
     *
     * @param array $requestData
     * @return bool
     * @throws Exception
     */
    public function exportAllContactList(array $requestData): bool
    {
        [$where, $extraWhere] = $this->commonWhere($requestData);

        // 客户列表
        $contactList = $this->handleChannelContactData($where, 0, 0, $extraWhere);

        $title = sprintf(
            '企微客户-客户列表-%s',
            Carbon::now()->getTimestamp()
        );

        downloadExcel($title, function ($spreadsheet) use ($contactList) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'ID')
                ->setCellValue('B1', '名称')
                ->setCellValue('C1', '头像')
                ->setCellValue('D1', '识别码')
                ->setCellValue('E1', '性别')
                ->setCellValue('F1', '会员等级')
                ->setCellValue('G1', '添加助理')
                ->setCellValue('H1', '添加形式')
                ->setCellValue('I1', '添加时间')
                ->setCellValue('J1', '来源渠道')
                ->setCellValue('K1', '添加渠道')
                ->setCellValue('L1', '是否消费')
                ->setCellValue('M1', '实际消费金额')
                ->setCellValue('N1', '状态');

            $excelKey = 1;

            foreach ($contactList as $contact) {
                $excelKey++;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['id'])
                    ->setCellValue('B' . $excelKey, $contact['name'])
                    ->setCellValue('C' . $excelKey, $contact['avatar'] ? : '')
                    ->setCellValue('D' . $excelKey, $contact['unionid'] ? : '')
                    ->setCellValue('E' . $excelKey, $contact['gender'])
                    ->setCellValue('F' . $excelKey, $contact['user_level_name'])
                    ->setCellValue('G' . $excelKey, $contact['user_name'])
                    ->setCellValue('H' . $excelKey, $contact['scene_name'])
                    ->setCellValue('I' . $excelKey, $contact['createtime'])
                    ->setCellValue('J' . $excelKey, $contact['channel_name'])
                    ->setCellValue('K' . $excelKey, $contact['source_channel_name'])
                    ->setCellValue('L' . $excelKey, $contact['is_consume'])
                    ->setCellValue('M' . $excelKey, $contact['actual_consume_amount'])
                    ->setCellValue('N' . $excelKey, $contact['status']);

                unset($contact);
            }
        });
        return true;
    }

    /**
     * 获取宝姐客户等级列表
     *
     * @return array
     */
    public function getUserLevelList(): array
    {
        return ContactDao::getUserLevelList();
    }

    /**
     * 路径客户搜索条件
     *
     * @param $requestData
     * @return array
     * @throws Exception
     */
    private function wayWhere($requestData): array
    {
        $wayWhere = [
            'add_way'      => ['<>', 100],
            'follow.state' => $requestData['way_id']
        ];

        [$where, $extraWhere] = $this->commonWhere($requestData);
        return array_merge($wayWhere, $where);
    }

    /**
     * 渠道客户搜索条件
     *
     * @param array $wayInfo
     * @param array $requestData
     * @param string $channelId
     * @return array
     * @throws Exception
     */
    private function channelWhere(array $wayInfo, array $requestData, string $channelId = ''): array
    {
        if ($channelId) {
            $channelWhere = [
                'add_way'      => ContactFollowUser::MOMENT_ADD_WAY,
                'follow.state' => $channelId
            ];
        } else {
            $wayIdArr = array_column($wayInfo, 'id');

            $channelWhere = [
                'follow.state' => ['in', $wayIdArr],
            ];
        }
        [$where, $extraWhere] = $this->commonWhere($requestData);
        return array_merge($channelWhere, $where);
    }

    /**
     * 通用搜索条件
     *
     * @param array $requestData 条件
     * @return array
     * @throws Exception
     */
    private function commonWhere(array $requestData): array
    {
        $where = $extraWhere = [];

        // 关键词
        if (
            isset($requestData['keyword'])
            && $requestData['keyword'] !== ''
        ) {
            $where['name|follow.id'] = ['like', '%' . $requestData['keyword'] . '%'];
        }

        // 性别
        if (
            isset($requestData['gender'])
            && $requestData['gender'] !== ''
        ) {
            $where['contact.gender'] = $requestData['gender'];
        }

        // 状态
        if (
            isset($requestData['status'])
            && $requestData['status'] !== ''
        ) {
            $where['follow.status'] = $requestData['status'];
        }

        // 是否消费
        if (
            isset($requestData['is_consume'])
            && $requestData['is_consume'] !== ''
        ) {
            $where['contact.is_consume'] = $requestData['is_consume'];
        }

        // 是否在群
        if (
            isset($requestData['is_in_group'])
            && $requestData['is_in_group'] !== ''
        ) {
            $where['contact.is_in_group'] = $requestData['is_in_group'];
        }

        // 添加时间开始
        if (
            isset($requestData['create_time_start'])
            && empty($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
        ) {
            $where['follow.create_date'] = ['>=', date('Y-m-d', strtotime($requestData['create_time_start']))];
        }

        // 添加时间结束
        if (
            isset($requestData['create_time_end'])
            && empty($requestData['create_time_start'])
            && !empty($requestData['create_time_endqwe'])
        ) {
            $where['follow.create_date'] = ['<=', date('Y-m-d', strtotime($requestData['create_time_end']))];
        }

        if (
            isset($requestData['create_time_start'])
            && isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['follow.create_date'] = [
                'between',
                [
                    date('Y-m-d', strtotime($requestData['create_time_start'])),
                    date('Y-m-d', strtotime($requestData['create_time_end']))
                ]
            ];
        }

        // 识别码
        if (
            isset($requestData['unionid'])
            && !empty($requestData['unionid'])
        ) {
            $where['contact.unionid'] = trim($requestData['unionid']);
        }

        // 会员等级
        if (
            isset($requestData['user_level_id'])
            && $requestData['user_level_id'] !== ''
        ) {
            $where['contact.user_level_id'] = $requestData['user_level_id'];
        }

        // 添加形式
        if (
            isset($requestData['scene'])
            && !empty($requestData['scene'])
        ) {
            switch ($requestData['scene']) {
                case 1: // 小程序
                case 2: // 活码
                    $where['way.scene'] = $requestData['scene'];
                    break;

                case 3:
                    $where['follow.state'] = 0;
                    $where['follow.add_way'] = 1; // 普通扫码
                    break;

                case 4:
                    $where['follow.add_way'] = ['in', [2, 5]]; // 手机号添加（搜索手机号、手机通讯录）
                    break;

                case 5:
                    $where['follow.state']   = 0;
                    $where['follow.add_way'] = 4; // 群聊
                    break;

                case 6:
                    $where['follow.add_way'] = 7; // 来自微信的添加好友申请
                    break;

                case 7:
                    $where['follow.add_way'] = 201; // 内部成员共享
                    break;

                case 8:
                    $where['follow.state']   = 0;
                    $where['follow.add_way'] = 202; // 管理员/负责人分配
                    break;

                case 9:
                    $where['follow.add_way'] = 10; // 视频号主页添加
                    break;

                case 10:
                    $where['follow.add_way'] = ContactFollowUser::MOMENT_ADD_WAY; // 朋友圈广告添加
                    break;

                case 11:
                    $where['follow.add_way'] = 0; // 未知来源
                    $where['follow.state'] = 0;
                    break;

                case 12:
                    $where['follow.add_way'] = 3; // 名片分享
                    break;

                case 13:
                    $where['follow.add_way'] = 6; // 微信联系人
                    break;

                case 14:
                    $where['follow.add_way'] = 8; // 安装第三方应用时自动添加的客服人员
                    break;

                case 15:
                    $where['follow.add_way'] = 9; // 搜索邮箱
                    break;

                case 16: // 个微朋友圈广告
                    // 宝姐珠宝开头的
                    $userInfo = UserDao::getAllList(['userid'], [
                        'name'           => ['like', "%宝姐珠宝%"],
                        'is_deleted'     => 0,
                        'is_follow_user' => 1
                    ]);
                    $where['follow.add_way'] = 0; // 未知来源
                    $where['follow.state'] = 0;
                    $where['follow.is_first_add'] = 1;
                    $where['follow.userid'] = ['in', array_column($userInfo, 'userid')];
                    $where['follow.createtime'] = ['>', strtotime('2022-03-14')];
                    break;
            }
        }

        // 添加渠道
        if (
            isset($requestData['channel'])
            && $requestData['channel'] !== ''
        ) {
            if ($requestData['channel'] == 0) {
                $where['follow.state'] = 0;
            } else {
                if (in_array($requestData['channel'], array_keys(ContactChannels::MOMENT_CHANNEL_MAP))) {
                    $where['follow.state'] = $requestData['channel'];
                    $where['follow.add_way'] = ContactFollowUser::MOMENT_ADD_WAY;
                } elseif (in_array($requestData['channel'], array_keys(ContactChannels::WECHAT_VIDEO_STATE_MAP))) {
                    $where['follow.state'] = ContactChannels::WECHAT_VIDEO_STATE_MAP[$requestData['channel']];
                } else {
                    $where['way.channel_id'] = $requestData['channel'];
                }
            }
        }

        // 添加助理
        if (
            isset($requestData['userid'])
            && !empty($requestData['userid'])
        ) {
            $where['follow.userid'] = ['in', $requestData['userid']];
        }

        // 来源渠道
        if (
            isset($requestData['source_channel'])
            && $requestData['source_channel'] !== ''
        ) {
            if ($requestData['source_channel'] == 0) {
                $where['follow.state'] = 0;
            } else {
                if (in_array($requestData['source_channel'], array_keys(ContactChannels::MOMENT_CHANNEL_MAP))) {
                    $where['follow.state'] = $requestData['source_channel'];
                    $where['follow.add_way'] = ContactFollowUser::MOMENT_ADD_WAY;
                } elseif (
                    in_array(
                        $requestData['source_channel'],
                        array_keys(ContactChannels::WECHAT_VIDEO_STATE_MAP)
                    )
                ) {
                    $where['follow.state'] = ContactChannels::WECHAT_VIDEO_STATE_MAP[$requestData['channel']];
                } else {
                    $where['way.channel_id'] = $requestData['source_channel'];
                }
            }
            $where['follow.is_first_add'] = 1;
        }

        // 是否消费
        if (
            isset($requestData['is_consume'])
            && $requestData['is_consume'] !== ''
        ) {
            $where['contact.is_consume'] = $requestData['is_consume'];
        }

        // 实际消费金额开始
        if (
            isset($requestData['actual_consume_amount_begin'])
            && empty($requestData['actual_consume_amount_end'])
            && !empty($requestData['actual_consume_amount_begin'])
        ) {
            $where['contact.actual_consume_amount'] = ['>=', $requestData['actual_consume_amount_begin']];
        }

        // 实际消费金额结束
        if (
            isset($requestData['actual_consume_amount_end'])
            && empty($requestData['actual_consume_amount_begin'])
            && !empty($requestData['actual_consume_amount_end'])
        ) {
            $where['contact.actual_consume_amount'] = ['<=', $requestData['actual_consume_amount_end']];
        }

        if (
            isset($requestData['actual_consume_amount_begin'])
            && isset($requestData['actual_consume_amount_end'])
            && !empty($requestData['actual_consume_amount_begin'])
            && !empty($requestData['actual_consume_amount_end'])
        ) {
            $where['contact.actual_consume_amount'] = [
                'between',
                [
                    $requestData['actual_consume_amount_begin'],
                    $requestData['actual_consume_amount_end']
                ]
            ];
        }

        // 企微标签
        if (
            isset($requestData['tag_id'])
            && $requestData['tag_id'] !== ''
        ) {
            $where['tag.tag_id'] = $requestData['tag_id'];
        }

        return [$where, $extraWhere];
    }

    /**
     * 客户列表数据后处理
     *
     * @param array $where
     * @param int   $page
     * @param int   $limit
     * @return mixed
     * @throws Exception
     */
    private function handleChannelContactData(
        array $where,
        int $page,
        int $limit,
        $extraWhere = []
    ) {
        $fields = [
            'follow.id',
            'follow.external_userid',
            'follow.userid', // 添加助理
            'follow.createtime',
            'follow.status',
            'follow.state',
            'follow.add_way',
            'follow.is_first_add',
            'follow.wechat_channels_source',
            'contact.unionid',
            'contact.user_level_id',
            'contact.name',
            'contact.avatar',
            'contact.gender',
            'contact.is_consume',
            'contact.actual_consume_amount',
            'contact.is_in_group',
            'way.scene',
            'way.channel_id'
        ];

        $contactList = ContactFollowUserDao::getContactList(
            $fields,
            $where,
            $page,
            $limit,
            'createtime DESC',
            $extraWhere
        );

        if ($contactList) {
            // 咨询助理名称 begin
            $userIdArr = array_column($contactList, 'userid');

            $userInfo = UserDao::getAllList(
                [
                    'userid',
                    'name'
                ],
                [
                    'userid' => ['in', $userIdArr]
                ]
            );

            $newUserInfo = [];

            foreach ($userInfo as $user) {
                $newUserInfo[$user['userid']] = $user['name'];
            }
            // end

            // 渠道 begin
            $channelId = array_filter(array_unique(array_column($contactList, 'channel_id')));

            $channelId =  array_merge($channelId, array_keys(ContactChannels::MOMENT_CHANNEL_MAP));

            $channelArr = ContactChannelsDao::getAllList(
                ['id', 'channel_name'],
                [
                    'id' => ['in', $channelId]
                ]
            );

            $newChannelArr = [];

            foreach ($channelArr as $channelInfo) {
                $newChannelArr[$channelInfo['id']] = $channelInfo['channel_name'];
            }
            // end

            // ways表的自增id和渠道名的映射 begin
            $waysArr = Db::name('contact_ways')
                ->alias('a')
                ->join(
                    'scrm_contact_channels b',
                    'a.channel_id = b.id',
                    'LEFT'
                )
                ->field([
                    'a.id',
                    'b.channel_name'
                ])
                ->where([
                    'b.is_deleted' => 0,
                    'a.is_deleted' => 0
                ])
                ->select();

            $newWaysArr = [];
            // state直接对应渠道channel名
            foreach ($waysArr as $way) {
                $newWaysArr[$way['id']] = $way['channel_name'];
            }
            // end

            $contactHttpDao = new ContactHttpDao();

            array_walk($contactList, function (&$val) use ($newUserInfo, $newChannelArr, $contactHttpDao, $newWaysArr) {
                if ($val['add_way'] == ContactFollowUser::MOMENT_ADD_WAY) {
                    $val['channel_id'] = $val['state'];
                }

                $val['user_center_id'] = 0;
                if ($val['unionid']) {
                    $userCenterData         = $contactHttpDao->getUserCenter($val['unionid']);
                    $val['user_level_name'] = $userCenterData['user_level_name'] ? : '新人';
                    $val['user_center_id'] = $userCenterData['userId'] ? : 0;
                } else {
                    $val['user_level_name'] = '新人';
                }

                switch ($val['gender']) {
                    case 0:
                        $val['gender'] = '未知';
                        break;

                    case 1:
                        $val['gender'] = '男';
                        break;

                    case 2:
                        $val['gender'] = '女';
                        break;
                }

                switch ($val['status']) {
                    case 0:
                        $val['status'] = '正常';
                        break;

                    case 1:
                        $val['status'] = '员工删除外部联系人';
                        break;

                    case 2:
                        $val['status'] = '外部联系人删除员工';
                        break;
                }

                // 是否消费
                $val['is_consume'] = $val['is_consume'] == 1 ? '是' : '否';
                // 是否在群
                $val['is_in_group'] = $val['is_in_group'] == 1 ? '是' : '否';

                // 添加形式
                if ($val['add_way'] != 100 && in_array($val['scene'], [1, 2])) {
                    $val['scene_name'] = ContactWays::SCENE_MAP[$val['scene']];
                } else {
                    switch ($val['add_way']) {
                        case 0:
                            if ($val['state'] == 0 && $val['is_first_add'] == 1) {
                                $val['scene_name'] = '个微朋友圈广告';
                            } else {
                                $val['scene_name'] = '未知来源';
                            }

                            break;

                        case 1:
                            $val['scene_name'] = '普通扫码';
                            break;

                        case 2:
                        case 5:
                            $val['scene_name'] = '手机号添加（搜索手机号、手机通讯录）';
                            break;

                        case 3:
                            $val['scene_name'] = '名片分享';
                            break;

                        case 4:
                            $val['scene_name'] = '群聊';
                            break;

                        case 6:
                            $val['scene_name'] = '微信联系人';
                            break;

                        case 7:
                            $val['scene_name'] = '来自微信的添加好友申请';
                            break;

                        case 8:
                            $val['scene_name'] = '安装第三方应用时自动添加的客服人员';
                            break;

                        case 9:
                            $val['scene_name'] = '搜索邮箱';
                            break;

                        case 10:
                            if ($val['wechat_channels_source'] == 2) {
                                $val['scene_name'] = '视频号直播间添加';
                            } else {
                                $val['scene_name'] = '视频号主页添加';
                            }

                            break;

                        case ContactFollowUser::MOMENT_ADD_WAY:
                            $val['scene_name'] = '企微朋友圈广告';
                            break;

                        case 201:
                            $val['scene_name'] = '内部成员共享';
                            break;

                        case 202:
                            $val['scene_name'] = '管理员/负责人分配';
                            break;
                    }
                }

                // 来源渠道
                $stateInfo = ContactFollowUserDao::getDetail([
                    'add_way',
                    'state',
                    'userid'
                ], [
                    'external_userid' => $val['external_userid'],
                    'is_first_add'    => 1
                ]);

                [
                    $val['user_name'],       // 咨询助理
                    $val['createtime'],      // 首次添加时间
                    //$val['user_level_name'], // 会员等级
                    $val['channel_name'],     // 添加渠道
                ] =
                [
                    $newUserInfo[$val['userid']] ?? '',
                    Carbon::createFromTimestamp($val['createtime'])->toDateTimeString(),
                    //ExternalContact::USER_LEVEL_MAP[$val['user_level_id']],
                    isset($val['channel_id']) ? ($newChannelArr[$val['channel_id']] ?? '未知') : '未知'
                ];
                // 来源渠道
                $val['source_channel_name'] = '未知';
                if (isset($stateInfo['add_way'])) {
                    if ($stateInfo['add_way'] == 100) {
                        $val['source_channel_name'] = isset($stateInfo['state'])
                            ? ($newChannelArr[$stateInfo['state']] ?? '未知')
                            : '未知';
                    } else {
                        $val['source_channel_name'] = isset($stateInfo['state'])
                            ? ($newWaysArr[$stateInfo['state']] ?? '未知')
                            : '未知';
                    }
                }


                unset(
                    $val['userid'],
                    $newUserInfo,
                    $val['user_level_id'],
                    $val['scene'],
                    $val['channel_id'],
                    $val['state'],
                    $val['add_way']
                );
            });
        }

        return $contactList;
    }

    /**
     * 获取单个员工统计数据
     *
     * @param array $userIdArr
     * @return array
     * @throws Exception
     */
    public function getStatisticsData(array $userIdArr): array
    {
        $redis = Cache::store()->handler();

        $redis->select(12);

        $userCount = count($userIdArr);

        if ($userCount > 12) {
            $userKey = 'feiyue';
        } elseif ($userCount == 1) {
            $userKey = $userIdArr[0];
        } else {
            $userKey = 'zhaowei';
        }

        [
            $sevenDaysAgoDate,  // 7天前时间戳
            $sixDaysAgoDate,    // 6天前时间戳
            // $lastWeekBeginTime, // 上周一时间戳
            $lastWeekEndTime,   // 本周一时间戳
            $lastWeekBeginDate,  // 上周一日期
            $weekBeginDate       // 本周一日期
        ] =
        [
            date('Y-m-d', strtotime('-7 days')),
            date('Y-m-d', strtotime('-6 days')),
            // strtotime('-2 sunday +1 day'),
            strtotime('this week Monday'),
            Carbon::now()->subWeek()->startOfWeek()->toDateString(),
            date('Y-m-d', strtotime('this week Monday'))
        ];

        $getRedisKeyName = function ($beginDate) use ($userKey) {
            return sprintf(
                '%s_%s_valid_contact_count',
                $beginDate,
                $userKey
            );
        };

        $nowKeyName = $getRedisKeyName($weekBeginDate);
        $previousKeyName = $getRedisKeyName($lastWeekBeginDate);

        // 累计客户数（去重）
        // 只要加过，不管有没有删除
        $allContactCount = Db::name('contact_follow_user')
            ->where(
                [
                    'userid'     => ['in', $userIdArr],
                    // 'status'     => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT],
                    // 'createtime' => ['<', $lastWeekEndTime]
                    'create_date' => ['<=', $weekBeginDate]
                ]
            )
            ->count('distinct external_userid');

        // 有效客户数据列表（去重）
        // 还互为好友关系的
        $validContactList = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->join(
                'external_contact contact',
                'follow.external_userid = contact.external_userid',
                'left'
            )
            ->field([
                'follow.id',
                'contact.gender',
                'contact.unionid'
            ])
            ->where([
                'userid'     => ['in', $userIdArr],
                'status'     => ContactFollowUser::NORMAL,
                // 'createtime' => ['<', $lastWeekEndTime]
                'create_date' => ['<=', $weekBeginDate]
            ])
            ->group('unionid')
            ->select();

        // 当前客户数
        $validContactCount = count($validContactList);
        // 保存
        $redis->set($nowKeyName, $validContactCount);

        $sevenRateClosure = function ($part, $all) {
            if ($part == 0) {
                return '-（7日前无新增客户）';
            }
            if ($all == 0) {
                return '0%';
            }
            return sprintf("%01.2f%%", ($part / $all) * 100);
        };

        // 上周添加人数
        // 首次添加该顾问
        // 并在统计时仍互为好友关系的人
        /*$lastWeekAgoCount = ContactFollowUserDao::getCount(
            [
                'userid'     => ['in', $userIdArr],
                'createtime' => ['between', [$lastWeekBeginTime, $lastWeekEndTime]],
                'del_time'   => null, // 首次添加
                'status'     => ContactFollowUser::NORMAL // 互为好友关系
            ]
        );*/
        // 较上周净增新人 = 本周的"当前客户数" - 上周的"当前客户数"
        $previousValidCount = $redis->get($previousKeyName);
        $lastWeekAgoCount = $validContactCount - $previousValidCount;

        // 当前客户的性别比例
        $female = $male = $unknown = 0;

        foreach ($validContactList as $contact) {
            switch ($contact['gender']) {
                case 0:
                    $unknown++;
                    break;

                case 1:
                    $male++;
                    break;

                case 2:
                    $female++;
                    break;
            }
        }

        // 7日留存率-begin
        // 7天前的数据
        $sevenDaysAgoList = ContactFollowUserDao::getAllList(
            [
                'id'
            ],
            [
                'userid'     => ['in', $userIdArr],
                //'createtime' => ['between', [$sevenDaysAgoTime, $sixDaysAgoTime]]
                'create_date' => ['between', [$sevenDaysAgoDate, $sixDaysAgoDate]]
            ]
        );

        $sevenDaysAgoCount = count($sevenDaysAgoList);

        $idArr = array_column($sevenDaysAgoList, 'id');

        // 截止到昨天晚上删除的有多少
        $yesterdayCount = ContactFollowUserDao::getCount(
            [
                'id'       => ['in', $idArr],
                'status'   => ['<>', ContactFollowUser::NORMAL],
                'del_time' => ['<', date('Y-m-d 00:00:00')]
            ]
        );

        // 剩下的就是7天后还是好友的
        $friendsCount = $sevenDaysAgoCount - $yesterdayCount;

        $sevenRetentionRate = $sevenRateClosure($friendsCount, $sevenDaysAgoCount);

        // 7日留存率-end

        unset($redis);

        return [
            'allContactCount'    => $allContactCount,
            'validContactCount'  => $validContactCount,
            'lastWeekAgoCount'   => $lastWeekAgoCount,
            'sevenRetentionRate' => $sevenRetentionRate,
            'genderRate'         => [
                'femaleRate'  => get_rate($female, $validContactCount),
                'maleRate'    => get_rate($male, $validContactCount),
                'unknownRate' => get_rate($unknown, $validContactCount)
            ]
        ];
    }

    /**
     * 获取公司的客户统计数据
     *
     * @return array
     * @throws Exception
     */
    public function getCompanyStatisticsData(): array
    {
        $redis = Cache::store()->handler();

        $redis->select(12);

        [
            $sevenDaysAgoTime,
            $sixDaysAgoTime,
            $sevenDaysAgoDate,
            $sixDaysAgoDate,
            // $lastWeekBeginTime, // 上周一
            $lastWeekEndTime,   // 本周一
            $lastWeekBeginDate,  // 上周一日期
            $weekBeginDate       // 本周一日期
        ] =
        [
            strtotime(date('Y-m-d', strtotime('-7 days'))),
            strtotime(date('Y-m-d', strtotime('-6 days'))),
            date('Y-m-d', strtotime('-7 days')),
            date('Y-m-d', strtotime('-6 days')),
            // strtotime('-2 sunday +1 day'),
            strtotime('this week Monday'),
            Carbon::now()->subWeek()->startOfWeek()->toDateString(),
            date('Y-m-d', strtotime('this week Monday'))
        ];

        $nowKeyName = sprintf('%s_company_valid_contact_count', $weekBeginDate);
        $previousKeyName = sprintf('%s_company_valid_contact_count', $lastWeekBeginDate);

        // 都是去重的

        // 去重累计客户
        $companyContactData = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.id',
                'contact.gender',
                'contact.user_level_id',
                'follow.external_userid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                // 'userid'     => ['<>', ''],
                // 'status'     => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT],
                // 'createtime' => ['<', $lastWeekEndTime]
                'create_date' => ['<=', $weekBeginDate]
            ])
            ->group('follow.external_userid')
            ->select();

        $companyContactCount = count($companyContactData);

        // 去重当前客户
        $companyValidContactData = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.id',
                'contact.gender',
                'contact.user_level_id',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                // 'userid'     => ['<>', ''],
                'status'     => ContactFollowUser::NORMAL,
                // 'createtime' => ['<', $lastWeekEndTime]
                'create_date' => ['<=', $weekBeginDate]
            ])
            ->group('follow.external_userid')
            ->select();
        /*
         */
        $companyValidContactCount = count($companyValidContactData);

        // 保存本周当前客户数
        $redis->set($nowKeyName, $companyValidContactCount);

        // 较上周净增
        // 去重
        // 仍互为好友关系的
        /*$companyLastWeekAgoCount = Db::name('contact_follow_user')
            ->where([
                'createtime' => ['between', [$lastWeekBeginTime, $lastWeekEndTime]],
                'status'     => ContactFollowUser::NORMAL,
                'del_time'   => null // 首次添加
            ])
            ->count('distinct external_userid');*/

        // 较上周净增新人 = 本周的"当前客户数" - 上周的"当前客户数"
        $previousValidCount = $redis->get($previousKeyName);
        $companyLastWeekAgoCount = $companyValidContactCount - $previousValidCount;

        // 7日留存率-begin
        // 7天前的数据
        $companySevenDaysAgoData = ContactFollowUserDao::getAllList(
            ['id'],
            [
                // 'createtime' => ['between', [$sevenDaysAgoTime, $sixDaysAgoTime]]
                'create_date' => ['between', [$sevenDaysAgoDate, $sixDaysAgoDate]]
            ]
        );

        $companySevenDaysAgoCount = count($companySevenDaysAgoData);

        $companyIdArr = array_column($companySevenDaysAgoData, 'id');

        // 截止到昨天晚上删除的有多少
        $yesterdayCount = ContactFollowUserDao::getCount(
            [
                'id'       => ['in', $companyIdArr],
                'status'   => ['<>', ContactFollowUser::NORMAL],
                'del_time' => ['<', date('Y-m-d 00:00:00')]
            ]
        );

        // 剩下的就是7天后还是好友的
        $friendsCount = $companySevenDaysAgoCount - $yesterdayCount;

        // 7日留存率-end

        // 当前客户性别占比-begin
        $female = $male = $unknown = 0;

        foreach ($companyValidContactData as $contact) {
            switch ($contact['gender']) {
                case 0:
                    $unknown++;
                    break;

                case 1:
                    $male++;
                    break;

                case 2:
                    $female++;
                    break;
            }
        }
        // 当前客户性别占比-end

        unset($redis);

        return [
            'allContactCount'    => $companyContactCount,
            'validContactCount'  => $companyValidContactCount,
            'sevenRetentionRate' => get_rate($friendsCount, $companySevenDaysAgoCount),
            'lastWeekAgoCount'   => $companyLastWeekAgoCount,
            'genderRate'         => [
                'femaleRate'  => get_rate($female, $companyValidContactCount),
                'maleRate'    => get_rate($male, $companyValidContactCount),
                'unknownRate' => get_rate($unknown, $companyValidContactCount)
            ]
        ];
    }

    /**
     * 导出客户
     *
     * @throws Exception
     */
    public function exportContact1(): bool
    {
        // 队列名
        $jobQueue = 'get_contact_info_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\GetContactInfoJob';

        $allContact = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'a.id',
                'name',
                'avatar',
                'unionid',
                'b.gender',
                'status'
            ])
            ->where([
                'a.userid' => 'yangyang123'
            ])
            ->select();

        foreach ($allContact as $contact) {
            switch ($contact['gender']) {
                case 0:
                    $contact['gender'] = '未知';
                    break;

                case 1:
                    $contact['gender'] = '男';
                    break;

                case 2:
                    $contact['gender'] = '女';
                    break;
            }

            switch ($contact['status']) {
                case 0:
                    $contact['status'] = '正常';
                    break;

                case 1:
                    $contact['status'] = '员工删除外部联系人';
                    break;

                case 2:
                    $contact['status'] = '外部联系人删除员工';
                    break;
            }

            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }

        return true;
    }

    /**
     * 导出客户到Excel
     *
     * @throws Exception
     */
    public function exportContact2()
    {
        $title = '宝姐家阳阳1-首单消费客户-' . Carbon::now();

        $redis = Cache::store()->handler();

        $contactIterator = null;

        $contactArr = [];

        while ($contacts = $redis->sScan('newContact', $contactIterator, '*', 10)) {
            foreach ($contacts as $contact) {
                $contactArr[] = json_decode($contact, true);
            }
        }

        downloadExcel($title, function ($spreadsheet) use ($contactArr) {
            $spreadsheet->setActiveSheetIndex(0)
                ->setCellValue('A1', 'ID')
                ->setCellValue('B1', '名称')
                ->setCellValue('C1', '头像')
                ->setCellValue('D1', 'unionID')
                ->setCellValue('E1', '性别')
                ->setCellValue('F1', '会员等级')
                ->setCellValue('G1', '分配助理')
                ->setCellValue('H1', '首单消费')
                ->setCellValue('I1', '消费时间')
                ->setCellValue('J1', '状态');

            foreach ($contactArr as $key => $contact) {
                $excelKey = $key + 2;

                $spreadsheet->setActiveSheetIndex(0)
                    ->setCellValue('A' . $excelKey, $contact['id'])
                    ->setCellValue('B' . $excelKey, $contact['name'])
                    ->setCellValue('C' . $excelKey, $contact['avatar'] ? : '')
                    ->setCellValue('D' . $excelKey, $contact['unionid'] ? : '')
                    ->setCellValue('E' . $excelKey, $contact['gender'])
                    ->setCellValue('F' . $excelKey, $contact['user_level_name'])
                    ->setCellValue('G' . $excelKey, $contact['assistant_name'] ?? '')
                    ->setCellValue('H' . $excelKey, $contact['first_order_consume_money'] ?? '暂无')
                    ->setCellValue('I' . $excelKey, $contact['first_order_consume_date'] ?? '')
                    ->setCellValue('J' . $excelKey, $contact['status']);
            }
        });
    }

    /**
     * 更新用户等级
     *
     * @throws Exception
     */
    public function updateUserLevel1(): bool
    {
        // 队列名
        $jobQueue = 'update_user_level_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\UpdateUserLevelJob';

        $allContact = Db::name('contact_follow_user')
            ->alias('a')
            ->join(
                'scrm_external_contact b',
                'a.external_userid = b.external_userid',
                'LEFT'
            )
            ->field([
                'b.id',
                'unionid'
            ])
            ->where([
                'a.userid'      => 'yangyang123',
                'user_level_id' => 0
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }

        return true;
    }

    /**
     * 更新客户等级
     *
     * @throws Exception
     */
    public function updateUserLevel2(): bool
    {
        $redis = Cache::store()->handler();

        $contactIterator = null;

        while ($contacts = $redis->sScan('contactLevel', $contactIterator, '*', 200)) {
            $contactArr = [];

            foreach ($contacts as $contact) {
                $contactArr[] = json_decode($contact, true);
            }

            ContactDao::updateBatchData(new ExternalContact(), $contactArr);
        }

        return true;
    }

    /**
     * 判断是否互为好友
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isFriend(string $unionId): array
    {
        return ['is_friend' => $this->isTwoWayFriend($unionId)];
    }

    /**
     * 判断是否和费月下的6个号互为好友
     * 以及进入过这6个号做群主的群
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isJoinGroup(string $unionId): array
    {
        $userServiceImpl = new UserServiceImpl();
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);
        // 是否互为好友
        $isFriendPipe = function ($unionId) use ($feiyueAccounts) {
            $isFriend = false;

            $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

            if (!empty($contactInfo)) {
                $followInfo = ContactFollowUserDao::getAllList(['id'], [
                    'external_userid' => $contactInfo['external_userid'],
                    'status'          => ContactFollowUser::NORMAL,
                    'userid'          => ['in', $feiyueAccounts]
                ]);

                if ($followInfo) {
                    $isFriend = true;
                }
            }

            // Log::info($unionId.'-好友关系是-'.$isFriend);

            if ($isFriend) { // 是好友就不需要接着判断了，短路出去
                throw new LogicException();
            }

            return $unionId;
        };

        // 是否在群里
        $isJoinGroupPipe = function ($unionId) use ($feiyueAccounts) {
            $isJoinGroup = false;

            // 费月名下号的所有群
            $contactGroupList = ContactGroupDao::getAllList(
                [
                    'chat_id'
                ],
                [
                    'owner'      => ['in', $feiyueAccounts],
                    'is_deleted' => ContactGroups::NOT_DELETED
                ]
            );

            $chatIdArr = array_column($contactGroupList, 'chat_id');

            if (
                ContactGroupMembersDao::getAllList(['id'], [
                'chat_id'    => ['in', $chatIdArr],
                'unionid'    => $unionId,
                'is_deleted' => ContactGroupMembers::NOT_DELETED
                ])
            ) {
                $isJoinGroup = true;
            }

            // Log::info($unionId.'-进群关系是-'.$isJoinGroup);

            return $isJoinGroup;
        };

        $isFriendAndJoinGroupPipe = (new Pipeline())
            ->pipe($isFriendPipe)
            ->pipe($isJoinGroupPipe);

        try {
            $isFriendAndJoinGroupRes = $isFriendAndJoinGroupPipe->process($unionId);
        } catch (LogicException $e) {
            $isFriendAndJoinGroupRes = true;
        }

        return ['is_join_group' => $isFriendAndJoinGroupRes];
    }

    /**
     * 用户是否在公司企业微信任意个人号中或社群中
     *
     * @param string $unionId
     * @return bool[]
     */
    public function isContactOrGroupMember(string $unionId): array
    {
        // 是否互为好友
        $isFriendPipe = function ($unionId) {
            $isFriend = false;

            $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

            if (!empty($contactInfo)) {
                $followInfo = ContactFollowUserDao::getAllList(['id'], [
                    'external_userid' => $contactInfo['external_userid'],
                    'status'          => ContactFollowUser::NORMAL
                ]);

                if ($followInfo) {
                    $isFriend = true;
                }
            }

            // Log::info($unionId.'-好友关系是-'.$isFriend);

            if ($isFriend) { // 是好友就不需要接着判断了，短路出去
                throw new LogicException();
            }

            return $unionId;
        };

        // 是否在群里
        $isJoinGroupPipe = function ($unionId) {
            $isJoinGroup = false;

            if (
                Db::name('contact_group_members')
                ->alias('member')
                ->field(['member.id'])
                ->join(
                    'scrm_contact_groups group',
                    'member.chat_id = group.chat_id',
                    'LEFT'
                )
                ->where([
                    'member.unionid'    => $unionId,
                    'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                    'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
                ])
                ->select()
            ) {
                $isJoinGroup = true;
            }

            // Log::info($unionId.'-进群关系是-'.$isJoinGroup);

            return $isJoinGroup;
        };

        $isContactOrGroupMemberPipe = (new Pipeline())
            ->pipe($isFriendPipe)
            ->pipe($isJoinGroupPipe);

        try {
            $isContactOrGroupMemberRes = $isContactOrGroupMemberPipe->process($unionId);
        } catch (LogicException $e) {
            $isContactOrGroupMemberRes = true;
        }

        return ['is_contact_or_group_member' => $isContactOrGroupMemberRes];
    }


    /**
     * 是否和媛媛互为好友
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isYuanyuanFriend(string $unionId): array
    {
        return [
            'is_yuanyuan_friend' => $this->isTwoWayFriend(
                $unionId,
                'yuanyuan',
                true
            )
        ];
    }

    /**
     * 统计最近未登陆三端应用的人数
     *
     * @return bool
     * @throws Exception
     */
    public function lastLoginCount(): bool
    {
        $followUserArr = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => ['in',[
                    'yangyang1',
                    'yangyang123',
                    'yuanyuan',
                    'yiyi',
                    'xixi',
                    'yunyingkefu',
                    'mengmeng',
                    'kefuxiaoxiao'
                ]],
                'status' => ContactFollowUser::NORMAL,
            ])
            ->group('follow.external_userid')
            ->select();

        // 队列名
        $jobQueue = 'count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\CountJob';

        foreach ($followUserArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }
        return true;
    }

    /**
     * 是否和赵蔚名下的账号是陌生关系
     * 从未添加过一个任意一个个人号，无单向/双向好友记录
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isZhaoweiStranger(string $unionId): array
    {
        $isZhaoweiStranger = true;

        $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

        if (!empty($contactInfo)) {
            $userServiceImpl = new UserServiceImpl();

            $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

            $followInfo = ContactFollowUserDao::getAllList(['id'], [
                'external_userid' => $contactInfo['external_userid'],
                // 'status'          => ContactFollowUser::NORMAL,
                // 'status'          => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT],
                'userid'          => ['in', $zhaoweiAccounts]
            ]);

            if ($followInfo) {
                $isZhaoweiStranger = false;
            }
        }

        return ['is_zhaowei_stranger' => $isZhaoweiStranger];
    }

    /**
     * 是否是费月名下的宝姐家粉丝颜值福利群的成员
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isFeiyueGroupMember(string $unionId): array
    {
        $memberInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.name'       => ['like', '%宝姐家粉丝颜值福利%'],
                'b.is_deleted' => ContactGroups::NOT_DELETED,
                'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'a.unionid'    => $unionId
            ])
            ->find();


        return ['is_feiyue_group_member' => (bool)$memberInfo];
    }

    /**
     * 是否和赵蔚名下的号是双向好友关系
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isZhaoweiFriend(string $unionId): array
    {
        return [
            'is_zhaowei_friend' => $this->isTwoWayFriend(
                $unionId,
                'zhaowei'
            )
        ];
    }

    /**
     * 是否和费月名下的号是双向好友关系
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isFeiyueFriend(string $unionId): array
    {
        return [
            'is_feiyue_friend' => $this->isTwoWayFriend(
                $unionId,
                'feiyue'
            )
        ];
    }

    /**
     * 是否互为好友
     *
     * @param string $unionId 用户unionId
     * @param string $userId 账号持有人
     * @param bool $isSingle true-单账号 false-多账号
     * @return bool
     * @throws Exception
     */
    private function isTwoWayFriend(
        string $unionId,
        string $userId = '',
        bool $isSingle = false
    ): bool {
        $isTwoWayFriend = false;

        $contactInfo = ContactDao::getDetail(
            ['external_userid'],
            [
                'unionid' => $unionId
            ]
        );

        if (!empty($contactInfo)) {
            $followWhere = [
                'external_userid' => $contactInfo['external_userid'],
                'status'          => ContactFollowUser::NORMAL
            ];

            // 指定账号持有人
            if ($userId) {
                if (!$isSingle) { // 多个账号
                    $userServiceImpl = new UserServiceImpl();

                    $userArr = $userServiceImpl->getSpecificUserAccount($userId, false);
                } else { // 单个账号
                    $userArr = $userId;
                }

                $followWhere['userid'] = ['in', $userArr];
            }

            $followInfo = ContactFollowUserDao::getAllList(
                ['id'],
                $followWhere
            );

            if ($followInfo) {
                $isTwoWayFriend = true;
            }
        }

        return $isTwoWayFriend;
    }

    /**
     * 获取来源渠道
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getSourceChannel(string $unionId): array
    {
        $contactInfo = Db::name('contact_follow_user')
                        ->alias('a')
                        ->join(
                            'external_contact b',
                            'a.external_userid = b.external_userid',
                            'LEFT'
                        )
                        ->field([
                            'state',
                            'add_way',
                            'userid',
                            'createtime'
                        ])
                        ->where([
                            'unionid'      => $unionId,
                            'is_first_add' => 1
                        ])
                        ->find();

        if (!$contactInfo) {
            $channelId = -1;
            $channelName = '非企微客户';
        } else {
            if ($contactInfo['state'] != 0) {
                // 朋友圈添加来的
                if ($contactInfo['add_way'] == ContactFollowUser::MOMENT_ADD_WAY) {
                    $momentChannelId = search_two_dimensional_array(
                        $contactInfo['userid'],
                        ContactChannels::MOMENT_CHANNEL_MAP
                    );

                    $channelNameArr =  ContactChannelsDao::getDetail(['channel_name'], [
                        'id' => $momentChannelId
                    ]);

                    $channelId   = $momentChannelId ?? 0;
                    $channelName = $channelNameArr['channel_name'] ?? '';
                } else {
                    $channelInfo = Db::name('contact_ways')
                        ->alias('way')
                        ->join('contact_channels channel', 'way.channel_id = channel.id', 'LEFT')
                        ->field([
                            'channel.channel_name',
                            'channel.id'
                        ])
                        ->where([
                            'way.id' => $contactInfo['state']
                        ])
                        ->find();

                    $channelId   = $channelInfo['id'];
                    $channelName = $channelInfo['channel_name'];
                }
            } else {
                $channelId   = 0;
                $channelName = '未知渠道';
            }
        }

        return [
            'channel_id'   => $channelId,
            'channel_name' => $channelName
        ];
    }

    /**
     * 是否在赵蔚的群中
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isInZhaoweiGroup(string $unionId): array
    {
        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $memberInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where([
                'b.owner'      => ['in', $zhaoweiAccounts],
                'b.is_deleted' => ContactGroups::NOT_DELETED,
                'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'a.unionid'    => $unionId
            ])
            ->find();

        return ['is_in_zhaowei_group' => (bool)$memberInfo];
    }

    /**
     * 是否有过加人记录，是否加群
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getRelationshipRecord(string $unionId): array
    {
        $isNowFriend = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.update_time',
                'follow.create_time',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => $unionId,
                'status'  => ContactFollowUser::NORMAL
            ])
            ->order('follow.update_time desc')
            ->order('follow.create_time desc')
            ->find();

        if (!$isNowFriend) { // 不是好友
            $followUserInfo = Db::name('contact_follow_user')
                ->alias('follow')
                ->field([
                    'follow.createtime',
                    'follow.update_time',
                    'follow.create_time'
                ])
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where([
                    'unionid' => $unionId
                ])
                ->order('follow.update_time desc')
                ->order('follow.createtime desc')
                ->find();

            $lastAddFriendTime = $followUserInfo['create_time'] ? strtotime($followUserInfo['create_time']) : 0;
        } else { // 是好友
            $lastAddFriendTime = $isNowFriend['update_time']
                ? strtotime($isNowFriend['update_time'])
                : ($isNowFriend['create_time'] ? strtotime($isNowFriend['create_time']) : 0);
        }

        $memberInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.join_time'
            ])
            ->where([
                'a.unionid' => $unionId
            ])
            ->order('join_time desc')
            ->find();

        $isInGroup = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.join_time'
            ])
            ->where([
                'b.is_deleted' => ContactGroups::NOT_DELETED,
                'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'a.unionid'    => $unionId
            ])
            ->find();

        return [
            'is_now_friend'         => (bool)$isNowFriend,
            'last_add_friend_time'  => $lastAddFriendTime,
            'is_in_group'           => (bool)$isInGroup,
            'last_add_group_time'   => $memberInfo['join_time'] ?? 0
        ];
    }

    /**
     * 删除加好友记录
     *
     * @param string $unionId
     * @return bool
     * @throws Exception
     */
    public function deleteFriend(string $unionId): bool
    {
        $contactInfo = ContactDao::getDetail(['external_userid'], ['unionid' => $unionId]);

        ContactDao::hardDelete(['unionid' => $unionId]);
        if ($contactInfo) {
            ContactFollowUserDao::hardDelete(['external_userid' => $contactInfo['external_userid']]);
        }
        return true;
    }

    /**
     * 删除进群历史
     *
     * @param string $unionId
     * @return bool
     * @throws Exception
     */
    public function deleteGroup(string $unionId): bool
    {
        ContactGroupMembersDao::hardDelete(['unionid' => $unionId]);
        return true;
    }

    /**
     * 获取客户所在群名
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getContactGroup(string $unionId): array
    {
        $groupData = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field(['group.name'])
            ->join(
                'scrm_contact_groups group',
                'member.chat_id = group.chat_id',
                'LEFT'
            )
            ->where([
                'member.unionid'    => $unionId,
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
            ])
            ->select();

        return ['group_name' => array_column($groupData, 'name')];
    }

    /**
     * 是否从来没有加过企微（客服或群）
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isPureStranger(string $unionId): array
    {
        $isPureStranger = true;

        if (
            $joinTimeArr = ContactGroupMembersDao::getDetail(
                [
                    'id',
                    'join_time'
                ],
                [
                    'unionid' => $unionId
                ],
                'join_time'
            )
        ) {
            $isPureStranger   = false;
            $lastAddGroupTime = $joinTimeArr['join_time'];
        }

        if (
            $addFriendTime = Db::name('contact_follow_user')
                ->alias('follow')
                ->field([
                    'follow.createtime',
                ])
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where([
                    'unionid' => $unionId,
                ])
                ->order('follow.createtime')
                ->find()
        ) {
            $isPureStranger       = false;
            $last_add_friend_time = $addFriendTime['createtime'];
        }

        return [
            'is_pure_stranger'     => $isPureStranger,
            'last_add_friend_time' => $last_add_friend_time ?? 0,
            'last_add_group_time'  => $lastAddGroupTime ?? 0
        ];
    }

    /**
     * 保存推粉数据
     *
     * @param array $pushFansArr
     * @throws Exception
     */
    public function savePushFans(array $pushFansArr)
    {
        $unionIdArr = array_column($pushFansArr, 'unionid');

        $existData = PushFansDao::getAllList(['unionid'], [
            'unionid' => ['in', $unionIdArr]
        ]);
        $existUnionIdArr = array_unique(array_column($existData, 'unionid'));

        $savePushFansData = [];

        foreach ($pushFansArr as $value) {
            if (!in_array($value['unionid'], $existUnionIdArr)) {
                $savePushFansData[] = $value;
            }
        }

        PushFansDao::addBatchData($savePushFansData);
    }

    /**
     * 添加好友的时间
     *
     * @param array $request
     * @return int[]
     * @throws Exception
     */
    public function addFriendTime(array $request): array
    {
        $wayId = $request['way_id'];
        $unionId = $request['unionid'];

        $wayUserArr = WayUserMapDao::getAllList(
            [
                'user_id'
            ],
            [
                'way_id' => $wayId
            ]
        );

        $userIdArr = array_column($wayUserArr, 'user_id');

        $contactInfo = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.createtime',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => $unionId,
                'userid'  => ['in', $userIdArr]
            ])
            ->order('follow.createtime')
            ->find();

        return [
            'add_friend_time' => $contactInfo['createtime'] ?? 0
        ];
    }

    /**
     * 获取企微二维码
     *
     * @param array $requestData
     * @return string[]
     * @throws Exception
     */
    public function getFriendQRCode(array $requestData): array
    {
        $qrcodeData = ContactWaysDao::getDetail(['qr_code'], ['id' => $requestData['way_id']]);
        $qrcodeUrl = $qrcodeData['qr_code'] ?? '';

        // 添加过企微
        if (ContactDao::getDetail(['id'], ['unionid' => $requestData['unionid']])) {
            $unifyUserData = UnifyServiceDao::getAllList(['userid']);
            $unifyUserIdArr = array_column($unifyUserData, 'userid');

            $followUserData = Db::name('contact_follow_user')
                ->alias('follow')
                ->field([
                    'follow.userid'
                ])
                ->join(
                    'scrm_external_contact contact',
                    'follow.external_userid = contact.external_userid',
                    'LEFT'
                )
                ->where([
                    'userid'  => ['in', $unifyUserIdArr],
                    'status'  => ContactFollowUser::NORMAL,
                    'unionid' => $requestData['unionid']
                ])
                ->order('follow.createtime')
                ->find();
            if ($followUserData) {
                $userQrCodeData = UserDao::getDetail(['qr_code'], ['userid' => $followUserData['userid']]);
                $qrcodeUrl = $userQrCodeData['qr_code'];
            }
        }

        return [
            'url' => $qrcodeUrl
        ];
    }

    /**
     * 获取好友名称
     *
     * @param array $unionIdArr
     * @return array
     * @throws Exception
     */
    public function getFriendsName(array $unionIdArr): array
    {
        $followUserData = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status'  => ContactFollowUser::NORMAL,
                'unionid' => ['in', $unionIdArr]
            ])
            ->select();

        $returnFollowUserData = [];

        if ($followUserData) {
            $userIdArr = array_unique(array_column($followUserData, 'userid'));
            $userInfo = UserDao::getAllList(
                [
                    'userid',
                    'name'
                ],
                ['userid' => ['in', $userIdArr]]
            );
            $userMap = array_column($userInfo, 'name', 'userid');

            $newFollowUserData = [];
            foreach ($followUserData as $follow) {
                $newFollowUserData[$follow['unionid']][] = $userMap[$follow['userid']];
            }

            foreach ($newFollowUserData as $unionId => $newFollow) {
                $returnFollowUserData[$unionId] = implode(',', $newFollow);
            }
        }

        return $returnFollowUserData;
    }

    /**
     * 是否是招募官好友
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function isRecruitingOfficerFriend(string $unionId): array
    {
        $isRecruitingOfficerFriend = false;

        $redis = Cache::store()->handler();

        if ($redis->get('asharer:' . $unionId)) {
            $isRecruitingOfficerFriend = true;
        } else {
            if (
                Db::name('contact_follow_user')
                    ->alias('follow')
                    ->field([
                        'follow.id',
                    ])
                    ->join(
                        'scrm_external_contact contact',
                        'follow.external_userid = contact.external_userid',
                        'LEFT'
                    )
                    ->where([
                        'status'  => ContactFollowUser::NORMAL,
                        'unionid' => $unionId,
                        'userid'  => ContactFollowUser::RECRUITING_OFFICER
                    ])
                    ->find()
            ) {
                $isRecruitingOfficerFriend = true;
            } else {
                $contactWayArr = ContactWaysDao::getDetail(['qr_code'], [
                    'id' => ContactWays::RECRUITING_OFFICER_ID
                ]);
            }
        }

        return [
            'is_recruiting_officer_friend' => $isRecruitingOfficerFriend,
            'qr_code'                      => $contactWayArr['qr_code'] ?? ''
        ];
    }

    /**
     * 根据数组获取加人和加群记录
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getArrayRecord(array $requestData): array
    {
        $followInfo = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->join(
                'external_contact contact',
                'follow.external_userid = contact.external_userid',
                'left'
            )
            ->field([
                'contact.unionid'
            ])
            ->where([
                'unionid' => ['in', $requestData],
                'status'  => ContactFollowUser::NORMAL
            ])
            ->select();

        $followUnionIdArr = array_column($followInfo, 'unionid');

        $groupInfo = (array)Db::name('contact_group_members')
            ->alias('member')
            ->field([
                'unionid'
            ])
            ->join(
                'scrm_contact_groups group',
                'member.chat_id = group.chat_id',
                'LEFT'
            )
            ->where([
                'member.unionid'    => ['in', $requestData],
                'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                'group.is_deleted'  => ContactGroups::NOT_DELETED // 群没解散
            ])
            ->select();

        $groupUnionIdArr = array_column($groupInfo, 'unionid');

        $returnData = [];
        foreach ($requestData as $value) {
            $returnData[$value] = [
                'in_group'  => in_array($value, $groupUnionIdArr) ? 1 : 0,
                'is_friend' => in_array($value, $followUnionIdArr) ? 1 : 0
            ];
        }

        return $returnData;
    }
}
