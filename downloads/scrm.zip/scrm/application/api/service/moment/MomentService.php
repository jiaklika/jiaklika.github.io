<?php

declare(strict_types=1);

namespace app\api\service\moment;

/**
 * Interface MomentService
 * @package app\api\service\moment
 */
interface MomentService
{
}
