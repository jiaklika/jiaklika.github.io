<?php

declare(strict_types=1);

namespace app\api\service\moment\impl;

use app\api\common\Response;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\moment\MomentHttpDao;
use app\api\dao\mysql\message\GroupMsgTagMapDao;
use app\api\dao\mysql\moment\MomentImageMapDao;
use app\api\dao\mysql\moment\MomentListDao;
use app\api\dao\mysql\moment\MomentSenderMapDao;
use app\api\dao\mysql\moment\MomentTagMapDao;
use app\api\dao\mysql\moment\MomentTaskDao;
use app\api\service\groupMsg\impl\GroupMsgServiceImpl;
use app\api\service\moment\MomentService;
use app\api\util\FileManager;
use app\common\model\moment\MomentTask;
use Exception;
use think\Db;
use think\File;

/**
 * Class MomentServiceImpl
 * @package app\api\service\moment\impl
 */
class MomentServiceImpl implements MomentService
{
    /**
     * @var MomentHttpDao
     */
    private static $momentHttpDao;

    /**
     * MomentServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$momentHttpDao)) {
            self::$momentHttpDao = new MomentHttpDao();
        }
    }

    /**
     * 获取朋友圈群发任务列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getMomentTaskList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $fields = [
            'id',
            'task_name',
            'content_text',
            'status',
            'send_time',
            'creator'
        ];

        $where = [
            'is_deleted' => 0
        ];

        if (
            isset($requestData['task_name'])
            && $requestData['task_name'] !== ''
        ) {
            $where['task_name'] = ['like', '%' . $requestData['task_name'] . '%'];
        }

        if (
            isset($requestData['status'])
            && $requestData['status'] !== ''
        ) {
            $where['status'] = $requestData['status'];
        }

        if (
            isset($requestData['send_time_start'])
            && !isset($requestData['send_time_end'])
            && !empty($requestData['send_time_start'])
        ) {
            $where['send_time'] = ['>', $requestData['send_time_start']];
        }

        if (
            isset($requestData['send_time_end'])
            && !isset($requestData['send_time_start'])
            && !empty($requestData['send_time_end'])
        ) {
            $where['send_time'] = ['<', $requestData['send_time_end']];
        }

        if (
            isset($requestData['send_time_start'])
            && isset($requestData['send_time_end'])
            && !empty($requestData['send_time_start'])
            && !empty($requestData['send_time_end'])
        ) {
            $where['send_time'] = ['between', [$requestData['send_time_start'], $requestData['send_time_end']]];
        }

        if (
            isset($requestData['creator'])
            && $requestData['creator'] !== ''
        ) {
            $where['creator'] = ['like', '%' . $requestData['creator'] . '%'];
        }

        $momentTaskList = MomentTaskDao::getPaginationList(
            $fields,
            $where,
            (int)$page,
            (int)$limit,
            'id DESC'
        );

        $momentTaskCount = MomentTaskDao::getCount($where);

        if ($momentTaskList) {
        }
        return [
            'list'  => $momentTaskList,
            'count' => $momentTaskCount
        ];
    }

    /**
     * 创建发表任务
     *
     * @param array $momentData
     * @return bool
     * @throws Exception
     */
    public function addMomentTask(array $momentData): bool
    {
        [
            $content,
            $attachmentType,
            $attachments,
            $userList,
            $tagList
        ] = [
            $momentData['content_text'] ?? '',
            $momentData['attachment_type'],
            $momentData['attachments'] ?? [],
            $momentData['visible_range']['sender_list']['user_list'] ?? [],
            $momentData['visible_range']['external_contact_list']['tag_list'] ?? []
        ];

        $insertTaskData = [
            'task_name'       => $momentData['task_name'],
            'creator'         => $momentData['creator'],
            'receiver_range'  => $momentData['receiver_range'],
            'content_text'    => $content,
            'attachment_type' => $momentData['attachment_type'],
            'attachments'     => json_encode($attachments, JSON_UNESCAPED_UNICODE),
            'is_plan'         => $momentData['is_plan']
        ];

        if (!$momentData['is_plan']) {
            // 去除media_url
            switch ($attachmentType) {
                case 1:
                    foreach ($attachments as &$singleAttach) {
                        unset($singleAttach['image']['media_url']);
                        unset($singleAttach['image']['created_at']);
                    }
                    break;

                case 2:
                    unset($attachments[0]['link']['media_url']);
                    unset($attachments[0]['link']['created_at']);
                    break;

                case 3:
                    unset($attachments[0]['video']['media_url']);
                    unset($attachments[0]['video']['created_at']);
                    break;
            }

            try {
                $jobId = self::$momentHttpDao->addMomentTask(
                    $content,
                    $attachments,
                    $userList,
                    $tagList
                );
                $insertTaskData['job_id'] = $jobId;
            } catch (Exception $e) {
                send_msg_to_wecom($e->getMessage());
                return false;
            }
        }

        Db::startTrans();

        $taskAddRes = MomentTaskDao::addData($insertTaskData, true);
        $senderMapAddRes = $tagMapAddRes = true;
        if ($userList) {
            $insertSenderMapData = [];
            foreach ($userList as $userId) {
                $insertSenderMapData[] = [
                    'moment_task_id' => $taskAddRes,
                    'sender_user_id' => $userId
                ];
            }
            $senderMapAddRes = MomentSenderMapDao::addBatchData($insertSenderMapData);
        }

        if ($tagList) {
            $insertTagMapData = [];
            foreach ($tagList as $tagId) {
                $insertTagMapData[] = [
                    'moment_task_id' => $taskAddRes,
                    'tag_id'         => $tagId
                ];
            }
            $tagMapAddRes = MomentTagMapDao::addBatchData($insertTagMapData);
        }

        if ($taskAddRes && $senderMapAddRes && $tagMapAddRes) {
            Db::commit();
        } else {
            Db::rollback();
            return false;
        }

        return true;
    }

    /**
     * 初始化获取所有朋友圈
     *
     * @return bool
     * @throws Exception
     */
    public function initAllMoment(): bool
    {
        $returnRes = self::$momentHttpDao->getMomentList(1606752000, 1609344000);

        $mediaHttpDao = new MediaHttpDao();

        $momentInsertBatchData = $imageInsertBatchData = [];

        $imageAddRes = true;

        if ($momentList = $returnRes['moment_list']) {
            foreach ($momentList as $key => $moment) {
                $momentInsertBatchData[$key] = [
                    'moment_id'    => $moment['moment_id'],
                    'creator'      => $moment['creator'],
                    'create_time'  => $moment['create_time'],
                    'create_type'  => $moment['create_type'],
                    'visible_type' => $moment['visible_type'],
                    'text_content' => $moment['text']['content'],
                ];

                if (isset($moment['image'])) {
                    // todo 下载图片
                    foreach ($moment['image'] as $singleImage) {
                        $mediaHttpDao->downloadMedia($moment['video']['media_id'], 'mp4');
                    }
                }

                if (isset($moment['video'])) {
                    try {
                        $mediaHttpDao->downloadMedia($moment['video']['media_id'], 'mp4');
                    } catch (Exception $e) {
                    }
                }

                if (isset($moment['link'])) {
                    $momentInsertBatchData[$key]['link_title'] = $moment['link']['title'];
                    $momentInsertBatchData[$key]['link_url'] = $moment['link']['url'];
                }

                if (isset($moment['location'])) {
                    $momentInsertBatchData[$key]['location_latitude'] = $moment['location']['latitude'];
                    $momentInsertBatchData[$key]['location_longitude'] = $moment['location']['longitude'];
                    $momentInsertBatchData[$key]['location_name'] = $moment['location']['name'];
                }
            }
        }

        Db::startTrans();

        $momentAddRes = MomentListDao::addBatchData($momentInsertBatchData);

        if ($imageInsertBatchData) {
            $imageAddRes = MomentImageMapDao::addBatchData($imageInsertBatchData);
        }

        if ($momentAddRes && $imageAddRes) {
            Db::commit();
            return true;
        } else {
            Db::rollback();
            return false;
        }
    }

    /**
     * 获取查看时的标签列表
     *
     * @param int $momentTaskId
     * @return array
     * @throws Exception
     */
    public function getChooseTagList(int $momentTaskId): array
    {
        $groupMsgServiceImpl = new GroupMsgServiceImpl();
        $tagList = $groupMsgServiceImpl->getTagList();

        if (
            !$tagMapList = MomentTagMapDao::getAllList(
                ['tag_id'],
                [
                    'moment_task_id' => $momentTaskId,
                ]
            )
        ) {
            return [];
        }

        $tadIdArr = array_column($tagMapList, 'tag_id');

        foreach ($tagList as &$val) {
            $count = 0;
            foreach ($val['tags'] as &$tagVal) {
                if (in_array($tagVal['tag_id'], $tadIdArr)) {
                    $tagVal['is_selected'] = 1;
                    $count += 1;
                } else {
                    $tagVal['is_selected'] = 0;
                }
            }
            $val['tag_selected_count'] = $count;
        }


        return $tagList;
    }

    /**
     * @param File $file
     * @param string $fileType
     * @return array
     * @throws Exception
     */
    public function uploadAttachment(File $file, string $fileType): array
    {
        $fileManager = new FileManager();

        [$status, $info] = $fileManager->uploadAttachment($file, $fileType);

        if ($status) {
            return [
                'media_url'  => $info['media_url'],
                'media_id'   => $info['media_id'],
                'created_at' => $info['created_at']
            ];
        }

        return [$info];
    }

    /**
     * @param int $momentTaskId
     * @return array
     * @throws Exception
     */
    public function getMomentTaskDetail(int $momentTaskId): array
    {
        $momentInfo = MomentTaskDao::getDetail([
            'task_name',
            'receiver_range',
            'content_text',
            'attachments',
            'is_plan',
            'send_time'
        ], [
            'id'         => $momentTaskId,
            'is_deleted' => MomentTask::NOT_DELETED
        ]);

        if (!$momentInfo) {
            return [];
        }
        $momentInfo['attachments'] = json_decode($momentInfo['attachments'], true);

        return $momentInfo;
    }

    /**
     * 删除任务
     *
     * @param int $momentTaskId
     * @return array
     * @throws Exception
     */
    public function delete(int $momentTaskId): array
    {
        $momentTaskDetail = MomentTaskDao::getDetail(
            ['status'],
            [
                'id'         => $momentTaskId,
                'is_deleted' => MomentTask::NOT_DELETED
            ]
        );

        if (!$momentTaskDetail) {
            return [false, '此任务不存在或已删除！'];
        }

        if ($momentTaskDetail['status'] != MomentTask::STATUS_NOT_BEGIN) {
            return [false, '只能删除"未开始"的任务！'];
        }

        if (MomentTaskDao::deleteById($momentTaskId) == false) {
            return [false, '删除失败！'];
        }

        return [true, '删除成功！'];
    }
}
