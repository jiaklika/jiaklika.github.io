<?php

namespace app\api\service\group\impl;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\group\GroupService;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use Carbon\Carbon;
use Exception;
use think\Db;

/**
 * Class GroupServiceImpl
 * @package app\api\service\group\impl
 */
class GroupServiceImpl implements GroupService
{
    /**
     * 获取群列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getGroupList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $fields = [
            'id',
            'chat_id',
            'name',
            'owner',
            'group_create_time'
        ];

        $where = [
            'is_deleted' => ContactGroups::NOT_DELETED
        ];

        // 群名
        if (
            isset($requestData['keyword'])
            && $requestData['keyword'] !== ''
        ) {
            $where['name|id'] = ['like', '%' . $requestData['keyword'] . '%'];
        }

        // 只有业务类型
        if (
            isset($requestData['business_type'])
            && $requestData['business_type'] != 0
            && (!isset($requestData['owner'])
            || empty($requestData['owner']))
        ) {
            $userServiceImpl =  new UserServiceImpl();
            if ($requestData['business_type'] == 1) {
                $accounts = $userServiceImpl->getSpecificUserAccount('feiyue');
            } else {
                $accounts = $userServiceImpl->getSpecificUserAccount('zhaowei');
            }

            $where['owner'] = ['in', $accounts];
        }

        // 只有群主
        if (
            isset($requestData['owner'])
            && $requestData['owner'] !== ''
            && (!isset($requestData['business_type'])
            || empty($requestData['business_type']))
        ) {
            $where['owner'] = ['in', explode(',', $requestData['owner'])];
        }

        // 群主和业务类型
        if (
            isset($requestData['owner'])
            && $requestData['owner'] !== ''
            && isset($requestData['business_type'])
            && $requestData['business_type'] != 0
        ) {
            $userServiceImpl =  new UserServiceImpl();
            if ($requestData['business_type'] == 1) {
                $accounts = $userServiceImpl->getSpecificUserAccount('feiyue');
            } else {
                $accounts = $userServiceImpl->getSpecificUserAccount('zhaowei');
            }

            $finalOwner = array_filter(explode(',', $requestData['owner']), function ($val) use ($accounts) {
                if (in_array($val, $accounts)) {
                    return $val;
                }
            });

            $where['owner'] = ['in', $finalOwner];
        }

        // 创建时间
        if (
            isset($requestData['create_time_start'])
            && !isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
        ) {
            $where['group_create_time'] = ['>', strtotime($requestData['create_time_start'])];
        }

        if (
            isset($requestData['create_time_end'])
            && !isset($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['group_create_time'] = ['<', strtotime($requestData['create_time_end'])];
        }

        if (
            isset($requestData['create_time_start'])
            && isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['group_create_time'] = [
                'between',
                [strtotime($requestData['create_time_start']), strtotime($requestData['create_time_end'])]
            ];
        }

        $groupList = ContactGroupDao::getPaginationList(
            $fields,
            $where,
            (int)$page,
            (int)$limit,
            'group_create_time DESC'
        );

        $channelCount = ContactGroupDao::getCount($where);

        if ($groupList) {
            $ownerUserIdArr = array_column($groupList, 'owner');

            $ownerUserInfoArr = UserDao::getAllList(['userid', 'name'], [
                'userid' => ['in', $ownerUserIdArr]
            ]);

            $ownerUserIdNameMapArr = [];

            foreach ($ownerUserInfoArr as $owner) {
                $ownerUserIdNameMapArr[$owner['userid']] = $owner['name'];
            }

            array_walk($groupList, function (&$val) use ($ownerUserIdNameMapArr) {
                // 群人数
                $val['member_total'] = ContactGroupMembersDao::getCount([
                    'chat_id'    => $val['chat_id'],
                    'is_deleted' => ContactGroupMembers::NOT_DELETED
                ]);
                $val['owner'] = $ownerUserIdNameMapArr[$val['owner']] ?? '未知';

                $val['group_create_time'] = Carbon::createFromTimestamp($val['group_create_time'])->toDateTimeString();
                unset($val['chat_id']);
            });
        }

        return [
            'list'  => $groupList,
            'count' => $channelCount
        ];
    }

    /**
     * 获取群成员详情
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getGroupDetail(array $requestData): array
    {
        $groupDetail = ContactGroupDao::getDetail(
            [
                'id',
                'chat_id',
                'owner',
                'group_create_time',
                'name',
                'notice'
            ],
            [
                'id'         => $requestData['group_id'],
                'is_deleted' => ContactGroups::NOT_DELETED
            ]
        );

        if (empty($groupDetail)) {
            return [];
        }

        $where = [
            'chat_id'      => $groupDetail['chat_id'],
            'a.is_deleted' => ContactGroupMembers::NOT_DELETED
        ];

        if (
            isset($requestData['keyword'])
            && !empty($requestData['keyword'])
        ) {
            $keyword = urldecode(trim($requestData['keyword']));
            $where['a.original_name|a.unionid'] = ['like', "%{$keyword}%"];
        }

        // 是否消费
        if (
            isset($requestData['is_consume'])
            && $requestData['is_consume'] !== ''
        ) {
            if (in_array($requestData['is_consume'], [0,1])) {
                $where['is_consume'] = $requestData['is_consume'];
            }
            if ($requestData['is_consume'] == 2) {
                $where['b.unionid'] = null;
            }
        }

        // 进群时间
        if (
            isset($requestData['join_time_start'])
            && !isset($requestData['join_time_end'])
            && !empty($requestData['join_time_start'])
        ) {
            $where['join_time'] = ['>', strtotime($requestData['join_time_start'])];
        }

        if (
            isset($requestData['join_time_end'])
            && !isset($requestData['join_time_start'])
            && !empty($requestData['join_time_end'])
        ) {
            $where['join_time'] = ['<', strtotime($requestData['join_time_end'])];
        }

        if (
            isset($requestData['join_time_start'])
            && isset($requestData['join_time_end'])
            && !empty($requestData['join_time_start'])
            && !empty($requestData['join_time_end'])
        ) {
            $where['join_time'] = [
                'between',
                [strtotime($requestData['join_time_start']), strtotime($requestData['join_time_end'])]
            ];
        }

        // 会员等级
        if (
            isset($requestData['user_level'])
            && $requestData['user_level'] !== ''
        ) {
            $where['b.user_level_id'] = $requestData['user_level'];
        }

        // 入群方式
        if (
            isset($requestData['join_scene'])
            && $requestData['join_scene'] !== ''
        ) {
            $where['a.join_scene'] = $requestData['join_scene'];
        }

        // 邀请人
        if (
            isset($requestData['invitor'])
            && $requestData['invitor'] !== ''
        ) {
            if ($requestData['invitor'] == 'member') {
                $where['a.invitor'] = '';
            } else {
                $where['a.invitor'] = $requestData['invitor'];
            }
        }

        $groupDetail['member_list'] = (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_external_contact b', 'a.unionid = b.unionid', 'LEFT')
            ->field([
                'a.userid',
                'a.unionid',
                'b.name',
                'b.avatar',
                // 'a.inviter',
                'a.join_time',
                'a.join_scene',
                'a.original_name',
                'a.invitor',
                'b.user_level_id',
                'b.is_consume',
                'a.join_scene'
            ])
            ->where($where)
            ->page($requestData['page'], $requestData['limit'])
            ->order('a.join_time desc')
            ->select();

        $memberCount = Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_external_contact b', 'a.unionid = b.unionid', 'LEFT')
            ->where($where)
            ->count();

        unset($groupDetail['id'], $groupDetail['chat_id']);

        $userInfo = UserDao::getDetail(['name'], ['userid' => $groupDetail['owner']]);

        $groupDetail['owner'] = $userInfo['name'] ?? '未知';

        $groupDetail['group_create_time'] = Carbon::createFromTimestamp($groupDetail['group_create_time'])
            ->toDateTimeString();

        $invitorArr = array_column($groupDetail['member_list'], 'invitor');

        $userNameArr = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $invitorArr]]);

        $newUserNameArr = [];

        foreach ($userNameArr as $user) {
            $newUserNameArr[$user['userid']] = $user['name'];
        }

        $contactHttpDao = new ContactHttpDao();

        array_walk($groupDetail['member_list'], function (&$val) use ($newUserNameArr, $contactHttpDao) {
            $val['join_time'] = Carbon::createFromTimestamp($val['join_time'])
                ->toDateTimeString();

            $invitorName = '群成员';

            if ($val['invitor']) {
                $invitorName = $newUserNameArr[$val['invitor']];
            }

            switch ($val['join_scene']) {
                case 0:
                    $val['join_scene'] = "未知";
                    break;

                case 1:
                    $val['join_scene'] = "由 {$invitorName} 邀请入群（直接邀请入群）";
                    break;

                case 2:
                    $val['join_scene'] = "由 {$invitorName} 邀请入群（通过邀请链接入群）";
                    break;

                case 3:
                    $val['join_scene'] = "通过扫描 {$invitorName} 二维码入群";
                    break;
            }

            switch ($val['user_level_id']) {
                case 0:
                default:
                    $val['user_level_name'] = '新人';
                    break;

                case 1:
                    $val['user_level_name'] = '宝迷';
                    break;

                case 2:
                    $val['user_level_name'] = '忠实宝迷';
                    break;

                case 3:
                    $val['user_level_name'] = '铁杆宝迷';
                    break;

                case 4:
                    $val['user_level_name'] = '名媛';
                    break;

                case 5:
                    $val['user_level_name'] = '风尚名媛';
                    break;

                case 6:
                    $val['user_level_name'] = '至尊名媛';
                    break;
            }

            $val['is_consume'] = $val['is_consume'] == 1 ? '是' : '否';

            if (!$val['original_name']) {
                $val['original_name'] = $val['name'];
            }

            $userCenterData = $contactHttpDao->getUserCenter($val['unionid']);
            $val['user_center_id'] = $userCenterData['userId'] ?? 0;

            unset($val['invitor'], $val['user_level_id']);
        });

        $groupDetail['member_info']['count']       = $memberCount;
        $groupDetail['member_info']['member_list'] = $groupDetail['member_list'];
        unset($groupDetail['member_list']);

        return $groupDetail;
    }

    /**
     * 获取群数量
     *
     * @param string $keyword
     * @return array
     * @throws Exception
     */
    public function getGroupCount(string $keyword): array
    {
        $groupCount = ContactGroupDao::getCount([
            'name'       => ['like', "%{$keyword}%"],
            'is_deleted' => ContactGroups::NOT_DELETED
        ]);

        return [
            'keyword'     => $keyword,
            'group_count' => $groupCount
        ];
    }

    /**
     * 是否在关键词的群里
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function isInKeyWordGroup(array $requestData): array
    {
        [
            $unionId,
            $keyword
        ] =
        [
            $requestData['union_id'],
            $requestData['keyword']
        ];

        $keywordArr = explode(',', $keyword);

        $memberInfo = Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.id'
            ])
            ->where(function ($query) use ($unionId) {
                $query->where([
                    'unionid'      => $unionId,
                    'a.is_deleted' => ContactGroupMembers::NOT_DELETED,
                    'b.is_deleted' => ContactGroups::NOT_DELETED
                ]);
            })->where(function ($query) use ($keywordArr) {
                foreach ($keywordArr as $keyword) {
                    $query->whereOr('name', 'like', "%{$keyword}%");
                }
            })
            ->find();

        return [
            'is_in_keyword_group' => (bool)$memberInfo
        ];
    }

    /**
     * 获取所有群成员列表
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getAllGroupMemberList(array $requestData): array
    {
        [
            $limit,
            $page
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $where = [
            'a.type' => ContactGroupMembers::EXTERNAL_USER
        ];

        // 关键词
        if (
            isset($requestData['keyword'])
            && $requestData['keyword'] !== ''
        ) {
            $where['b.name|a.id'] = ['like', '%' . $requestData['keyword'] . '%'];
        }

        // unionId
        if (
            isset($requestData['unionid'])
            && $requestData['unionid'] !== ''
        ) {
            $where['a.unionid'] = $requestData['unionid'];
        }

        // 性别
        if (
            isset($requestData['gender'])
            && $requestData['gender'] !== ''
        ) {
            $where['gender'] = $requestData['gender'];
        }

        // 会员等级
        if (
            isset($requestData['user_level_id'])
            && $requestData['user_level_id'] !== ''
        ) {
            $where['user_level_id'] = $requestData['user_level_id'];
        }

        // 所进群
        if (
            isset($requestData['chat_id'])
            && $requestData['chat_id'] !== ''
        ) {
            $where['a.chat_id'] = $requestData['chat_id'];
        }

        // 是否在号
        if (
            isset($requestData['is_friend'])
            && $requestData['is_friend'] !== ''
        ) {
            $where['b.is_friend'] = $requestData['is_friend'];
        }

        // 进群方式
        if (
            isset($requestData['join_scene'])
            && $requestData['join_scene'] !== ''
        ) {
            $where['join_scene'] = $requestData['join_scene'];
        }

        // 是否消费
        if (
            isset($requestData['is_consume'])
            && $requestData['is_consume'] !== ''
        ) {
            if (in_array($requestData['is_consume'], [0,1])) {
                $where['is_consume'] = $requestData['is_consume'];
            }
            if ($requestData['is_consume'] == 2) {
                $where['b.unionid'] = null;
            }
        }

        // 是否在群
        if (
            isset($requestData['is_in_group'])
            && $requestData['is_in_group'] !== ''
        ) {
            $where['is_in_group'] = $requestData['is_in_group'];
        }

        // 添加时间
        if (
            isset($requestData['create_time_start'])
            && !isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
        ) {
            $where['join_time'] = ['>', strtotime($requestData['create_time_start'])];
        }

        if (
            isset($requestData['create_time_end'])
            && !isset($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['join_time'] = ['<', strtotime($requestData['create_time_end'])];
        }

        if (
            isset($requestData['create_time_start'])
            && isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['join_time'] = [
                'between',
                [strtotime($requestData['create_time_start']), strtotime($requestData['create_time_end'])]
            ];
        }

        $model = Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_external_contact b', 'a.unionid = b.unionid', 'left')
            ->join('scrm_contact_groups c', 'a.chat_id = c.chat_id', 'left')
            ->field([
                'a.id',
                'a.invitor',
                'a.unionid',
                'a.userid',
                'b.avatar',
                'a.original_name',
                'c.name',
                'b.gender',
                'b.user_level_id',
                'b.name as user_name',
                'a.join_scene',
                'a.join_time',
                'b.is_consume',
                'a.is_deleted',
                'b.is_friend'
            ])
            ->where($where);

        $allGroupMembersList = (array)$model
            ->page($page, $limit)
            ->order('a.id desc')
            ->select();

        $channelCount = Db::name('contact_group_members')
            ->alias('a')
            ->join('scrm_external_contact b', 'a.unionid = b.unionid', 'left')
            ->join('scrm_contact_groups c', 'a.chat_id = c.chat_id', 'left')
            ->field([
                'a.id',
                'a.invitor',
                'a.unionid',
                'a.userid',
                'b.avatar',
                'a.original_name',
                'c.name',
                'b.gender',
                'b.user_level_id',
                'b.name as user_name',
                'a.join_scene',
                'a.join_time',
                'b.is_consume',
                'a.is_deleted',
                'b.is_friend'
            ])
            ->where($where)
            ->count();

        if ($allGroupMembersList) {
            $invitorArr = array_column($allGroupMembersList, 'invitor');

            $userNameArr = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $invitorArr]]);

            $newUserNameArr = [];

            foreach ($userNameArr as $user) {
                $newUserNameArr[$user['userid']] = $user['name'];
            }

            array_walk($allGroupMembersList, function (&$val) use ($newUserNameArr) {
                switch ($val['gender']) {
                    case 0:
                    default:
                        $val['gender'] = '未知';
                        break;

                    case 1:
                        $val['gender'] = '男';
                        break;

                    case 2:
                        $val['gender'] = '女';
                        break;
                }

                $val['join_time'] = Carbon::createFromTimestamp($val['join_time'])
                    ->toDateTimeString();

                $invitorName = '群成员';

                if ($val['invitor']) {
                    $invitorName = $newUserNameArr[$val['invitor']] ?? '';
                }

                switch ($val['join_scene']) {
                    case 0:
                        $val['join_scene'] = "未知";
                        break;

                    case 1:
                        $val['join_scene'] = "由 {$invitorName} 邀请入群（直接邀请入群）";
                        break;

                    case 2:
                        $val['join_scene'] = "由 {$invitorName} 邀请入群（通过邀请链接入群）";
                        break;

                    case 3:
                        $val['join_scene'] = "通过扫描 {$invitorName} 二维码入群";
                        break;
                }

                switch ($val['user_level_id']) {
                    case 0:
                    default:
                        $val['user_level_name'] = '新人';
                        break;

                    case 1:
                        $val['user_level_name'] = '宝迷';
                        break;

                    case 2:
                        $val['user_level_name'] = '忠实宝迷';
                        break;

                    case 3:
                        $val['user_level_name'] = '铁杆宝迷';
                        break;

                    case 4:
                        $val['user_level_name'] = '名媛';
                        break;

                    case 5:
                        $val['user_level_name'] = '风尚名媛';
                        break;

                    case 6:
                        $val['user_level_name'] = '至尊名媛';
                        break;
                }

                $val['is_consume'] = $val['is_consume'] == 1 ? '是' : '否';

                $val['is_in_group'] = $val['is_deleted'] == 0 ? '是' : '否';

                $val['is_friend'] = $val['is_friend'] == 1 ? '是' : '否';

                if (!$val['original_name']) {
                    $val['original_name'] = $val['user_name'];
                }

                unset(
                    $val['invitor'],
                    $val['userid'],
                    $val['user_name'],
                    $val['user_level_id'],
                    $val['is_deleted']
                );
            });
        }

        return [
            'list'  => $allGroupMembersList,
            'count' => $channelCount
        ];
    }


    /**
     * 获取所有群列表
     *
     * @param string|null $keyword
     * @return array
     * @throws Exception
     */
    public function getAllGroupList(?string $keyword): array
    {
        $where = [
            'is_deleted' => 0,
        ];
        if ($keyword) {
            $where['name'] = ['like', "%{$keyword}%"];
        }
        return ContactGroupDao::getAllList([
            'chat_id',
            'name'
        ], $where);
    }

    /**
     * 获取群的所有邀请者
     *
     * @param int $groupId
     * @return array
     * @throws Exception
     */
    public function getInvitorList(int $groupId): array
    {
        $groupData = ContactGroupDao::getDetail(['chat_id'], [
            'id'         => $groupId,
            'is_deleted' => 0
        ]);

        if ($groupData) {
            if (
                $memberInfo = ContactGroupMembersDao::getAllList(
                    [
                        'invitor'
                    ],
                    [
                        'chat_id' => $groupData['chat_id']
                    ]
                )
            ) {
                $userIdArr = array_values(array_unique(array_column($memberInfo, 'invitor')));

                $userData = UserDao::getAllList(
                    [
                        'userid',
                        'name'
                    ],
                    [
                        'userid' => ['in', $userIdArr]
                    ]
                );

                $userData[] = [
                    'userid' => 'member',
                    'name'   => '群成员'
                ];

                return $userData;
            }
        }

        return [];
    }
}
