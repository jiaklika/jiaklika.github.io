<?php

declare(strict_types=1);

namespace app\api\service\group;

/**
 * Interface GroupService
 * @package app\api\service\group
 */
interface GroupService
{
    /**
     * 获取群列表
     *
     * @param array $requestData
     * @return array
     */
    public function getGroupList(array $requestData): array;

    /**
     * 获取群成员详情
     *
     * @param array $requestData
     * @return array
     */
    public function getGroupDetail(array $requestData): array;

    /**
     * 获取群数量
     *
     * @param string $keyword
     * @return array
     */
    public function getGroupCount(string $keyword): array;

    /**
     * 是否在关键词的群里
     *
     * @param array $requestData
     * @return array
     */
    public function isInKeyWordGroup(array $requestData): array;
}
