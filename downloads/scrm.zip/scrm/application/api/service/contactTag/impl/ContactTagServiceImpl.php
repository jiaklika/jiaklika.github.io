<?php

declare(strict_types=1);

namespace app\api\service\contactTag\impl;

use app\api\common\Response;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\http\message\GroupMsgHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\log\MqLogsDao;
use app\api\dao\mysql\message\GroupMsgReceiveMapDao;
use app\api\dao\mysql\user\UserDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\service\contactTag\ContactTagService;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactChannels;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactTags;
use app\common\model\MqLogs;
use app\common\model\User;
use Exception;
use Opis\Closure\SerializableClosure;
use think\Cache;
use think\Db;
use think\Log;
use think\Queue;

use function GuzzleHttp\Psr7\str;

/**
 * Class ContactTagServiceImpl
 * @package app\api\service\contactTag\impl
 */
class ContactTagServiceImpl implements ContactTagService
{
    /**
     * @var ContactTagHttpDao
     */
    private static $contactTagHttpDao;

    /**
     * @var int
     */
    public const GROUP = 1;

    /**
     * @var int
     */
    public const TAG = 2;

    /**
     * ContactTagServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$contactTagHttpDao)) {
            self::$contactTagHttpDao = new ContactTagHttpDao();
        }
    }

    /**
     * 初始化获取企业标签库并写入数据表
     *
     * @return bool
     * @throws Exception
     */
    public function initCorpTag(): bool
    {
        $groupArr = self::$contactTagHttpDao->getContactTag();

        $insertData = [];

        foreach ($groupArr as $group) {
            foreach ($group['tag'] as $key => $tag) {
                $insertData[] = [
                    'group_id'          => $group['group_id'],
                    'group_name'        => $group['group_name'],
                    'group_create_time' => $group['create_time'],
                    'group_order'       => $group['order'],
                    'tag_id'            => $tag['id'],
                    'tag_name'          => $tag['name'],
                    'tag_create_time'   => $tag['create_time'],
                    'tag_order'         => $tag['order'],
                ];
            }
        }

        return ContactTagsDao::addBatchData($insertData);
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getCorpTagList(): array
    {
        return [];
    }

    /**
     * 添加企业客户标签
     *
     * @param array $tagIdArr 标签数组
     * @param string $groupId 标签组id
     * @return array
     * @throws Exception
     */
    public function addCorpTag(array $tagIdArr, string $groupId): array
    {
        $tagArr = self::$contactTagHttpDao->addContactTag($tagIdArr, $groupId);

        $tagBatchData = array_map(function ($tagInfo) use ($tagArr) {
            return [
                'group_id'          => $tagArr['group_id'],
                'group_name'        => $tagArr['group_name'],
                'group_create_time' => $tagArr['create_time'],
                'group_order'       => $tagArr['order'] ?? 0,
                'tag_id'            => $tagInfo['id'],
                'tag_name'          => $tagInfo['name'],
                'tag_create_time'   => $tagInfo['create_time'],
                'tag_order'         => $tagInfo['order'] ?? 0
            ];
        }, $tagArr['tag']);

        if (!ContactTagsDao::addBatchData($tagBatchData)) {
            send_msg_to_wecom(sprintf('添加标签%s入表失败！', json_encode($tagIdArr)));
        }

        return $tagArr;
    }

    /**
     * 编辑企业客户标签
     *
     * @param int $tagType 更新类型 1-标签组 2-单个标签
     * @param string $tagId 标签/标签组的ID
     * @param string $tagName 标签/标签组的名称
     * @param int $tagOrder 标签/标签组的次序值
     * @return bool
     * @throws Exception
     */
    public function editContactTag(int $tagType, string $tagId, string $tagName, int $tagOrder = 0): bool
    {
        $editRes = self::$contactTagHttpDao->editContactTag($tagId, $tagName, $tagOrder);

        if ($editRes) {
            if ($tagType == self::GROUP) {
                $updateData = [
                    'group_name'  => $tagName,
                    'group_order' => $tagOrder
                ];
                $updateCondition = [
                    'group_id' => $tagId,
                ];
            } else {
                $updateData = [
                    'tag_name'  => $tagName,
                    'tag_order' => $tagOrder
                ];

                $updateCondition = [
                    'tag_id' => $tagId
                ];
            }

            if (
                ContactTagsDao::updateData(
                    $updateData,
                    $updateCondition
                ) !== false
            ) {
                return true;
            }
        }

        return false;
    }

    /**
     * 删除企业客户标签
     *
     * @param array $tagIdArr
     * @param array $groupIdArr
     * @return bool
     * @throws Exception
     */
    public function delContactTag(array $tagIdArr, array $groupIdArr): bool
    {
        return self::$contactTagHttpDao->delContactTag($tagIdArr, $groupIdArr);
    }

    /**
     * 获取标签组
     *
     * @param string|null $keyword
     * @return array
     * @throws Exception
     */
    public function getTagGroup(?string $keyword): array
    {
        return ContactTagsDao::getAllList([
            'distinct(group_id)',
            'group_name'
        ], [
            'group_name'       => ['like', "%{$keyword}%"],
            'group_is_deleted' => ContactTags::GROUP_NOT_DELETED
        ]);
    }

    /**
     * 获取标签组下的标签
     *
     * @param array $requestData
     * @return array
     * @throws Exception
     */
    public function getTag(array $requestData): array
    {
        $where = [
            'group_id'       => $requestData['group_id'],
            'tag_is_deleted' => ContactTags::TAG_NOT_DELETED
        ];

        if (isset($requestData['keyword'])) {
            $where['tag_name'] = ['like', "%{$requestData['keyword']}%"];
        }

        return ContactTagsDao::getAllList(
            [
                'tag_id',
                'tag_name'
            ],
            $where
        );
    }

    /**
     * 给客户打标签
     *
     * @return bool
     * @throws Exception
     */
    public function markTag(): bool
    {
        // 队列名
        $jobQueue = 'mark_contact_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\MarkTagJob';

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                /*'userid' => ['in', [
                    'chebin',
                ]],*/
                'status' => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]  // 当前客户
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 给客户打标签
     *
     * @return bool
     * @throws Exception
     */
    public function markTag123(): bool
    {
        // 队列名
        $jobQueue = 'mark_tag123_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\OtherMarkTag123Job';

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid',
                // 'follow.state'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                // 'status' => ContactFollowUser::NORMAL  // 当前客户
                'status' => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT],
                'userid' => 'taotao'
            ])
            ->limit(1, 2000)
            ->order('follow.id desc')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 给客户打新的累计消费标签
     *
     * @return bool
     * @throws Exception
     */
    public function markNewConsumeTag(): bool
    {
        // 队列名
        $jobQueue = 'mark_new_consume_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\InitContactTagJob';

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid',
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                // 'status' => ContactFollowUser::NORMAL  // 当前客户
                'status' => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 实时更改颜值标签
     *
     * @param string $unionId 客户微信唯一识别码
     * @param int    $levelId 1-青铜 2-白银 3-黄金
     * @return array
     * @throws Exception
     */
    public function changeYanzhiTag(string $unionId, int $levelId): array
    {
        $yanzhiGroup = [
            1 => 'et5b2CBwAAtqme5MTAO85dLN-4e4LRkQ', // 颜值青铜
            2 => 'et5b2CBwAA6EDeMLkk3fMqmPV0I95pgg', // 颜值白银
            3 => 'et5b2CBwAAJLNzLCPZ_IgMJDSL09HUjA'  // 颜值黄金
        ];

        $removeGroup = array_values($yanzhiGroup);

        $contactInfo = ContactDao::getDetail(
            [
                'external_userid'
            ],
            [
                'unionid' => $unionId
            ]
        );

        if (!$contactInfo) {
            return [false, '此客户不存在'];
        }

        $externalUserId = $contactInfo['external_userid'];

        // 找出此客户所有的follower
        $userArr = ContactFollowUserDao::getAllList(
            [
                'userid'
            ],
            [
                'external_userid' => $externalUserId,
                'status'          => ContactFollowUser::NORMAL
            ]
        );

        if (!$userArr) {
            return [false, '此客户不存在客服'];
        }

        $userIdArr = array_column($userArr, 'userid');

        $insertBatchData = [];

        $removeTagRes = $addTagRes = false;

        // 更改
        foreach ($userArr as $user) {
            try {
                // 先去掉旧有的同类标签
                $removeTagRes = self::$contactTagHttpDao->markTag(
                    $user['userid'],
                    $externalUserId,
                    [],
                    $removeGroup
                );

                $addTagRes = self::$contactTagHttpDao->markTag(
                    $user['userid'],
                    $externalUserId,
                    [$yanzhiGroup[$levelId]]
                );

                $insertBatchData[] = [
                    'tag_id'          => $yanzhiGroup[$levelId],
                    'external_userid' => $externalUserId,
                    'userid'          => $user['userid']
                ];
            } catch (Exception $e) {
                send_msg_to_wecom($e->getMessage());
                continue;
            }
        }

        if ($removeTagRes && $addTagRes) {
            // Db::startTrans();

            $deleteTagMapRes = ContactTagMapDao::hardDelete([
                'tag_id'          => ['in', $removeGroup],
                'external_userid' => $externalUserId,
                'userid'          => ['in', $userIdArr]
            ]);

            $addTagMapRes = !$insertBatchData || ContactTagMapDao::addBatchData($insertBatchData);

            if ($deleteTagMapRes !== false && $addTagMapRes) {
                // Db::commit();

                return [true, 'success'];
            } else {
                // Db::rollback();
                send_msg_to_wecom('实时更改颜值标签操作map表失败！' . $externalUserId);
            }
        }

        return [false, 'error'];
    }

    /**
     * 阳阳1、阳阳、费月的号
     * 忠实到名媛
     * 周日宣传
     */
    public function markPropagandaTag(): bool
    {
        /*$redis = Cache::store()->handler();

        if (!$redis->sMembers('notInGroupChatId'))
        {
            $getChatIdArrFunc = function (string $groupName){
                $groupIdArr = ContactGroupDao::getAllList(['chat_id'], [
                    'name' => ['like', "%$groupName%"]
                ]);

                return array_column($groupIdArr, 'chat_id');
            };

            $groupIdArr = array_merge(
                $getChatIdArrFunc('优享'),
                $getChatIdArrFunc('新粉福利'),
                $getChatIdArrFunc('知识视频分享')
            );

            pipeline($redis, function ($redis) use ($groupIdArr){
                foreach ($groupIdArr as $chatId)
                {
                    $redis->sAdd('notInGroupChatId', $chatId);
                }
            });
        }*/


        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\markPropagandaTagJob';

        /*$allUser = array_merge(
            [
                'yangyang1',
                'yangyang123',
            ],
            User::KO_USER_MAP
        );*/

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                /*'userid' => [
                    'in',
                    $allUser
                ],*/
                'status' => ContactFollowUser::DEL_FOLLOW_USER,  // 当前客户
                // 'createtime' => ['>', 1613788620]
                // 'status' => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]
            ])
            //->group('follow.external_userid') // 去重
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 初始化来源渠道标签
     *
     * @throws Exception
     * @return array
     */
    public function initChannelTag(): array
    {
        if (
            !$contactChannelList = ContactChannelsDao::getAllList(
                [
                    'id',
                    'channel_name'
                ],
                [
                    'is_deleted' => ContactChannels::NOT_DELETE
                ]
            )
        ) {
            return [false, '不存在渠道！'];
        }

        $updateBatchData = $insertBatchData = [];

        foreach ($contactChannelList as $channelInfo) {
            $addTagArr = [
                'name'  => $channelInfo['channel_name'],
                'order' => $channelInfo['id']
            ];

            if (
                $tagArr = self::$contactTagHttpDao->addContactTag(
                    $addTagArr,
                    ContactTags::GROUP_ID_MAP[ContactTags::SOURCE_CHANNEL]
                )
            ) {
                $updateBatchData[] = [
                    'id'     => $channelInfo['id'],
                    'tag_id' => $tagArr['tag'][0]['id']
                ];

                $insertBatchData[] = [
                    'group_id'          => $tagArr['group_id'],
                    'group_name'        => $tagArr['group_name'],
                    'group_create_time' => $tagArr['create_time'],
                    'group_order'       => $tagArr['order'] ?? 0,
                    'tag_id'            => $tagArr['tag'][0]['id'],
                    'tag_name'          => $tagArr['tag'][0]['name'],
                    'tag_create_time'   => $tagArr['tag'][0]['create_time'],
                    'tag_order'         => $tagArr['tag'][0]['order']
                ];
            }
        }

        Db::startTrans();

        // 更新渠道表
        if (
            ContactChannelsDao::updateBatchData(new ContactChannels(), $updateBatchData) !== false
            && ContactTagsDao::addBatchData($insertBatchData)
        ) {
            Db::commit();
            return [true, 'success'];
        }

        Db::rollback();
        return [false, '操作表失败！'];
    }

    /**
     * 初始化累计消费标签
     * @throws Exception
     */
    public function initConsumeTag(): array
    {
        $contactHttpDao = new ContactHttpDao();

        $consumeInfo = $contactHttpDao->getConsumeSegment('13357721075');

        $consumeSegmentList = array_column($consumeInfo['contract_tag_list'], 'utype');

        foreach ($consumeSegmentList as $key => $segmentName) {
            $addTagArr = [
                'name'  => $segmentName,
                'order' => $key
            ];

            if (
                $tagArr = self::$contactTagHttpDao->addContactTag(
                    $addTagArr,
                    ContactTags::GROUP_ID_MAP[ContactTags::NEW_CONTRACT_AMOUNT]
                )
            ) {
                $insertBatchData[] = [
                    'group_id'          => $tagArr['group_id'],
                    'group_name'        => $tagArr['group_name'],
                    'group_create_time' => $tagArr['create_time'],
                    'group_order'       => $tagArr['order'] ?? 0,
                    'tag_id'            => $tagArr['tag'][0]['id'],
                    'tag_name'          => $tagArr['tag'][0]['name'],
                    'tag_create_time'   => $tagArr['tag'][0]['create_time'],
                    'tag_order'         => $tagArr['tag'][0]['order']
                ];
            }
        }

        if (ContactTagsDao::addBatchData($insertBatchData)) {
            return [true, 'success'];
        }

        return [false, '操作表失败！'];
    }

    /**
     * 修复累计消费标签
     */
    public function fixConsumeTag()
    {
        $contactTagHttpDao = new ContactTagHttpDao();

        $tagMapArr = ContactTagMapDao::getAllList(
            [
                'userid',
                'external_userid'
            ],
            [
                'tag_id' => 'et5b2CBwAAoXwtl-WENfT6kwqW06J7_w'
            ]
        );

        $insertBatchData = [];

        foreach ($tagMapArr as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        ['et5b2CBwAAGEM3h6pr0Z0IVFbF0jLatg'] // 打标签
                    )
                ) {
                    $insertBatchData[] = [
                        'tag_id'          => 'et5b2CBwAAGEM3h6pr0Z0IVFbF0jLatg',
                        'external_userid' => $value['external_userid'],
                        'userid'          => $value['userid']
                    ];
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        ContactTagMapDao::addBatchData($insertBatchData);
    }

    /**
     *
     */
    public function fixTagMap()
    {
        $wrongData = Db::name('contact_tag_map')
            ->field([
                'external_userid',
                'count(external_userid) as count'
            ])
            ->where([
                'tag_id' => 'et5b2CBwAAndvq8rMizuMGaTsRFQ0Okg'
            ])
            ->group('external_userid')
            ->order('count desc')
            ->limit(0, 10)
            ->select();

        /*foreach ($wrongData as $value) {
            $singleData = Db::name('contact_tag_map')
                ->field([
                    'external_userid',
                    'userid',
                    'count(external_userid) as userid_count',
                    'create_time'
                ])
                ->where([
                    'tag_id' => 'et5b2CBwAAndvq8rMizuMGaTsRFQ0Okg',
                    'external_userid' => $value['external_userid']
                ])
                ->group('userid')
                ->order('userid_count desc')
                ->select();

            ContactTagMapDao::hardDelete([
                'external_userid' => $value['external_userid'],
                'tag_id'          => 'et5b2CBwAAndvq8rMizuMGaTsRFQ0Okg',
                'create_time'     => ['>', $singleData[0]['create_time']]
            ]);

        }*/

        print_r($wrongData);

        die;
    }

    /**
     * 打"首单客户-送首饰盒"标签
     *
     * @param string $unionId
     * @return bool
     * @throws Exception
     */
    public function markFirstOrderTag(string $unionId): bool
    {
        $addTags = ContactTags::FIRST_ORDER_TAG;

        return $this->pushTagToRedis($unionId, $addTags);
    }

    /**
     * 打"颜值加价购推广"标签
     *
     * @throws Exception
     */
    public function markYanzhiTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $allUser = array_merge(
            [
                'yanyan',
                'jiujiu',
                'mengmeng',
                'jiaojiao'
            ],
            $zhaoweiAccounts
        );

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => [
                    'in',
                    $allUser
                ],
                'status' => ContactFollowUser::NORMAL,  // 当前客户
                'follow.external_userid' => [
                    'in', [
                        'wm5b2CBwAAXvj8Kk0QEspPxSm5Ygo0eA',
                    ]
                ]
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"7.30继承"标签
     *
     * @throws Exception
     */
    public function mark730Inherit()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => [
                    'in',
                    $feiyueAccounts
                ],
                'status' => ContactFollowUser::NORMAL // 当前客户
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"0802抽奖活动"标签
     *
     * @throws Exception
     */
    public function mark0802LuckDraw()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => [
                    'in',
                    [
                        "owTq1jjGBXpoQRi9BmNyngAHlld8",
                    ]
                ],
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'userid' => ['in', $zhaoweiAccounts]
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"大拍画册"标签
     *
     * @throws Exception
     */
    public function markAuctionPictureAlbum()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        $allAccounts = array_merge($zhaoweiAccounts, $feiyueAccounts);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'userid' => ['in', $allAccounts],
                // 'follow.create_time' => ['>', '2021-08-12 14:50:26']
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 首单新客
     *
     * @param string $unionId 客户unionId
     * @param int $tagType 标签类型 1-宝姐饰界新客 2-兴趣电商新客 3-宝姐珠宝新客
     * @return bool
     * @throws Exception
     */
    public function markNewCustomerTag(string $unionId, int $tagType): bool
    {
        switch ($tagType) {
            case 1:
            default:
                $addTags = ContactTags::NEW_CUSTOMER_TAG[1]; // 宝姐饰界新客
                break;

            case 2:
                $addTags = ContactTags::NEW_CUSTOMER_TAG[2]; // 兴趣电商新客
                break;

            case 3:
                $addTags = ContactTags::NEW_CUSTOMER_TAG[3]; // 宝姐珠宝新客
                break;
        }

        return $this->pushTagToRedis($unionId, $addTags);
    }

    /**
     * 寻找联系人，写入标签队列
     *
     * @param string $unionId
     * @param string $addTags
     * @return bool
     * @throws Exception
     */
    private function pushTagToRedis(string $unionId, string $addTags): bool
    {
        // 这个客户目前的客服
        $followUserArr = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'contact.external_userid',
                'follow.userid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => $unionId,
                'status'  => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT] // 不是被客服删除
            ])
            ->select();

        // 一个客户的所有客服的标签都要变
        foreach ($followUserArr as $followValue) {
            $carryData = [
                'add_tags'        => [$addTags],
                'remove_tags'     => [],
                'userid'          => $followValue['userid'],
                'external_userid' => $followValue['external_userid'],
                'func'            => ''
            ];

            try {
                // 推送到打标签队列
                Queue::push(
                    ContactTags::HANDLE_CONTACT_TAG_HANDLER,
                    $carryData,
                    ContactTags::HANDLE_CONTACT_TAG_QUEUE
                );
            } catch (Exception $e) {
                send_msg_to_wecom('进入处理标签队列出错：' . $e->getMessage());
            }
        }
        return true;
    }

    /**
     * “拼团10.15”标签
     * 费月名下个人号里，8月1日至今有过购买行为的客户，双向好友
     * 在费月名下个号里去重打
     * @throws Exception
     */
    public function groupPurchasing1015()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'userid' => ['in', $feiyueAccounts]
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * “10.23群享价活动”标签
     * 从以下这些渠道加过来的，且不在赵蔚群内的【好友】去重
     *
     * @throws Exception
     */
    public function groupPurchasing1023()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $stateArr = [
            126
        ];

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'state' => ['in', $stateArr]
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 商品偏好标签
     */
    public function goodsPreference()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $unionIdArr = [
            "owTq1jvxK8mgIP4LVAwmnU-Zx--U",
        ];

        foreach ($unionIdArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, ['unionid' => $contact], $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 双11通知
     *
     * @throws Exception
     */
    public function double11()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);
        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);

        $allAccounts = array_merge($feiyueAccounts, $zhaoweiAccounts);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'userid' => ['in', $allAccounts]
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 转粉
     * @throws Exception
     */
    public function transferFans1()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';


        $userServiceImpl = new UserServiceImpl();
        // 筛出【在费月名下个号】且【互为好友关系】的
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL, // 当前客户
                'add_way' => 100
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 转粉2
     * @throws Exception
     */
    public function transferFans2()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();
        // 筛出【费月的所有群成员】
        $feiyueAccounts = $userServiceImpl->getSpecificUserAccount('feiyue', false);

        // 所有群成员
        $groupMemberArr = (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.unionid',
            ])
            ->where([
                'b.owner'      => ['in', $feiyueAccounts],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.type'       => ContactGroupMembers::EXTERNAL_USER
            ])
            ->group('a.unionid')
            ->select();

        foreach ($groupMemberArr as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 给朋友圈客户打"11.26~12.11珍珠加粉定向"标签
     */
    public function markPearlTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        [
            $beginTime,
            $endTime
        ] = [
            strtotime('2021-11-26'),
            strtotime('2021-12-12 23:59:59')
        ];

        // 所有朋友圈珍珠客户进入队列
        $allContact = Db::name('contact_follow_user')
            ->field([
                'userid',
                'external_userid'
            ])
            ->where([
                'status'     => ContactFollowUser::NORMAL, // 当前客户
                'add_way'    => 100,
                'userid'     => ['in', ContactChannels::MOMENT_CHANNEL_MAP[151]],
                'createtime' => ['between', [$beginTime, $endTime]]
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"12.16珍珠广告加粉"标签
     */
    public function mark1216PearlTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        [
            $beginTime,
            $endTime
        ] = [
            strtotime('2021-12-18'),
            strtotime('2021-12-19 23:59:59')
        ];

        // 所有朋友圈珍珠客户进入队列
        $allContact = (array)Db::name('contact_follow_user')
            ->field([
                'userid',
                'external_userid'
            ])
            ->where([
                'status'       => ContactFollowUser::NORMAL, // 当前客户
                'add_way'      => 100,
                'userid'       => ['in', ContactChannels::MOMENT_CHANNEL_MAP[146]],
                'createtime'   => ['between', [$beginTime, $endTime]],
                'is_first_add' => 1
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"秒杀30群客户转移"标签
     * 阳阳2和阳阳3上，宝姐家饰界福利秒杀30群的客户
     *
     * @throws Exception
     */
    public function markSecKillTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = ContactGroupMembersDao::getAllList(['userid'], [
            'chat_id'    => 'wr5b2CBwAAvdLGuSg-R4htvW9XtVkNJA',
            'is_deleted' => ContactGroupMembers::NOT_DELETED,
            'type'       => ContactGroupMembers::EXTERNAL_USER
        ]);

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 打"小红书"标签
     *
     * @throws Exception
     */
    public function markRedBookTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = ContactGroupMembersDao::getAllList(['userid'], [
            'chat_id'    => 'wr5b2CBwAADxnIZmUowyJraD5d1Harag',
            'is_deleted' => ContactGroupMembers::NOT_DELETED,
            'type'       => ContactGroupMembers::EXTERNAL_USER
        ]);

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 宝姐家秀秀号
     *
     * @throws Exception
     */
    public function markXiuxiuTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = ContactFollowUserDao::getAllList(
            [
                'userid',
                'external_userid'
            ],
            [
                'userid' => 'xiuxiu',
                'status' => 0
            ]
        );

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 翡翠手绳活动邀请
     *
     * @throws Exception
     */
    public function markJadeiteTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        /*$allContact = ContactFollowUserDao::getAllList(
            [
                'userid',
                'external_userid'
            ],
            [
                'userid'  => ['in', ['yangyang2','jiaojiao','baojiejiayangyang9']],
                'status'  => 0,
                'add_way' => 100
            ]
        );*/
        $allContact = $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'unionid' => ['in', [
                    'owTq1jrSxxKjTfPVF7iOMAEJkj10',
                    'owTq1jvxK8mgIP4LVAwmnU-Zx--U',
                    'owTq1jlCDJKpJr1_QIetk3kAqO5A',
                    'owTq1jmaZ_6QUiATOpu4HxyEpXQo',
                    'owTq1ji3tYOFX1LH2IYb5DCx2UW0',
                    'owTq1jrSxxKjTfPVF7iOMAEJkj10',
                    'owTq1jq5FXn-8N4CY7D3f6cBe52g',
                    'owTq1joBiutk2aNLKb0s6WOmyElc',
                    'owTq1jsgSgv8BsMZ7gbfLxLKVwKg',
                    'owTq1jhXsxjz_yPXiOJMkH3BILTc',
                    'owTq1jhgdU-Rljf-Mba9UnTUyhAE',
                    'owTq1jrSxxKjTfPVF7iOMAEJkj10',
                    'owTq1jnaxUNAwQL2X_HnsWb0XOXQ',
                    'owTq1jnHoMi9RMiNBh6XwFszaRsE',
                    'owTq1jh8b5G_GoAd9itrGNdZlIyg',
                    'owTq1jlZcvLlak53f9w9acBgE2iM',
                    'owTq1jkZA6Rb5AjMg29YBI7jKt9s',
                    'owTq1jmaZ_6QUiATOpu4HxyEpXQo',
                    'owTq1jooQOR0RNw7Ah-GmA5ACobA',
                    'owTq1jmBDLxS-3S8GhbYMmv6A2U8'
                ]],
                'status' => ContactFollowUser::NORMAL
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "彩宝1"标签
     *
     * @throws Exception
     */
    public function markGemstone1Tag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = ContactTagMapDao::getAllList([
            'external_userid',
            'userid'
        ], [
            'tag_id'      => 'et5b2CBwAA5ffiLu_hos1juabnCBTZqw',
            'userid'      => 'qingqing',
            'create_time' => ['>', '2022-01-19 00:00:00']
        ]);

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "翡翠多宝吊坠"标签
     *
     * @throws Exception
     */
    public function markPendantTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccounts = $userServiceImpl->getSpecificUserAccount('zhaowei', false);
        $zhaoweiAccounts = array_filter($zhaoweiAccounts, function ($val) {
            if ($val !== 'xiuxiu') {
                return true;
            }
            return false;
        });

        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => ['in', $zhaoweiAccounts],
                'status' => ContactFollowUser::NORMAL
            ])
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "企微裂变种子用户"标签
     */
    public function markFissionTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $redis = Cache::store()->handler();

        $allYangyang3Contact = $redis->sMembers('yangyang1');

        // 取前400名
        $fissionContact = array_slice($allYangyang3Contact, 0, 400);

        foreach ($fissionContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "2月26日企微裂变"标签
     */
    public function mark0226FissionTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $fissionContact = (array)Db::name('contact_follow_user')
            ->field([
                'external_userid',
                'userid',
                'state'
            ])
            ->whereRaw('length(state) > 20')
            ->where([
                'is_first_add' => 1
            ])
            ->select();

        foreach ($fissionContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "麦穗珍珠胸针活动"标签
     *
     * 阳阳6/9/10/11上
    朋友圈广告投放加来的人
    目前还是好友的
    没有进入阳阳社群的
     */
    public function markBroochTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = (array)Db::name('contact_follow_user')
            ->field([
                'userid',
                'external_userid'
            ])

            ->where([
                'userid' => ['in', ['yangyang2','baojiejiayangyang9','qingqing', 'yanyan']],
                'status' => ContactFollowUser::NORMAL,
                'state' => 10146
            ])
            ->group('external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "3.7彩宝1添加个微"标签
     *
     * 彩宝1朋友圈广告加来的人
    新人
    目前还是好友的
     */
    public function markStone1Tag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => 'qingqing',
                'status' => ContactFollowUser::NORMAL,
                'state'  => 10146
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * 3.7珍珠老添加个微
     *
     * 珍珠老账号朋友圈广告加来的人
    新人
    目前还是好友的
     *
     * @throws Exception
     */
    public function markPearlOldTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $allContact = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.id',
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'userid' => ['in',
                    [
                        'yangyang1',
                        'yangyang123', // 2
                        'yangyang3',
                        'yangyang4',
                        'yangyang5',
                        'yangyang2', // 6
                        'youyou', // 7
                        'baojiejiayangyang9',
                        'qingqing', // 10
                        'yanyan' // 11
                       /* 'susu',
                        'BaoJieZhuBaoGuWenNiNi',
                        'xinxin',
                        'ake',
                        'xiaoshuo',
                        'luoluo',
                        'xiaobao',
                        'aning',
                        'xiaozhe',
                        'xiaoyu',
                        'xiaoou',
                        'xiaomin',
                        'xiaowei',
                        'xiaobei',
                        'xixihao',
                        'azhu',
                        'baojiezhubaoguwenxiaoyu2'*/
                    ]
                ],
                'status'     => ContactFollowUser::NORMAL,
                // 'add_way'    => 10
                // 'createtime' => ['>', strtotime(date('Y-m-d', strtotime('-1 months')))]
            ])
            ->group('contact.unionid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "3.7群发邀请添加个微"标签
     *
     * @throws Exception
     */
    public function markAddWechatTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        $userId = 'baojiejiayangyang9';
        $tagId = 'et5b2CBwAA1fMJjsjTLTuH1hz7PjBJKA'; // 已添加个微
        $groupHttpDao = new GroupMsgHttpDao();
        $groupList = $groupHttpDao->getGroupMsgList($userId, 1646582400, 1646668800);

        $msgId = $groupList['group_msg_list'][1]['msgid'];

        $sendResult = $groupHttpDao->getGroupMsgSendResult($msgId, $userId);

        $externalUserIdArr = array_column($sendResult['send_list'], 'external_userid');

        $tagMapData = ContactTagMapDao::getAllList(
            ['external_userid'],
            [
                'tag_id' => $tagId,
                'userid' => $userId
            ]
        );
        $hasTagArr = array_column($tagMapData, 'external_userid');

        $diffArr = array_diff($externalUserIdArr, $hasTagArr);

        $redis = Cache::store()->handler();

        foreach ($diffArr as $externalUserId) {
            if (!$redis->sIsMember('all', $externalUserId)) {
                $redis->sadd('all', $externalUserId);
            } else {
                continue;
            }
            $contact = [
                'userid'          => $userId,
                'external_userid' => $externalUserId
            ];

            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "企微海报加粉1.0"标签
     *
     * @throws Exception
     */
    public function markFissionChannelTag()
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        // 所有联系人进入队列
        $allContact = (array)Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid',
                'follow.createtime'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->whereRaw('length(state) > 20')
            ->where([
                'is_first_add'       => 1,
                'status'             => ContactFollowUser::NORMAL,
                'follow.create_time' => ['between', ['2022-03-09 00:00:00', '2022-03-14 23:59:59']]
            ])
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');
    }

    /**
     * "延发"标签
     */
    public function markDelayTag(): bool
    {
        $redis = Cache::store()->handler();
        $userServiceImpl = new UserServiceImpl();
        $userAccount = $userServiceImpl->getSpecificUserAccount('zhaowei');
        // 今天朋友圈广告加来的人
        /*Db::name('contact_follow_user')
            ->field([
                'id',
                'external_userid'
            ])
            ->where([
                'status'      => ContactFollowUser::NORMAL,
                // 'add_way'     => ContactFollowUser::MOMENT_ADD_WAY,
                'userid'      => ['in', $userAccount],
                'create_date' => ['>=', '2022-09-26']
            ])
            ->chunk(1000, function ($result) use ($redis) {
                if (!$result) {
                    return;
                }

                foreach ($result as $value) {
                    $redis->sadd('today_friend_circle', $value['external_userid']);
                }
            });*/

        /*Db::name('contact_tag_map')
            ->field([
                'id',
                'external_userid'
            ])
            ->where([
                'tag_id' => 'et5b2CBwAA1_TTk_ZAkHo2LKBxgo6d7w'
            ])
            ->chunk(1000, function ($result) use ($redis) {
                if (!$result) {
                    return;
                }
                foreach ($result as $value) {
                    $redis->sadd('join_group', $value['external_userid']);
                }
            });*/

        /*Db::name('contact_tag_map')
            ->field([
                'id',
                'external_userid'
            ])
            ->where([
                'tag_id' => 'et5b2CBwAAIlkl2BsTWcVtfI9e-MOp8g'
            ])
            ->chunk(1000, function ($result) use ($redis) {
                if (!$result) {
                    return;
                }

                foreach ($result as $value) {
                    $redis->sadd('join_group2', $value['external_userid']);
                }
            });*/
        /*$channelIdArr = ContactChannelsDao::getAllList(['id'], [
            'channel_name' => ['in', [
                '视频号直播导流企微社群——优优（费月）',
                '截图用户分享裂变专用——费月',
                '小程序导流社群—视频号活动',
                '关注后自动回复—赵蔚',
                '0元购活动费月渠道加粉（不使用）—赵蔚'
            ]],
            'is_deleted' => 0
        ]);*/
        /*$groupMembersArr = Db::name('contact_groups')
            ->alias('a')
            ->join('contact_group_members b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'b.userid'
            ])
            ->where([
                'a.chat_id' => ['in', [
                    'wr5b2CBwAAvIP1w-5LCw1dyLYWBVqQ5A',
                    'wr5b2CBwAAhBloKcE-68R6KEID5Ttlkw',
                    'wr5b2CBwAA3r3FhuDiZrOoT65_uPK8cQ',
                    'wr5b2CBwAArkE9rTHPmxRRqtKEI8nn5A'
                ]],
                'b.is_deleted' => 0,
                'b.type'       => 2
            ])
            ->group('b.userid')
            ->select();

        foreach ($groupMembersArr as $groupMemberValue) {
            $redis->sadd('join_group', $groupMemberValue['userid']);
        }*/

        $stateArr = ContactWaysDao::getAllList(['id'], [
            'channel_id' => ['in', [26,61,67,70]],
            'is_deleted' => 0
        ]);

        $stateIdArr = array_column($stateArr, 'id');

        $stateIdStr = implode(',', $stateIdArr);

        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid',
                'follow.add_way',
                'follow.state'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL,
                'userid' => ['in', [
                    'yangyang1',
                    'yangyang123',
                    'yangyang3',
                    'yangyang4',
                    'yangyang5',
                    'yangyang2',
                    'youyou',
                    'baojiejiayangyang9',
                    'qingqing',
                    'yanyan'
                ]]
            ])
            ->where([
                'create_date' => ['<=', '2022-10-05']
            ])
            ->where(function ($query) use ($stateIdArr) {
                $query->where(['state' => ['not in', $stateIdArr]])
                    ->whereOr([
                        'add_way' => ['=', 100]
                    ]);
            })
            ->group('follow.external_userid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * "KOC"标签
     */
    public function markKocTag(): bool
    {
        // 队列名
        $jobQueue = 'mark_propaganda_tag_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\tag\markPropagandaTagJob';

        /*$groupMemberArr = (array)Db::name('contact_group_members')
            ->alias('a')
            ->join('contact_groups b', 'a.chat_id = b.chat_id', 'LEFT')
            ->field([
                'a.unionid',
            ])
            ->where([
                'b.name'      => ['like', '%分享员%'],
                'a.is_deleted' => 0,
                'b.is_deleted' => 0,
                'a.type'       => ContactGroupMembers::EXTERNAL_USER,
                'unionid'      => ['in', [

                ]]
            ])
            ->group('a.unionid')
            ->select();*/

        // 宝姐家推广招募8群
        /*$a = ContactGroupMembersDao::getAllList([
            'unionid',
        ], [
            'chat_id' => 'wr5b2CBwAAFrFGjxlxcN64aXZuaeGo_A',
            'type'    => 2
        ]);

        $unionIdArr = array_column($a, 'unionid');

        $unionIdArr = array_unique(array_merge($unionIdArr, [
            'owTq1jqQSr9GR0HQJtFimScwIARM'
        ]));

        $b = ContactGroupMembersDao::getAllList([
            'unionid',
        ], [
            'chat_id'    => 'wr5b2CBwAAXMINB34zoXaVbWpd9KMWqA',
            'is_deleted' => 0,
            'type'       => 2
        ]);

        $allUnionIdArr = array_column($b, 'unionid');

        $notInUnionIdArr = [];

        foreach ($unionIdArr as $unionId) {
            if (!in_array($unionId, $allUnionIdArr)) {
                array_push($notInUnionIdArr, $unionId);
            }
        }*/

        // 所有联系人进入队列
        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status'  => ContactFollowUser::NORMAL,
                'unionid' => ['in', []]
            ])
            ->group('unionid')
            ->select();

        foreach ($allContact as $contact) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $contact, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                Response::error('队列出错：' . $e->getMessage());
            }
        }

        Response::success('执行成功！');

        return true;
    }

    /**
     * 移除标签
     *
     * @return bool
     * @throws Exception
     */
    public function removeTag(): bool
    {
        /*$removeUserArr = GroupMsgReceiveMapDao::getAllList(['user_id','external_userid'], [
            'template_id' => 206,
            'status'      => 2
        ]);*/

        $allContact = Db::name('contact_follow_user')
            ->alias('follow')
            ->field([
                'follow.userid',
                'follow.external_userid',
                'contact.unionid'
            ])
            ->join(
                'scrm_external_contact contact',
                'follow.external_userid = contact.external_userid',
                'LEFT'
            )
            ->where([
                'status' => ContactFollowUser::NORMAL,
                'userid' => ['in', [
                    'baojiejiayangyang9'
                ]],
                'state' => 10146,
                'create_date' => ['>', '2022-07-01']
            ])
            ->group('follow.external_userid')
            ->select();

        $contactTagHttpDao = new ContactTagHttpDao();

        $addTags = ['et5b2CBwAArtH04PhvxBsFPyPExy1bMw'];
        $removeTags = [];
        foreach ($allContact as $value) {
            try {
                if (
                    $contactTagHttpDao->markTag(
                        $value['userid'],
                        $value['external_userid'],
                        $addTags,
                        $removeTags
                    )
                ) {
                    /*ContactTagMapDao::hardDelete([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $removeTags[0],
                        'userid'          => $value['userid']
                    ]);*/
                    ContactTagMapDao::addData([
                        'external_userid' => $value['external_userid'],
                        'tag_id'          => $addTags[0],
                        'userid'          => $value['userid']
                    ]);
                }
            } catch (Exception $e) {
                Log::error($e->getMessage());
            }
        }

        return true;
    }
}
