<?php

declare(strict_types=1);

namespace app\api\service\contactTag;

/**
 * Interface ContactTagService
 * @package app\api\service\contactTag
 */
interface ContactTagService
{
    /**
     * 获取企业标签库并入表
     *
     * @return mixed
     */
    public function initCorpTag();

    /**
     * 获取企业标签库
     *
     * @return array
     */
    public function getCorpTagList(): array;

    /**
     * 添加企业客户标签
     *
     * @param array $tagIdArr
     * @param string $groupId
     * @return array
     */
    public function addCorpTag(array $tagIdArr, string $groupId): array;

    /**
     * 给客户打标签
     *
     * @return bool;
     */
    public function markTag(): bool;
}
