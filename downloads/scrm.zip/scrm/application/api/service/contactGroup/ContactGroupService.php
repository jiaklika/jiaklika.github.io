<?php

declare(strict_types=1);

namespace app\api\service\contactGroup;

/**
 * Interface ContactGroupService
 * @package app\api\service\contactGroup
 */
interface ContactGroupService
{
    /**
     * 初始化所有客户群
     *
     * @return bool
     */
    public function initContactGroupList(): bool;

    /**
     * 初始化所有客户群成员
     *
     * @return bool
     */
    public function initContactGroupDetail(): bool;

    /**
     * 初始化所有客户群列表和详情
     *
     * @return bool
     */
    public function initContactGroupListAndDetail(): bool;

    /**
     * 初始化单个群的成员信息
     *
     * @param string $chatId 客户群ID
     * @return bool
     */
    public function initSingleGroupMember(string $chatId): bool;
}
