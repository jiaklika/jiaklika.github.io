<?php

namespace app\api\service\contactGroup\impl;

use app\api\dao\http\contact\ContactGroupHttpDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\OpengidRecordsDao;
use app\api\service\contactGroup\ContactGroupService;
use app\common\model\ContactGroups;
use Exception;
use think\Db;

/**
 * Class ContactGroupServiceImpl
 * @package app\api\service\contactGroup\impl
 */
class ContactGroupServiceImpl implements ContactGroupService
{
    /**
     * @var ContactGroupHttpDao
     */
    private static $contactGroupHttpDao;

    /**
     * ContactGroupServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$contactGroupHttpDao)) {
            self::$contactGroupHttpDao = new ContactGroupHttpDao();
        }
    }

    /**
     * 初始化所有客户群
     *
     * @return bool
     * @throws Exception
     */
    public function initContactGroupList(): bool
    {
        $groupList = self::$contactGroupHttpDao->getContactGroupList();

        return ContactGroupDao::addBatchData($groupList);
    }

    /**
     * 初始化所有客户群成员信息
     *
     * @return bool
     * @throws Exception
     */
    public function initContactGroupDetail(): bool
    {
        $httpDao = self::$contactGroupHttpDao;

        static $allAddMemberData   = []; // 所有待写入成员数据
        static $allUpdateGroupData = []; // 所有待更新群数据

        $closure = function ($groupInfo) use ($httpDao, &$allAddMemberData, &$allUpdateGroupData) {

            $completeMemberList = $groupList = [];

            foreach ($groupInfo as $v) {
                // 客户群详情
                $groupDetail = $httpDao->getContactGroupDetail($v['chat_id'], 1);

                // 成员列表
                $memberList = $groupDetail['member_list'];

                $newMemberList = [];

                foreach ($memberList as $mem) {
                    $newMemberList[] = [
                        'unionid'        => $mem['unionid'] ?? '',
                        'chat_id'        => $groupDetail['chat_id'],
                        'invitor'        => $mem['invitor']['userid'] ?? '',
                        'original_name'  => $mem['name'] ?? '',
                        'userid'         => $mem['userid'],
                        'type'           => $mem['type'],
                        'join_time'      => $mem['join_time'],
                        'join_scene'     => $mem['join_scene'],
                        'group_nickname' => $mem['group_nickname'],
                    ];
                }

                $completeMemberList = array_merge($completeMemberList, $newMemberList);
                $groupList[] = [
                    'id'                => $v['id'],
                    'name'              => $groupDetail['name'],
                    'owner'             => $groupDetail['owner'],
                    'group_create_time' => $groupDetail['create_time'],
                    'notice'            => $groupDetail['notice'] ?? ''
                ];
                unset($memberList, $newMemberList, $groupDetail);
            }

            $allAddMemberData = array_merge($allAddMemberData, $completeMemberList);

            $allUpdateGroupData = array_merge($allUpdateGroupData, $groupList);
        };

        // 获取表中数据并处理
        ContactGroupDao::handleDataByChunk(
            [
                'id',
                'chat_id'
            ],
            [
                'name' => '',
                'id'   => ['between', [231, 300]],
            ],
            3,
            $closure
        );

        Db::startTrans();
        /*var_export($allAddMemberData);
        die;*/
        // 批量写入
        $addRes = ContactGroupMembersDao::addBatchData($allAddMemberData);
        // 批量更新
        $updateRes = ContactGroupDao::updateBatchData(new ContactGroups(), $allUpdateGroupData);

        unset($allAddMemberData, $allUpdateGroupData);

        if ($addRes && $updateRes !== false) {
            Db::commit();
            return true;
        }

        Db::rollback();
        return false;
    }

    /**
     * 初始化所有客户群列表和详情
     *
     * @return bool
     * @throws Exception
     */
    public function initContactGroupListAndDetail(): bool
    {
        $httpDao = self::$contactGroupHttpDao;

        $groupList = $httpDao->getContactGroupList();

        ContactGroupDao::addBatchData($groupList);

        static $allUpdateGroupData = []; // 所有待更新群数据

        $closure = function ($groupInfo) use ($httpDao, &$allUpdateGroupData) {

            $groupList = [];

            foreach ($groupInfo as $v) {
                // 客户群详情
                $groupDetail = $httpDao->getContactGroupDetail($v['chat_id']);

                $groupList[] = [
                    'id'                => $v['id'],
                    'name'              => $groupDetail['name'],
                    'owner'             => $groupDetail['owner'],
                    'group_create_time' => $groupDetail['create_time'],
                    'notice'            => $groupDetail['notice'] ?? ''
                ];
                unset($groupDetail);
            }

            $allUpdateGroupData = array_merge($allUpdateGroupData, $groupList);
        };

        // 获取表中数据并处理
        ContactGroupDao::handleDataByChunk(
            [
                'id',
                'chat_id'
            ],
            [
                'name' => ''
            ],
            3,
            $closure
        );

        // 批量更新
        $updateRes = ContactGroupDao::updateBatchData(new ContactGroups(), $allUpdateGroupData);

        unset($allUpdateGroupData);

        if ($updateRes !== false) {
            return true;
        }

        return false;
    }

    /**
     * 初始化单个群的成员信息
     *
     * @param string $chatId
     * @return bool
     * @throws Exception
     */
    public function initSingleGroupMember(string $chatId): bool
    {
        // 客户群详情
        $groupDetail = self::$contactGroupHttpDao->getContactGroupDetail($chatId, 1);
        // 成员列表
        $memberList = $groupDetail['member_list'];

        $newMemberList = [];

        foreach ($memberList as $mem) {
            $newMemberList[] = [
                'unionid'        => $mem['unionid'] ?? '',
                'chat_id'        => $groupDetail['chat_id'],
                'invitor'        => $mem['invitor']['userid'] ?? '',
                'original_name'  => $mem['name'] ?? '',
                'userid'         => $mem['userid'],
                'type'           => $mem['type'],
                'join_time'      => $mem['join_time'],
                'join_scene'     => $mem['join_scene'],
                'group_nickname' => $mem['group_nickname'],
            ];
        }

        // 批量写入
        $addRes = ContactGroupMembersDao::addBatchData($newMemberList);

        if ($addRes) {
            return true;
        }

        return false;
    }

    /**
     * 客户群opengid转换
     *
     * @param array $request
     * @return bool
     */
    public function transferOpenGid(array $request): bool
    {
        $insertData = [
            'open_gid'     => $request['open_gid'],
            'open_time'    => $request['open_time'],
            'program_type' => $request['program_type'],
            'unionid'      => $request['unionid'] ?? '',
            'open_path'    => $request['path']
        ];

        try {
            $insertData['chat_id'] = self::$contactGroupHttpDao->openGidToChatId($request['open_gid']);

            if (!OpengidRecordsDao::addData($insertData)) {
                exception('存表失败！');
            }
        } catch (Exception $e) {
            /*send_msg_to_wecom(
                '客户群opengid转换失败！' . json_encode($insertData, JSON_UNESCAPED_UNICODE) . $e->getMessage()
            );*/
            return false;
        }
        return true;
    }
}
