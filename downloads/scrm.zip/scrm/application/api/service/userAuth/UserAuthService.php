<?php

declare(strict_types=1);

namespace app\api\service\userAuth;

/**
 * Interface UserAuthService
 * @package app\api\service\userAuth
 */
interface UserAuthService
{
    public function handleCallback(string $code);
}
