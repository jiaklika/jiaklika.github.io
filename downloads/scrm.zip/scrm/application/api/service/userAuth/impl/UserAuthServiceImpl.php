<?php

declare(strict_types=1);

namespace app\api\service\userAuth\impl;

use app\api\dao\http\user\UserHttpDao;
use app\api\service\userAuth\UserAuthService;
use Exception;

/**
 * Class UserAuthServiceImpl
 * @package app\api\service\userAuth\impl
 */
class UserAuthServiceImpl implements UserAuthService
{
    /**
     * @var UserHttpDao
     */
    private static $_userHttpDao;

    /**
     * UserServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$_userHttpDao))
            self::$_userHttpDao = new UserHttpDao();
    }

    /**
     * 处理回调
     *
     * @param string $code
     * @throws Exception
     */
    function handleCallback(string $code)
    {
        $res = self::$_userHttpDao->getUserInfo($code);
        $userInfo = self::$_userHttpDao->getUser($res['UserId']);
    }
}