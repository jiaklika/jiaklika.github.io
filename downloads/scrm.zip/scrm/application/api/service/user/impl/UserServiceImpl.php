<?php

declare(strict_types=1);

namespace app\api\service\user\impl;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\user\UserHttpDao;
use app\api\dao\mysql\user\DepartmentDao;
use app\api\dao\mysql\user\UserBindAccountMapDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\user\UserService;
use app\common\model\User;
use app\common\model\UserBindAccountMap;
use Exception;
use think\Cache;

/**
 * Class UserServiceImpl
 * @package app\api\service\user\impl
 */
class UserServiceImpl implements UserService
{
    /**
     * @var UserHttpDao
     */
    private static $userHttpDao;

    /**
     * UserServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$userHttpDao)) {
            self::$userHttpDao = new UserHttpDao();
        }
    }

    /**
     * 读取并写入所有的部门
     *
     * @param int $departmentId 部门id
     * @return bool
     * @throws Exception
     */
    public function getDepartmentList(int $departmentId = 0): bool
    {
        $departmentList = self::$userHttpDao->getDepartmentList(0);

        $insertRes = false;

        if ($departmentList) {
            $insertData = array_map(function ($val) {
                return [
                    'department_id'       => $val['id'],
                    'department_name'     => $val['name'],
                    'department_name_en'  => $val['name_en'] ?? '',
                    'department_parentid' => $val['parentid'],
                    'order'               => $val['order']
                ];
            }, $departmentList);

            $insertRes = DepartmentDao::addBatchData($insertData);
        }

        return (bool)$insertRes;
    }

    /**
     * 读取并写入所有的员工信息
     *
     * @return bool
     * @throws Exception
     */
    public function getDepartmentMemberDetail(): bool
    {
        [
            $firstLevelDepartment, // 所有一级部门
            $fetchChild,           // 递归获取子部门下面的成员
            $insertData,
            $insertRes
        ] = [
            DepartmentDao::getAllFirstLevelDepartment(),
            1,
            [],
            false
        ];

        if ($firstLevelDepartment) {
            $firstLevelDepartmentIdArr = array_column($firstLevelDepartment, 'department_id');

            foreach ($firstLevelDepartmentIdArr as $v) {
                if ($userArr = self::$userHttpDao->getUserDetail($v, $fetchChild)) {
                    $userDetailArr = array_map(function ($val) {
                        return [
                            'userid'            => $val['userid'],
                            'name'              => $val['name'],
                            'english_name'      => $val['english_name'],
                            'mobile'            => $val['mobile'],
                            'hide_mobile'       => $val['hide_mobile'],
                            'department'        => implode(',', $val['department']),
                            'order'             => implode(',', $val['order']),
                            'position'          => $val['position'],
                            'gender'            => $val['gender'],
                            'email'             => $val['email'],
                            'is_leader_in_dept' => implode(',', $val['is_leader_in_dept']),
                            'avatar'            => $val['avatar'],
                            'thumb_avatar'      => $val['thumb_avatar'],
                            'telephone'         => $val['telephone'],
                            'alias'             => $val['alias'],
                            'extattr'           => json_encode($val['extattr'], JSON_UNESCAPED_UNICODE),
                            'status'            => $val['status'],
                            'qr_code'           => $val['qr_code'],
                            'external_profile'  => isset($val['external_profile'])
                                ? json_encode(
                                    $val['external_profile'],
                                    JSON_UNESCAPED_UNICODE
                                )
                                : '',
                            'external_position' => $val['external_position'] ?? '',
                            'address'           => $val['address'] ?? '',
                            'main_department'   => $val['main_department']
                        ];
                    }, $userArr);

                    $insertData = array_merge(
                        $insertData,
                        $userDetailArr
                    );
                }
            }

            $insertRes = UserDao::addBatchData($insertData);
        }

        return (bool)$insertRes;
    }

    /**
     * 读取并更新所有配置了客户联系功能的员工
     *
     * @return bool
     * @throws Exception
     */
    public function updateFollowUserList(): bool
    {
        // 先获取最新的
        $contactHttpDao       = new ContactHttpDao();
        $latestFollowUserList = $contactHttpDao->getFollowUserList();

        // 再获取表里的
        $usersInfo = UserDao::getAllList(
            ['userid'],
            [
                'is_follow_user' => 1
            ]
        );

        $originalFollowUserList = $usersInfo
            ? array_column($usersInfo, 'userid')
            : [];

        [
            $addData,
            $reduceData
        ] = [
            array_diff($originalFollowUserList, $latestFollowUserList),
            array_diff($latestFollowUserList, $originalFollowUserList)
        ];

        if (!$addData && !$reduceData) {
            // 即相互都不存在差集，那么这两个数组就是相同的了
            return true;
        }

        $updateFunc = function ($isFollowUser, $userIdArr) {
            return UserDao::updateData(
                ['is_follow_user' => $isFollowUser],
                [
                    'userid' => ['in', $userIdArr]
                ]
            );
        };

        $updateUserAddRes = !$addData || $updateFunc(User::NOT_FOLLOW_USER, $addData);

        $updateUserReduceRes = !$reduceData || $updateFunc(User::IS_FOLLOW_USER, $reduceData);

        if (
            $updateUserAddRes !== false
            && $updateUserReduceRes !== false
        ) {
            return true;
        }

        return false;
    }

    /**
     * 更新成员对外信息
     *
     * @param string $userId 成员UserID
     * @param array $extraParams 对外属性列表
     * @return bool
     * @throws Exception
     */
    public function updateUser(string $userId, array $extraParams): bool
    {
        return self::$userHttpDao->updateUser(
            $userId,
            [
                'external_profile' => [
                    'external_attr' => $extraParams
                ]
            ]
        );
    }

    /**
     * 获取用户绑定列表
     *
     * @param array $requestData 请求数据
     * @return array
     * @throws Exception
     */
    public function getUserBindList(array $requestData): array
    {
        $where['userid'] = ['in', User::USER_BIND_MAP];

        if (isset($requestData['name']) && !empty($requestData['name'])) {
            $where['name'] = ['like', "%{$requestData['name']}%"];
        }

        $userList = UserDao::getPaginationList(
            [
                'userid',
                'name',
                'department',
                'position'
            ],
            $where,
            (int)$requestData['page'],
            (int)$requestData['limit']
        );

        $total = UserDao::getCount($where);

        $userIdArr = array_column($userList, 'userid');

        $bindArr = UserBindAccountMapDao::getAllList(
            [
                'user_id',
                'account'
            ],
            [
                'user_id' => ['in', $userIdArr]
            ]
        );

        $accountArr = array_column($bindArr, 'account');

        $accountNameArr = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $accountArr]]);

        $newAccountNameArr = [];

        foreach ($accountNameArr as $accountName) {
            $newAccountNameArr[$accountName['userid']] = $accountName['name'];
        }

        $newBindArr = array_map(function ($val) use ($newAccountNameArr) {
            return [$val['user_id'] => $newAccountNameArr[$val['account']] ?? ''];
        }, $bindArr);

        $userMap = array_reduce($newBindArr, function ($carry, $item) {
            return array_merge_recursive($carry, $item);
        }, []);

        foreach ($userList as &$user) {
            $user['position'] = sprintf(
                '%s-%s',
                implode('-', DepartmentDao::getAllDepartmentPath((int)$user['department'], true)),
                $user['position']
            );

            $user['account'] = '';

            if (isset($userMap[$user['userid']]) && !empty($userMap[$user['userid']])) {
                if (is_array($userMap[$user['userid']])) {
                    $user['account'] = trim(implode(',', $userMap[$user['userid']]), ',');
                } else {
                    $user['account'] = $userMap[$user['userid']];
                }
            }

            unset($user['department']);
        }

        return [
            'list'  => $userList,
            'total' => $total
        ];
    }

    /**
     * 获取用户绑定企微账号详情
     *
     * @param string $userId 公司客服UserId
     * @return array
     * @throws Exception
     */
    public function getUserBindDetail(string $userId): array
    {
        $userDetail = UserDao::getDetail(
            [
                'name',
                'department',
                'position'
            ],
            [
                'userid' => $userId
            ]
        );

        if (!$userDetail) {
            return [];
        }

        $departmentInfo = DepartmentDao::getAllDepartmentPath((int)$userDetail['department']);

        $department = implode('-', $departmentInfo);

        $userDetail['position'] = $department . '-' . $userDetail['position'];

        $bindAccountInfo       = UserBindAccountMapDao::getAllList(['account'], ['user_id' => $userId]);
        $userDetail['account'] = array_column($bindAccountInfo, 'account');

        unset($userDetail['department']);
        return $userDetail;
    }

    /**
     * 用户绑定企微账号
     *
     * @param array $requestData 请求数据
     * @return array
     * @throws Exception
     */
    public function bindAccount(array $requestData): array
    {
        $bindInfoArr = UserBindAccountMapDao::getAllList(
            [
                'user_id',
                'account'
            ],
            [
                'account' => ['in', $requestData['account']]
            ]
        );

        $userInfo = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $requestData['account']]]);

        $newUserInfo = [];

        foreach ($userInfo as $user) {
            $newUserInfo[$user['userid']] = $user['name'];
        }

        $repeatBind = [];

        foreach ($bindInfoArr as $bindInfo) {
            if ($bindInfo['user_id'] != $requestData['user_id']) {
                $repeatBind[] = $newUserInfo[$bindInfo['account']];
            }
        }

        if ($repeatBind) {
            return [false, implode(',', $repeatBind) . '-已经绑定其他用户！'];
        }

        // 先移除此客户已经绑定的所有账号
        if (UserBindAccountMapDao::hardDelete(['user_id' => $requestData['user_id']]) !== false) {
            $insertBatchData = array_map(function ($account) use ($requestData) {
                return [
                    'user_id' => $requestData['user_id'],
                    'account' => $account
                ];
            }, $requestData['account']);

            if (UserBindAccountMapDao::addBatchData($insertBatchData)) {
                return [true, '绑定成功！'];
            }
        }

        return [false, '绑定失败！'];
    }

    /**
     * 获取指定客服的账号
     *
     * @param string $userId 企业客服UserId
     * @param bool $getFromCache 是否从缓存中获取
     * @return mixed
     * @throws Exception
     */
    public function getSpecificUserAccount(string $userId, bool $getFromCache = true)
    {
        $getBindInfoFromDatabaseClosure = function () use ($userId) {
            $bindAccountInfo = UserBindAccountMapDao::getAllList(['account'], ['user_id' => $userId]);

            return array_column($bindAccountInfo, 'account');
        };

        if ($getFromCache) {
            $redis = Cache::store()->handler();

            $keyName = sprintf(
                UserBindAccountMap::SPECIFIC_USER_ACCOUNTS_KEY,
                $userId
            );

            if (!$userAccountsJson = $redis->get($keyName)) {
                $userAccountsArr = $getBindInfoFromDatabaseClosure();

                $redis->set($keyName, json_encode($userAccountsArr), 3600 * 24);
            } else {
                $userAccountsArr = json_decode($userAccountsJson, true);
            }
        } else {
            $userAccountsArr = $getBindInfoFromDatabaseClosure();
        }

        return $userAccountsArr;
    }

    /**
     * 获取对外客服列表
     *
     * @throws Exception
     */
    public function getCustomerServiceList()
    {
        $customerServiceDepartmentId = 189;

        return UserDao::getAllList(
            [
                'id',
                'userid',
                'name'
            ],
            [
                'department' => $customerServiceDepartmentId,
                'is_deleted' => User::NOT_DELETED
            ]
        );
    }
}
