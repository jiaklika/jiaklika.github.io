<?php

declare(strict_types=1);

namespace app\api\service\user;

/**
 * Interface UserService
 * @package app\api\service\user
 */
interface UserService
{
    /**
     * 获取部门列表
     *
     * @param int $departmentId 部门id
     * @return bool
     */
    public function getDepartmentList(int $departmentId = 0): bool;

    /**
     * 读取并更新所有配置了客户联系功能的员工
     *
     * @return bool
     */
    public function getDepartmentMemberDetail(): bool;

    /**
     * 读取并更新配置了客户联系功能的成员列表
     *
     * @return bool
     */
    public function updateFollowUserList(): bool;

    /**
     * 更新成员
     *
     * @param string $userId      成员UserID
     * @param array  $extraParams 其他字段
     * @return bool
     */
    public function updateUser(string $userId, array $extraParams): bool;
}
