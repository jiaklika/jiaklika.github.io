<?php

declare(strict_types=1);

namespace app\api\service\way;

/**
 * Interface ContactWayService
 * @package app\api\service\way
 */
interface ContactWayService
{
    /**
     * 路径列表
     *
     * @param array $requestData 请求数据
     * @return array
     */
    public function index(array $requestData): array;

    /**
     * 路径详情
     *
     * @param int $wayId 路径id
     * @return array
     */
    public function detail(int $wayId): array;

    /**
     * 添加路径
     *
     * @param array $requestData 添加数据
     * @return array
     */
    public function add(array $requestData): array;

    /**
     * 更新路径
     *
     * @param array $updateData 更新数据
     * @return array
     */
    public function update(array $updateData): array;

    /**
     * 删除路径
     *
     * @param int $wayId 路径id
     * @return array
     */
    public function delete(int $wayId): array;

    /**
     * 咨询助理列表
     *
     * @param string $keyword 搜索关键词
     * @return array
     */
    public function getUserList(string $keyword): array;

    /**
     * 可选渠道列表
     *
     * @param string $keyword 搜索关键词
     * @return array
     */
    public function getChannelList(string $keyword): array;

    /**
     * 下载活码
     *
     * @param int $way_id
     * @return void
     */
    public function downloadQrCode(int $way_id): void;
}
