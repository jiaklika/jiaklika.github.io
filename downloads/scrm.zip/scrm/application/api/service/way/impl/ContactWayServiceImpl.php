<?php

namespace app\api\service\way\impl;

use app\api\dao\http\contact\ContactWayHttpDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\dao\mysql\user\UserDao;
use app\api\dao\mysql\way\WayUserMapDao;
use app\api\service\user\impl\UserServiceImpl;
use app\api\service\way\ContactWayService;
use app\api\util\HttpClient;
use app\common\model\ContactWays;
use app\common\model\User;
use Exception;
use think\Db;

/**
 * Class ContactWayServiceImpl
 * @package app\api\service\way\impl
 */
class ContactWayServiceImpl implements ContactWayService
{
    use HttpClient;

    /**
     * @var ContactWayHttpDao
     */
    private static $contactWayHttpDao;

    /**
     * ContactWayServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$contactWayHttpDao)) {
            self::$contactWayHttpDao = new ContactWayHttpDao();
        }
    }

    /**
     * 路径列表
     *
     * @param array $requestData 请求数据
     * @return array
     * @throws Exception
     */
    public function index(array $requestData): array
    {
        [
            $limit,
            $page,
        ] = [
            $requestData['limit'],
            $requestData['page'],
        ];

        $where = [
            'is_deleted' => 0,
            'scene'      => $requestData['scene']
        ];

        // 咨询助理
        if (
            isset($requestData['user_id'])
            && $requestData['user_id'] !== ''
        ) {
            $where['b.user_id'] = $requestData['user_id'];
        }

        // 渠道
        if (
            isset($requestData['channel_id'])
            && !empty($requestData['channel_id'])
        ) {
            $where['channel_id'] = $requestData['channel_id'];
        }

        // 关键词
        if (
            isset($requestData['way_keyword'])
            && !empty($requestData['way_keyword'])
        ) {
            $where['way_name|a.id'] = ['like', '%' . $requestData['way_keyword'] . '%'];
        }

        // 创建时间
        if (
            isset($requestData['create_time_start'])
            && !isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
        ) {
            $where['create_time'] = ['>', $requestData['create_time_start']];
        }

        if (
            isset($requestData['create_time_end'])
            && !isset($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['create_time'] = ['<', $requestData['create_time_end']];
        }

        if (
            isset($requestData['create_time_start'])
            && isset($requestData['create_time_end'])
            && !empty($requestData['create_time_start'])
            && !empty($requestData['create_time_end'])
        ) {
            $where['create_time'] = ['between', [$requestData['create_time_start'], $requestData['create_time_end']]];
        }

        $getModel = function () use ($where) {
            return Db::name('contact_ways')
                ->alias('a')
                ->join(
                    'scrm_way_user_map b',
                    'a.id = b.way_id',
                    'left'
                )
                ->field(
                    '
                a.id,
                way_name,
                channel_id,
                config_id,
                create_time,
                qr_code,
                (SELECT group_concat(scrm_way_user_map.user_id) FROM 
                scrm_way_user_map WHERE scrm_way_user_map.way_id = a.id) as user_id'
                )
                ->where($where)
                ->group('a.id');
        };

        $wayCount = $getModel()->count();

        $wayInfoArr = (array)$getModel()
            ->page($page, $limit)
            ->order('a.id desc')
            ->select();

        if ($wayInfoArr) {
            // 咨询助理名称-begin
            $allUserIdArr = $newUserInfo = $newChannelInfo = [];

            foreach ($wayInfoArr as &$wayInfo) {
                $wayInfo['user_id'] = explode(',', $wayInfo['user_id']);
                $allUserIdArr = array_merge($allUserIdArr, $wayInfo['user_id']);
            }

            $allUserIdArr = array_unique($allUserIdArr);

            $userInfo = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $allUserIdArr]]);

            foreach ($userInfo as $user) {
                $newUserInfo[$user['userid']] = $user['name'];
            }
            // 咨询助理名称-end

            // 渠道名称
            $channelIdArr = array_column($wayInfoArr, 'channel_id');

            $channelInfo = ContactChannelsDao::getAllList(['id', 'channel_name'], ['id' => ['in', $channelIdArr]]);

            if ($channelInfo) {
                foreach ($channelInfo as $channel) {
                    $newChannelInfo[$channel['id']] = $channel['channel_name'];
                }
            }
            // end

            array_walk($wayInfoArr, function (&$val) use ($newUserInfo, $newChannelInfo) {
                $val['total'] = ContactFollowUserDao::getCount(['state' => $val['id']]) ?: 0;
                $allUserNameArr = [];
                foreach ($val['user_id'] as $userId) {
                    $allUserNameArr[] = $newUserInfo[$userId] ?? '';
                }
                $val['user_name'] = implode(',', $allUserNameArr);

                $val['channel_name'] = $newChannelInfo[$val['channel_id']] ?? '';
                unset($val['user_id'], $val['channel_id'], $totalContact, $newUserInfo, $newChannelInfo);
            });
        }

        return [
            'list'  => $wayInfoArr,
            'count' => $wayCount
        ];
    }

    /**
     * 路径详情
     *
     * @param int $wayId
     * @return array
     * @throws Exception
     */
    public function detail(int $wayId): array
    {
        $fields = ['way_name', 'channel_id', 'qr_code'];

        $contactWayInfo = ContactWaysDao::getDetail($fields, ['id' => $wayId]);

        $userIdArr = WayUserMapDao::getAllList(['user_id'], ['way_id' => $wayId]);

        $contactWayInfo['user_id'] = array_column($userIdArr, 'user_id');

        return $contactWayInfo;
    }

    /**
     * 添加路径
     *
     * @param array $requestData 请求数据
     * @return array
     * @throws Exception
     */
    public function add(array $requestData): array
    {
        [
            $wayName,   // 路径名称
            $channelId, // 渠道id
            $userIdArr, // 咨询助理
            $scene,     // 场景
        ] = [
            $requestData['way_name'],
            $requestData['channel_id'],
            $requestData['user_id'],
            $requestData['scene']
        ];

        $wayInsertData = [
            'way_name'   => $wayName,
            'channel_id' => $channelId,
            'scene'      => $scene,
        ];

        if ($scene == 1) {
            $wayInsertData['style'] = 2;
        }

        if (count($userIdArr) > 1) {
            $wayInsertData['type'] = 2;
        }

        $notExistUserStr = '';

        $userInfo = UserDao::getAllList(
            [
                'id',
                'userid'
            ],
            [
                'userid'     => ['in', $userIdArr],
                'is_deleted' => 0
            ]
        );
        $existUserIdArr = array_column($userInfo, 'userid');

        foreach ($userIdArr as $userId) {
            if (!in_array($userId, $existUserIdArr)) {
                $notExistUserStr .= $userId . ',';
            }
        }

        if ($notExistUserStr) {
            return [false, trim($notExistUserStr, ',') . '不存在'];
        }

        Db::StartTrans();

        // 获取路径自增id
        $wayId = ContactWaysDao::addData($wayInsertData, true);

        if (!$wayId) {
            Db::rollback();
            return [false, '新建联系我路径失败！'];
        }

        $mapInsertData = [];
        foreach ($userIdArr as $userId) {
            $mapInsertData[] = [
                'way_id'  => $wayId,
                'user_id' => $userId
            ];
        }

        $wayUserInsertRes = WayUserMapDao::addBatchData($mapInsertData);

        // 请求企业微信接口，添加联系我方式
        // wayId是state
        $wayInfo = self::$contactWayHttpDao->addContactWay($wayId, $userIdArr, $scene);

        // 请求成功，更新数据
        if ($wayInfo['config_id']) {
            $updateData['config_id'] = $wayInfo['config_id'];

            if ($scene == 2) { // 二维码
                $updateData['qr_code'] = $wayInfo['qr_code'];
            }

            $updateRes = ContactWaysDao::updateData($updateData, [
                'id' => $wayId
            ]);

            if ($updateRes !== false && $wayUserInsertRes) {
                Db::commit();
                return [true,'新建联系我路径成功！'];
            }
        }

        Db::rollback();
        return [false, '配置客户联系「联系我」方式失败！'];
    }

    /**
     * 更新路径
     *
     * @param array $updateData
     * @return array
     * @throws Exception
     */
    public function update(array $updateData): array
    {
        $updateRes = ContactWaysDao::updateData([
            'way_name' => $updateData['way_name']
        ], [
            'id' => $updateData['way_id']
        ]);
        if ($updateRes) {
            return [true, '更新路径成功！'];
        }

        return [false, '更新路径失败！'];
    }

    /**
     * 删除路径
     *
     * @param int $wayId 路径自增id
     * @return array
     * @throws Exception
     */
    public function delete(int $wayId): array
    {
        $wayInfo = ContactWaysDao::getDetail(
            ['config_id'],
            [
                'id'         => $wayId,
                'is_deleted' => 0
            ]
        );

        $configId = $wayInfo['config_id'];

        if (!$configId) {
            return [false, '此记录不存在或已删除！'];
        }

        // 先企业微信直接删除
        $delApiRes = self::$contactWayHttpDao->delContactWay($configId);

        if ($delApiRes == 0) {
            // 成功后再软删除
            Db::startTrans();
            $delSqlRes = ContactWaysDao::deleteById($wayId);
            $delMapRes = WayUserMapDao::hardDelete(['way_id' => $wayId]);

            if ($delSqlRes !== false && $delMapRes) {
                Db::commit();
                return [true, '删除路径成功！'];
            }

            Db::rollback();
        }

        return [false, '删除路径失败！'];
    }

    /**
     * 咨询助理列表
     *
     * @param string|null $keyword
     * @return array
     * @throws Exception
     */
    public function getUserList(?string $keyword): array
    {
        $userService = new UserServiceImpl();

        $userService->updateFollowUserList();

        return UserDao::getAllList(
            [
                'userid',
                'name'
            ],
            [
                'is_follow_user' => User::IS_FOLLOW_USER,
                'is_deleted'     => User::NOT_DELETED,
                'userid|name'    => ['like', '%' . $keyword . '%']
            ]
        );
    }

    /**
     * 可选的渠道列表
     *
     * @param string|null $keyword
     * @return array
     * @throws Exception
     */
    public function getChannelList(?string $keyword): array
    {
        $where = [
            'is_deleted'   => 0,
        ];

        if ($keyword) {
            $where['channel_name'] = ['like', '%' . $keyword . '%'];
        }

        $channelData = ContactChannelsDao::getAllList(
            [
                'id',
                'channel_name'
            ],
            $where
        );
        $unknownChannel = [
            'id'           => 0,
            'channel_name' => '未知'
        ];

        array_unshift($channelData, $unknownChannel);
        return $channelData;
    }

    /**
     * 下载二维码
     *
     * @param int $way_id
     * @throws Exception
     */
    public function downloadQrCode(int $way_id): void
    {
        $wayInfo = ContactWaysDao::getDetail(
            [
                'qr_code',
                'way_name',
                'user_id'
            ],
            [
                'id'         => $way_id,
                'is_deleted' => 0
            ]
        );

        $saveName = sprintf('%s_%s.png', $wayInfo['way_name'], $wayInfo['user_id']);

        self::downloadRemoteFileToLocal($wayInfo['qr_code'], $saveName);

        $savePath = 'public/downloads/' . $saveName;

        if (!file_exists($savePath)) {
            throw new Exception('文件不存在！');
        } else {
            // 打开文件
            $file = fopen($savePath, "r");
            // 输入文件标签
            Header("Content-type: application/octet-stream");
            Header("Accept-Ranges: bytes");
            Header("Accept-Length: " . filesize($savePath));
            Header("Content-Disposition: attachment; filename=" . $saveName);
            echo fread($file, filesize($savePath));
            fclose($file);
            @unlink($savePath);
        }
    }

    /**
     * 根据配置ID返回联系我类型
     *
     * @param string|null $configId
     * @return array
     * @throws Exception
     */
    public function getConfigType(?string $configId): array
    {
        $contactWayInfo = ContactWaysDao::getDetail(
            ['type'],
            [
                'config_id'  => $configId,
                'is_deleted' => ContactWays::NOT_DELETED
            ]
        );

        if (!isset($contactWayInfo['type']) || empty($contactWayInfo['type'])) {
            return ['error_msg' => '此配置ID不存在'];
        }

        return [
            'config_type' => $contactWayInfo['type']
        ];
    }
}
