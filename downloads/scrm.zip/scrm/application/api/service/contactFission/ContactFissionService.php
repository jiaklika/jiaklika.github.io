<?php

namespace app\api\service\contactFission;

interface ContactFissionService
{

}
