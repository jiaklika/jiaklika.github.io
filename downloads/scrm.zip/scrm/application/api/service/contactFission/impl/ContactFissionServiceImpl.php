<?php

namespace app\api\service\contactFission\impl;

use app\api\dao\http\contact\ContactWayHttpDao;
use app\api\dao\mysql\contact\ContactFissionRecordsDao;
use app\api\service\contactFission\ContactFissionService;
use app\api\util\FileManager;
use app\common\model\ContactFissionRecords;
use Exception;
use think\Cache;

class ContactFissionServiceImpl implements ContactFissionService
{
    /**
     * 生成邀请码
     *
     * @param string $unionId
     * @return array
     * @throws Exception
     */
    public function getInvitationCode(string $unionId): array
    {
        if (
            $fissionData = ContactFissionRecordsDao::getDetail(
                [
                    'id',
                    'image_url',
                    'media_create_at',
                    'media_id'
                ],
                [
                    'unionid' => $unionId
                ]
            )
        ) {
            return [
                'id'          => $fissionData['id'],
                'create_time' => $fissionData['media_create_at'],
                'media_url'   => $fissionData['image_url'],
                'media_id'    => $fissionData['media_id']
            ];
        }

        $addUser = [
            'yiyi'
        ];

        $contactWayHttpDao = new ContactWayHttpDao();

        $wayData = $contactWayHttpDao->addContactWay($unionId, $addUser, 2);

        $fileManager = new FileManager();

        $fissionInfo = $fileManager->handleAndSaveFissionCode($wayData['qr_code']);

        // 谁生成了二维码，存起来
        $fissionRecord = [
            'config_id'       => $wayData['config_id'],
            'qr_code'         => $wayData['qr_code'],
            'unionid'         => $unionId,
            'image_url'       => $fissionInfo['media_url'] ?? '',
            'media_id'        => $fissionInfo['media_id'] ?? '',
            'media_create_at' => $fissionInfo['media_create_at'] ?? 0,
        ];

        $insertId = ContactFissionRecordsDao::addData($fissionRecord, true);

        return [
            'id'          => (int)$insertId,
            'create_time' => $fissionInfo['media_create_at'] ?? 0,
            'media_url'   => $fissionInfo['media_url'] ?? '',
            'media_id'    => $fissionInfo['media_id'] ?? ''
        ];
    }

    /**
     * 修改结束时间
     *
     * @param $endTime
     */
    public function changeEndTime($endTime)
    {
        try {
            $redis = Cache::store()->handler();
            $redis->set(ContactFissionRecords::REDIS_KEY_FISSION_END_TIME, $endTime);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
        }
    }
}
