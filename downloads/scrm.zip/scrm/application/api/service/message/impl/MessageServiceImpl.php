<?php

declare(strict_types=1);

namespace app\api\service\message\impl;

use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactStatisticHttpDao;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\message\InfoHttpDao;
use app\api\dao\http\message\MessageHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\liveData\VideoLiveTaskDao;
use app\api\dao\mysql\media\TemporaryMediaDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\contact\impl\ContactServiceImpl;
use app\api\service\message\MessageService;
use app\api\service\user\impl\UserServiceImpl;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\TemporaryMedia;
use Carbon\Carbon;
use Exception;
use think\Cache;
use think\Db;
use think\File;
use think\Log;
use think\Queue;

/**
 * Class MessageServiceImpl
 * @package app\api\service\message\impl
 */
class MessageServiceImpl implements MessageService
{
    /**
     * @var $messageHttpDao
     */
    private static $messageHttpDao;

    /**
     * MessageServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$messageHttpDao)) {
            self::$messageHttpDao = new MessageHttpDao();
        }
    }

    /**
     * 发送知乎日报数据到用户
     *
     * @param array $toUser
     * @return bool
     * @throws Exception
     */
    public function sendZhiHuDailyNews(array $toUser): bool
    {
        $infoHttpDao = new InfoHttpDao();

        $news = $infoHttpDao->getZhiHuDailyNews();

        $articles = [];

        if ($news) {
            $stories = $news['stories'];

            foreach ($stories as $story) {
                $articles['articles'][] = [
                    'title'       => $story['title'],
                    'description' => $story['hint'],
                    'url'         => $story['url'],
                    'picurl'      => $story['images'][0] ?? ''
                ];
            }
        }

        if ($articles) {
            self::$messageHttpDao->sendMessage('news', $articles, $toUser);
        }

        return true;
    }

    /**
     * 发送客户统计数据
     *
     * @param array $toUser
     * @return bool
     * @throws Exception
     */
    public function sendBehaviorData(array $toUser): bool
    {
        $yesterday = Carbon::yesterday()->getTimestamp();

        $contactStatisticHttpDao = new ContactStatisticHttpDao();

        $behaviorDataArr = $contactStatisticHttpDao->getUserBehaviorData(['yangyang1'], [], $yesterday, $yesterday);

        $behaviorData = $behaviorDataArr[0];

        $behaviorDataDate = date('Y-m-d', $behaviorData['stat_time']);

        $content['content'] =
        "{$behaviorDataDate}宝姐家阳阳1联系客户统计数据
    >聊天总数：{$behaviorData['chat_cnt']}条 
    >发送消息数：{$behaviorData['message_cnt']}条
    >发起申请数：{$behaviorData['new_apply_cnt']}人 
    >新增客户数：{$behaviorData['new_contact_cnt']}人
    >已回复聊天占比：{$behaviorData['reply_percentage']}%
    >平均首次回复时长：{$behaviorData['avg_reply_time']}分钟
    >删除/拉黑成员的客户数：{$behaviorData['negative_feedback_cnt']}人";

        self::$messageHttpDao->sendMessage('markdown', $content, $toUser);

        return true;
    }

    /**
     * 发送统计数据
     *
     * @param array $toUser
     * @param int $sendType
     * @return bool
     * @throws Exception
     */
    public function sendStatisticsData(array $toUser, int $sendType): bool
    {
        // 上周一
        $lastWeekMonday = Carbon::now()->subWeek()->startOfWeek()->toDateString();
        // 上周日
        $lastWeekSunday = Carbon::now()->subWeek()->endOfWeek()->toDateString();

        $userServiceImpl = new UserServiceImpl();

        $userIdArr1 = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $userIdArr2 = [
            'baojiejoyee',
            'fuliguan',
            'xiuxiu',
            'taotao'
        ];

        $handleUserInfo = function ($userIdArr) {
            $newUserArr = [];

            $userInfoArr = UserDao::getAllList(['userid', 'name'], ['userid' => ['in', $userIdArr]]);

            foreach ($userInfoArr as $user) {
                $newUserArr[$user['userid']] = ['name' => $user['name']];
            }

            return $newUserArr;
        };

        $userArr = $handleUserInfo($userIdArr1);
        $userArr2 = $handleUserInfo($userIdArr2);

        // $todayDate = date('Y-m-d');

        $content['content'] =
            "【{$lastWeekMonday}～{$lastWeekSunday}】企微客户数据";

        $contactService = new ContactServiceImpl();
        $redis = Cache::store()->handler();

        $sendMsg = function (
            $userArr,
            \Closure $getData,
            int $type
        ) use (
            $redis,
            $content,
            $toUser,
            $lastWeekMonday,
            $lastWeekSunday,
            $userServiceImpl
        ) {
            $contentStr = function (
                $statisticData,
                $userId = ''
            ) use (
                &$content,
                $redis,
                $lastWeekMonday,
                $lastWeekSunday,
                $userServiceImpl
            ) {
                $userLevel0 = $userId . '_level_0';
                $userLevel1 = $userId . '_level_1';
                $userLevel2 = $userId . '_level_2';
                $userLevel3 = $userId . '_level_3';
                $userLevel4 = $userId . '_level_4';
                $userLevel5 = $userId . '_level_5';
                $userLevel6 = $userId . '_level_6';

                $redis->select(11);

                $rate0 = get_rate((int)$redis->get($userLevel0), (int)$statisticData['validContactCount']);
                $rate1 = get_rate((int)$redis->get($userLevel1), (int)$statisticData['validContactCount']);
                $rate2 = get_rate((int)$redis->get($userLevel2), (int)$statisticData['validContactCount']);
                $rate3 = get_rate((int)$redis->get($userLevel3), (int)$statisticData['validContactCount']);
                $rate4 = $redis->get($userLevel4) ? : 0;
                $rate5 = $redis->get($userLevel5) ? : 0;
                $rate6 = $redis->get($userLevel6) ? : 0;

                $content['content'] .= "
>**累计客户数**：{$statisticData['allContactCount']}人
            >**当前客户数**：{$statisticData['validContactCount']}人
            >**较上周净增新人**：{$statisticData['lastWeekAgoCount']}人
            >**近7日留存率**：{$statisticData['sevenRetentionRate']}
            >**性别占比**：
            女性：{$statisticData['genderRate']['femaleRate']}
            男性：{$statisticData['genderRate']['maleRate']}
            未知：{$statisticData['genderRate']['unknownRate']}
            >**当前客户等级占比**：
            新人：{$rate0}
            宝迷：{$rate1}
            忠实宝迷：{$rate2}
            铁杆宝迷：{$rate3}
            名媛：{$rate4}人
            风尚名媛：{$rate5}人
            至尊名媛：{$rate6}人
            >**当前客户消费占比**：
            ";

                $priceSegmentArr = ContactHttpDao::PRICE_SEGMENT_ARR;

                foreach ($priceSegmentArr as $key => $price) {
                    $rate = get_rate(
                        (int)$redis->get($userId . '_' . $price),
                        (int)$statisticData['validContactCount']
                    );

                    if (in_array($key, [12, 13, 14, 15, 16])) {
                        $numFor1000 = ($countFor1000 = $redis->get($userId . '_' . $price))
                            ? $countFor1000 . '人'
                            : '-';

                        $content['content'] .= "{$price}：{$numFor1000}\n";
                    } else {
                        $content['content'] .= "{$price}：{$rate}\n";
                    }
                }

                return $content;
            };

            $newContent = [];

            if ($type == 1) { // type为1是个人数据，为2是公司数据，3是费月（泛社群）汇总数据，4是赵蔚（电商）汇总
                foreach ($userArr as $userId => $user) {
                    $statisticData = $getData($userId);

                    $content['content'] .= "
>**顾问号**：<font color='warning'>{$user['name']}</font>";

                    $newContent = $contentStr($statisticData, $userId);
                }
            }
            if ($type == 2) {
                $statisticData = $getData();

                // 公司统计数据
                $content['content'] = "<font color='warning'>【{$lastWeekMonday}～{$lastWeekSunday}】 公司企微客户数据概览</font>";
                $newContent = $contentStr($statisticData, 'company');
            }

            /*if ($type == 3) {
                $feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue');
                $statisticData = $getData($feiyueAccountsArr);

                $content['content'] .= "
>**顾问号**：<font color='warning'>泛社群号汇总</font>";

                $newContent = $contentStr($statisticData, 'feiyue');
            }*/

            if ($type == 4) {
                $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei');
                $statisticData = $getData($zhaoweiAccountsArr);

                $content['content'] .= "
>**顾问号**：<font color='warning'>电商号汇总</font>";

                $newContent = $contentStr($statisticData, 'zhaowei');
            }

            try {
                self::$messageHttpDao->sendMessage('markdown', $newContent, $toUser);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }

            sleep(1);
        };

        switch ($sendType) {
            case 1:
                // 费月汇总
                /*$sendMsg(['feiyue'], function ($userId) use ($contactService) {
                    return $contactService->getStatisticsData($userId);
                }, 3);*/

                // 赵蔚汇总
                $sendMsg(['zhaowei'], function ($userId) use ($contactService) {
                    return $contactService->getStatisticsData($userId);
                }, 4);

                // 公司数据
                $sendMsg([], function () use ($contactService) {
                    return $contactService->getCompanyStatisticsData();
                }, 2);
                break;

            case 2:
                $chunkUserArr = count($userArr) > 2
                    ? array_chunk($userArr, 2, true)
                    : $userArr;

                foreach ($chunkUserArr as $twoUserArr) {
                    $sendMsg($twoUserArr, function ($userId) use ($contactService) {
                        return $contactService->getStatisticsData([$userId]);
                    }, 1);
                }
                break;

            case 3:
                $chunkUserArr2 = count($userArr2) > 2
                    ? array_chunk($userArr2, 2, true)
                    : $userArr2;

                foreach ($chunkUserArr2 as $twoUserArr2) {
                    $sendMsg($twoUserArr2, function ($userId) use ($contactService) {
                        return $contactService->getStatisticsData([$userId]);
                    }, 1);
                }
                $sendMsg([], function () use ($contactService) {
                    return $contactService->getCompanyStatisticsData();
                }, 2);
                break;

            case 4:
                $chunkUserArr = count($userArr) > 2
                    ? array_chunk($userArr, 2, true)
                    : $userArr;

                foreach ($chunkUserArr as $twoUserArr) {
                    $sendMsg($twoUserArr, function ($userId) use ($contactService) {
                        return $contactService->getStatisticsData([$userId]);
                    }, 1);
                }
                $chunkUserArr2 = count($userArr2) > 2
                    ? array_chunk($userArr2, 2, true)
                    : $userArr2;

                foreach ($chunkUserArr2 as $twoUserArr2) {
                    $sendMsg($twoUserArr2, function ($userId) use ($contactService) {
                        return $contactService->getStatisticsData([$userId]);
                    }, 1);
                }
                // 费月汇总
                /*$sendMsg(['feiyue'], function ($userId) use ($contactService) {
                    return $contactService->getStatisticsData($userId);
                }, 3);*/

                // 赵蔚汇总
                $sendMsg(['zhaowei'], function ($userId) use ($contactService) {
                    return $contactService->getStatisticsData($userId);
                }, 4);

                // 公司数据
                $sendMsg([], function () use ($contactService) {
                    return $contactService->getCompanyStatisticsData();
                }, 2);
                break;
        }

        return true;
    }

    /**
     * Excel任务进入队列
     *
     * @throw Exception
     * @return bool
     * @throws Exception
     */
    public function excelDataToRedis(): bool
    {
        $redis = Cache::store()->handler();

        // “是否在过新粉群”为【进过优享群前进入过新粉群】的用户-begin

        // 新粉福利群全部成员进入redis
        $newFansGroup = ContactGroupDao::getAllList(['chat_id'], [
            'name' => ['like', "%新粉福利%"]
        ]);

        $newFansGroupChatIdArr = array_column($newFansGroup, 'chat_id');

        $newFansUnionIdArr = Db::name('contact_group_members')
            ->field([
                'unionid',
                'join_time'
            ])
            ->where([
                'chat_id' => ['in', $newFansGroupChatIdArr],
                'unionid' => ['<>', ''],
                'type'    => ContactGroupMembers::EXTERNAL_USER
            ])
            ->order('join_time')
            ->group('unionid')
            ->select();

        pipeline($redis, function ($redis) use ($newFansUnionIdArr) {
            foreach ($newFansUnionIdArr as $unionIdArr) {
                $redis->hset(
                    ContactGroupMembers::NEW_FANS_ALL_UNION_ID_KEY,
                    $unionIdArr['unionid'],
                    $unionIdArr['join_time']
                );
            }
        });

        // 好物优享群
        $goodStuffGroup = ContactGroupDao::getAllList(['chat_id'], [
            'name' => ['like', "%好物优享%"]
        ]);

        pipeline($redis, function ($redis) use ($goodStuffGroup) {
            foreach ($goodStuffGroup as $groupIdArr) {
                $redis->sadd(ContactGroupMembers::GOOD_STUFF_ALL_GROUP_ID_KEY, $groupIdArr['chat_id']);
            }
        });
        // “是否在过新粉群”为【进过优享群前进入过新粉群】的用户-end

        // 队列名
        $jobQueue = 'generate_group_excel_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\excel\GroupExcelJob';

        $redis = Cache::store()->handler();

        if ($redis->get(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME) != null) {
            $redis->incr(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME);
        } else {
            $redis->set(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME, 1);
        }

        $getAllGroup = function (array $ownerArr = [], array $invalidGroup = []) {
            return ContactGroupDao::getAllList(
                [
                    'chat_id',
                    'name'
                ],
                [
                    'is_deleted' => ContactGroups::NOT_DELETED,
                    'name'       => ['<>', ''],
                    'owner' => [
                        'in',
                        $ownerArr
                    ],
                    'chat_id' => [
                        'not in',
                        $invalidGroup
                    ]
                ]
            );
        };

        $userServiceImpl = new UserServiceImpl();

        $zhaoweiAccountsArr = $userServiceImpl->getSpecificUserAccount('zhaowei');

        $allGroup = $getAllGroup(
            $zhaoweiAccountsArr,
            [
                'wr5b2CBwAAnYmIQ6G3k_koY3j4uG_KLQ', // 没有群名
                'wr5b2CBwAA-d4G974F9d5revqLkWgpUg', // 测试2群
                'wr5b2CBwAAQ7GhGLc7M_HN3SSa809EDg',
                'wr5b2CBwAAzrDKRrL870hLXCL6usiwoQ',
                'wr5b2CBwAARIIj-BBwpJFHUPlAgwpdTw',
                'wr5b2CBwAAQMFAkqCzYHfxbAN5WPJEQw',
                'wr5b2CBwAAFaBmuSrgGy9Xdvj-ser2dA',
                'wr5b2CBwAAtUO2xo6AfaJR93D2yS6sLQ',
                'wr5b2CBwAAcw0nwTbaDh-tlOFYDoiHTA',
                'wr5b2CBwAAmmCPr7gAN0E7ENXVVSzSbA',
                'wr5b2CBwAAgQe5ltcx0gS-NS9zPDOFZQ'
            ]
        );

        /*$feiyueAccountsArr = $userServiceImpl->getSpecificUserAccount('feiyue');
        $allGroup = $getAllGroup(
            $feiyueAccountsArr,
            [
                'wr5b2CBwAAZbyVHoYfD5dAH87QZVy2yA',
            ]
        );*/

        foreach ($allGroup as $group) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $group, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }

        return true;
    }

    /**
     * 汇总表数据进入redis
     */
    public function summaryExcelDataToRedis(): bool
    {
        $redis = Cache::store()->handler();

        // 新粉福利群全部成员进入redis-begin
        $newFansGroup = ContactGroupDao::getAllList(['chat_id'], [
            'name' => ['like', "%新粉福利%"]
        ]);

        $newFansGroupChatIdArr = array_column($newFansGroup, 'chat_id');

        $newFansUnionIdArr = Db::name('contact_group_members')
            ->field([
                'unionid',
                'join_time'
            ])
            ->where([
                'chat_id' => ['in', $newFansGroupChatIdArr],
                'unionid' => ['<>', ''],
                'type'    => ContactGroupMembers::EXTERNAL_USER
            ])
            ->order('join_time')
            ->group('unionid')
            ->select();

        pipeline($redis, function ($redis) use ($newFansUnionIdArr) {
            foreach ($newFansUnionIdArr as $unionIdArr) {
                $redis->hset(
                    ContactGroupMembers::NEW_FANS_ALL_UNION_ID_KEY,
                    $unionIdArr['unionid'],
                    $unionIdArr['join_time']
                );
            }
        });
        // 新粉福利群全部成员进入redis-end

        $allGroup = [];

        $cacheGroupId = function ($groupName, $keyName) use ($redis, &$allGroup) {
            $groupIdArr = ContactGroupDao::getAllList(['chat_id'], [
                'name' => ['like', "%{$groupName}%"]
            ]);

            if ($redis->sCard($keyName) == 0) {
                pipeline($redis, function ($redis) use ($groupIdArr, $keyName) {
                    foreach ($groupIdArr as $groupIdArr) {
                        $redis->sadd($keyName, $groupIdArr['chat_id']);
                    }
                });
            }
            $allGroup[] = [
                'group_name' => $groupName,
                'key_name'   => $keyName
            ];
        };

        // 新粉福利群
        $cacheGroupId('宝姐家新粉福利', ContactGroupMembers::NEW_FANS_ALL_GROUP_ID_KEY);
        // 好物优享群
        $cacheGroupId('好物优享', ContactGroupMembers::GOOD_STUFF_ALL_GROUP_ID_KEY);
        // 宝姐饰界福利秒杀
        $cacheGroupId('宝姐饰界福利秒杀', ContactGroupMembers::ORNAMENTS_WELFARE_ALL_GROUP_ID_KEY);
        // 好物专享
        $cacheGroupId('宝姐家好物专享', ContactGroupMembers::GOOD_STUFF_VIP_ALL_GROUP_ID_KEY);
        // 官方福利
        $cacheGroupId('官方福利', ContactGroupMembers::COMPANY_DISCOUNT_ALL_GROUP_ID_KEY);

        // 队列名
        $jobQueue = 'generate_summary_group_excel_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\excel\SummaryGroupExcelJob';

        $redis = Cache::store()->handler();

        if ($redis->get(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME) != null) {
            $redis->incr(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME);
        } else {
            $redis->set(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME, 1);
        }

        foreach ($allGroup as $group) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $group, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }

        return true;
    }

    /**
     * 发送Excel
     *
     * @param array $toUser
     * @return bool
     * @throws Exception
     */
    public function sendExcel(array $toUser): bool
    {
        $redis = Cache::store()->handler();

        $activityCount = $redis->get(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME);

        /*print_r($activityCount);
        die;*/
        /*$getAllGroup = function (array $ownerArr, array $invalidGroup)
        {
            return ContactGroupDao::getAllList(
                [
                    'chat_id',
                    'name'
                ],
                [
                    'is_deleted' => ContactGroups::NOT_DELETED,
                    'owner' => [
                        'in',
                        $ownerArr
                    ],
                    'chat_id' => [
                        'not in',
                        $invalidGroup
                    ]
                ]
            );
        };

        /*$allGroup = $getAllGroup(
            [
                'yangyang1',
                'yangyang123'
            ],
            [
                'wr5b2CBwAAnYmIQ6G3k_koY3j4uG_KLQ', // 没有群名
                'wr5b2CBwAA-d4G974F9d5revqLkWgpUg', // 测试2群
                'wr5b2CBwAAQ7GhGLc7M_HN3SSa809EDg',
                'wr5b2CBwAAzrDKRrL870hLXCL6usiwoQ',
                'wr5b2CBwAARIIj-BBwpJFHUPlAgwpdTw',
                'wr5b2CBwAAQMFAkqCzYHfxbAN5WPJEQw'
            ]
        );*/

        /*$allGroup = $getAllGroup(
            [
                'mengmeng',
                'kefuxiaoxiao',
                'yunyingkefu'
            ],
            [
                'wr5b2CBwAAMOUk3QkDkZyhg3DbahLrAw', // 没有群名
                'wr5b2CBwAAL9KNLfUqKz2oIrrNPi1F2w',
                'wr5b2CBwAAJ2f0uQm72Nfut96AfuBjYw',
                'wr5b2CBwAA01DVKj6BaMRdE7RS01v1GA',
                'wr5b2CBwAAZbyVHoYfD5dAH87QZVy2yA',
                'wr5b2CBwAAdO_mXWWGreK7lVgL0r1ASg'
            ]
        );

        [
            $todayDate,
            $yesterday,     // 昨天0点时间戳
            $today,          // 今天0点时间戳
            $lastWeekBeginTime, // 上周一
            $lastWeekEndTime,   // 本周一
            $twoWeeksAgoBeginTime,
            $twoWeeksAgoEndTime,
        ] =
        [
            date('Y-m-d'),
            strtotime(date("Y-m-d",strtotime("-1 day"))),
            strtotime(date("Y-m-d")),
            strtotime('-2 sunday +1 day'),
            strtotime( 'this week Monday'),
            strtotime('-3 sunday +1 day'),
            strtotime( 'this week Monday'),
        ];


        // 20个一组
        $chunkResult = array_chunk($allGroup, 20);

        foreach ($chunkResult as $key => $groupChunk)
        {
            $content = [];
            $index = $key+1;

            $content['content'] =
                "{$todayDate} 客户群统计数据概览{$index}";

            foreach ($groupChunk as $group)
            {
                $allCount = ContactGroupMembersDao::getCount(
                    [
                        'chat_id'    => $group['chat_id'],
                        'is_deleted' => 0
                    ]
                );

                $yesterdayCount = ContactGroupMembersDao::getCount(
                    [
                        'chat_id'    => $group['chat_id'],
                        'is_deleted' => 0,
                        // 'join_time'  => ['between', [$yesterday, $today]] // 昨日新增人数
                        'join_time'  => ['between', [$lastWeekBeginTime, $lastWeekEndTime]] // 上周新增人数
                        // 'join_time'  => ['between', [$twoWeeksAgoBeginTime, $twoWeeksAgoEndTime]] // 上2周新增人数
                    ]
                );

                $content['content'] .= "
>**群名**：{$group['name']}
            >**总人数**：{$allCount}人
            >**上2周进群人数**：{$yesterdayCount}人
            \n";
            }

            try {
                // self::$messageHttpDao->sendMessage('markdown', $content, $toUser);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
        }*/

        // 发送文件
        $mediaInfo = TemporaryMediaDao::getAllList(
            [
                'media_id'
            ],
            [
                'activity_id' => $activityCount,
                'media_name'  => ['<>', ''],
                'id'          => ['between', [121, 150]]
            ]
        );

        $mediaArr = array_column($mediaInfo, 'media_id');

        foreach ($mediaArr as $media) {
            $fileInfo['media_id'] = $media;

            try {
                self::$messageHttpDao->sendMessage(
                    'file',
                    $fileInfo,
                    $toUser
                );
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
            sleep(1);
        }

        return true;
    }

    /**
     * 发送汇总Excel
     *
     * @param array $toUser
     * @param int $sendType
     * @return bool
     * @throws Exception
     */
    public function sendSummaryExcel(array $toUser, int $sendType): bool
    {
        $redis = Cache::store()->handler();

        $activityCount = $redis->get(TemporaryMedia::ACTIVITY_COUNT_CACHE_NAME);

        /*print_r($activityCount);
        die;*/

        $where = [
            'activity_id' => $activityCount,
            'id'          => ['between', [1, 4]]
        ];

        if ($sendType == 2) {
            $where['id'] = 5;
        }

        // 发送文件
        $mediaInfo = TemporaryMediaDao::getAllList(
            [
                'media_id'
            ],
            $where
        );

        $mediaArr = array_column($mediaInfo, 'media_id');

        foreach ($mediaArr as $media) {
            $fileInfo['media_id'] = $media;

            try {
                self::$messageHttpDao->sendMessage(
                    'file',
                    $fileInfo,
                    $toUser
                );
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
            sleep(1);
        }

        return true;
    }


    /**
     * #123 用户运营社群消费数据统计2
     * 数据进入redis
     * https://bojem.coding.net/p/scrm/backlog/issues/123
     *
     * @return bool
     * @throws Exception
     */
    public function specialGroupDataToRedis(): bool
    {
        $redis = Cache::store()->handler();
        // 队列名
        $jobQueue = 'count_special_group_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\SpecialGroupJob';

        $writeRedisClosure = function (
            $groupName,
            $groupKeyName,
            $userId = ''
        ) use (
            $redis,
            $jobQueue,
            $jobHandler
        ) {

            if (!$userId) {
                $groupList = ContactGroupDao::getAllList(
                    [
                        'chat_id'
                    ],
                    [
                        'name'       => ['like', "%{$groupName}%"],
                        'is_deleted' => ContactGroups::NOT_DELETED
                    ]
                );

                if (empty($groupList)) {
                    return false;
                }

                // 总群数
                $redis->set($groupKeyName . '_group_num_count', 0);
                $redis->set($groupKeyName . '_group_member_count', 0);

                $redis->set($groupKeyName . '_group_num_count', count($groupList));

                $chatIdArr = array_column($groupList, 'chat_id');

                foreach ($chatIdArr as $value) {
                    // 群的全部人员
                    $allGroupMemberArr = ContactGroupMembersDao::getAllList(
                        [
                            'userid',
                            'unionid'
                        ],
                        [
                            'chat_id'    => $value,
                            'is_deleted' => ContactGroupMembers::NOT_DELETED,
                            'type'       => ContactGroupMembers::EXTERNAL_USER
                        ]
                    );

                    // 总人数
                    $redis->incr($groupKeyName . '_group_member_count', count($allGroupMemberArr));

                    foreach ($allGroupMemberArr as $member) {
                        $member['key_name'] = $groupKeyName;
                        try {
                            // 推送到队列
                            $isPushed = Queue::push($jobHandler, $member, $jobQueue);

                            if ($isPushed !== false) {
                                continue;
                            }
                        } catch (Exception $e) {
                            Log::error('队列出错：' . $e->getMessage());
                            return false;
                        }
                    }
                }
            } else {
                $userServiceImpl = new UserServiceImpl();
                $userIdArr = $userServiceImpl->getSpecificUserAccount($userId, false);

                $groupList = ContactGroupDao::getAllList(
                    [
                        'chat_id'
                    ],
                    [
                        'owner'      => ['in', $userIdArr],
                        'is_deleted' => ContactGroups::NOT_DELETED
                    ]
                );


                // 总群数
                $redis->set($groupKeyName . '_group_num_count', 0);
                $redis->set($groupKeyName . '_group_member_count', 0);

                $redis->set($groupKeyName . '_group_num_count', count($groupList));

                $allGroupMemberArr = (array)Db::name('contact_group_members')
                    ->alias('member')
                    ->field([
                        'member.unionid',
                        'member.userid',
                    ])
                    ->join(
                        'scrm_contact_groups groups',
                        'member.chat_id = groups.chat_id',
                        'LEFT'
                    )
                    ->where([
                        'owner'             => ['in', $userIdArr],
                        'groups.is_deleted' => ContactGroups::NOT_DELETED,
                        'member.is_deleted' => ContactGroupMembers::NOT_DELETED,
                        'member.type'       => ContactGroupMembers::EXTERNAL_USER
                    ])
                    ->group('member.unionid')
                    ->select();

                // 总人数
                $redis->incr($groupKeyName . '_group_member_count', count($allGroupMemberArr));

                foreach ($allGroupMemberArr as $member) {
                    $member['key_name'] = $groupKeyName;
                    try {
                        // 推送到队列
                        $isPushed = Queue::push($jobHandler, $member, $jobQueue);

                        if ($isPushed !== false) {
                            continue;
                        }
                    } catch (Exception $e) {
                        Log::error('队列出错：' . $e->getMessage());
                        return false;
                    }
                }
            }

            return true;
        };

        $writeRedisClosure('好物优享', 'good_stuff');
        $writeRedisClosure('宝姐家新粉福利', 'new_fans');
        $writeRedisClosure('宝姐饰界福利秒杀', 'ornaments_welfare');
        $writeRedisClosure('宝姐家好物专享', 'good_stuff_vip');
        $writeRedisClosure('电商社群汇总', 'online_summary', 'zhaowei');


        return true;
    }

    /**
     * 发送购买率
     *
     * @param array $toUser
     * @throws Exception
     */
    public function sendSpecialGroupData(array $toUser)
    {
        $sendGroupDataClosure = function ($groupName, $groupIndex) use ($toUser) {
            $todayDate = date('Y-m-d');
            $redis = Cache::store()->handler();

            $content['content'] =
                "{$todayDate} 【<font color='warning'>{$groupName}</font>】";

            [
                $allGroupMemberCount,  // 总人数
                $contractAmount,        // 客户数
                $last_week_buy_count,   // 上周购买人数
                $last_week_buy_count_group, // 上周群聊购买人数
                $last_week_buy_count_platform_1, // 上周用户运营商品购买总人数
                $last_week_buy_count_platform_1_group // 上周用户运营商品群聊购买人数
            ] =
            [
                $redis->get($groupIndex . '_group_member_count') ? : 0,
                $redis->get($groupIndex . '_contract_amount') ? : 0,
                $redis->get($groupIndex . '_last_week_buy_count') ? : 0,
                $redis->get($groupIndex . '_last_week_buy_count_group') ? : 0,
                $redis->get($groupIndex . '_last_week_buy_count_platform_1') ? : 0,
                $redis->get($groupIndex . '_last_week_buy_count_platform_1_group') ? : 0
            ];

            [
                $rate1,
                $rate2,
                $rate3,
                $rate4,
                $rate5
            ] =
            [
                get_rate($contractAmount, $allGroupMemberCount),
                get_rate($last_week_buy_count, $allGroupMemberCount),
                get_rate($last_week_buy_count_group, $allGroupMemberCount),
                get_rate($last_week_buy_count_platform_1, $allGroupMemberCount),
                get_rate($last_week_buy_count_platform_1_group, $allGroupMemberCount)
            ];

            $content['content'] .= "
>**总群数**：{$redis->get($groupIndex.'_group_num_count')}个
            >**总人数**：{$allGroupMemberCount}人
            >**客户数（消费过的）**：{$contractAmount}人
            >**客户占比**：$rate1
            >**当前客户消费**：
            ";

            $priceSegmentArr = ContactHttpDao::PRICE_SEGMENT_ARR;

            foreach ($priceSegmentArr as $key => $price) {
                $rate = get_rate(
                    (int)$redis->get($groupIndex . '_' . $price),
                    (int)$allGroupMemberCount
                );

                if (in_array($key, [13, 14, 15, 16, 17])) {
                    $numFor1000 = ($countFor1000 = $redis->get($groupIndex . '_' . $price))
                        ? $countFor1000 . '人'
                        : '-';

                    $content['content'] .= "{$price}：{$numFor1000}\n";
                } else {
                    $content['content'] .= "{$price}：{$rate}\n";
                }
            }

            $content['content'] .= ">**上周购买人数**：{$last_week_buy_count}人
            >**购买率**：$rate2
            >**上周群聊购买人数**：{$last_week_buy_count_group}人
            >**群聊购买率**：$rate3
            >**上周用户运营商品购买总人数**：{$last_week_buy_count_platform_1}人
            >**购买率**：$rate4
            >**上周用户运营商品群聊购买人数**：{$last_week_buy_count_platform_1_group}人
            >**群聊购买率**：$rate5
            \n";

            try {
                self::$messageHttpDao->sendMessage('markdown', $content, $toUser);
            } catch (Exception $e) {
                throw new Exception($e->getMessage());
            }
        };

        $sendGroupDataClosure('好物优享群', 'good_stuff');
        $sendGroupDataClosure('宝姐家新粉福利群', 'new_fans');
        $sendGroupDataClosure('宝姐饰界福利秒杀群', 'ornaments_welfare');
        $sendGroupDataClosure('宝姐家好物专享群', 'good_stuff_vip');
        $sendGroupDataClosure('电商社群汇总', 'online_summary');
    }

    /**
     * 发送视频号直播进群统计
     *
     * @param array $toUser
     * @return bool
     * @throws Exception
     */
    public function sendMsg(array $toUser): bool
    {
        $redis = Cache::store()->handler();

        // 当天13点
        // 下午1点的不发
        $ignoreTime = strtotime(date('Y-m-d 19:29:00'));
        $now = time();

        if ($now < $ignoreTime) {
            return true;
        }

        $currentTime = date('Y-m-d H:i:s');
        $content = [];

        $groupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'  => ['like', "%进群看群公告%"]
            ]
        );

        $groupArr = array_column($groupList, 'chat_id');

        $beginTime = strtotime('2021-02-01 19:00:00');

        $allMember = Db::name('contact_group_members')
            ->distinct(true)
            ->field(['unionid'])
            ->where([
                'chat_id'   => ['in', $groupArr],
                'join_time' => ['>=', $beginTime],
                'type'      => ContactGroupMembers::EXTERNAL_USER
                //'is_deleted' => 0
            ])
            ->select();

        $unionIdArr = array_column((array)$allMember, 'unionid');

        $allCount = count($unionIdArr);

        $todayDate = date('Y-m-d');

        $rateClosure = function ($part, $all) {
            if ($all == 0) {
                return '0%';
            }
            return sprintf("%01.2f%%", ($part / $all) * 100);
        };

        $newbie = $redis->get($todayDate . '-newbie') ? : 0;
        $other1 = $redis->get($todayDate . '-other1') ? : 0;
        $other2 = $redis->get($todayDate . '-other2') ? : 0;
        $other3 = $redis->get($todayDate . '-other3') ? : 0;

        $rate = $rateClosure($newbie, $allCount);

        $content['content'] =
            "{$todayDate} 视频号直播社群数据统计";

        $content['content'] .= "
>**<font color='warning'>累计进群</font>**：{$allCount}人
            >**<font color='warning'>累计公域</font>**：{$newbie}人  **占比**：{$rate}
            >**<font color='warning'>非公域且仅在该群</font>**：{$other1}人
            >**<font color='warning'>非公域且不在福利社群</font>**：{$other2}人
            >**<font color='warning'>非公域且不在初级转化社群</font>**：{$other3}人
            \n
统计时间：{$currentTime} （每半小时统计一次）";

        /*$content['content'] .= "
>**<font color='warning'>累计进群</font>**：{$allCount}人
            >**<font color='warning'>累计公域</font>**：{$newbie}人  **占比**：{$rate}\n
统计时间：{$currentTime} （每半小时统计一次）";*/

        try {
            self::$messageHttpDao->sendMessage('markdown', $content, $toUser);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return true;
    }

    /**
     * 发送视频号直播进群统计
     *
     * @param array $toUser
     * @return bool
     * @throws Exception
     */
    public function sendVideoMsg(array $toUser): bool
    {
        $videoLiveInfo = VideoLiveTaskDao::getDetail([
            'live_id',
            'way_id',
            'start_time',
            'end_time'
        ], [
            'is_handle' => 0
        ]);

        if (!$videoLiveInfo) {
            return true;
        }

        /*// 测试数据
        $videoLiveInfo = [
            'live_id'    => 1,
            'way_id'     => 337,
            'start_time' => strtotime('2022-01-20 13:00:00'),
            'end_time'   => strtotime('2022-01-20 18:10:00')
        ];*/

        $beginTime = $videoLiveInfo['start_time'];
        $beginTimeDate = date('Y-m-d H:i:s', $beginTime);

        // 直播开始15分钟后再发
        $beginDelayTime = 800;
        $beginIgnoreTime = $beginTime + $beginDelayTime;

        $now = time();

        if ($now < $beginIgnoreTime) {
            return true;
        }

        // 直播结束15分钟后再停
        $endDelayTime = 1000;
        $endIgnoreTime = $videoLiveInfo['end_time'] + $endDelayTime;

        if ($now > $endIgnoreTime) {
            VideoLiveTaskDao::updateData([
                'is_handle' => 1,
            ], [
                'live_id' => $videoLiveInfo['live_id']
            ]);
            return true;
        }

        $currentData = date('Y-m-d');
        $currentTime = date('Y-m-d H:i:s');
        $content = [];

        $webHookHttpDao = new WebHookHttpDao();
        $contactHttpDao = new ContactHttpDao();

        $passMinutes = round(($now - $beginTime) / 60);

        $purchaseRes = $webHookHttpDao->getPurchaseData((int)$passMinutes);

        $purchaseData = $purchaseRes['data'];

        // 弹窗数据
        [$popupAddWay, $popupUserIdArr] = [10,
            [
                'yangyang1',
                'yangyang3'
            ]
        ];

        /**
         * 当前直播加了多少客户
         *
         * @param int $state 客户路径
         * @param false $isFirst 是否首次添加
         * @return int|void
         * @throws Exception
         */
        $getUserCount = function (
            int $state = 0,
            bool $isFirst = false
        ) use (
            $beginTime,
            $popupAddWay,
            $popupUserIdArr
        ) {
            if ($state) { // 截屏添加
                $where = [
                    'state'      => $state,
                    'createtime' => ['>=', $beginTime]
                ];
            } else { // 弹窗添加
                $where = [
                    'add_way'    => $popupAddWay,
                    'userid'     => ['in', $popupUserIdArr],
                    'createtime' => ['>=', $beginTime]
                ];
            }

            if ($isFirst) {
                $where['is_first_add'] = 1;
            }

            $allFollowUsers = ContactFollowUserDao::getAllList(['external_userid'], $where);

            $allExternalUserId = array_column($allFollowUsers, 'external_userid');

            if (!$isFirst) {
                return count($allExternalUserId);
            } else {
                // 以前进过群
                $groupMembers = ContactGroupMembersDao::getAllList([
                    'userid'
                ], [
                    'userid'    => ['in', $allExternalUserId],
                    'join_time' => ['<=', $beginTime]
                ]);
                $groupMembersUserId = array_column($groupMembers, 'userid');
                // 去除
                return count(array_diff($allExternalUserId, $groupMembersUserId));
            }
        };

        // 直播开始前不在企微（没有好友记录且有过进群记录）里的人数
        $newbieCount = 0;
        // 上面这些人直播开始前加好友或进群的人数
        $newbieScanJoinCount = $newbiePopupJoinCount = 0;

        if ($purchaseData['new_union_id']) {
            // 直播开始前有记录的
            $allContact = ContactDao::getAllList(
                ['unionid'],
                [
                    'unionid'     => ['in', $purchaseData['new_union_id']],
                    'create_time' => ['<', $beginTimeDate]
                ]
            );

            $allContactUnionIdArr = array_column($allContact, 'unionid');
            // 新客中去除有好友记录的
            $notContactUnionIdArr = array_diff($purchaseData['new_union_id'], $allContactUnionIdArr);

            $notContactCount = count($notContactUnionIdArr);

            $allGroupMemberCount = 0;
            $allGroupMemberUnionIdArr = [];

            if ($notContactUnionIdArr) {
                $allGroupMemberArr = ContactGroupMembersDao::getAllList(
                    ['unionid'],
                    [
                        'unionid'   => ['in', $notContactUnionIdArr],
                        'join_time' => ['<', $beginTime],
                        'type'      => ContactGroupMembers::EXTERNAL_USER
                    ]
                );

                $allGroupMemberUnionIdArr = array_column($allGroupMemberArr, 'unionid');

                $allGroupMemberCount = count($allGroupMemberUnionIdArr);
            }
            // 再去除直播开始前在群里的
            $newbieCount = $notContactCount - $allGroupMemberCount;
            // 再去除直播开始前关注过公众号和授权小程序的
            $restUnionIdArr = array_diff($notContactUnionIdArr, $allGroupMemberUnionIdArr);

            $filterUnionIdArr = array_filter($restUnionIdArr, function ($v) use ($contactHttpDao, $beginTime) {
                $authTime = $contactHttpDao->getFirstAuthorizeTime($v);
                if ($authTime['gzh'] == false && $authTime['xxx'] == false) {
                    return true;
                }
                if ($authTime['gzh'] < $beginTime && $authTime['xxx'] < $beginTime) {
                    return false;
                }
                if ($authTime['gzh'] > $beginTime && $authTime['xxx'] > $beginTime) {
                    return true;
                }
                return false;
            });

            $newbieCount = $newbieCount - count($filterUnionIdArr);

            // 新客（非企微）中进了企微的人数
            $newbieUnionIdArr = array_diff($notContactUnionIdArr, $allGroupMemberUnionIdArr);

            $newbieUnionIdArr = array_diff($newbieUnionIdArr, $filterUnionIdArr);

            /**
             * @param array $extraWhere
             * @return int|string
             * @throws Exception
             */
            $getAddWayCount = function (array $extraWhere = []) use ($newbieUnionIdArr, $beginTimeDate) {
                $originWhere = [
                    'unionid'       => ['in', $newbieUnionIdArr],
                    'b.create_time' => ['>=', $beginTimeDate]
                ];
                return Db::name('contact_follow_user')
                    ->alias('a')
                    ->join(
                        'external_contact b',
                        'a.external_userid = b.external_userid',
                        'left'
                    )
                    ->where(array_merge($originWhere, $extraWhere))
                    ->group('b.unionid')
                    ->count();
            };

            // 新客扫码添加的人数
            $newbieScanJoinCount = $getAddWayCount([
                'state' => $videoLiveInfo['way_id']
            ]);
            // 新客弹窗添加的人数
            $newbiePopupJoinCount = $getAddWayCount([
                'userid'  => ['in', $popupUserIdArr],
                'add_way' => $popupAddWay
            ]);
        }

        // 截屏扫码
        if ($videoLiveInfo['way_id']) {
            $scanCount = $getUserCount($videoLiveInfo['way_id']);
            $firstScanCount = $getUserCount($videoLiveInfo['way_id'], true);
            $scanRate = get_rate($firstScanCount, $scanCount);
        } else {
            $scanCount = $firstScanCount = 0;
            $scanRate = '0.00%';
        }

        // 弹窗添加
        $popupCount = $getUserCount();
        $firstPopupCount = $getUserCount(0, true);
        $popupRate = get_rate($firstPopupCount, $popupCount);
        // 客服添加
        /*$serviceCount = $getUserCount(11);
        $firstServiceCount = $getUserCount(11, true);

        // 截屏扫码和客服添加
        $scanCount = $scanCount + $serviceCount;
        $firstScanCount = $firstScanCount + $firstServiceCount;
        $scanRate = get_rate($firstScanCount, $scanCount);*/

        // 总添加
        $totalCount = $scanCount + $popupCount;
        $totalFirstCount = $firstScanCount + $firstPopupCount;
        $totalRate = get_rate($totalFirstCount, $totalCount);

        // 购物袋
        /*$shoppingBagCount = $getUserCount(157);
        $firstShoppingBagCount = $getUserCount(157, true);
        $shoppingBagRate = get_rate($firstShoppingBagCount, $shoppingBagCount);*/

        /*$content['content'] = "
><font color='warning'>$currentData 【视频号直播实时数据】</font>
>－－－－－－－－－－－－添加企微数据－－－－－－－－－－－－
>**截屏扫码添加**：{$scanCount}人 **首次添加**：{$firstScanCount}人 **占比**：{$scanRate}
>**购物袋添加**：{$shoppingBagCount}人 **首次添加**：{$firstShoppingBagCount}人 **占比**：{$shoppingBagRate}
>－－－－－－－－－－－－-购买数据－－－－－－－－－－－－
>**购买人数**：{$purchaseData['buy_number']}人 **新客**：{$purchaseData['new_user_number']}人
>**<font color='info'>商品购买数据</font>：**
>**总单数**：{$purchaseData['order_number']}单";*/

        $content['content'] = "
><font color='warning'>$currentData 【视频号直播实时数据】</font>
><font color='info'>添加企微数据</font>
>总添加：{$totalCount}人，首次添加：{$totalFirstCount}人，占比：{$totalRate}
>截屏扫码和客服添加：{$scanCount}人，首次添加：{$firstScanCount}人，占比：{$scanRate}
>弹窗添加：{$popupCount}人，首次添加：{$firstPopupCount}人，占比：{$popupRate}";
/*><font color='info'>购买数据</font>
>购买人数：{$purchaseData['buy_number']}人，新客：{$purchaseData['new_user_number']}人，其中公域新客：{$newbieCount}人，公域新客截屏和客服添加企微人数：{$newbieScanJoinCount}人，公域新客弹窗添加企微人数：{$newbiePopupJoinCount}人";*/

        /*$orderContent['content'] = "
><font color='info'>商品购买数据</font>
>总单数：{$purchaseData['order_number']}单，总金额：{$purchaseData['order_money']}";

        foreach ($purchaseData['goods'] as $value) {
            $goodName = preg_replace('/[\*]+/', '', $value['goods_name']);

            $orderContent['content'] .= "
            >{$goodName}：{$value['order_number']}单，新客单：{$value['new_user_number']}单";
        }

        $newbieContent['content'] = "
><font color='info'>新客购买数据</font>
>新客总单数：{$purchaseData['new_user_order_number']}单，总金额：{$purchaseData['new_user_order_money']}";

        foreach ($purchaseData['new_user_goods'] as $newbieValue) {
            $newbieGoodName = preg_replace('/[\*]+/', '', $newbieValue);

            $newbieContent['content'] .= "
            >{$newbieGoodName}";
        }*/

        $content['content'] .= "
        \n
统计时间：{$currentTime} （每15分钟统计一次）";

        try {
            self::$messageHttpDao->sendMessage('markdown', $content, $toUser);
            /*sleep(1);
            self::$messageHttpDao->sendMessage('markdown', $orderContent, $toUser);
            sleep(1);
            self::$messageHttpDao->sendMessage('markdown', $newbieContent, $toUser);*/
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return true;
    }


    /**
     * @param array $toUser
     * @throws Exception
     */
    public function sendMsg123(array $toUser)
    {
        $contactHttpDao = new ContactHttpDao();

        $currentTime = date('Y-m-d H:i:s');
        $content = [];

        $groupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'  => ['like', "%进群看群公告%"]
            ]
        );

        $groupArr = array_column($groupList, 'chat_id');

        $beginTime = strtotime('2021-01-04 19:00:00');

        $allMember = ContactGroupMembersDao::getAllList(
            ['unionid'],
            [
                'chat_id'   => ['in', $groupArr],
                'join_time' => ['>', $beginTime],
                'type'      => ContactGroupMembers::EXTERNAL_USER
                //'is_deleted' => 0
            ]
        );

        $unionIdArr = array_column($allMember, 'unionid');

        $allCount = count($unionIdArr);

        static $newbie = 0;

        /*static $zero = 0;
        static $one = 0;
        static $two = 0;
        static $three = 0;
        static $four = 0;
        static $five = 0;
        static $six = 0;*/

        foreach ($unionIdArr as $unionId) {
            $appLastLoginTime = $contactHttpDao->getAppLastLoginTime($unionId);

            // APP登录时间
            $appLogin = $appLastLoginTime['app_last_login'];

            $liveRankData = $contactHttpDao->getLiveRank($unionId);

            // 珠宝登录时间
            $baojieLogin = $liveRankData['last_login'];

            $mediaData = $contactHttpDao->getYanzhi($unionId);

            // 媒体登录时间
            $mediaLogin = $mediaData['last_login'];
            // 颜值数
            $yanzhiCount = $mediaData['yanzhi_total'];

            if (
                $baojieLogin == 0
                && $mediaLogin === false
                && $appLogin == 0
                && $yanzhiCount == 0
            ) {
                $userCenterData = $contactHttpDao->getUserCenter($unionId);
                if ($userCenterData['consume_amount'] == 0) {
                    Log::info($unionId . '-是公域新人');
                    $newbie++;
                }
            }

            /*$userCenterData = $contactHttpDao->getUserCenter($unionId);

            switch ($userCenterData['user_level_id'])
            {
                case 0:
                default:
                    $zero++;
                    break;

                case 1:
                    $one++;
                    break;

                case 2:
                    $two++;
                    break;

                case 3:
                    $three++;
                    break;

                case 4:
                    $four++;
                    break;

                case 5:
                    $five++;
                    break;

                case 6:
                    $six++;
                    break;
            }*/
        }

        $todayDate = date('Y-m-d');

        $rateClosure = function ($part, $all) {
            if ($all == 0) {
                return '0%';
            }
            return sprintf("%01.2f%%", ($part / $all) * 100);
        };

        $rate = $rateClosure($newbie, $allCount);

        /*$rate0 = $rateClosure($zero, $allCount);
        $rate1 = $rateClosure($one, $allCount);
        $rate2 = $rateClosure($two, $allCount);
        $rate3 = $rateClosure($three, $allCount);
        $rate4 = $rateClosure($four, $allCount);
        $rate5 = $rateClosure($five, $allCount);
        $rate6 = $rateClosure($six, $allCount);*/

        $content['content'] =
            "{$todayDate} 视频号直播社群数据统计";

        /*$content['content'] .= "
>**<font color='warning'>累计进群</font>**：{$allCount}人
            >**<font color='warning'>累计公域</font>**：{$newbie}人  **占比**：{$rate}
            >**<font color='warning'>等级画像（不包含小商店）</font>**：
            新人：{$rate0}
            宝迷：{$rate1}
            忠实宝迷：{$rate2}
            铁杆宝迷：{$rate3}
            名媛：{$rate4}
            风尚名媛：{$rate5}
            至尊名媛：{$rate6}
            \n
统计时间：{$currentTime} （每半小时统计一次）";*/

        $content['content'] .= "
>**<font color='warning'>累计进群</font>**：{$allCount}人
            >**<font color='warning'>累计公域</font>**：{$newbie}人  **占比**：{$rate}\n
统计时间：{$currentTime} （每半小时统计一次）";

        try {
            self::$messageHttpDao->sendMessage('markdown', $content, $toUser);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * 1、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过个人号和进过其他群的人数；
    2、剔除公域的人，剩余的人中筛出仅在“进群看公告”这种类别群里的，未添加过阳阳、阳阳1个人号和进过阳阳、阳阳1其他群的人数；
     * @return bool
     * @throws Exception
     */
    public function sendGroupData10()
    {
        $redis = Cache::store()->handler();
        // 队列名
        $jobQueue = 'count_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\CountJob';

        $groupList = ContactGroupDao::getAllList(
            [
                'chat_id'
            ],
            [
                'name'  => ['like', "%进群看群公告%"],
            ]
        );

        if (empty($groupList)) {
            return false;
        }

        $chatIdArr = array_column($groupList, 'chat_id');

        $beginTime1 = strtotime('2021-01-04 19:00:00');
        $endTime1 = strtotime('2021-01-04 22:00:00');

        foreach ($chatIdArr as $value) {
            // 群的全部人员
            $allGroupMemberArr = ContactGroupMembersDao::getAllList(
                [
                    'userid',
                    'unionid'
                ],
                [
                    'chat_id'    => $value,
                    // 'is_deleted' => 0,
                    //'type'       => 2,
                    'join_time'  => ['between', [$beginTime1, $endTime1]]
                ]
            );

            foreach ($allGroupMemberArr as $member) {
                //$redis->incr('group_member_count');
                try {
                    // 推送到队列
                    $isPushed = Queue::push($jobHandler, $member, $jobQueue);

                    if ($isPushed !== false) {
                        continue;
                    }
                } catch (Exception $e) {
                    Log::error('队列出错：' . $e->getMessage());
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 公司全部社群人数进入redis
     *
     * @throws Exception
     */
    public function allGroupWriteToRedis()
    {
        $redis = Cache::store()->handler();
        // 队列名
        $jobQueue = 'count_group_queue';
        // 队列处理类
        $jobHandler = 'app\api\job\count\CountGroupJob';

        // 所有的群
        $groupList = ContactGroupDao::getAllList(
            [
                'name',
                'chat_id'
            ],
            [
                'is_deleted' => ContactGroups::NOT_DELETED,
                'owner'      => ['not in', ['chebin', 'lvjunyan']],
                'name'       => ['<>', '']
            ]
        );

        if (empty($groupList)) {
            return false;
        }

        $redis->set('company_group_num_count', count($groupList));

        $chatIdArr = array_column($groupList, 'chat_id');

        // 群的全部人员
        $allGroupMemberArr = Db::name('contact_group_members')
            ->distinct(true) // 去重
            ->field(['unionid'])
            ->where([
                'chat_id'    => ['in', $chatIdArr],
                'is_deleted' => ContactGroupMembers::NOT_DELETED,
                'type'       => ContactGroupMembers::EXTERNAL_USER,
                //'unionid' => ['<>', '']
            ])
            ->select();

        $redis->set('company_group_member_count', count($allGroupMemberArr));

        foreach ($allGroupMemberArr as $member) {
            try {
                // 推送到队列
                $isPushed = Queue::push($jobHandler, $member, $jobQueue);

                if ($isPushed !== false) {
                    continue;
                }
            } catch (Exception $e) {
                Log::error('队列出错：' . $e->getMessage());
                return false;
            }
        }

        return true;
    }

    /**
     * 公司社群数据汇总
     *
     * @param array $toUsers
     * @throws Exception
     */
    public function sendAllGroupData(array $toUsers)
    {
        $todayDate = date('Y-m-d');
        $redis = Cache::store()->handler();

        $content['content'] =
            "{$todayDate} 【<font color='warning'>公司社群数据汇总</font>】";

        $allMemberCount = (int)$redis->get('company_group_member_count');

        $consumerRate = get_rate((int)$redis->get('company_contract_amount_count'), $allMemberCount);


        $userLevelRate0 = get_rate((int)$redis->get('zero'), $allMemberCount);
        $userLevelRate1 = get_rate((int)$redis->get('one'), $allMemberCount);
        $userLevelRate2 = get_rate((int)$redis->get('two'), $allMemberCount);
        $userLevelRate3 = get_rate((int)$redis->get('three'), $allMemberCount);

        $content['content'] .= "
>**总群数**：{$redis->get('company_group_num_count')}个
            >**总人数（去重）**：{$allMemberCount}人
            >**客户数（消费过的）**：{$redis->get('company_contract_amount_count')}人
            >**客户占比**：{$consumerRate}
            >**累计消费占比**：
            ";

        $priceSegmentArr = ContactHttpDao::PRICE_SEGMENT_ARR;

        foreach ($priceSegmentArr as $key => $price) {
            $rate = get_rate(
                (int)$redis->get('company_' . $price),
                (int)$allMemberCount
            );

            if (in_array($key, [13, 14, 15, 16, 17])) {
                $numFor1000 = ($countFor1000 = $redis->get('company_' . $price))
                    ? $countFor1000 . '人'
                    : '-';

                $content['content'] .= "{$price}：{$numFor1000}\n";
            } else {
                $content['content'] .= "{$price}：{$rate}\n";
            }
        }

        $content['content'] .= ">**客户等级占比**：
            新人：{$userLevelRate0}
            宝迷：{$userLevelRate1}
            忠实宝迷：{$userLevelRate2}
            铁杆宝迷：{$userLevelRate3}
            名媛：{$redis->get('four')}人
            风尚名媛：{$redis->get('five')}人
            至尊名媛：{$redis->get('six')}人
            \n";

        try {
            self::$messageHttpDao->sendMessage('markdown', $content, $toUsers);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    /**
     * 发送文件
     *
     * @param File $file 文件实体
     * @param array $toUser 接收者数组
     * @return array
     * @throws Exception
     */
    public function sendFile(File $file, array $toUser): array
    {

        [$result, $uploadInfo] = uploadFile(
            $file
        );

        if ($result) {
            try {
                $realPath = $uploadInfo->getPathname();

                // 文件名
                $saveName = $uploadInfo->getSaveName();

                $mediaHttpDao = new MediaHttpDao();

                $uploadInfo = $mediaHttpDao->uploadMedia(MediaHttpDao::FILE, $realPath, $saveName);

                $fileInfo['media_id'] = $uploadInfo['media_id'];

                self::$messageHttpDao->sendMessage(
                    'file',
                    $fileInfo,
                    $toUser
                );
                // 删除本地文件
                @unlink($realPath);
                return [true, ''];
            } catch (Exception $e) {
                return [false, $e->getMessage()];
            }
        }
        return [false, '上传文件失败！'];
    }
}
