<?php

declare(strict_types=1);

namespace app\api\service\message;

/**
 * Interface MessageService
 * @package app\api\service\message
 */
interface MessageService
{
    /**
     * 发送知乎日报到用户
     *
     * @param array $toUser 接收的用户
     * @return bool
     */
    public function sendZhiHuDailyNews(array $toUser): bool;

    /**
     * @param array $toUser
     * @return bool
     */
    public function sendBehaviorData(array $toUser): bool;

    /**
     * 发送统计汇总数据
     *
     * @param array $toUser
     * @param int $sendType
     * @return bool
     */
    public function sendStatisticsData(array $toUser, int $sendType): bool;
}
