<?php

declare(strict_types=1);

namespace app\api\service\callback\impl;

use app\api\dao\http\user\UserHttpDao;
use app\api\dao\mysql\user\DepartmentDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\callback\CallbackService;
use app\common\model\CallbackLogs;
use Carbon\Carbon;
use Exception;

/**
 * 通讯录变更事件
 *
 * Class UserCallbackServiceImpl
 * @package app\api\service
 */
class UserCallbackServiceImpl extends CallbackService
{
    /**
     * @var string
     */
    public static $encodingAesKey;

    /**
     * @var string
     */
    public static $token;

    /**
     * @var int 回调日志表主键
     */
    private $logId;

    /**
     * @var array 回调内容
     */
    private $content;

    /**
     * 处理回调事件
     *
     * @param int $logId
     * @param array $content
     * @return void
     * @throws Exception
     */
    public function handleData(int $logId, array $content)
    {
        $this->logId = $logId;
        $this->content = $content;

        switch ($this->content['ChangeType']) {
            case 'create_user':
                $this->createUser();
                break;

            case 'update_user':
                $this->updateUser();
                break;

            case 'delete_user':
                $this->deleteUser();
                break;

            case 'create_party':
                $this->createParty();
                break;

            case 'update_party':
                $this->updateParty();
                break;

            case 'delete_party':
                $this->deleteParty();
                break;
        }
    }

    /**
     * 新增成员事件
     *
     * @throws Exception
     */
    private function createUser()
    {
        $insertData = [
            'userid'            => $this->content['UserID'],
            'name'              => $this->content['Name'],
            'mobile'            => $this->content['Mobile'] ?? '',
            'department'        => $this->content['Department'],
            'position'          => $this->content['Position'] ?? '',
            'gender'            => $this->content['Gender'] ?? 0,
            'is_leader_in_dept' => $this->content['IsLeaderInDept'],
            'avatar'            => $this->content['Avatar'],
            'status'            => $this->content['Status'],
            'main_department'   => $this->content['MainDepartment'],
            'entry_time'        => $this->content['CreateTime']
        ];

        $this->updateCallbackLog($this->logId, CallbackLogs::USER, 'create_user', (int)UserDao::addData($insertData));
    }

    /**
     * 更新成员事件
     *
     * @throws Exception
     */
    private function updateUser()
    {
        $userHttpDao = new UserHttpDao();
        $userInfo = $userHttpDao->getUser($this->content['UserID']);

        $updateData = [
            'name'              => $userInfo['name'],
            'english_name'      => $userInfo['english_name'],
            'alias'             => $userInfo['alias'],
            'mobile'            => $userInfo['mobile'],
            'hide_mobile'       => $userInfo['hide_mobile'],
            'telephone'         => $userInfo['telephone'],
            'department'        => implode(',', $userInfo['department']),
            'order'             => implode(',', $userInfo['order']),
            'position'          => $userInfo['position'],
            'gender'            => $userInfo['gender'],
            'is_leader'         => $userInfo['isleader'],
            'is_leader_in_dept' => implode(',', $userInfo['is_leader_in_dept']),
            'avatar'            => $userInfo['avatar'],
            'thumb_avatar'      => $userInfo['thumb_avatar'],
            'qr_code'           => $userInfo['qr_code'],
            'status'            => $userInfo['status'],
            'main_department'   => $userInfo['main_department'],
            'email'             => $userInfo['email'],
            'address'           => $userInfo['address'] ?? '',
            'extattr'           => json_encode($userInfo['extattr'], JSON_UNESCAPED_UNICODE),
            'external_profile'  => isset($userInfo['external_profile'])
                ? json_encode(
                    $userInfo['external_profile'],
                    JSON_UNESCAPED_UNICODE
                )
                : '',
            'external_position' => isset($userInfo['external_position'])
                ? json_encode(
                    $userInfo['external_position'],
                    JSON_UNESCAPED_UNICODE
                )
                : '',
            'update_time'       => Carbon::createFromTimestamp($this->content['CreateTime'])->toDateTimeString()
        ];

        $updateRes = UserDao::updateData(
            $updateData,
            [
                'userid' => $this->content['UserID'],
            ]
        );

        $this->updateCallbackLog($this->logId, CallbackLogs::USER, 'update_user', $updateRes !== false ? 1 : 0);
    }

    /**
     * 删除成员事件
     *
     * @throws Exception
     */
    private function deleteUser()
    {
        $deleteRes = UserDao::updateData(
            [
                'is_deleted' => 1,
                'del_time'   => Carbon::createFromTimestamp($this->content['CreateTime'])->toDateTimeString()
            ],
            [
                'userid' => $this->content['UserID']
            ]
        );

        $this->updateCallbackLog($this->logId, CallbackLogs::USER, 'delete_user', $deleteRes !== false ? 1 : 0);
    }

    /**
     * 新增部门事件
     *
     * @throws Exception
     */
    private function createParty()
    {
        $insertData = [
            'department_id'       => $this->content['Id'],
            'department_name'     => $this->content['Name'],
            'department_parentid' => $this->content['ParentId'],
            'order'               => $this->content['Order'],
        ];

        $this->updateCallbackLog(
            $this->logId,
            CallbackLogs::USER,
            'create_party',
            (int)DepartmentDao::addData($insertData)
        );
    }

    /**
     * 更新部门事件
     *
     * @throws Exception
     */
    private function updateParty()
    {
        $updateData = [
            'update_time' => Carbon::createFromTimestamp($this->content['CreateTime'])->toDateTimeString()
        ];

        if (isset($this->content['Name'])) {
            $updateData['department_name'] = $this->content['Name'];
        }

        if (isset($this->content['ParentId'])) {
            $updateData['department_parentid'] = $this->content['ParentId'];
        }

        $updateRes = DepartmentDao::updateData(
            $updateData,
            [
                'department_id' => $this->content['Id'],
            ]
        );

        $this->updateCallbackLog($this->logId, CallbackLogs::USER, 'update_party', $updateRes !== false ? 1 : 0);
    }

    /**
     * 删除部门事件
     *
     * @throws Exception
     */
    private function deleteParty()
    {
        $deleteRes = DepartmentDao::updateData(
            [
                'is_deleted' => 1,
                'del_time'   => Carbon::createFromTimestamp($this->content['CreateTime'])->toDateTimeString()
            ],
            [
                'department_id' => $this->content['Id']
            ]
        );

        $this->updateCallbackLog($this->logId, CallbackLogs::USER, 'delete_party', $deleteRes !== false ? 1 : 0);
    }
}
