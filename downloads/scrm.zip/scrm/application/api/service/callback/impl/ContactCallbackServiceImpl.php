<?php

declare(strict_types=1);

namespace app\api\service\callback\impl;

use app\api\dao\http\contact\ContactGroupHttpDao;
use app\api\dao\http\contact\ContactHttpDao;
use app\api\dao\http\contact\ContactTagHttpDao;
use app\api\dao\http\contactFission\ContactFissionHttpDao;
use app\api\dao\http\media\MediaHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\contact\ContactDao;
use app\api\dao\mysql\contact\ContactFissionRecordsDao;
use app\api\dao\mysql\way\ChannelWelcomeMsgDao;
use app\api\dao\mysql\way\ContactChannelsDao;
use app\api\dao\mysql\contact\ContactFollowUserDao;
use app\api\dao\mysql\contact\ContactGroupDao;
use app\api\dao\mysql\contact\ContactGroupMembersDao;
use app\api\dao\mysql\contact\ContactTagMapDao;
use app\api\dao\mysql\contact\ContactTagsDao;
use app\api\dao\mysql\way\ContactWaysDao;
use app\api\service\callback\CallbackService;
use app\api\service\contactFission\impl\ContactFissionServiceImpl;
use app\api\service\user\impl\UserServiceImpl;
use app\api\util\FileManager;
use app\api\util\HttpClient;
use app\common\model\CallbackLogs;
use app\common\model\ContactChannels;
use app\common\model\ContactFissionRecords;
use app\common\model\ContactFollowUser;
use app\common\model\ContactGroupMembers;
use app\common\model\ContactGroups;
use app\common\model\ContactTags;
use app\common\model\ContactWays;
use app\common\model\ExternalContact;
use Carbon\Carbon;
use Exception;
use Opis\Closure\SerializableClosure;
use think\Cache;
use think\Db;
use think\Log;
use think\Queue;

/**
 * 企业客户（对外联系人）变更事件
 *
 * Class ContactCallbackServiceImpl
 *
 * @package app\api\service\callback\impl
 */
class ContactCallbackServiceImpl extends CallbackService
{
    use HttpClient;

    /**
     * @var ContactHttpDao
     */
    private static $contactHttpDao;

    /**
     * @var string
     */
    public static $encodingAesKey;

    /**
     * @var string
     */
    public static $token;

    /**
     * @var int 回调日志表主键
     */
    private $logId;

    /**
     * @var string 企业服务人员的UserID
     */
    private $userId;

    /**
     * @var string 外部联系人的UserID
     */
    private $externalUserId;

    /**
     * @var int 消息创建时间
     */
    private $createTime;

    /**
     * @var mixed 添加此用户的「联系我」方式配置的state参数，可用于识别添加此用户的渠道
     */
    private $state;

    /**
     * @var string 欢迎语code，可用于发送欢迎语
     */
    private $welcomeCode;

    /**
     * @var string 群ID
     */
    private $chatId;

    /*
     * @var string 消息类型
     */
    private $changeType;

    /**
     * @var string  标签或标签组的ID
     */
    private $tagId;

    /**
     * @var string 变更标签时，此项为tag，变更标签组时，此项为tag_group
     */
    private $tagType;

    /**
     * ContactCallbackServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$contactHttpDao)) {
            self::$contactHttpDao = new ContactHttpDao();
        }
    }

    /**
     * 处理客户变更事件
     *
     * @param  int   $logId   回调记录表主键ID
     * @param  array $content 回调内容
     * @return void
     * @throws Exception
     */
    public function handleData(int $logId, array $content)
    {
        $this->logId = $logId;
        // 消息创建时间（整型）
        $this->createTime = $content['CreateTime'];

        // 事件的类型，客户的增删改都是change_external_contact
        if ($content['Event'] == 'change_external_contact') {
            [
                $this->userId,         // 企业服务人员的UserID
                $this->externalUserId, // 外部联系人的UserID
                $this->changeType
            ] = [
                $content['UserID'],
                $content['ExternalUserID'],
                $content['ChangeType']
            ];

            switch ($content['ChangeType']) {
                case 'add_external_contact':
                case 'add_half_external_contact':
                    $this->state = $content['State'] ?? 0;
                    $this->welcomeCode = $content['WelcomeCode'] ?? null;
                    $this->addExternalContact($content);
                    break;

                case 'edit_external_contact': // 编辑企业客户事件
                    $this->editExternalContact();
                    break;

                case 'del_external_contact': // 删除企业客户事件
                    $this->delExternalContact();
                    break;

                case 'del_follow_user': // 删除跟进成员事件
                    $this->delFollowUser();
                    break;

                default:
                    $this->updateCallbackLog($this->logId, CallbackLogs::UNKNOWN, $content['ChangeType'], 0);
                    break;
            }
        }

        // 客户群事件
        if ($content['Event'] == 'change_external_chat') {
            $this->chatId = $content['ChatId'];

            switch ($content['ChangeType']) {
                case 'create':
                    $this->createExternalChat();
                    break;

                case 'dismiss':
                    $this->dismissExternalChat();
                    break;

                case 'update':
                default:
                    $groupContent = [
                        'update_detail' => $content['UpdateDetail'],
                        'quit_scene'    => $content['QuitScene'] ?? 0
                    ];
                    $this->updateExternalChat($groupContent);
                    break;
            }
        }

        // 企业客户标签事件
        if ($content['Event'] == 'change_external_tag') {
            [
                $this->tagId,
                $this->tagType
            ] = [
                $content['Id'],
                $content['TagType'] ?? 'tag'
            ];

            switch ($content['ChangeType']) {
                case 'create':
                    $this->createExternalTag();
                    break;

                case 'delete':
                    $this->deleteExternalTag();
                    break;

                case 'shuffle':
                    $this->shuffleExternalTag();
                    break;

                case 'update':
                default:
                    $this->updateExternalTag();
                    break;
            }
        }
    }

    /**
     * 添加企业客户事件
     * 两种情况：
     * 1、第一次添加
     * 2、删除后再次添加
     *
     * @param array $content 回调数据
     * @return void
     * @throws Exception
     */
    private function addExternalContact(array $content)
    {
        // 及时性高
        if (
            isset($content['State'])
            && $content['State'] == ContactWays::RECRUITING_OFFICER_ID
        ) {
            try {
                $contactHttpDao = new ContactHttpDao();
                $contactDetailArr = $contactHttpDao->getContactDetail($content['ExternalUserID'], false);
                $unionId = $contactDetailArr['external_contact']['unionid'] ?? '';
                if ($unionId) {
                    $redis = Cache::store()->handler();
                    $redis->set(
                        'asharer:' . $unionId,
                        1,
                        20
                    );
                }
            } catch (Exception $e) {
                send_msg_to_wecom($e->getMessage());
            }
        }

        // 根据state(way_id)寻找到预先设置的欢迎语
        // if ($this->state && $this->welcomeCode) {
        if ($this->welcomeCode) {
            $sendRes = $this->sendWelcomeMsg();
        }

        // 通过企业微信接口获取外部联系人详情并存表
        /*try {
            $contactDetailArr = self::$contactHttpDao->getContactDetail($this->externalUserId, false);
        } catch (Exception $e) {
            // 企业微信服务器在五秒内收不到响应会断掉连接，并且重新发起请求，总共重试三次。如果企业在调试中，发现成员无法收到被动回复的消息，可以检查是否消息处理超时。
            // 当接收成功后，http头部返回200表示接收ok，其他错误码企业微信后台会一律当做失败并发起重试。
            send_msg_to_wecom($e->getMessage());
            header('HTTP/1.1 404 Not Found');
            exit();
        }*/

        $updateCallbackLogFunc = function ($changeType, $isSuccess) {
            $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT, $changeType, $isSuccess);
        };

        $wrapper = new SerializableClosure($updateCallbackLogFunc);

        $content['func'] = serialize($wrapper);

        try {
            $content['random_index'] = $sendRes['random_index'] ?? 0;

            // 推送到队列
            Queue::push(
                ExternalContact::CALLBACK_ADD_CONTACT_HANDLER,
                $content,
                ExternalContact::CALLBACK_ADD_CONTACT_QUEUE
            );
        } catch (Exception $e) {
            send_msg_to_wecom('进入回调加客户队列出错：' . $e->getMessage());
        }
    }

    /**
     * 发送欢迎语
     *
     * @return false|int[]|void
     * @throws Exception
     */
    private function sendWelcomeMsg()
    {
        // 立即去获取客户详情
        $contactHttpDao = new ContactHttpDao();
        try {
            $contactDetailArr = $contactHttpDao->getContactDetail($this->externalUserId, false);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getTraceAsString());
            return false;
        }

        $externalContactArr = $contactDetailArr['external_contact'];
        $followUserArr = $contactDetailArr['follow_user'];

        $randomIndex = 0;
        /**
         * 根据渠道ID返回欢迎语
         *
         * @param int $channelId 渠道ID
         * @return array
         * @throws Exception
         */
        $getSendMsg = function (int $channelId) use (&$randomIndex): array {

            $channelFields = [
                'id',
                'is_open_welcome',     // 是否开启欢迎语 0-否 1-是
                'is_distinguish_time', // 是否区分时段 0-否 1-是
                'is_random'            // 是否随机发送欢迎语
            ];

            $channelWhere = [
                'id'         => $channelId,
                'is_deleted' => ContactChannels::NOT_DELETE
            ];

            // 从渠道表找出预置的欢迎语
            $channelInfo = ContactChannelsDao::getDetail($channelFields, $channelWhere);

            // 渠道存在且开启了欢迎语
            if ($channelInfo && $channelInfo['is_open_welcome'] == 1) {
                $newAttachmentsArr = [];
                // 寻找当前时间段的欢迎语
                $welcomeMsgFields = [
                    'id',
                    'welcome_text',
                    'attachments'
                ];

                $welcomeMsgWhere = [
                    'channel_id' => $channelInfo['id'],
                ];

                // 区分时段就添加时段搜索条件
                if ($channelInfo['is_distinguish_time']) {
                    $welcomeMsgWhere['is_working_time'] = is_work_time($this->createTime);
                }
                // 开启了随机发送欢迎语
                if ($channelInfo['is_random']) {
                    $randomIndexData = ChannelWelcomeMsgDao::getAllList(
                        [
                            'random_index'
                        ],
                        [
                            'channel_id' => $channelInfo['id']
                        ]
                    );
                    $randomIndexArr = array_column($randomIndexData, 'random_index');

                    $welcomeMsgWhere['random_index'] = $randomIndex = $randomIndexArr[array_rand($randomIndexArr)];
                }

                $welcomeMsgData = ChannelWelcomeMsgDao::getDetail($welcomeMsgFields, $welcomeMsgWhere);

                if ($attachmentsJson = $welcomeMsgData['attachments']) {
                    $attachmentsArr = json_decode($attachmentsJson, true);

                    $fileManager = new FileManager();

                    foreach ($attachmentsArr as $key => $attachment) {
                        switch ($attachment['welcome_type']) {
                            case 1:
                                $fileData = [
                                    'id'          => $welcomeMsgData['id'],
                                    'key'         => $key,
                                    'create_time' => $attachment['miniprogram_pic_create_time'],
                                    'media_url'   => $attachment['miniprogram_pic_url'],
                                    'media_id'    => $attachment['miniprogram_pic_media_id']
                                ];

                                $suffix = substr(
                                    $attachment['miniprogram_pic_url'],
                                    strrpos($attachment['miniprogram_pic_url'], '.') + 1
                                );

                                $newAttachmentsArr[$key]['msgtype'] = 'miniprogram';
                                $miniprogramPage = $attachment['miniprogram_page'];
                                if (strpos($miniprogramPage, '?')) {
                                    $miniprogramPage .= '&scrm=1';
                                } else {
                                    $miniprogramPage .= '?scrm=1';
                                }
                                $newAttachmentsArr[$key]['miniprogram'] = [
                                    'title'        => $attachment['miniprogram_title'],
                                    'pic_media_id' => $this->getMediaId(
                                        'image',
                                        $fileData,
                                        $suffix,
                                        $attachmentsArr,
                                        $fileManager
                                    ),
                                    'appid'        => $attachment['miniprogram_appid'],
                                    'page'         => $miniprogramPage
                                ];
                                break;

                            case 2:
                                $newAttachmentsArr[$key]['msgtype'] = 'image';
                                $newAttachmentsArr[$key]['image'] = [
                                    'pic_url' => $attachment['image_pic_url'],
                                ];
                                break;

                            case 3:
                                $newAttachmentsArr[$key]['msgtype'] = 'link';
                                $newAttachmentsArr[$key]['link'] = [
                                    'title'  => $attachment['link_title'],
                                    'picurl' => $attachment['link_pic_url'],
                                    'desc'   => $attachment['link_desc'],
                                    'url'    => $attachment['link_url']
                                ];
                                break;

                            case 4:
                                $videoData = [
                                    'id'          => $welcomeMsgData['id'],
                                    'key'         => $key,
                                    'create_time' => $attachment['video_media_create_at'],
                                    'media_url'   => $attachment['video_media_url'],
                                    'media_id'    => $attachment['video_media_id']
                                ];

                                $newAttachmentsArr[$key]['msgtype'] = 'video';
                                $newAttachmentsArr[$key]['video'] = [
                                    'media_id' => $this->getVideoMediaId(
                                        'video',
                                        $videoData,
                                        $attachmentsArr,
                                        $fileManager
                                    )
                                ];
                                break;

                            case 5:
                                $fileData = [
                                    'id'          => $welcomeMsgData['id'],
                                    'key'         => $key,
                                    'create_time' => $attachment['file_media_create_at'],
                                    'media_url'   => $attachment['file_media_url'],
                                    'media_id'    => $attachment['file_media_id'],
                                ];

                                $lastStr = strrchr($attachment['file_media_url'], '.');
                                $fileData['suffix'] = substr($lastStr, 1, strlen($lastStr) - 1);

                                $newAttachmentsArr[$key]['msgtype'] = 'file';
                                $newAttachmentsArr[$key]['file'] = [
                                    'media_id' => $this->getFileMediaId(
                                        'file',
                                        $fileData,
                                        $attachmentsArr,
                                        $fileManager
                                    )
                                ];
                                break;
                        }
                    }
                }
                return [$welcomeMsgData['welcome_text'], $newAttachmentsArr];
            }

            return ['', []];
        };

        $welcomeText = '';
        $newAttachmentsArr = [];
        if (
            $this->state === 0
        ) {
            // 视频号
            foreach ($followUserArr as $followUser) {
                if ($followUser['userid'] == $this->userId) {
                    // $wechatSource = $followUser['wechat_channels']['source'];
                    if (isset($followUser['wechat_channels'])) {
                        if ($followUser['wechat_channels']['nickname'] == '宝姐家') {
                            if (in_array($this->userId, ['yangyang123','yangyang3'])) {
                                [$welcomeText, $newAttachmentsArr] = $getSendMsg(197);
                            }
                            if (in_array($this->userId, ['xiaoshuo','xiaobao'])) {
                                [$welcomeText, $newAttachmentsArr] = $getSendMsg(214);
                            }
                        } else {
                            [$welcomeText, $newAttachmentsArr] = $getSendMsg(
                                array_search(
                                    $followUser['wechat_channels']['nickname'],
                                    ContactChannels::WECHAT_VIDEO_MAP
                                )
                            );
                        }
                    }
                    break;
                }
            }

            if (!$welcomeText) {
                if ($this->userId === 'youyou') {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(ContactChannels::YANGYANG7_VIDEO_LIVE_CHANNEL_ID);
                }

                /*if (in_array($this->userId, ['yangyang5', 'mengmeng'])) {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(ContactChannels::MENGMENG_CHANNEL_ID);
                }*/

                if ($this->userId == 'yangyang5') {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(ContactChannels::YANGYANG5_CHANNEL_ID);
                }

                if ($this->userId == 'yangyang123') {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(ContactChannels::YANGYANG2_CHANNEL_ID);
                }

                if ($this->userId === 'yangyang3') {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(ContactChannels::YANGYANG3_CHANNEL_ID);
                }
            }
        } elseif (strlen($this->state) > 20) { // 裂变
            $contactFissionHttpDao = new ContactFissionHttpDao();
            $isNewContact = $contactFissionHttpDao->isNewContact($externalContactArr['unionid']);

            $redis = Cache::store()->handler();

            $endTime = 0;
            if ($fissionEndTime = $redis->get(ContactFissionRecords::REDIS_KEY_FISSION_END_TIME)) {
                $endTime = strtotime($fissionEndTime);
            }

            if (time() < $endTime) {
                if ($isNewContact) {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(172);
                } else {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(173);
                }
                $contactFissionServiceImpl = new ContactFissionServiceImpl();

                if (isset($externalContactArr['unionid'])) {
                    $posterInfo = $contactFissionServiceImpl->getInvitationCode($externalContactArr['unionid']);

                    array_unshift(
                        $newAttachmentsArr,
                        [
                            'msgtype' => 'image',
                            'image' => [
                                'media_id' => $this->getFissionMediaId($posterInfo)
                            ]
                        ]
                    );
                }
            } else {
                if ($isNewContact) {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(174);
                } else {
                    [$welcomeText, $newAttachmentsArr] = $getSendMsg(175);
                }
            }
        } else {
            $wayInfo['channel_id'] = 0;
            if ($this->state === ContactFollowUser::MOMENT_ORIGIN_STATE) {
                if ($this->userId != 'yangyang5') {
                    $wayInfo['channel_id'] = search_two_dimensional_array(
                        $this->userId,
                        ContactChannels::MOMENT_CHANNEL_MAP
                    );
                }
            } else {
                $wayInfo = ContactWaysDao::getDetail(['channel_id'], ['id' => $this->state]);

                if (!$wayInfo) {
                    $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT, 'add_external_contact', 0, '路径不存在');
                    echo 'error';
                    return false;
                }
            }
            [$welcomeText, $newAttachmentsArr] = $getSendMsg($wayInfo['channel_id']);
        }

        $redis = Cache::store()->handler();
        $json = $redis->hGet('external', $externalContactArr['unionid']);
        if (!empty($json)) {
            $temp = json_decode($json, true);

            $arr = explode(".", $temp['pic']);
            $ext = array_pop($arr);

            $saveName = time() . mt_rand(100, 999) . '.' . $ext;
            self::downloadRemoteFileToLocal($temp['pic'], $saveName);

            $mediaHttpDao = new MediaHttpDao();
            $uploadRes = $mediaHttpDao->uploadMedia("image", 'public/downloads/' . $saveName, $saveName);

            $newAttachmentsArr[] = [
                'msgtype' => 'miniprogram',
                'miniprogram' => [
                    'title' => $temp['title'],
                    'pic_media_id' => $uploadRes['media_id'] ?? '',
                    'appid' => 'wx3378cc5758d57fb2',
                    'page' => $temp['path']
                ]
            ];
        }

        if ($welcomeText || $newAttachmentsArr) {
            try {
                self::$contactHttpDao->sendWelcomeMsgToContact(
                    $this->welcomeCode,
                    $welcomeText,
                    $newAttachmentsArr
                );
                return ['random_index' => $randomIndex];
            } catch (Exception $e) { // 发送失败不影响接下来存表的流程
                send_msg_to_wecom(
                    sprintf(
                        '%s-欢迎语发送失败，%s',
                        $this->externalUserId,
                        $e->getMessage()
                    )
                );
                /*Log::error(
                    sprintf(
                        '%s-欢迎语发送失败，%s',
                        $this->externalUserId,
                        $e->getMessage()
                    )
                );*/
            }
        }
    }

    /**
     * 编辑企业客户事件
     * 修改外部联系人的备注、手机号或标签时，回调该事件
     *
     * @throws Exception
     */
    private function editExternalContact()
    {
        // 获取客户详情
        $contactDetailArr = self::$contactHttpDao->getContactDetail($this->externalUserId, false);

        [
            $followUserArr,          // 外部联系人数组
            $specificFollowUserData, // 此时编辑的客服的客户数据
            $isSuccess
        ] =
        [
            $contactDetailArr['follow_user'],
            [],
            0
        ];

        // 返回多个followUsers列表，找到当前更新的助理
        foreach ($followUserArr as $followUser) {
            if ($followUser['userid'] == $this->userId) {
                $specificFollowUserData = $followUser;
                break;
            }
        }

        // 不知道哪个字段发生变化了，更新全部字段
        // 更新follow表
        $followUserUpdateRes = ContactFollowUserDao::updateData(
            [
                'description'      => $specificFollowUserData['description'] ?? '',
                'tags'             => (isset($specificFollowUserData['tags'])
                    && !empty($specificFollowUserData['tags']))
                    ? json_encode($specificFollowUserData['tags'], JSON_UNESCAPED_UNICODE) : null,
                'remark_corp_name' => $specificFollowUserData['remark_corp_name'] ?? '',
                'remark_mobiles'   => (isset($specificFollowUserData['remark_mobiles'])
                    && !empty($specificFollowUserData['remark_mobiles']))
                    ? implode(',', $specificFollowUserData['remark_mobiles']) : '',
                'update_time'      => Carbon::createFromTimestamp($this->createTime)->toDateTimeString(),
            ],
            [
                'external_userid' => $this->externalUserId,
                'userid'          => $this->userId
            ]
        );

        // 当前客服给此客户的最新的标签
        $newestTagsIdArr = [];

        if (isset($specificFollowUserData['tags']) && $specificFollowUserData['tags']) {
            array_map(
                function ($value) use (&$newestTagsIdArr) {
                    if ($value['type'] == 1) { // 只处理企业标签
                        $newestTagsIdArr = array_merge([$value['tag_id']], $newestTagsIdArr);
                    }
                },
                $specificFollowUserData['tags']
            );
        }

        // 旧的数据
        $originalTags = ContactTagMapDao::getAllList(
            [
                'tag_id'
            ],
            [
                'external_userid' => $this->externalUserId,
                'userid'          => $this->userId
            ]
        );

        if ($originalTags) {
            $originalTags = array_column($originalTags, 'tag_id');
        }

        // 对比，得到去掉的标签
        $reduceTags = array_values(array_diff($originalTags, $newestTagsIdArr));
        // 对比，得到新增的标签
        $addTags = array_values(array_diff($newestTagsIdArr, $originalTags));

        if ($reduceTags) {
            foreach ($reduceTags as $reduceValue) {
                $deleteRes = ContactTagMapDao::hardDelete(
                    [
                        'external_userid' => $this->externalUserId,
                        'tag_id'          => $reduceValue,
                        'userid'          => $this->userId
                    ]
                );

                if ($deleteRes === false) {
                    send_msg_to_wecom(
                        sprintf(
                            '%s-客户-%s-移除标签-%s-失败！',
                            $this->userId,
                            $this->externalUserId,
                            $reduceValue
                        )
                    );
                }
            }
        }

        $insertTagsData = [];

        if ($addTags) {
            foreach ($addTags as $addValue) {
                $insertTagsData[] = [
                    'external_userid' => $this->externalUserId,
                    'tag_id'          => $addValue,
                    'userid'          => $this->userId
                ];
            }

            $addTagRes = ContactTagMapDao::addBatchData($insertTagsData);

            if (!$addTagRes) {
                send_msg_to_wecom(sprintf('%s-客户-%s-添加标签失败！', $this->userId, $this->externalUserId));
            }
        }

        if ($followUserUpdateRes !== false) {
            $isSuccess = 1;
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT, 'edit_external_contact', $isSuccess);
    }

    /**
     * 员工删除外部联系人
     *
     * @throws Exception
     */
    private function delExternalContact()
    {
        $deleteRes = ContactFollowUserDao::updateData(
            [
                'status'   => ContactFollowUser::DEL_EXTERNAL_CONTACT,
                'del_time' => Carbon::now()
            ],
            [
                'external_userid' => $this->externalUserId,
                'userid'          => $this->userId
            ]
        );

        $isSuccess = 1;
        $remark = '';

        if ($deleteRes === false) {
            $isSuccess = 0;
            $remark = '员工删除外部联系人写表失败！';
            Log::error($remark);
        } else {
            if (
                !ContactFollowUserDao::getDetail(
                    [
                        'id'
                    ],
                    [
                        'external_userid' => $this->externalUserId,
                        'status'          => ContactFollowUser::NORMAL
                    ]
                )
            ) {
                ContactDao::updateData(
                    [
                        'is_friend' => ExternalContact::NOT_FRIEND
                    ],
                    [
                        'external_userid' => $this->externalUserId
                    ]
                );
            }
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT, 'del_external_contact', $isSuccess, $remark);
    }

    /**
     * 外部联系人删除员工
     *
     * @throws Exception
     */
    private function delFollowUser()
    {
        $deleteRes = ContactFollowUserDao::updateData(
            [
                'status'   => ContactFollowUser::DEL_FOLLOW_USER,
                'del_time' => Carbon::now()
            ],
            [
                'external_userid' => $this->externalUserId,
                'userid'          => $this->userId
            ]
        );

        $isSuccess = 1;
        $remark = '';

        if ($deleteRes === false) {
            $isSuccess = 0;
            $remark = '外部联系人删除员工写表失败！';
            send_msg_to_wecom($remark);
        } else {
            // 删除成功后处理标签
            $carryData = [
                'add_tags'        => [ContactTags::NOT_FRIEND_TAG],
                'remove_tags'     => [ContactTags::IS_FRIEND_TAG],
                'userid'          => $this->userId,
                'external_userid' => $this->externalUserId,
                'func'            => ''
            ];

            try {
                // 是否还有其他好友，没有的话更新is_friend字段
                if (
                    !ContactFollowUserDao::getDetail(
                        [
                            'id'
                        ],
                        [
                            'external_userid' => $this->externalUserId,
                            'status'          => ContactFollowUser::NORMAL
                        ]
                    )
                ) {
                    ContactDao::updateData(
                        [
                            'is_friend' => ExternalContact::NOT_FRIEND
                        ],
                        [
                            'external_userid' => $this->externalUserId
                        ]
                    );
                }

                // 推送到打标签队列
                Queue::push(
                    ContactTags::HANDLE_CONTACT_TAG_HANDLER,
                    $carryData,
                    ContactTags::HANDLE_CONTACT_TAG_QUEUE
                );
            } catch (Exception $e) {
                send_msg_to_wecom($e->getLine() . $e->getMessage());
            }
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT, 'del_follow_user', $isSuccess, $remark);
    }

    /**
     * 客户群创建事件
     * 收到该事件后，企业可以调用获取客户群详情接口获取客户群详情。
     *
     * @throws Exception
     */
    private function createExternalChat()
    {
        $contactGroupHttpDao = new ContactGroupHttpDao();

        $contactGroupDetail = $contactGroupHttpDao->getContactGroupDetail($this->chatId);

        Db::startTrans();

        $createGroupRes = ContactGroupDao::addData(
            [
                'chat_id'           => $contactGroupDetail['chat_id'],
                'name'              => $contactGroupDetail['name'] ?? '',
                'owner'             => $contactGroupDetail['owner'] ?? '',
                'notice'            => $contactGroupDetail['notice'] ?? '',
                'group_create_time' => $contactGroupDetail['create_time'],
            ]
        );

        $insertBatchData = [];

        foreach ($contactGroupDetail['member_list'] as $member) {
            $insertBatchData[] = [
                'chat_id'    => $contactGroupDetail['chat_id'],
                'userid'     => $member['userid'],
                'unionid'    => $member['unionid'] ?? '',
                'type'       => $member['type'],
                'join_time'  => $member['join_time'],
                'join_scene' => $member['join_scene'],
            ];
        }

        $groupMemberRes = ContactGroupMembersDao::addBatchData($insertBatchData);

        if ($createGroupRes && $groupMemberRes) {
            Db::commit();
        } else {
            Db::rollback();
            throw new Exception(sprintf('新建群聊-%s-存表失败！', $this->chatId));
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT_GROUP, 'create_external_chat', 1);
    }

    /**
     * 客户群解散事件
     *
     * @throws Exception
     */
    private function dismissExternalChat()
    {
        $groupDeleteRes = ContactGroupDao::deleteById(0, [], ['chat_id' => $this->chatId]);

        if ($groupDeleteRes === false) {
            throw new Exception(sprintf('解散群聊-%s-更改数据表失败！', $this->chatId));
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT_GROUP, 'dismiss_external_chat', 1);
    }

    /**
     * 客户群变更事件
     * 收到该事件后，企业需要再调用获取客户群详情接口，以获取最新的群详情。
     *
     * @param array $groupContent 回调的群消息
     * @throws Exception
     */
    private function updateExternalChat(array $groupContent)
    {
        $contactGroupHttpDao = new ContactGroupHttpDao();
        // 获取客户群详情
        $contactGroupDetail = $contactGroupHttpDao->getContactGroupDetail($this->chatId, 1);

        // 更改群信息
        if (
            in_array(
                $groupContent['update_detail'],
                ['change_owner', 'change_name', 'change_notice']
            )
        ) {
            $changeType = substr($groupContent['update_detail'], strpos($groupContent['update_detail'], '_') + 1);

            if (
                ContactGroupDao::updateData(
                    [
                    "{$changeType}" => $contactGroupDetail["{$changeType}"] ?? '',
                    ],
                    [
                    'chat_id' => $this->chatId
                    ]
                ) === false
            ) {
                send_msg_to_wecom($this->chatId . '更新群信息出错！');
            }
        }

        // 更改群成员
        if (
            in_array(
                $groupContent['update_detail'],
                ['add_member', 'del_member']
            )
        ) {
            // 推送到打标签队列
            $pushToQueueClosure = function (array $queueCarryData, string $errorMsg) {
                try {
                    Queue::push(
                        ContactTags::HANDLE_CONTACT_TAG_HANDLER,
                        $queueCarryData,
                        ContactTags::HANDLE_CONTACT_TAG_QUEUE
                    );
                } catch (Exception $e) {
                    send_msg_to_wecom("进入{$errorMsg}处理标签队列出错：" . $e->getMessage());
                }
            };

            $memberList = $contactGroupDetail['member_list'];

            // 新的数据
            $newMemUserIdArr = array_column($memberList, 'userid');
            // 原有的数据
            $originalMemArr = ContactGroupMembersDao::getAllList(
                [
                    'id',
                    'userid',
                    'unionid',
                    'type'
                ],
                [
                    'chat_id'    => $this->chatId,
                    'is_deleted' => 0
                ]
            );
            $originalMemUserIdArr = array_column($originalMemArr, 'userid');

            // 只判断指定群的加群人员，得到指定群的groupId数组-begin
            $userServiceImpl = new UserServiceImpl();

            $getGroupIdArr = function (string $userId) use ($userServiceImpl) {

                $accountsArr = $userServiceImpl->getSpecificUserAccount($userId, false);

                $groupArr = ContactGroupDao::getAllList(['chat_id'], [
                    'owner'      => ['in', $accountsArr],
                    'is_deleted' => ContactGroups::NOT_DELETED
                ]);
                return array_column($groupArr, 'chat_id');
            };

            // 费月名下的所有群id数组
            $feiyueGroupIdArr = $getGroupIdArr('feiyue');

            // 赵蔚名下的所有群id数组
            $zhaoweiGroupIdArr = $getGroupIdArr('zhaowei');
            // 得到指定群的groupId数组-end

            $getAllUserMap = function ($externalUseridArr) {
                $allUserInfo = ContactFollowUserDao::getAllList(
                    [
                        'external_userid',
                        'userid'
                    ],
                    [
                        'external_userid' => ['in', $externalUseridArr],
                        'status'          => ['<>', ContactFollowUser::DEL_EXTERNAL_CONTACT]
                    ]
                );

                $allUserMap = [];

                foreach ($allUserInfo as $user) {
                    $allUserMap[$user['external_userid']][] = $user['userid'];
                }
                return $allUserMap;
            };

            // 进群的那一刻需要判断
            // 一次可能有多个客户进群
            if ($groupContent['update_detail'] == 'add_member') {
                // 对比，得到加群的人
                $addUser = array_values(array_diff($newMemUserIdArr, $originalMemUserIdArr));

                $allUserMap = $getAllUserMap($addUser);

                foreach ($memberList as $member) {
                    if (in_array($member['userid'], $addUser)) { // 找到进群的那几个人
                        $theExternalUserId = $member['userid'];
                        $allUser = $allUserMap[$theExternalUserId] ?? [];

                        $addData = [
                            'chat_id'        => $this->chatId,
                            'userid'         => $theExternalUserId,
                            'unionid'        => $member['unionid'] ?? '',
                            'type'           => $member['type'],
                            'state'          => $member['state'] ?? 0,
                            'join_time'      => $member['join_time'],
                            'join_scene'     => $member['join_scene'],
                            'invitor'        => $member['invitor']['userid'] ?? '',
                            'group_nickname' => $member['group_nickname'] ?? '',
                            'original_name'  => $member['name'] ?? ''
                        ];

                        $addRes = ContactGroupMembersDao::addData($addData);

                        if ($addRes) {
                            // 外部联系人
                            if (
                                $member['type'] == ContactGroupMembers::EXTERNAL_USER
                            ) {
                                // 进宝姐家小红书福利群时，判定该用户之前是否添加过公司任一企微号且进过任一企微群，若没有则打上"小红书"标签。
                                $redBookChatIdArr = ContactGroupDao::getAllList(
                                    ['chat_id'],
                                    [
                                        'name' => ['like', "%小红书%"]
                                    ]
                                );
                                $redBookChatId = array_column($redBookChatIdArr, 'chat_id');

                                if (in_array($this->chatId, $redBookChatId)) {
                                    $redBookUserId = 'joyee';

                                    $firstAddInfo = ContactFollowUserDao::getDetail(
                                        [
                                            'userid',
                                        ],
                                        [
                                            'external_userid' => $theExternalUserId,
                                            'is_first_add'    => 1
                                        ]
                                    );

                                    if (
                                        empty($firstAddInfo)
                                        || $firstAddInfo['userid'] == $redBookUserId
                                    ) {
                                        // 是否进过其他的任一企微群
                                        if (
                                            !ContactGroupMembersDao::getDetail(
                                                ['id'],
                                                [
                                                    'userid' => $theExternalUserId,
                                                    'chat_id' => ['<>', $this->chatId]
                                                ]
                                            )
                                        ) {
                                            if (
                                                ContactFollowUserDao::getDetail(
                                                    [
                                                        'id',
                                                    ],
                                                    [
                                                        'external_userid' => $theExternalUserId,
                                                        'userid'          => $redBookUserId
                                                    ]
                                                )
                                            ) {
                                                $pushToQueueClosure([
                                                    'add_tags'        => [ContactTags::RED_BOOK_TAG],
                                                    'userid'          => $redBookUserId,
                                                    'external_userid' => $theExternalUserId
                                                ], '小红书');
                                            }
                                        }
                                    }
                                }

                                $removeNotInGroupTagClosure = function (
                                    $groupIdArr,
                                    $removeTag
                                ) use (
                                    $allUser,
                                    $theExternalUserId,
                                    $pushToQueueClosure
                                ) {
                                    if ($allUser) {
                                        // 判断是否在指定群中
                                        if (in_array($this->chatId, $groupIdArr)) {
                                            foreach ($allUser as $companyUser) {
                                                $pushToQueueClosure([
                                                    'add_tags'        => [],
                                                    'remove_tags'     => [$removeTag],
                                                    'userid'          => $companyUser,
                                                    'external_userid' => $theExternalUserId,
                                                    'func'            => ''
                                                ], '去除不在费月/赵蔚群内');
                                            }
                                        }
                                    }
                                };

                                // 去除"不在费月群内"标签
                                $removeNotInGroupTagClosure($feiyueGroupIdArr, ContactTags::NOT_IN_FEIYUE_GROUP_TAG);

                                // 去除"不在赵蔚群内"标签
                                $removeNotInGroupTagClosure($zhaoweiGroupIdArr, ContactTags::NOT_IN_ZHAOWEI_GROUP_TAG);

                                // 往宝姐家小程序发消息
                                if (
                                    isset($member['unionid'])
                                    && $member['unionid']
                                ) {
                                    // 更新external_contact表的is_in_group字段
                                    try {
                                        ContactDao::updateData(['is_in_group' => 1], ['unionid' => $member['unionid']]);
                                    } catch (Exception $e) {
                                        send_msg_to_wecom(
                                            $member['unionid'] . '进群时更新是否在群状态失败！' . $e->getTraceAsString()
                                        );
                                    }

                                    $webHookHttpDao = new WebHookHttpDao();
                                    $webHookHttpDao->noticeKoContactEvent($member['unionid']);
                                    // 宝姐家珠宝捡漏
                                    $groupArr = ContactGroupDao::getAllList(
                                        [
                                            'chat_id'
                                        ],
                                        [
                                            'name'       => ['like', '%宝姐家珠宝捡漏%'],
                                            'is_deleted' => ContactGroups::NOT_DELETED
                                        ]
                                    );

                                    $chatIdArr = array_column($groupArr, 'chat_id');

                                    if (in_array($this->chatId, $chatIdArr)) {
                                        $webHookHttpDao->noticeKoJoinGroup($member['unionid']);
                                    }

                                    if (isset($member['state'])) {
                                        // $webHookHttpDao->joinSharerGroupCallback($member['unionid'], $member['state']);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if ($groupContent['update_detail'] == 'del_member') {
                // 对比，得到退群的人
                $reduceUser = array_values(array_diff($originalMemUserIdArr, $newMemUserIdArr));
                $allUserMap = $getAllUserMap($reduceUser);

                foreach ($originalMemArr as $mem) {
                    if (in_array($mem['userid'], $reduceUser)) {
                        $theRemoveExternalUserId = $mem['userid'];
                        $allUser = $allUserMap[$theRemoveExternalUserId] ?? [];

                        ContactGroupMembersDao::deleteById($mem['id'], ['quit_scene' => $groupContent['quit_scene']]);
                        // 外部联系人
                        if ($mem['type'] == ContactGroupMembers::EXTERNAL_USER) {
                            $addNotInGroupTagClosure = function (
                                $groupIdArr,
                                $addTag
                            ) use (
                                $allUser,
                                $theRemoveExternalUserId,
                                $pushToQueueClosure
                            ) {
                                if ($allUser) {
                                    // 从费月和赵蔚的群里退群的才判断，费月的判断费月的，赵蔚的判断赵蔚的。
                                    if (in_array($this->chatId, $groupIdArr)) {
                                        // 只有不在所有的指定群群里才打上"不在费月群内"标签
                                        if (
                                            !ContactGroupMembersDao::getAllList(
                                                ['id'],
                                                [
                                                'chat_id'    => ['in', $groupIdArr],
                                                'userid'     => $theRemoveExternalUserId,
                                                'is_deleted' => ContactGroupMembers::NOT_DELETED
                                                ]
                                            )
                                        ) {
                                            foreach ($allUser as $companyUser) {
                                                $pushToQueueClosure([
                                                    'add_tags'        => [$addTag],
                                                    'remove_tags'     => [],
                                                    'userid'          => $companyUser,
                                                    'external_userid' => $theRemoveExternalUserId,
                                                    'func'            => ''
                                                ], '添加不在费月/赵蔚群内');
                                            }
                                        }
                                    }
                                }
                            };

                            $addNotInGroupTagClosure($feiyueGroupIdArr, ContactTags::NOT_IN_FEIYUE_GROUP_TAG);

                            $addNotInGroupTagClosure($zhaoweiGroupIdArr, ContactTags::NOT_IN_ZHAOWEI_GROUP_TAG);

                            if (
                                isset($mem['unionid'])
                                && $mem['unionid']
                            ) {
                                // 更新external_contact表的is_in_group字段
                                try {
                                    if (
                                        ContactGroupMembersDao::getCount([
                                            'unionid'    => $mem['unionid'],
                                            'is_deleted' => 0
                                        ]) == 0
                                    ) {
                                        ContactDao::updateData(['is_in_group' => 0], ['unionid' => $mem['unionid']]);
                                    }
                                } catch (Exception $e) {
                                    send_msg_to_wecom($mem['unionid'] . '退群时更新是否在群状态失败！');
                                }
                            }
                        }
                    }
                }
            }
        }

        $this->updateCallbackLog(
            $this->logId,
            CallbackLogs::CONTACT_GROUP,
            'update_external_chat',
            1,
            $groupContent['update_detail']
        );
    }

    /**
     * 获取小程序的media_id
     *
     * @param string $mediaType 文件类型
     * @param array $fileData 渠道欢迎语表的字段
     * @param string $suffix 图片文件后缀
     * @param array $attachments 附件数组
     * @param FileManager $fileManager 文件处理类
     * @return mixed
     * @throws Exception
     */
    private function getMediaId(
        string $mediaType,
        array $fileData,
        string $suffix,
        array $attachments,
        FileManager $fileManager
    ) {
        $updateFunc = function ($fileData, $uploadRes) use ($attachments) {

            foreach ($attachments as $key => &$singleAttachment) {
                if ($key == $fileData['key']) {
                    $singleAttachment['miniprogram_pic_media_id'] = $uploadRes['media_id'];
                    $singleAttachment['miniprogram_pic_create_time'] = $uploadRes['created_at'];
                    break;
                }
            }

            return ChannelWelcomeMsgDao::updateData(
                [
                    'attachments' => json_encode($attachments, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia($mediaType, $suffix, $fileData, $updateFunc);
    }

    /**
     * 获取视频的media_id
     *
     * @param string $mediaType 文件类型
     * @param array $fileData 渠道欢迎语表的字段
     * @param array $attachments 附件数组
     * @param FileManager $fileManager 文件处理类
     * @return mixed
     * @throws Exception
     */
    private function getVideoMediaId(
        string $mediaType,
        array $fileData,
        array $attachments,
        FileManager $fileManager
    ) {
        $updateFunc = function ($fileData, $uploadRes) use ($attachments) {
            foreach ($attachments as $key => &$singleAttachment) {
                if ($key == $fileData['key']) {
                    $singleAttachment['video_media_id'] = $uploadRes['media_id'];
                    $singleAttachment['video_media_create_at'] = $uploadRes['created_at'];
                    break;
                }
            }

            return ChannelWelcomeMsgDao::updateData(
                [
                    'attachments' => json_encode($attachments, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia($mediaType, 'mp4', $fileData, $updateFunc);
    }

    /**
     * 获取文件的media_id
     *
     * @param string $mediaType 文件类型
     * @param array $fileData 渠道欢迎语表的字段
     * @param array $attachments 附件数组
     * @param FileManager $fileManager 文件处理类
     * @return mixed
     * @throws Exception
     */
    private function getFileMediaId(
        string $mediaType,
        array $fileData,
        array $attachments,
        FileManager $fileManager
    ) {
        $updateFunc = function ($fileData, $uploadRes) use ($attachments) {
            foreach ($attachments as $key => &$singleAttachment) {
                if ($key == $fileData['key']) {
                    $singleAttachment['file_media_id'] = $uploadRes['media_id'];
                    $singleAttachment['file_media_create_at'] = $uploadRes['created_at'];
                    break;
                }
            }

            return ChannelWelcomeMsgDao::updateData(
                [
                    'attachments' => json_encode($attachments, JSON_UNESCAPED_UNICODE)
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };

        return $fileManager->updateTemporaryMedia($mediaType, $fileData['suffix'], $fileData, $updateFunc);
    }

    /**
     * 获取企微裂变的media_id
     *
     * @param array $fileData 海报相关字段
     * @return mixed
     * @throws Exception
     */
    private function getFissionMediaId(array $fileData)
    {
        $updateFunc = function ($fileData, $uploadRes) {
            return ContactFissionRecordsDao::updateData(
                [
                    'media_id'        => $uploadRes['media_id'],
                    'media_create_at' => $uploadRes['created_at']
                ],
                [
                    'id' => $fileData['id']
                ]
            );
        };
        $fileManager = new FileManager();

        return $fileManager->updateTemporaryMedia('image', 'png', $fileData, $updateFunc);
    }

    /**
     * 企业客户标签创建事件
     * 企业/管理员创建客户标签/标签组时，回调此事件。收到该事件后，企业需要调用获取企业标签库来获取标签/标签组的详细信息。
     *
     * @throws Exception
     */
    private function createExternalTag()
    {
        $isSuccess = 0;

        if ($this->tagType == 'tag') {
            $contactTagHttpDao = new ContactTagHttpDao();

            $contactTagDetail = $contactTagHttpDao->getContactTag([$this->tagId]);

            if ($contactTag = $contactTagDetail[0]) {
                $tagData = [
                    'group_id'          => $contactTag['group_id'],
                    'group_name'        => $contactTag['group_name'],
                    'group_create_time' => $contactTag['create_time'],
                    'group_order'       => $contactTag['order'],
                    'group_is_deleted'  => $contactTag['deleted'],
                    'tag_id'            => $contactTag['tag'][0]['id'],
                    'tag_name'          => $contactTag['tag'][0]['name'],
                    'tag_create_time'   => $contactTag['tag'][0]['create_time'],
                    'tag_order'         => $contactTag['tag'][0]['order']
                ];

                $isSuccess = ContactTagsDao::addData($tagData);
            }

            $changeType = 'create_external_tag';
        } else {
            $changeType = 'create_external_tag_group';
            $isSuccess = 1;
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT_GROUP, $changeType, (int)$isSuccess);
    }

    /**
     * 企业客户标签变更事件
     * 当企业客户标签/标签组被修改时，回调此事件。收到该事件后，企业需要调用获取企业标签库来获取标签/标签组的详细信息。
     *
     * @throws Exception
     */
    private function updateExternalTag()
    {
        $isSuccess = 0;

        $contactTagHttpDao = new ContactTagHttpDao();

        $updateRes = false;

        if ($this->tagType == 'tag') {
            $contactTagDetail = $contactTagHttpDao->getContactTag([$this->tagId]);

            if ($contactTag = $contactTagDetail[0]) {
                $updateRes = ContactTagsDao::updateData(
                    [
                        'tag_name'  => $contactTag['tag'][0]['name'],
                        'tag_order' => $contactTag['tag'][0]['order']
                    ],
                    [
                        'tag_id' => $this->tagId
                    ]
                );
            }

            $changeType = 'update_external_tag';
        } else {
            $contactTagList = $contactTagHttpDao->getContactTag();

            foreach ($contactTagList as $tagGroup) {
                if ($tagGroup['group_id'] == $this->tagId) {
                    $updateRes = ContactTagsDao::updateData(
                        [
                            'group_name'  => $tagGroup['group_name'],
                            'group_order' => $tagGroup['order']
                        ],
                        [
                            'group_id' => $this->tagId
                        ]
                    );
                    break;
                }
            }

            $changeType = 'update_external_tag_group';
        }

        if ($updateRes !== false) {
            $isSuccess = 1;
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT_GROUP, $changeType, (int)$isSuccess);
    }

    /**
     * 企业客户标签删除事件
     * 当企业客户标签/标签组被删除改时，回调此事件。删除标签组时，该标签组下的所有标签将被同时删除，但不会进行回调。
     *
     * @throws Exception
     */
    private function deleteExternalTag()
    {
        $isSuccess = 0;

        if ($this->tagType == 'tag') {
            $updateRes = ContactTagsDao::updateData(
                [
                    'tag_is_deleted' => ContactTags::TAG_IS_DELETED
                ],
                [
                    'tag_id' => $this->tagId
                ]
            );
            $changeType = 'delete_external_tag';
        } else {
            $updateRes = ContactTagsDao::updateData(
                [
                    'tag_is_deleted' => ContactTags::TAG_IS_DELETED
                ],
                [
                    'group_id' => $this->tagId
                ]
            );

            $changeType = 'delete_external_tag_group';
        }

        if ($updateRes !== false) {
            $isSuccess = 1;
        }

        $this->updateCallbackLog($this->logId, CallbackLogs::CONTACT_GROUP, $changeType, (int)$isSuccess);
    }

    /**
     * 企业客户标签重排事件
     * 当企业管理员在终端/管理端调整标签顺序时，可能导致标签顺序整体调整重排，引起大部分标签的order值发生变化，此时会回调此事件，收到此事件后企业应尽快全量同步标签的order值，防止后续调用接口排序出现非预期结果。
     *
     * @throws Exception
     */
    private function shuffleExternalTag()
    {
        $tagJson = json_encode($this->tagId);
        send_msg_to_wecom("标签组{$tagJson}顺序有变化");
    }
}
