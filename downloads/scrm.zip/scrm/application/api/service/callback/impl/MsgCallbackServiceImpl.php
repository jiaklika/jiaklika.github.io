<?php

declare(strict_types=1);

namespace app\api\service\callback\impl;

use app\api\service\callback\CallbackService;

/**
 * 接收应用的消息与事件
 *
 * Class MsgCallbackServiceImpl
 * @package app\api\service\callback\impl
 */
class MsgCallbackServiceImpl extends CallbackService
{
    /**
     * @var string
     */
    public static $encodingAesKey;

    /**
     * @var string
     */
    public static $token;


    /**
     * 处理回调消息与事件
     *
     * @param int $logId
     * @param array $content
     * @return mixed|void
     */
    public function handleData(int $logId, array $content)
    {
    }
}
