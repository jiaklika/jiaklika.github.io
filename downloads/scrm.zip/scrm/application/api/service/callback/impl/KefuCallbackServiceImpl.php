<?php

namespace app\api\service\callback\impl;

use app\api\dao\http\kefu\KefuHttpDao;
use app\api\dao\http\webHook\WebHookHttpDao;
use app\api\dao\mysql\kefu\KefuAccountsDao;
use app\api\dao\mysql\kefu\KefuCallbackLogDao;
use app\api\dao\mysql\kefu\KefuChatListDao;
use app\api\dao\mysql\kefu\KefuChatRecordsDao;
use app\api\dao\mysql\kefu\KefuCustomerInfoDao;
use app\api\dao\mysql\kefu\KefuKeywordMapDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyAttachmentsDao;
use app\api\dao\mysql\kefu\KefuKeywordReplyDao;
use app\api\dao\mysql\kefu\KefuKeywordUserMapDao;
use app\api\dao\mysql\kefu\KefuMsgLogDao;
use app\api\dao\mysql\kefu\KefuMsgMenuDao;
use app\api\dao\mysql\kefu\KefuServiceRecordsDao;
use app\api\dao\mysql\kefu\KefuServicerMapDao;
use app\api\dao\mysql\user\UserDao;
use app\api\service\callback\CallbackService;
use app\api\util\FileManager;
use app\api\util\HttpClient;
use app\common\model\kefu\KefuAccounts;
use app\common\model\kefu\KefuChatRecords;
use Closure;
use Exception;
use think\Db;

/**
 * 微信客服回调事件
 *
 * Class KefuCallbackServiceImpl
 *
 * @package app\api\service\callback\impl
 */
class KefuCallbackServiceImpl extends CallbackService
{
    use HttpClient;

    /**
     * @var $kefuHttpDao
     */
    private static $kefuHttpDao;

    /**
     * @var string
     */
    public static $encodingAesKey;

    /**
     * @var string
     */
    public static $token;

    /**
     * @var int 回调日志表主键
     */
    private $logId;

    /**
     * @var array 回调内容
     */
    private $content;

    /**
     * KefuCallbackServiceImpl constructor.
     */
    public function __construct()
    {
        if (empty(self::$kefuHttpDao)) {
            self::$kefuHttpDao = new KefuHttpDao();
        }
    }

    /**
     * @param int $logId
     * @param array $content
     * @return void
     * @throws Exception
     */
    public function handleData(int $logId, array $content)
    {
        // 写入回调日志
        KefuCallbackLogDao::addData([
            'callback_json' => json_encode($content, JSON_UNESCAPED_UNICODE)
        ]);

        $token = $content['Token'] ?? '';

        // 获取下一个cursor
        $cursorData = KefuMsgLogDao::getDetail(
            [
                'next_cursor',
            ],
            [
            ],
            'id desc'
        );

        $nextCursor = $cursorData['next_cursor'] ?? '';

        try {
            // 读取消息
            // 微信客户发送的消息、接待人员在企业微信回复的消息、发送消息接口发送失败事件（如被用户拒收）、客户点击菜单消息的回复消息，可以通过该接口获取具体的消息内容和事件。不支持读取通过发送消息接口发送的消息。
            // 每次一条
            $res = [];
            try {
                $res = self::$kefuHttpDao->getSyncMsg(
                    $token,
                    $nextCursor,
                    10
                );
                if ($res['errcode'] !== 0) {
                    exception($res['errmsg']);
                }
            } catch (Exception $e) {
                send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
            }

            if (!$res) {
                exit();
            }
            $msgList = $res['msg_list'];

            $latestMsg = $msgList[count($msgList) - 1] ?? [];
            if (!$latestMsg) {
                exit();
            }

            KefuMsgLogDao::addData([
                'msg_content' => json_encode($latestMsg, JSON_UNESCAPED_UNICODE),
                'msg_type'    => $latestMsg['msgtype'],
                'next_cursor' => $res['next_cursor'],
                'has_more'    => $res['has_more']
            ]);

            $openKfId = $latestMsg['open_kfid'] ?? $latestMsg[$latestMsg['msgtype']]['open_kfid'];
            // 接待人员接待状态变更事件
            if (
                $latestMsg['msgtype'] == 'event'
                && $latestMsg['event']['event_type'] == 'servicer_status_change'
            ) {
                // event.status 状态类型：1-接待中 2-停止接待
                $state = $latestMsg['event']['status'] == 1 ? 3 : 0;

                KefuServicerMapDao::updateData(
                    [
                        'state' => $state
                    ],
                    [
                        'open_kfid' => $openKfId,
                        'userid'    => $latestMsg['event']['servicer_userid']
                    ]
                );
                if ($state == 0) {
                    KefuServiceRecordsDao::updateData(
                        [
                            'service_state' => 0
                        ],
                        [
                            'open_kfid'       => $openKfId,
                            'service_userid'  => $latestMsg['event']['servicer_userid'],
                        ]
                    );
                }
                exit();
            }
            // 客户UserID
            $externalUserId = $latestMsg['external_userid'] ?? $latestMsg[$latestMsg['msgtype']]['external_userid'];

            // 保存客户信息
            $nickName = $this->saveCustomerInfo($externalUserId);

            // 保存聊天记录
            $chatId = $this->saveChatRecord($latestMsg, $openKfId, $externalUserId, $nickName);

            // 如果满足条件就发送欢迎语
            if (isset($latestMsg['event']['welcome_code'])) {
                $this->sendWelcomeMsg($latestMsg['event']['welcome_code'], $latestMsg['event']['open_kfid'], $chatId);
            }

            // 会话状态变更事件
            // 结束语
            if (
                isset($latestMsg['event']['msg_code'])
                && $latestMsg['event']['change_type'] == 3
            ) {
                // 结束会话
                // 把客服设置为空闲
                KefuServicerMapDao::updateData(
                    [
                        'state' => 0
                    ],
                    [
                        'open_kfid' => $openKfId,
                        'userid'    => $latestMsg['event']['old_servicer_userid']
                    ]
                );
                KefuServiceRecordsDao::updateData(
                    [
                        'service_state' => 0
                    ],
                    [
                        'open_kfid'       => $openKfId,
                        'service_userid'  => $latestMsg['event']['old_servicer_userid'],
                        'external_userid' => $externalUserId
                    ]
                );
                // $this->sendEndMsg($latestMsg['event']['msg_code'], $latestMsg['event']['old_servicer_userid'], $chatId);
            }

            // 从接待池接入
            if (
                $latestMsg['msgtype'] == 'event'
                && $latestMsg['event']['event_type'] == 'session_status_change'
                && $latestMsg['event']['change_type'] == 1
            ) {
                // 修改接待状态
                KefuServicerMapDao::updateData(
                    [
                        'state'   => 3,
                        'is_next' => 0
                    ],
                    [
                        'open_kfid' => $openKfId,
                        'userid'    => $latestMsg['event']['new_servicer_userid']
                    ]
                );
                // 没有就记录
                if (
                    !KefuServiceRecordsDao::getDetail(
                        ['id'],
                        [
                            'open_kfid'       => $openKfId,
                            'service_userid'  => $latestMsg['event']['new_servicer_userid'],
                            'external_userid' => $externalUserId,
                            'service_state'   => 3
                        ]
                    )
                ) {
                    KefuServiceRecordsDao::addData([
                        'open_kfid'       => $openKfId,
                        'service_userid'  => $latestMsg['event']['new_servicer_userid'],
                        'external_userid' => $externalUserId,
                        'service_state'   => 3
                    ]);
                }
            }

            // 客户账号信息
            $kefuAccountInfo = KefuAccountsDao::getDetail(
                [
                    'service_period',
                    'service_time_start',
                    'service_time_end',
                    'rest_time_automatic_reply'
                ],
                [
                    'open_kfid' => $openKfId
                ]
            );

            if (!$kefuAccountInfo) {
                send_msg_to_wecom($openKfId . '客服账号不存在');
                exit();
            }

            // 不是事件，客户主动发消息
            if ($latestMsg['msgtype'] != 'event') {
                // 判断是否点击的是智能菜单
                $handleMenuTextClosure = function ($latestMsg) use ($nickName, $chatId, $openKfId) {
                    if (
                        $latestMsg['msgtype'] == 'text'
                        && isset($latestMsg['text']['menu_id'])
                    ) { // 点击菜单发的文字
                        $this->keywordReply(
                            $latestMsg['text']['content'],
                            $latestMsg['external_userid'],
                            $nickName,
                            $latestMsg['open_kfid'],
                            $chatId
                        );
                        if (strstr($latestMsg['text']['content'], '人工')) {
                            // 转人工接待
                            $this->transferService($openKfId, $latestMsg['external_userid']);
                        }
                    } else {
                        // 转人工接待
                        $this->transferService($openKfId, $latestMsg['external_userid']);
                    }
                };

                // 是否是全天接待
                // 现在的时间
                $nowTime = strtotime(date('H:m:s'));
                if ($kefuAccountInfo['service_period'] == 2) { // 不是全天接待
                    if (
                        $nowTime < strtotime($kefuAccountInfo['service_time_start']) ||
                        $nowTime > strtotime($kefuAccountInfo['service_time_end'])
                    ) { // 不在接待时间
                        // 把设置的非接待时间回复内容发送过去
                        $replyContentArr = [
                            'content' => $kefuAccountInfo['rest_time_automatic_reply']
                        ];
                        $msgId = self::$kefuHttpDao->sendMsg(
                            $externalUserId,
                            $openKfId,
                            'text',
                            $replyContentArr
                        );

                        // 加入聊天记录
                        $chatRecordData = [
                            'msg_id'          => $msgId,
                            'servicer_userid' => '',
                            'send_time'       => time(),
                            'origin'          => KefuChatRecords::SERVICE,
                            'msg_type'        => 'text',
                            'attachments'     => json_encode($replyContentArr, JSON_UNESCAPED_UNICODE)
                        ];

                        $chatRecordData['chat_id'] = $chatId;

                        KefuChatRecordsDao::addData($chatRecordData);
                        // 是否触发关键词
                        if (isset($latestMsg['text']['content'])) {
                            $this->keywordReply(
                                $latestMsg['text']['content'],
                                $latestMsg['external_userid'],
                                $nickName,
                                $latestMsg['open_kfid'],
                                $chatId
                            );
                        }
                    } else { // 在接待时间
                        $handleMenuTextClosure($latestMsg);
                    }
                }

                // 全天接待
                if ($kefuAccountInfo['service_period'] == 1) {
                    $handleMenuTextClosure($latestMsg);
                }
            }
        } catch (Exception $e) { // 发送失败不影响接下来存表的流程
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }
    }

    /**
     * 存储客户基础信息
     *
     * @param string $externalUserid 客户UserID
     * @return string 客户昵称
     * @throws Exception
     */
    private function saveCustomerInfo(string $externalUserid): string
    {
        // 是否存在客户信息
        $customerInfo = KefuCustomerInfoDao::getDetail(
            [
                'id',
                'nickname'
            ],
            [
                'external_userid' => $externalUserid
            ]
        );
        $customerArr = [];
        if (!$customerInfo) {
            // 不存在就获取然后存储
            $customerInfo = self::$kefuHttpDao->getCustomerInfo([$externalUserid]);
            $customerArr = $customerInfo[0];
            if (!KefuCustomerInfoDao::addData($customerArr)) {
                send_msg_to_wecom('存储客户' . $externalUserid . '基础信息失败！');
            }
        }
        return $customerArr['nickname'] ?? $customerInfo['nickname'];
    }

    /**
     * 保存聊天记录
     *
     * @param array $latestMsg 最新一条信息内容
     * @param string $openKfId 客服帐号ID
     * @param string $externalUserId 客户UserID
     * @param string $nickName 客户昵称
     * @return int
     * @throws Exception
     */
    public function saveChatRecord(
        array $latestMsg,
        string $openKfId,
        string $externalUserId,
        string $nickName = ''
    ): int {
        // 附件
        $attachments = [];
        $platForm = $chatId = 0;
        $channel = '';
        // 获取客服名
        $getUserName = function (string $userId) {
            $userInfo = UserDao::getDetail(['name'], ['userid' => $userId]);
            return $userInfo['name'] ?? $userId;
        };
        // 事件
        if ($latestMsg['msgtype'] == 'event') {
            switch ($latestMsg['event']['event_type']) {
                case 'enter_session': // 用户进入会话事件
                    $attachments = [
                        'content' => $nickName . '进入会话',
                    ];
                    $platForm = $latestMsg['event']['scene'];
                    if (isset($latestMsg['event']['scene_param'])) {
                        $sceneParamArr = explode('-', $latestMsg['event']['scene_param']);
                        if (in_array($sceneParamArr[0], [1,2])) {
                            $channel = $sceneParamArr[1];
                        } else {
                            $channel = $sceneParamArr[0];
                        }
                    }
                    break;

                case 'msg_send_fail': // 消息发送失败事件
                    switch ($latestMsg['event']['fail_type']) {
                        case 0:
                        default:
                            $failContent = '未知原因';
                            break;

                        case 1:
                            $failContent = '客服账号已删除';
                            break;

                        case 2:
                            $failContent = '应用已关闭 ';
                            break;

                        case 4:
                            $failContent = '会话已过期，超过48小时';
                            break;

                        case 5:
                            $failContent = '会话已关闭';
                            break;

                        case 6:
                            $failContent = '超过5条限制';
                            break;

                        case 7:
                            $failContent = '未绑定视频号';
                            break;

                        case 8:
                            $failContent = '主体未验证';
                            break;

                        case 9:
                            $failContent = '未绑定视频号且主体未验证';
                            break;

                        case 10:
                            $failContent = '用户拒收';
                            break;
                    }
                    $attachments = [
                        'content' => '发送失败-' . $failContent,
                    ];
                    break;

                case 'servicer_status_change': // 接待人员接待状态变更事件
                    $status = $latestMsg['event']['status'] == 1 ? '接待中' : '停止接待';
                    $attachments = [
                        'content' => $getUserName($latestMsg['event']['servicer_userid']) . $status,
                    ];
                    break;

                case 'session_status_change':
                    $oldUserName = $newUserName = '';
                    if (isset($latestMsg['event']['new_servicer_userid'])) {
                        $oldUserName = $getUserName($latestMsg['event']['new_servicer_userid']);
                    }

                    if (isset($latestMsg['event']['old_servicer_userid'])) {
                        $newUserName = $getUserName($latestMsg['event']['old_servicer_userid']);
                    }

                    switch ($latestMsg['event']['change_type']) {
                        case 1:
                        default:
                            $changeContent = '从接待池接入会话';
                            $userName = $newUserName;
                            break;

                        case 2:
                            $changeContent = '转接会话';
                            $userName = $oldUserName;
                            break;

                        case 3:
                            $changeContent = '结束会话';
                            $userName = $oldUserName;
                            break;

                        case 4:
                            $changeContent = '重新接入已结束/已转接会话';
                            $userName = $newUserName;
                            break;
                    }
                    $attachments = [
                        'content' => $userName . $changeContent,
                    ];
                    break;
            }
        } else {
            $attachments = $latestMsg[$latestMsg['msgtype']];
        }

        try {
            if (
                in_array(
                    $latestMsg['msgtype'],
                    ['image', 'voice', 'video', 'file']
                )
            ) {
                // 转换格式
                $fileInfo = $this->downloadMediaAndGetUrl($attachments['media_id']);
                $attachments = [
                    'url'       => $fileInfo['url'],
                    'file_name' => $fileInfo['file_name']
                ];
            }
            if ($latestMsg['msgtype'] == 'miniprogram') {
                $fileInfo = $this->downloadMediaAndGetUrl($attachments['thumb_media_id']);

                $attachments['pic_url'] = $fileInfo['url'];
                unset($attachments['thumb_media_id']);
            }
            // 单个聊天记录
            $chatRecordData = [
                'msg_id'          => $latestMsg['msgid'],
                'servicer_userid' => $latestMsg['servicer_userid'] ?? '',
                'send_time'       => $latestMsg['send_time'],
                'origin'          => $latestMsg['origin'],
                'msg_type'        => $latestMsg['msgtype'],
                'attachments'     => json_encode($attachments, JSON_UNESCAPED_UNICODE)
            ];

            // 聊天列表
            $chatListData = KefuChatListDao::getDetail(
                [
                    'id'
                ],
                [
                    'open_kfid'       => $openKfId,
                    'external_userid' => $externalUserId
                ]
            );
            if ($chatListData) { // 存在就更新最近聊天时间
                $chatId = $chatListData['id'];
                $updateData = [
                    'external_userid' => $externalUserId
                ];
                if ($platForm != 0) {
                    $updateData['platform'] = $platForm;
                }
                if ($channel) {
                    $updateData['channel'] = $channel;
                }

                KefuChatListDao::updateData(
                    $updateData,
                    [
                        'id' => $chatId
                    ]
                );
            } else { // 不存在就存储列表和记录
                $chatListData = [
                    'open_kfid'       => $openKfId,
                    'external_userid' => $externalUserId,
                    'platform'        => $platForm,
                    'channel'         => $channel
                ];
                $chatId = KefuChatListDao::addData($chatListData, true);
            }

            $chatRecordData['chat_id'] = $chatId;

            KefuChatRecordsDao::addData($chatRecordData);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }

        return $chatId;
    }

    /**
     * 发送欢迎语
     *
     * @param string $welcomeCode 欢迎语code
     * @param string $openKfId 客服帐号ID
     * @param int $chatId 聊天列表id
     * @throws Exception
     */
    public function sendWelcomeMsg(string $welcomeCode, string $openKfId, int $chatId): void
    {
        $welcomeInfo = KefuAccountsDao::getDetail(
            [
                'is_open_welcome',
                'welcome_type',
                'welcome_text',
                'welcome_menu_id'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        if (
            !$welcomeInfo
            || $welcomeInfo['is_open_welcome'] == 0
        ) {
            return;
        }

        try {
            if ($welcomeInfo['welcome_type'] == KefuAccounts::WELCOME_TYPE_TEXT) {
                $welcomeType = 'text';
                $welcomeContent = [
                    'content' => $welcomeInfo['welcome_text']
                ];
            } else {
                $welcomeType = 'msgmenu';
                $menuData = KefuMsgMenuDao::getDetail(
                    [
                        'head_content',
                        'menu_list',
                        'tail_content',
                        'is_open'
                    ],
                    [
                        'id' => $welcomeInfo['welcome_menu_id']
                    ]
                );
                if (!$menuData) {
                    send_msg_to_wecom('智能菜单不存在！');
                    return;
                }

                if ($menuData['is_open'] == 0) {
                    // send_msg_to_wecom('智能菜单已关闭！');
                    return;
                }
                $welcomeContent = [
                    'list' => json_decode($menuData['menu_list'], true)
                ];

                if ($menuData['head_content']) {
                    $welcomeContent['head_content'] = $menuData['head_content'];
                }
                if ($menuData['tail_content']) {
                    $welcomeContent['tail_content'] = $menuData['tail_content'];
                }
            }

            $welcomeMsgId = self::$kefuHttpDao->sendMsgOnEvent(
                $welcomeCode,
                $welcomeType,
                $welcomeContent
            );
            // 写入聊天记录
            $welcomeChatRecordData = [
                'msg_id'          => $welcomeMsgId,
                'servicer_userid' => '',
                'send_time'       => time(),
                'origin'          => KefuChatRecords::SERVICE,
                'msg_type'        => $welcomeInfo['welcome_type'] == 1 ? 'text' : 'msgmenu',
                'attachments'     => json_encode($welcomeContent, JSON_UNESCAPED_UNICODE)
            ];

            $welcomeChatRecordData['chat_id'] = $chatId;

            KefuChatRecordsDao::addData($welcomeChatRecordData);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }
    }

    /**
     * 发送结束语
     *
     * @param string $msgCode 用于发送事件响应消息的code
     * @param string $serviceUserId 接待人员id
     * @param int $chatId 聊天列表id
     */
    public function sendEndMsg(string $msgCode, string $serviceUserId, int $chatId): void
    {
        try {
            $welcomeContentArr = [
                'content' => '感谢您的咨询，期待继续为你服务'
            ];

            $welcomeMsgId = self::$kefuHttpDao->sendMsgOnEvent(
                $msgCode,
                'text',
                $welcomeContentArr
            );
            // 写入聊天记录
            $welcomeChatRecordData = [
                'msg_id'          => $welcomeMsgId,
                'servicer_userid' => $serviceUserId,
                'send_time'       => time(),
                'origin'          => KefuChatRecords::SERVICE,
                'msg_type'        => 'text',
                'attachments'     => json_encode($welcomeContentArr, JSON_UNESCAPED_UNICODE)
            ];

            $welcomeChatRecordData['chat_id'] = $chatId;

            KefuChatRecordsDao::addData($welcomeChatRecordData);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }

        /*$welcomeInfo = KefuAccountsDao::getDetail(
            [
                'is_open_welcome',
                'welcome_type',
                'welcome_text',
                'welcome_menu_id'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        if (
            !$welcomeInfo
            || $welcomeInfo['is_open_welcome'] == 0
        ) {
            return;
        }

        try {
            if ($welcomeInfo['welcome_type'] == KefuAccounts::WELCOME_TYPE_TEXT) {
                $welcomeType = 'text';
                $welcomeContent = [
                    'content' => $welcomeInfo['welcome_text'] . '这是结束语！'
                ];
            } else {
                $welcomeType = 'msgmenu';
                $menuData = KefuMsgMenuDao::getDetail(
                    [
                        'head_content',
                        'menu_list',
                        'tail_content'
                    ],
                    [
                        'id' => $welcomeInfo['welcome_menu_id']
                    ]
                );
                $welcomeContent = [
                    'head_content' => $menuData['head_content'] . '这是结束语！',
                    'list'         => json_decode($menuData['menu_list'], true),
                    'tail_content' => $menuData['tail_content'] . '这是结束语！',
                ];
            }

            $welcomeMsgId = self::$kefuHttpDao->sendMsgOnEvent(
                $msgCode,
                $welcomeType,
                $welcomeContent
            );
            // 写入聊天记录
            $welcomeChatRecordData = [
                'msg_id'          => $welcomeMsgId,
                'servicer_userid' => '',
                'send_time'       => time(),
                'origin'          => KefuChatRecords::SERVICE,
                'msg_type'        => $welcomeInfo['welcome_type'] == 1 ? 'text' : 'msgmenu',
                'attachments'     => json_encode($welcomeContent, JSON_UNESCAPED_UNICODE)
            ];

            $welcomeChatRecordData['chat_id'] = $chatId;

            KefuChatRecordsDao::addData($welcomeChatRecordData);
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }*/
    }

    /**
     * 关键词回复
     *
     * @param string $keyword 关键词
     * @param string $externalUserid 咨询的客户
     * @param string $nickName 咨询客户的昵称
     * @param string $openKfId 客服账号
     * @param int $chatId 聊天列表id
     */
    public function keywordReply(
        string $keyword,
        string $externalUserid,
        string $nickName,
        string $openKfId,
        int $chatId
    ) {
        try {
            // 寻找关键词对应的回复内容
            $allKeywordArr = KefuKeywordMapDao::getAllList(
                [
                    'reply_id',
                    'keyword',
                    'id'
                ]
            );

            $replyId = $keywordId = 0;
            foreach ($allKeywordArr as $singeKeyword) {
                if (!$singeKeyword) {
                    continue;
                }
                if ($keyword == $singeKeyword['keyword']) {
                    $replyId   = $singeKeyword['reply_id'];
                    $keywordId = $singeKeyword['id'];
                    break;
                }
            }

            if (!$replyId) {
                foreach ($allKeywordArr as $singeKeyword) {
                    if (strpos($keyword, $singeKeyword['keyword']) !== false) {
                        $replyId   = $singeKeyword['reply_id'];
                        $keywordId = $singeKeyword['id'];
                        break;
                    }
                }
            }

            if (!$replyId) {
                return;
            }
            $replyData = KefuKeywordReplyDao::getDetail(
                [
                    'keyword_title',
                    'is_open_reply',
                    'is_push_to_group',
                    'webhook_url'
                ],
                [
                    'id' => $replyId
                ]
            );

            if (!$replyData['is_open_reply']) {
                return;
            }

            // 关键词触发数+1
            Db::name('kefu_keyword_reply')
                ->where([
                    'id' => $replyId
                ])
                ->setInc('trigger_count');
            // 用户触发数
            if (
                !KefuKeywordUserMapDao::getDetail(
                    ['id'],
                    [
                        'external_userid' => $externalUserid,
                        'keyword_id'      => $keywordId
                    ]
                )
            ) {
                KefuKeywordUserMapDao::addData([
                    'external_userid' => $externalUserid,
                    'keyword_id'      => $keywordId
                ]);
                Db::name('kefu_keyword_reply')
                    ->where([
                        'id' => $replyId
                    ])
                    ->setInc('user_count');
            }

            if ($replyData['is_push_to_group']) {
                $replyTemplate = '用户：%s，正在咨询“%s”相关问题。
请相关人员尽快前往回复！';

                $webHookHttpDao = new WebHookHttpDao();
                $sendContent    = sprintf($replyTemplate, $nickName, $replyData['keyword_title']);
                $webHookHttpDao->sendKefuMsg($replyData['webhook_url'], $sendContent);
            }

            $replyArr = KefuKeywordReplyAttachmentsDao::getAllList(
                [
                    'id',
                    'msg_type',
                    'attachment'
                ],
                [
                    'reply_id' => $replyId
                ]
            );

            if (!$replyArr) {
                exit();
            }
            $chatRecordBatchData = [];
            foreach ($replyArr as $reply) {
                $updateId = $reply['id'];
                $msgType = $reply['msg_type'];
                $saveChatRecordData = $content = $attachmentArr = json_decode($reply['attachment'], true);
                if (in_array($msgType, ['image', 'voice', 'video', 'file'])) {
                    // 更新临时素材id和创建时间
                    $updateFunc = function ($fileData, $uploadRes) use ($updateId) {
                        $keywordAttachments = [
                            'media_url'       => $fileData['media_url'],
                            'media_id'        => $uploadRes['media_id'],
                            'media_create_at' => $uploadRes['created_at']
                        ];

                        return KefuKeywordReplyAttachmentsDao::updateData(
                            [
                                'attachment' => json_encode($keywordAttachments, JSON_UNESCAPED_UNICODE)
                            ],
                            [
                                'id' => $updateId
                            ]
                        );
                    };
                    $mediaId = $this->getSingleNewestMediaId($msgType, $attachmentArr, $updateFunc);
                    $content = [
                        'media_id' => $mediaId
                    ];
                    $saveChatRecordData = [
                        'url' => $attachmentArr['media_url']
                    ];
                }
                if (in_array($msgType, ['link', 'miniprogram'])) {
                    $content = json_decode($reply['attachment'], true);

                    $mediaData = [
                        'media_url'       => $content['media_url'],
                        'media_id'        => $content['media_id'],
                        'media_create_at' => $content['media_create_at']
                    ];
                    // 更新临时素材id和创建时间
                    $linkUpdateFunc = function ($fileData, $uploadRes) use ($updateId) {
                        $content['media_url'] = $fileData['media_url'];
                        $content['media_id'] = $uploadRes['media_id'];
                        $content['media_create_at'] = $uploadRes['created_at'];

                        return KefuKeywordReplyAttachmentsDao::updateData(
                            [
                                'attachment' => json_encode($content, JSON_UNESCAPED_UNICODE)
                            ],
                            [
                                'id' => $updateId
                            ]
                        );
                    };

                    $mediaId = $this->getLinkNewestMediaId($mediaData, $linkUpdateFunc);
                    $mediaUrl = $content['media_url'];
                    unset($content['media_url'], $content['media_id'], $content['media_create_at']);
                    $content['thumb_media_id'] = $mediaId;
                    $saveChatRecordData = $content;
                    unset($saveChatRecordData['thumb_media_id']);
                    $saveChatRecordData['pic_url'] = $mediaUrl;
                }

                if ($msgType == 'msgmenu') {
                    $menuAttachmentArr = json_decode($reply['attachment'], true);
                    $menuId = $menuAttachmentArr['menu_id'];

                    $menuData = KefuMsgMenuDao::getDetail(
                        [
                            'head_content',
                            'menu_list',
                            'tail_content',
                            'is_open'
                        ],
                        [
                            'id' => $menuId
                        ]
                    );
                    if ($menuData['is_open']) {
                        $menuListArr = json_decode($menuData['menu_list'], true);

                        $content = [
                            'list' => $menuListArr
                        ];
                        if ($menuData['head_content']) {
                            $content['head_content'] = $menuData['head_content'];
                        }
                        if ($menuData['tail_content']) {
                            $content['tail_content'] = $menuData['tail_content'];
                        }
                    }
                    $saveChatRecordData = $content;
                }
                // 1个1个发送
                $msgId = self::$kefuHttpDao->sendMsg(
                    $externalUserid,
                    $openKfId,
                    $msgType,
                    $content
                );

                // 加入聊天记录
                $chatRecordData = [
                    'msg_id'          => $msgId,
                    'servicer_userid' => '',
                    'send_time'       => time(),
                    'origin'          => KefuChatRecords::SERVICE,
                    'msg_type'        => $msgType,
                    'attachments'     => json_encode($saveChatRecordData, JSON_UNESCAPED_UNICODE)
                ];

                $chatRecordData['chat_id'] = $chatId;
                $chatRecordBatchData[] = $chatRecordData;
            }
            if ($chatRecordBatchData) {
                KefuChatRecordsDao::addBatchData($chatRecordBatchData);
            }
        } catch (Exception $e) {
            send_msg_to_wecom($e->getFile() . $e->getLine() . $e->getMessage());
        }
    }

    /**
     * 分配客服会话
     *
     * @param string $openKfId 客服帐号ID
     * @param string $externalUserId 微信客户的external_userid
     * @throws Exception
     */
    public function transferService(string $openKfId, string $externalUserId)
    {
        // 查询客户的会话状态
        $serviceState = self::$kefuHttpDao->getServiceState($openKfId, $externalUserId);

        // 账号详情
        $accountInfoArr = KefuAccountsDao::getDetail(
            [
                'allocation_rule',
                'previous_or_first',
                'maximum_limit'
            ],
            [
                'open_kfid' => $openKfId
            ]
        );

        // 客户正在被接待，直接退出
        if ($serviceState['service_state'] == 3) {
            exit();
        }

        // 超过1个才有分配规则
        if (KefuServicerMapDao::getCount(['open_kfid' => $openKfId]) > 1) {
            if ($accountInfoArr['allocation_rule'] == 1) { // 空闲分配
                // 找出空闲的
                $serviceUserid = $this->takeIdleService(
                    $accountInfoArr['previous_or_first'],
                    $openKfId,
                    $externalUserId
                );
            } else { // 轮流分配
                // 找出下一个
                $serviceUserid = $this->takeTurnsService(
                    $accountInfoArr['previous_or_first'],
                    $openKfId,
                    $externalUserId
                );
            }
        } else {
            $singleService = KefuServicerMapDao::getDetail(['userid'], ['open_kfid' => $openKfId]);
            $serviceUserid = $singleService['userid'];
        }
        // 判断服务人员是否满员了
        $serviceIsFull = KefuServiceRecordsDao::getCount([
            'open_kfid'      => $openKfId,
            'service_userid' => $serviceUserid,
            'service_state'  => 3
        ]);

        // 没满员就接待
        if ($serviceIsFull < $accountInfoArr['maximum_limit']) {
            // 修改接待状态
            KefuServicerMapDao::updateData(
                [
                    'state'   => 3,
                    'is_next' => 0
                ],
                [
                    'open_kfid' => $openKfId,
                    'userid'    => $serviceUserid
                ]
            );
            // 没有就记录
            if (
                !KefuServiceRecordsDao::getDetail(
                    ['id'],
                    [
                        'open_kfid'       => $openKfId,
                        'service_userid'  => $serviceUserid,
                        'external_userid' => $externalUserId,
                        'service_state'   => 3
                    ]
                )
            ) {
                KefuServiceRecordsDao::addData([
                    'open_kfid'       => $openKfId,
                    'service_userid'  => $serviceUserid,
                    'external_userid' => $externalUserId,
                    'service_state'   => 3
                ]);
            }

            // 调用接口进行接待
            self::$kefuHttpDao->transServiceState($openKfId, $externalUserId, 3, $serviceUserid);

            // 移除出轮流
            $this->setNotIsNext($openKfId, $serviceUserid);
        } else { // 满员了就进入接待池
            self::$kefuHttpDao->transServiceState($openKfId, $externalUserId, 2);
        }
    }

    /**
     * 空闲分配
     *
     * @param int $previousOrFirst 是否优先上次接待人员
     * @param string $openKfId 客服账号ID
     * @param string $externalUserId 外部联系人id
     * @return string
     * @throws Exception
     */
    public function takeIdleService(int $previousOrFirst, string $openKfId, string $externalUserId): string
    {
        // 找出目前接待人数最少的客服
        $findIdleService = function () use ($openKfId) {
            $allKefuArr = KefuServicerMapDao::getAllList(
                ['userid'],
                [
                    'open_kfid' => $openKfId,
                ]
            );
            $allUserIdArr = array_column($allKefuArr, 'userid');
            $newCountArr = [];
            foreach ($allUserIdArr as $userId) {
                $count = KefuServiceRecordsDao::getCount(
                    [
                        'open_kfid'      => $openKfId,
                        'service_userid' => $userId,
                        'service_state'  => 3
                    ]
                );
                $newCountArr[$count] = $userId;
            }
            ksort($newCountArr);
            return array_shift($newCountArr);
        };

        // 优先上次接待
        if ($previousOrFirst) {
            $lastService = KefuServiceRecordsDao::getDetail(
                [
                    'service_userid'
                ],
                [
                    'open_kfid'       => $openKfId,
                    'external_userid' => $externalUserId
                ],
                'id desc'
            );
            if ($lastService) {
                // 如果上次接待人员没有被移除
                if (
                    KefuServicerMapDao::getDetail(['id'], [
                        'open_kfid' => $openKfId,
                        'userid'    => $lastService['service_userid']
                    ])
                ) {
                    return $lastService['service_userid'];
                }
            }
        }
        return $findIdleService();
    }

    /**
     * 轮流分配
     *
     * @param int $previousOrFirst 是否优先上次接待人员
     * @param string $openKfId 客服账号ID
     * @param string $externalUserid 外部联系人id
     * @return string
     * @throws Exception
     */
    public function takeTurnsService(int $previousOrFirst, string $openKfId, string $externalUserid): string
    {
        if ($previousOrFirst) { // 优先分配给上次的顾问
            // 找到上次接待的人员
            $recordInfo = KefuServiceRecordsDao::getDetail([
                'service_userid',
            ], [
                'open_kfid'       => $openKfId,
                'external_userid' => $externalUserid
            ], 'id desc');
            if ($recordInfo) {
                // 如果上次接待人员没有被移除
                if (
                    KefuServicerMapDao::getDetail(['id'], [
                        'open_kfid' => $openKfId,
                        'userid'    => $recordInfo['service_userid']
                    ])
                ) {
                    return $recordInfo['service_userid'];
                }
            }
        }

        $serviceInfo = KefuServicerMapDao::getDetail(
            [
                'userid'
            ],
            [
                'open_kfid' => $openKfId,
                'is_next'   => 1
            ]
        );
        return $serviceInfo['userid'];
    }

    /**
     * 设置为不是下一个
     *
     * @param $openKfId
     * @param $userId
     * @throws Exception
     */
    private function setNotIsNext($openKfId, $userId)
    {
        KefuServicerMapDao::updateData(['is_next' => 1]);
        KefuServicerMapDao::updateData(['is_next' => 0], [
            'open_kfid' => $openKfId,
            'userid'    => $userId
        ]);
    }

    /**
     * 获取最新的media_id
     *
     * @param string $msgType
     * @param array $fileInfo
     * @param Closure $closure
     * @return mixed
     * @throws Exception
     */
    private function getSingleNewestMediaId(string $msgType, array $fileInfo, Closure $closure)
    {
        $fileManager = new FileManager();

        return $fileManager->updateKefuTemporaryMedia($msgType, $fileInfo, $closure);
    }

    /**
     * 获取小程序和图文的最新media_id
     *
     * @param array $fileInfo
     * @param Closure $closure
     * @return mixed
     * @throws Exception
     */
    private function getLinkNewestMediaId(array $fileInfo, Closure $closure)
    {
        $fileManager = new FileManager();

        return $fileManager->updateKefuTemporaryMedia('image', $fileInfo, $closure);
    }

    /**
     * 下载临时素材然后上传到OSS
     *
     * @param string $mediaId
     * @param string $saveName
     * @return array
     * @throws Exception
     */
    private function downloadMediaAndGetUrl(string $mediaId, string $saveName = ''): array
    {
        $fileManager = new FileManager();
        return $fileManager->downloadMediaUploadOss($mediaId, $saveName);
    }
}
