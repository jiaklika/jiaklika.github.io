<?php

namespace app\api\service\callback\impl;

use app\api\service\callback\CallbackService;

/**
 * Class ApprovalCallbackServiceImpl
 * @package app\api\service\callback\impl
 */
class ApprovalCallbackServiceImpl extends CallbackService
{

    public function handleData(int $logId, array $content)
    {
    }
}
