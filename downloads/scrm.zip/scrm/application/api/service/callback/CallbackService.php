<?php

declare(strict_types=1);

namespace app\api\service\callback;

require_once "extend/workweixin/WXBizMsgCrypt.php";

use app\api\dao\mysql\callback\CallbackLogsDao;
use app\api\util\TokenManager;
use Exception;
use think\Log;
use WXBizMsgCrypt;

/**
 * Class CallbackService
 *
 * @package app\api\service\contracts
 */
abstract class CallbackService
{
    /**
     * @var string
     */
    protected static $encodingAesKey;

    /**
     * @var string
     */
    protected static $token;

    public const APP_ID = TokenManager::APP_ID;


    /**
     * @var object
     */
    private static $instance;

    /**
     * 不同的回调有不同的值
     *
     * @param $encodingAesKey
     * @param $token
     */
    public function setSecret($encodingAesKey, $token)
    {
        static::$encodingAesKey = $encodingAesKey;
        static::$token          = $token;
    }

    /**
     * 获取实例
     *
     * @return object|WXBizMsgCrypt
     */
    private static function getInstance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new WXBizMsgCrypt(static::$token, static::$encodingAesKey, self::APP_ID);
        }
        return self::$instance;
    }

    /**
     * 验证URL
     *
     * @param  $sVerifyMsgSig
     * @param  $sVerifyTimeStamp
     * @param  $sVerifyNonce
     * @param  $sVerifyEchoStr
     * @return void
     */
    public function verifyURL($sVerifyMsgSig, $sVerifyTimeStamp, $sVerifyNonce, $sVerifyEchoStr)
    {
        $sEchoStr = '';

        $errCode = self::getInstance()->VerifyURL(
            $sVerifyMsgSig,
            $sVerifyTimeStamp,
            $sVerifyNonce,
            $sVerifyEchoStr,
            $sEchoStr
        );

        if ($errCode == 0) {
            echo $sEchoStr . "\n";
        } else {
            print("ERR: " . $errCode . "\n\n");
            exit();
        }
    }

    /**
     * 解密数据
     *
     * @param string $sReqMsgSig
     * @param string $sReqTimeStamp
     * @param string $sReqNonce
     * @param string $sReqData 密文
     * @return string
     * @throws Exception
     */
    public function decryptMsg(string $sReqMsgSig, string $sReqTimeStamp, string $sReqNonce, string $sReqData): string
    {
        $sMsg = '';

        $errCode = self::getInstance()->DecryptMsg($sReqMsgSig, $sReqTimeStamp, $sReqNonce, $sReqData, $sMsg);

        if ($errCode != 0) {
            Log::error('解密出错！：' . $errCode);
        }

        return $sMsg;
    }

    /**
     * 处理数据
     *
     * @param  int   $logId   回调记录表主键ID
     * @param  array $content 回调数据
     * @return mixed
     */
    abstract public function handleData(int $logId, array $content);

    /**
     * 添加回调记录
     *
     * @param  string $encryption_xml 密文
     * @param  string $decrypt_xml    解密后的字符串
     * @param  string $callbackUrl    回调地址
     * @return int|string
     */
    public function addCallbackLog(string $encryption_xml, string $decrypt_xml, string $callbackUrl)
    {
        if ($this->isRecordLog()) {
            return CallbackLogsDao::addData(
                [
                    'encryption_xml' => $encryption_xml,
                    'decrypt_xml'    => $decrypt_xml,
                    'callback_url'   => $callbackUrl
                ],
                true
            );
        }
        return 0;
    }

    /**
     * 更新回调记录
     *
     * @param  int    $logId      回调记录主键ID
     * @param  int    $type       消息类型
     *                            0-未知
     *                            1-通讯录
     *                            2-外部联系人
     *                            3-消息推送
     * @param  string $changeType 事件的具体类型
     * @param  int    $isSuccess  是否成功处理
     * @param  string $remark     备注
     * @throws Exception
     */
    public function updateCallbackLog(
        int $logId,
        int $type,
        string $changeType,
        int $isSuccess,
        string $remark = ''
    ) {
        if (!$this->isRecordLog()) {
            return;
        }

        $updateLogData = [
            'type'        => $type,
            'change_type' => $changeType,
            'is_success'  => $isSuccess
        ];

        if ($remark) {
            $updateLogData['remark'] = $remark;
        }

        $updateRes = CallbackLogsDao::updateData($updateLogData, ['id' => $logId]);

        if ($updateRes === false) {
            Log::error('更新回调记录失败！');
        }
    }

    /**
     * 是否记录回调日志
     *
     * @return bool
     */
    private function isRecordLog(): bool
    {
        return config('callback.record_log');
    }
}
