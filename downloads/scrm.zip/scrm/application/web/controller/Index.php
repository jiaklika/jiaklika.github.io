<?php

namespace app\web\controller;

use Exception;
use think\View;

/**
 * Class Index
 * @package app\web\controller
 */
class Index
{
    /**
     * 客户详情页面
     *
     * @param View $view
     * @return string
     * @throws Exception
     */
    public function index(View $view): string
    {
        $view->assign([
            'requestUrl' => config('workweixin.jssdk_config_url'),
            'url2'       => config('workweixin.detail_data_url')
        ]);

        return $view->fetch();
    }

    /**
     * @param View $view
     * @return string
     * @throws Exception
     */
    public function data(View $view): string
    {
        return $view->fetch();
    }

    /**
     * @param View $view
     * @return string
     * @throws Exception
     */
    public function kefu(View $view): string
    {
        $view->assign([
            'requestUrl' => config('workweixin.jssdk_config_url'),
            'url2'       => config('workweixin.add_wechat_url')
        ]);

        return $view->fetch();
    }
}
