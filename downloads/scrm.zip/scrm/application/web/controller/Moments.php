<?php

namespace app\web\controller;

use Exception;
use think\View;

/**
 * Class Moment
 * @package app\web\controller
 */
class Moments
{
    /**
     * 客户详情页面
     *
     * @param View $view
     * @return string
     * @throws Exception
     */
    public function index(View $view): string
    {
        $view->assign([
            'requestUrl' => config('workweixin.jssdk_config_url'),
            'url2'       => config('workweixin.detail_data_url')
        ]);
        return $view->fetch();
    }
}
