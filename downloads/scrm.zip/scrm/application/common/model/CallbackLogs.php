<?php

namespace app\common\model;

use think\Model;

/**
 * Class CallbackLogs
 * @package app\common\model
 */
class CallbackLogs extends Model
{
    // 未知
    public const UNKNOWN = 0;
    // 通讯录
    public const USER = 1;
    // 外部联系人
    public const CONTACT = 2;
    // 消息推送
    public const MESSAGE = 3;
    // 客户群
    public const CONTACT_GROUP = 4;
}
