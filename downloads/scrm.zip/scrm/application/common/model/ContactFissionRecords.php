<?php

namespace app\common\model;

use think\Model;

/**
 * Class ContactFissionRecords
 * @package app\common\model
 */
class ContactFissionRecords extends Model
{
    /**
     * @var string 活动结束时间
     */
    public const REDIS_KEY_FISSION_END_TIME = 'fission_end_time';

    /**
     * @var string 性别开关
     */
    public const IS_DISTINGUISH_GENDER = 'is_distinguish_gender';
}
