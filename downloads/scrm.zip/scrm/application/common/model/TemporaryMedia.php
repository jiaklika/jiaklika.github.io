<?php

namespace app\common\model;

use think\Model;

class TemporaryMedia extends Model
{
    // 活动数量缓存名
    public const ACTIVITY_COUNT_CACHE_NAME = 'activity_count';
}
