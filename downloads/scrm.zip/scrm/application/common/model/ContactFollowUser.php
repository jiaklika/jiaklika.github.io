<?php

namespace app\common\model;

use think\Model;

class ContactFollowUser extends Model
{

    /**
     * 状态-正常
     *
     * @var int
     */
    public const NORMAL = 0;

    /**
     * @var int 状态-员工删除外部联系人
     */
    public const DEL_EXTERNAL_CONTACT = 1;

    /**
     * @var int 状态-外部联系人删除员工
     */
    public const DEL_FOLLOW_USER = 2;

    /**
     * @var int 朋友圈'wxad_button'对应数字
     */
    public const MOMENT_TRANSFER_STATE = 10146;

    /**
     * @var string 朋友圈'wxad_button'
     */
    public const MOMENT_ORIGIN_STATE = 'wxad_button';

    /**
     * @var int 扫描二维码添加
     */
    public const SCAN_CODE_ADD_WAY = 1;

    /**
     * @var int 朋友圈添加方式
     */
    public const MOMENT_ADD_WAY = 100;

    /**
     * 视频号映射
     *
     * @var array
     */
    public const VIDEO_STATE_MAP = [
        20000 => '宝姐家',
        20001 => '宝姐珠宝'
    ];

    /**
     * 宝姐家推广招募官
     */
    public const RECRUITING_OFFICER = 'mengmeng';
}
