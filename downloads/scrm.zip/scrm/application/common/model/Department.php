<?php

namespace app\common\model;

use think\Model;

class Department extends Model
{
    // 没有删除
    public const NOT_DEL = 0;
    // 已经删除
    public const HAS_DEL = 1;

    // 是否删除映射
    public const IS_DEL_MAP = [
        self::NOT_DEL => '否',
        self::HAS_DEL => '是'
    ];

    public const ROOT_PARENT_DEPARTMENT_ID = 1; // 根部门id为1
}
