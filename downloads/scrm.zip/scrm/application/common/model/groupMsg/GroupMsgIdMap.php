<?php

namespace app\common\model\groupMsg;

use think\Model;

/**
 * Class GroupMsgIdMap
 * @package app\common\model\groupMsg
 */
class GroupMsgIdMap extends Model
{
    /**
     * @var int 未获取群发执行结果
     */
    public const NOT_GET_RESULT = 0;

    /**
     * @var int 已获取群发执行结果
     */
    public const IS_GET_RESULT = 1;
}
