<?php

namespace app\common\model\groupMsg;

use think\Model;

/**
 * Class GroupMsgSenderMap
 * @package app\common\model\groupMsg
 */
class GroupMsgSenderMap extends Model
{

}
