<?php

namespace app\common\model\groupMsg;

use think\Model;

/**
 * Class GroupMsgTemplates
 * @package app\common\model\groupMsg
 */
class GroupMsgTemplates extends Model
{
    /**
     * @var string 队列处理类
     */
    public const JOB_HANDLER = 'app\api\job\groupMsg\GroupMsgJob';

    /**
     * @var string 队列名称
     */
    public const JOB_QUEUE_NAME = 'send_group_msg_queue';

    /**
     * @var string redis的Hash结构名
     */
    public const REDIS_GROUP_MSG_HASH_KEY_NAME = 'group_msg_external_user_id:%s';

    /**
     * @var string redis的Set结构名
     */
    public const REDIS_GROUP_MSG_SET_KEY_NAME = 'group_msg_set:%s';

    /**
     * @var int 所有客户
     */
    public const RECEIVER_ALL = 0;

    /**
     * @var int 只按用户筛选
     */
    public const RECEIVER_ONLY_SENDER = 1;

    /**
     * @var int 只按标签筛选
     */
    public const RECEIVER_ONLY_TAG = 2;

    /**
     * @var int 按用户和标签筛选
     */
    public const RECEIVER_SENDER_AND_TAG = 3;

    /**
     * @var int 立即发送
     */
    public const NOT_PLAN = 0;

    /**
     * @var int 定时发送
     */
    public const IS_PLAN = 1;

    /**
     * @var int 定时任务没处理
     */
    public const NOT_HANDLE = 0;

    /**
     * @var int 定时任务已处理
     */
    public const HAS_HANDLED = 1;

    /**
     * @var int 未开始
     */
    public const STATUS_NOT_BEGIN = 0;

    /**
     * @var int 进行中
     */
    public const STATUS_IS_PROCESSING = 1;

    /**
     * @var int 已结束
     */
    public const STATUS_IS_END = 2;

    /**
     * @var int 没有删除
     */
    public const NOT_DELETED = 0;

    /**
     * @var int 已经删除
     */
    public const IS_DELETED = 1;
}
