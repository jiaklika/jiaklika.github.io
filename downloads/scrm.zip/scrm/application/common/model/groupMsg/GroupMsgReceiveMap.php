<?php

namespace app\common\model\groupMsg;

use think\Model;

/**
 * Class GroupMsgReceiveMap
 * @package app\common\model\groupMsg
 */
class GroupMsgReceiveMap extends Model
{
    /**
     * @var int 未发送
     */
    public const STATUS_NOT_SEND = 0;

    /**
     * @var int 已发送
     */
    public const STATUS_HAS_SEND = 1;

    /**
     * @var int 因客户不是好友导致发送失败
     */
    public const STATUS_NOT_FRIEND = 2;

    /**
     * @var int 因客户已经收到其他群发消息导致发送失败
     */
    public const STATUS_IS_LOCK = 3;
}
