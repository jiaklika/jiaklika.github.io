<?php

namespace app\common\model\groupMsg;

use think\Model;

/**
 * Class GroupMsgTagMap
 * @package app\common\model\groupMsg
 */
class GroupMsgTagMap extends Model
{

}
