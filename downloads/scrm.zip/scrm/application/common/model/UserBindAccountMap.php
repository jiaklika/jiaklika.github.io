<?php

namespace app\common\model;

use think\Model;

/**
 * Class UserBindAccountMap
 * @package app\common\model
 */
class UserBindAccountMap extends Model
{
    /**
     * @var string 指定客服对应账号缓存名
     */
    public const SPECIFIC_USER_ACCOUNTS_KEY = '%s_accounts';
}
