<?php

namespace app\common\model;

use think\Model;

/**
 * Class ContactChannels
 * @package app\common\model
 */
class ContactChannels extends Model
{
    // 未知
    public const UNKNOWN = 0;
    // 小程序
    public const MINI_PROGRAM = 1;
    // 图片
    public const IMAGE = 2;
    // 链接
    public const LINK = 3;

    // 未删除
    public const NOT_DELETE = 0;
    // 已删除
    public const IS_DELETE = 1;

    // 欢迎语类型映射
    public const WELCOME_TYPE_MAP = [
        self::UNKNOWN      => '',
        self::MINI_PROGRAM => 'miniprogram',
        self::IMAGE        => 'image',
        self::LINK         => 'link'
    ];

    /**
     * @var array 小程序APPID和名称映射
     */
    public const MINI_PROGRAM_APP_ID_MAP = [
        'wx3378cc5758d57fb2' => '宝姐家小程序',
        'wxf07cf3fb7e470a92' => '宝姐珠宝小程序'
    ];

    /**
     * @var int 宝姐家阳阳3普通添加渠道ID
     */
    public const YANGYANG3_CHANNEL_ID = 147;

    /**
     * @var int 宝姐家阳阳5和宝姐家福利官·凡凡普通添加渠道ID
     */
    public const MENGMENG_CHANNEL_ID = 148;

    /**
     * @var int 阳阳7视频号欢迎语
     */
    public const YANGYANG7_VIDEO_LIVE_CHANNEL_ID = 170;

    /**
     * @var int 宝姐家阳阳5普通添加渠道ID
     */
    public const YANGYANG5_CHANNEL_ID = 200;

    /**
     * @var int 宝姐家阳阳2普通添加渠道ID
     */
    public const YANGYANG2_CHANNEL_ID = 199;

    /**
     * 朋友圈推广渠道和客服映射
     */
    public const MOMENT_CHANNEL_MAP = [
        190 => ['yangyang3', 'yangyang4', 'yangyang123', 'yangyang5'], // 彩宝3（私域定投）
        165 => ['qingqing', 'yangyang123', 'yangyang5', 'yangyang1', 'baojiejiayangyang9'], // 彩宝1
        203 => ['yiyi', 'yangyang2'], // 阳阳12
        146 => ['yangyang3', 'baojiejiayangyang9'], // 【朋友圈加粉】—珍珠老
        149 => ['xiaohan', 'BaoJieZhuBaoGuWenNiNi', 'jiaojiao'],   // 【朋友圈加粉】—宝姐珠宝
        151 => ['yangyang2'], // 【朋友圈加粉】—蜜蜡（珍珠新）
        // 152 => ['jiaojiao']   // 【朋友圈加粉】—蓝宝石
        166 => ['yanyan'], // 彩宝2
        153 => ['yanyan', 'qingqing', 'yangyang3', 'yangyang4',
            'yangyang123', 'yangyang5', 'yangyang1', 'baojiejiayangyang9'], // 彩宝汇总
    ];

    /**
     * 视频号映射
     *
     * @var array
     */
    public const WECHAT_VIDEO_MAP = [
        197 => '宝姐家',
        198 => '宝姐珠宝'
    ];

    /**
     * 视频号映射
     *
     * @var array
     */
    public const WECHAT_VIDEO_STATE_MAP = [
        197 => 20000,
        198 => 20001
    ];
}
