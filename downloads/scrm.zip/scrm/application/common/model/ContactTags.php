<?php

namespace app\common\model;

use think\Model;

class ContactTags extends Model
{
    /**
     * @var int
     *
     * 标签没被删除
     */
    public const TAG_NOT_DELETED = 0;

    /**
     * @var int
     *
     * 标签被删除
     */
    public const TAG_IS_DELETED = 1;

    /**
     * @var int
     *
     * 标签组没被删除
     */
    public const GROUP_NOT_DELETED = 0;

    /**
     * @var int
     *
     * 标签组被删除
     */
    public const GROUP_IS_DELETED = 1;

    /**
     * @var string 来源渠道
     */
    public const SOURCE_CHANNEL = 'source_channel';

    /**
     * @var string 新的累计消费
     */
    public const NEW_CONTRACT_AMOUNT = 'new_contract_amount';

    /**
     * @var string 会员等级
     */
    public const MEMBER_LEVEL = 'member_level';

    /**
     * @var string 颜值等级
     */
    public const YANZHI_RANK = 'yanzhi_rank';

    /**
     * @var array
     *
     * 标签组
     */
    public const GROUP_ID_MAP = [
        self::SOURCE_CHANNEL      => 'et5b2CBwAAhdxSELLTK9WEjrqPaoi8Cg', // 来源渠道
        self::MEMBER_LEVEL        => 'et5b2CBwAAkSMm5yU8poo265T8Ctpc6w', // 会员等级
        self::YANZHI_RANK         => 'et5b2CBwAA2psCik_tcO25trr6X49JJw', // 颜值等级
        self::NEW_CONTRACT_AMOUNT => 'et5b2CBwAAAKGgQ-AvbuCAoR6XR2xGXQ', // 新的累计消费
    ];

    /**
     * @var string
     *
     * 来源渠道"未知"渠道
     */
    public const CHANNEL_UNKNOWN_TAG_ID = 'et5b2CBwAA5ffiLu_hos1juabnCBTZqw';

    /**
     * @var string
     *
     * 标签组redis集合
     */
    public const CALLBACK_REDIS_SET_KEY = 'callback_group_tag';

    /**
     * @var string "好友"标签
     */
    public const IS_FRIEND_TAG = 'et5b2CBwAAndvq8rMizuMGaTsRFQ0Okg';

    /**
     * @var string "非好友"标签
     */
    public const NOT_FRIEND_TAG = 'et5b2CBwAAy9O_FmNeY9tpBmBc8O62FA';

    /**
     * @var string "不在费月群内"标签
     */
    public const NOT_IN_FEIYUE_GROUP_TAG = 'et5b2CBwAAZSM1gcPLz5uDNeaD7xL_LQ';

    /**
     * @var string "不在赵蔚群内"标签
     */
    public const NOT_IN_ZHAOWEI_GROUP_TAG = 'et5b2CBwAAO6SmG7yGbSSIxmcWiY2aDA';

    /**
     * @var array 员工和标签关于群的映射
     */
    public const NOT_IN_GROUP_TAG = [
        'feiyue'  => self::NOT_IN_FEIYUE_GROUP_TAG,
        'zhaowei' => self::NOT_IN_ZHAOWEI_GROUP_TAG
    ];

    /**
     * @var string 处理标签队列名
     */
    public const HANDLE_CONTACT_TAG_QUEUE = 'handle_contact_tag_queue';

    /**
     * @var string 处理标签队列类
     */
    public const HANDLE_CONTACT_TAG_HANDLER = 'app\api\job\tag\HandleContactTagJob';

    /**
     * @var string 首单客户
     */
    public const FIRST_ORDER_TAG = 'et5b2CBwAAU4htvjM_D0GIMP9eFu_DSA';

    /**
     * @var array 首单新客
     */
    public const NEW_CUSTOMER_TAG = [
        1 => 'et5b2CBwAA5xF-lSnrne-IuR2-DzvgjA', // 宝姐饰界新客
        2 => 'et5b2CBwAApWZvwxLPvVvDUmPwplNmuw', // 兴趣电商新客
        3 => 'et5b2CBwAAdCLTgd5nC4WVEDF01biaSQ'  // 宝姐珠宝新客
    ];

    /**
     * @var string 小红书
     */
    public const RED_BOOK_TAG = 'et5b2CBwAAEVojNvI7cEkBfdSsikP8sw';

    /**
     * @var string 推粉标签组
     */
    public const PUSH_FANS_GROUP_TAG = 'et5b2CBwAAbE1rh0HTSyjEYWyW7HT8Ag';

    /**
     * @var string 分享员
     */
    public const SHARER_TAG = 'et5b2CBwAApTrJZNC1dTbf3hexPdyXVA';
}
