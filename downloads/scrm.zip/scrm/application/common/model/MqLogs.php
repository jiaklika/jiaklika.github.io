<?php

namespace app\common\model;

use think\Model;

class MqLogs extends Model
{
    // 是企微成员
    public const IS_CONTACT = 1;
}
