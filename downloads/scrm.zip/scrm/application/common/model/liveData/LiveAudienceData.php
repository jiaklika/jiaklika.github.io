<?php

namespace app\common\model\liveData;

use think\Model;

/**
 * Class LiveAudienceData
 * @package app\common\model\liveData
 */
class LiveAudienceData extends Model
{
    /**
     * @var int 不是消费者
     */
    public const NOT_CONSUME = 0;

    /**
     * @var int 是消费者
     */
    public const IS_CONSUME = 1;

    /**
     * @var int 不是新客
     */
    public const NOT_FIRST_ORDER = 0;

    /**
     * @var int 是新客
     */
    public const IS_FIRST_ORDER = 1;

    /**
     * @var int 参与抽奖
     */
    public const IS_LUCK_DRAW = 1;
}
