<?php

namespace app\common\model\liveData;

use think\Model;

/**
 * Class LiveData
 * @package app\common\model\liveData
 */
class LiveData extends Model
{
    /**
     * @var int 直播没结束
     */
    public const NOT_END = 0;

    /**
     * @var int 直播已结束
     */
    public const IS_END = 1;

    /**
     * @var int 没发送消息
     */
    public const NOT_SEND = 0;

    /**
     * @var int 已发送消息
     */
    public const IS_SEND = 1;

    /**
     * @var int 小程序直播
     */
    public const MINI_PROGRAM_LIVE = 0;

    /**
     * @var int 视频号直播
     */
    public const VIDEO_LIVE = 1;
}
