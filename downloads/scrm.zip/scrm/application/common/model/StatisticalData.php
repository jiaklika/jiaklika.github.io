<?php

namespace app\common\model;

use think\Model;

class StatisticalData extends Model
{
    /**
     * @var int
     *
     * 日
     */
    public const DAY = 1;

    /**
     * @var int
     *
     * 周
     */
    public const WEEK = 2;

    /**
     * @var int
     *
     * 月
     */
    public const MONTH = 3;
}
