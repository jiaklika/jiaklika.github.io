<?php

namespace app\common\model;

use think\Model;

/**
 * Class ChannelWelcomeMsg
 * @package app\common\model
 */
class ChannelWelcomeMsg extends Model
{
    // 非工作时间
    public const NOT_WORKING_TIME = 0;
    // 工作时间
    public const IS_WORKING_TIME = 1;
}
