<?php

namespace app\common\model\moment;

use think\Model;

/**
 * Class MomentTask
 * @package app\common\model\moment
 */
class MomentTask extends Model
{
    /**
     * @var int 所有客户
     */
    public const RECEIVER_ALL = 0;

    /**
     * @var int 只按用户筛选
     */
    public const RECEIVER_ONLY_SENDER = 1;

    /**
     * @var int 只按标签筛选
     */
    public const RECEIVER_ONLY_TAG = 2;

    /**
     * @var int 按用户和标签筛选
     */
    public const RECEIVER_SENDER_AND_TAG = 3;

    /**
     * @var int 立即发送
     */
    public const NOT_PLAN = 0;

    /**
     * @var int 定时发送
     */
    public const IS_PLAN = 1;

    /**
     * @var int 定时任务没处理
     */
    public const NOT_HANDLE = 0;

    /**
     * @var int 定时任务已处理
     */
    public const HAS_HANDLED = 1;

    /**
     * @var int 未开始
     */
    public const STATUS_NOT_BEGIN = 0;

    /**
     * @var int 进行中
     */
    public const STATUS_IS_PROCESSING = 1;

    /**
     * @var int 已结束
     */
    public const STATUS_IS_END = 2;

    /**
     * @var int 没有删除
     */
    public const NOT_DELETED = 0;

    /**
     * @var int 已经删除
     */
    public const IS_DELETED = 1;
}
