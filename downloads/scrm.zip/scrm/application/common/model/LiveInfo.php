<?php

namespace app\common\model;

use think\Model;

/**
 * Class LiveInfo
 * @package app\common\model
 */
class LiveInfo extends Model
{

}
