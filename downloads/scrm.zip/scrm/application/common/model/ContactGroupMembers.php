<?php

namespace app\common\model;

use think\Model;

/**
 * Class ContactGroupMembers
 * @package app\common\model
 */
class ContactGroupMembers extends Model
{
    /**
     * @var int 内部员工
     */
    public const INTERNAL_USER = 1;

    /**
     * @var int 外部联系人
     */
    public const EXTERNAL_USER = 2;

    /**
     * @var array
     *
     * 群成员类型映射
     */
    public const USER_TYPE_MAP = [
        self::INTERNAL_USER => '内部员工',
        self::EXTERNAL_USER => '外部联系人'
    ];

    /**
     * @var int 没有退群
     */
    public const NOT_DELETED = 0;

    /**
     * @var int 已经退群
     */
    public const IS_DELETED = 1;

    /**
     * @var int 由成员邀请入群（直接邀请入群）
     */
    public const DIRECT_INVITE = 1;

    /**
     * @var int 由成员邀请入群（通过邀请链接入群）
     */
    public const LINK_INVITE = 2;

    /**
     * @var int 通过扫描群二维码入群
     */
    public const SCAN_QRCODE = 3;

    /**
     * @var string 新粉福利群所有群成员的unionId集合名
     */
    public const NEW_FANS_ALL_UNION_ID_KEY = 'new_fans_all_unionid';

    /**
     * @var string 好物优享群所有群Id集合名
     */
    public const GOOD_STUFF_ALL_GROUP_ID_KEY = 'good_stuff_all_group_id';

    /**
     * @var string 新粉福利群所有群Id集合名
     */
    public const NEW_FANS_ALL_GROUP_ID_KEY = 'new_fans_all_group_id';

    /**
     * @var string 周一至周五下午5点发优惠券群Id集合名
     */
    public const WEEK_COUPON_ALL_GROUP_ID_KEY = 'week_coupon_all_group_id';

    /**
     * @var string 官方福利群Id集合名
     */
    public const COMPANY_DISCOUNT_ALL_GROUP_ID_KEY = 'company_discount_all_group_id';

    /**
     * @var string 宝姐家优享福利群Id集合名
     */
    public const ENJOY_WELFARE_ALL_GROUP_ID_KEY = 'enjoy_welfare_all_group_id';

    /**
     * @var string 宝姐饰界福利秒杀群Id集合名
     */
    public const ORNAMENTS_WELFARE_ALL_GROUP_ID_KEY = 'ornaments_welfare_all_group_id';

    /**
     * @var string 宝姐珠宝好物专享群Id集合名
     */
    public const GOOD_STUFF_VIP_ALL_GROUP_ID_KEY = 'good_stuff_vip_all_group_id';
}
