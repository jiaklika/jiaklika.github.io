<?php

namespace app\common\model;

use think\Model;

/**
 * Class ExternalContact
 * @package app\common\model
 */
class ExternalContact extends Model
{
    // 微信
    public const WEIXIN_USER = 1;
    // 企业微信
    public const WORK_WEIXIN_USER = 2;

    // 未知
    public const UNKNOWN_GENDER = 0;
    // 男
    public const MALE = 1;
    // 女
    public const FEMALE = 2;

    /**
     * 类型映射
     */
    public const TYPE_MAP = [
        self::WEIXIN_USER      => '微信',
        self::WORK_WEIXIN_USER => '企业微信'
    ];

    /**
     * 性别映射
     */
    public const GENDER_MAP = [
        self::UNKNOWN_GENDER => '未知',
        self::MALE           => '男',
        self::FEMALE         => '女'
    ];

    // 宝姐客户等级
    public const NEW_USER = 0;
    public const FANS = 1;
    public const LOYAL_FANS = 2;
    public const BIG_FANS = 3;
    public const LADIES = 4;
    public const FASHION_LADIES = 5;
    public const SUPREME_LADIES = 6;

    public const USER_LEVEL_LIST = [
        [
            'id'   => self::NEW_USER,
            'name' => '新人',
        ],
        [
            'id'   => self::FANS,
            'name' => '宝迷',
        ],
        [
            'id'   => self::LOYAL_FANS,
            'name' => '忠实宝迷',
        ],
        [
            'id'   => self::BIG_FANS,
            'name' => '铁杆宝迷',
        ],
        [
            'id'   => self::LADIES,
            'name' => '名媛',
        ],
        [
            'id'   => self::FASHION_LADIES,
            'name' => '风尚名媛',
        ],
        [
            'id'   => self::SUPREME_LADIES,
            'name' => '至尊名媛',
        ],

    ];

    public const USER_LEVEL_MAP = [
        self::NEW_USER       => '新人',
        self::FANS           => '宝迷',
        self::LOYAL_FANS     => '忠实宝迷',
        self::BIG_FANS       => '铁杆宝迷',
        self::LADIES         => '名媛',
        self::FASHION_LADIES => '风尚名媛',
        self::SUPREME_LADIES => '至尊名媛',
    ];

    // 回调打标签队列名称
    public const CALLBACK_TAG_QUEUE = 'callback_tag_queue';
    // 回调打标签队列处理类
    public const CALLBACK_TAG_JOB_HANDLER = 'app\api\job\tag\CallbackMarkTagJob';

    // 回调加客户队列名称
    public const CALLBACK_ADD_CONTACT_QUEUE = 'callback_add_contact_queue';
    // 回调打标签队列处理类
    public const CALLBACK_ADD_CONTACT_HANDLER = 'app\api\job\callback\AddContactJob';

    /**
     * @var string 颜值青铜
     */
    public const YANZHI_BRONZE = '颜值青铜';

    /**
     * @var string 颜值白银
     */
    public const YANZHI_SILVER = '颜值白银';

    /**
     * @var string 颜值黄金
     */
    public const YANZHI_GOLD = '颜值黄金';

    /**
     * @var int 有消费
     */
    public const IS_CONSUME = 1;

    /**
     * @var int 有消费
     */
    public const NO_CONSUME = 0;

    /**
     * @var int 是好友
     */
    public const IS_FRIEND = 1;

    /**
     * @var int 不是好友
     */
    public const NOT_FRIEND = 0;
}
