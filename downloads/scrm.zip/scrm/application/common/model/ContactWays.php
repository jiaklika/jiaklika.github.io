<?php

namespace app\common\model;

use think\Model;

class ContactWays extends Model
{
    /**
     * 删除
     */
    public const IS_DELETED = 1;

    /**
     * 未删除
     */
    public const NOT_DELETED = 0;

    /**
     * 小程序
     */
    public const MINI_PROGRAM = 1;

    /**
     * 活码
     */
    public const QR_CODE = 2;

    /**
     * 添加场景映射
     */
    public const SCENE_MAP = [
        self::MINI_PROGRAM => '咨询按钮',
        self::QR_CODE      => '活码'
    ];

    /**
     * 推荐官活码ID
     *
     * @var int
     */
    public const RECRUITING_OFFICER_ID = 390;
}
