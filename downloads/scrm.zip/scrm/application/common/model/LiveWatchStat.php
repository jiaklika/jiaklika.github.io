<?php

namespace app\common\model;

use think\Model;

/**
 * Class LiveWatchStat
 * @package app\common\model
 */
class LiveWatchStat extends Model
{
    // 企业成员
    public const USER = 1;
    // 外部成员
    public const EXTERNAL_USER = 2;

    // 非外部成员
    public const NOT_EXTERNAL = 0;
    // 微信用户
    public const EXTERNAL_WEIXIN = 1;
    // 企业微信用户
    public const EXTERNAL_WORK_WEIXIN = 2;

    /**
     * 观众类型映射
     */
    public const USER_TYPE_MAP = [
        self::USER          => '企业成员',
        self::EXTERNAL_USER => '外部成员'
    ];

    /**
     * 外部成员类型映射
     */
    public const EXTERNAL_TYPE_MAP = [
        self::NOT_EXTERNAL         => '非外部成员',
        self::EXTERNAL_WEIXIN      => '微信用户',
        self::EXTERNAL_WORK_WEIXIN => '企业微信用户'
    ];
}
