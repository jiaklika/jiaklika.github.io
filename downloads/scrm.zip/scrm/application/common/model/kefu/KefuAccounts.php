<?php

namespace app\common\model\kefu;

use think\Model;

/**
 * Class KefuAccounts
 * @package app\common\model\kefu
 */
class KefuAccounts extends Model
{
    /**
     * @var string 发送文字欢迎语
     */
    public const WELCOME_TYPE_TEXT = 1;

    /**
     * @var string 初级销售顾问
     */
    public const PRIMARY_ADVISER = 'wk5b2CBwAAHgUtP2iymJSLRvVUJzGiHA';

    /**
     * @var string 宝姐家客服
     */
    public const BAOJIE_HOME_ADVISER = 'wk5b2CBwAA_W-Vut0NDm_QYM8mQm0Aig';
}
