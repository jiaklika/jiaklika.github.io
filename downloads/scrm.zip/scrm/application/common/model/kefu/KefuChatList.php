<?php

namespace app\common\model\kefu;

use think\Model;

/**
 * Class KefuChatList
 * @package app\common\model\kefu
 */
class KefuChatList extends Model
{
    /**
     * @var array 渠道映射
     */
    public const CHANNEL_MAP = [
        'good'              => '商品详情',
        'goods_detail'      => '商品详情',
        'payment'           => '支付',
        'user'              => '用户中心',
        'order_detail'      => '订单详情',
        'order_list'        => '订单列表',
        'live'              => '直播',
        'auction'           => '拍卖',
        'friend_circle'     => '朋友圈',
        'install'           => '安装',
        'live_good'         => '直播商品',
        'member_center'     => '会员中心',
        'member_interest'   => '会员权益',
        'member_upgrade'    => '会员升级',
        'new_order_detail'  => '新订单详情',
        'video'             => '视频',
        'point_collect'     => '点收集',
        'custom_jump'       => '自定义跳转 ',
        'confirm_order'     => '确认订单',
        'my_page'           => '我的页面',
        'activity'          => '限时活动',
        'auction_list'      => '拍卖主页',
        'auction_detail'    => '拍卖详情',
        'crowdfund'         => '众筹',
        'newAuctionPreview' => '预展页面',
        'auctionLive'       => '拍卖页面',
        'live_list'         => '直播列表',
        'value_exchange'    => '宝姐家分享员',
        'video_detail'      => '视频详情',
        'content_detail'    => '文章详情',
        'personal_center'   => '个人中心',
        'sign_rule'         => '签到规则',
        'money_detail'      => '购物金明细',
        'week_update'       => '每周上新',
        'auctionConpon'     => '我的大礼包',
        'bojem_auction'     => '宝姐拍卖'
    ];
}
