<?php

namespace app\common\model\kefu;

use think\Model;

/**
 * Class KefuChatRecords
 * @package app\common\model\kefu
 */
class KefuChatRecords extends Model
{
    /**
     * @var int 微信客户发送的消息
     */
    public const CONTACT = 3;

    /**
     * @var int 系统推送的事件消息
     */
    public const SYSTEM = 4;

    /**
     * @var int 接待人员在企业微信客户端发送的消息
     */
    public const SERVICE = 5;
}