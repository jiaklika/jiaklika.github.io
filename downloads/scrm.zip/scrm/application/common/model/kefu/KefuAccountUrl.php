<?php

namespace app\common\model\kefu;

use think\Model;

/**
 * 客服账号链接
 *
 * Class KefuAccounts
 * @package app\common\model\kefu
 */
class KefuAccountUrl extends Model
{
    /**
     * @var int 宝姐家小程序
     */
    public const BAOJIE_HOME = 1;

    /**
     * @var int 宝姐珠宝小程序
     */
    public const BAOJIE_JEWELLERY = 2;

    /**
     * @var int APP
     */
    public const APP = 3;
}
