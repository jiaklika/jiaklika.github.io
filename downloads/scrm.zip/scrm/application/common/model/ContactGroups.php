<?php

namespace app\common\model;

use think\Model;

class ContactGroups extends Model
{
    /**
     * 没有解散
     */
    public const NOT_DELETED = 0;

    /**
     * 已经解散
     */
    public const IS_DELETED = 1;


    public const GOOD_STUFF = 'good_stuff';
    public const NEW_FANS = 'new_fans';
    public const GOOD_STUFF_NAME = '好物优享';
    public const NEW_FANS_NAME = '新粉福利';

    public const GROUP_MAP = [
        self::GOOD_STUFF => self::GOOD_STUFF_NAME,
        self::NEW_FANS   => self::NEW_FANS_NAME
    ];
}
