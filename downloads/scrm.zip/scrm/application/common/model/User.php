<?php

namespace app\common\model;

use think\Model;

class User extends Model
{
    // 删除
    public const IS_DELETED = 1;
    // 没被删除
    public const NOT_DELETED = 0;

    // 已激活
    public const ACTIVATED = 1;
    // 已禁用
    public const DISABLED = 2;
    // 未激活
    public const INACTIVATED = 4;
    // 退出企业
    public const WITHDRAW = 5;

    // 激活状态映射
    public const STATUS_MAP = [
        self::ACTIVATED   => '已激活',
        self::DISABLED    => '已禁用',
        self::INACTIVATED => '未激活',
        self::WITHDRAW    => '退出企业'
    ];

    // 没有客户联系权限
    public const NOT_FOLLOW_USER = 0;
    // 有客户联系权限
    public const IS_FOLLOW_USER = 1;

    // 小程序导流企微社群
    /*public const KO_USER_MAP = [
        'yunyingkefu',  // 小雨
        'kefuxiaoxiao', // 晓晓
        'mengmeng',     // 凡凡
        'yuanyuan',     // 媛媛
        'yiyi',         // 伊伊
        'xixi',         // 茜茜
        'lingling',     // 玲玲
        'xingxing',     // 欣欣
        'qianqian',     // 千千
        'wanwan',       // 婉婉
        'lulu',         // 露露
        'yanyan',       // 燕燕
        'yaya   ',      // 丫丫
        'jiujiu',       // 酒酒
        'qingqing',     // 晴晴
        'jiaojiao'      // 娇娇
    ];*/

    /**
     * 用户绑定企业微信账号
     *
     * @var array
     */
    public const USER_BIND_MAP = [
        'feiyue',       // 费月
        'zhaowei',      // 赵蔚
        'peiyonghao',   // 裴永昊
        'louxuchun',    // 楼旭春
        'zhangbo',      // 张博
        'xujuntao',     // 徐俊涛
        'zhuyichang'    // 朱铃艳
    ];
}
