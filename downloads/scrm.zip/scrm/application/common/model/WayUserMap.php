<?php

namespace app\common\model;

use think\Model;

/**
 * Class WayUserMap
 * @package app\common\model
 */
class WayUserMap extends Model
{

}
