<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class OpengidRecords extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('opengid_records', [
            'engine'    => 'InnoDB',
            'comment'   => '小程序在客户群启动信息表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('open_gid', 'char', [
                'limit'   => 28,
                'default' => '',
                'comment' => '客户群opengid'
            ])
            ->addColumn('chat_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '客户群chat_id'
            ])
            ->addColumn('unionid', 'char', [
                'limit'   => 28,
                'default' => '',
                'comment' => '微信用户unionid'
            ])
            ->addColumn('open_path', 'string', [
                'limit'   => 200,
                'default' => '',
                'comment' => '打开的路径'
            ])
            ->addColumn('open_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '获取时间'
            ])
            ->addColumn('program_type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '小程序类型 0-未知 1-宝姐家 2-宝姐珠宝 默认0'
            ])
            ->addTimestamps()
            ->addIndex(['chat_id'], [
                'name' => 'chat_id_index'
            ])
            ->addIndex(['program_type'], [
                'name' => 'program_type_index'
            ])
            ->addIndex(['unionid'], [
                'name' => 'unionid_index'
            ])
            ->create();

        $table->removeColumn('update_time')->update();
    }
}
