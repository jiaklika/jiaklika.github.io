<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactFollowUser extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_follow_user', [
            'engine'    => 'InnoDB',
            'comment'   => '外部联系人对应用户表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('external_userid', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '外部联系人的userid'
            ])
            ->addColumn('userid', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '添加了此外部联系人的企业成员userid'
            ])
            ->addColumn('remark', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '该成员对此外部联系人的备注'
            ])
            ->addColumn('description', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '该成员对此外部联系人的描述'
            ])
            ->addColumn('createtime', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '该成员添加此外部联系人的时间'
            ])
            ->addColumn('create_date', 'date', [
                'default' => 0,
                'comment' => '该成员添加此外部联系人的日期'
            ])
            ->addColumn('tags', 'text', [
                'null' => true,
                'comment' => '该成员添加此外部联系人所打标签信息'
            ])
            ->addColumn('remark_corp_name', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '该成员对此客户备注的企业名称'
            ])
            ->addColumn('remark_mobiles', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '该成员对此客户备注的手机号码'
            ])
            ->addColumn('oper_userid', 'string', [
                'limit'   => 255,
                'default' => '',
                // @codingStandardsIgnoreLine
                'comment' => '发起添加的userid，如果成员主动添加，为成员的userid；如果是客户主动添加，则为客户的外部联系人userid；如果是内部成员共享/管理员分配，则为对应的成员/管理员userid'
            ])
            ->addColumn('add_type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '添加主动方 1-员工主动添加 2-客户主动添加 3-内部成员共享/管理员分配 默认1'
            ])
            ->addColumn('add_way', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                // @codingStandardsIgnoreLine
                'comment' => '该成员添加此客户的来源 0-未知来源 1-扫描二维码 2-搜索手机号 3-名片分享 4-群聊 5-手机通讯录 6-微信联系人 7-来自微信的添加好友申请 8-安装第三方应用时自动添加的客服人员 9-搜索邮箱 201-内部成员共享 202-管理员/负责人分配 默认0'
            ])
            ->addColumn('state', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '企业自定义的state参数，用于区分客户具体是通过哪个「联系我」添加'
            ])
            ->addColumn('random_index', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '欢迎语索引 0-未开启 1-a 2-b 3-c 4-d 5-e 默认0'
            ])
            ->addTimestamps()
            ->addColumn('status', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '状态 0-正常 1-员工删除外部联系人 2-外部联系人删除员工 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addIndex(['external_userid'], [
                'name' => 'external_userid_index'
            ])
            ->addIndex(['userid'], [
                'name' => 'userid_index'
            ])
            ->addIndex(['state'], [
                'name' => 'state_index'
            ])
            ->addIndex(['create_date'], [
                'name' => 'create_date_index'
            ])
            ->create();
    }
}
