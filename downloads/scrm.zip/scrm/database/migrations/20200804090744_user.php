<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class User extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        // create the table
        $table = $this->table('user', [
            'engine'    => 'InnoDB',
            'comment'   => '企业微信员工表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('userid', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '成员UserID'
            ])
            ->addColumn('name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '成员名称'
            ])
            ->addColumn('english_name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '英文名'
            ])
            ->addColumn('mobile', 'char', [
                'limit'   => 11,
                'default' => '',
                'comment' => '手机号码'
            ])
            ->addColumn('hide_mobile', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否隐藏手机号 0-否 1-是 默认0'
            ])
            ->addColumn('department', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '成员所属部门id列表'
            ])
            ->addColumn('order', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '部门内的排序值，默认为0。数量必须和department一致，数值越大排序越前面。'
            ])
            ->addColumn('position', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '职务信息'
            ])
            ->addColumn('gender', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '性别 0-未定义 1-男性 2-女性 默认0'
            ])
            ->addColumn('email', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '邮箱'
            ])
            ->addColumn('is_leader', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否为上级 0-否 1-是 默认0'
            ])
            ->addColumn('is_leader_in_dept', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '表示在所在的部门内是否为上级'
            ])
            ->addColumn('avatar', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '头像url'
            ])
            ->addColumn('thumb_avatar', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '头像缩略图url'
            ])
            ->addColumn('telephone', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '座机'
            ])
            ->addColumn('alias', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '别名'
            ])
            ->addColumn('extattr', 'text', [
                'null' => true,
                'comment' => '扩展属性'
            ])
            ->addColumn('status', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '激活状态: 1-已激活 2-已禁用 4-未激活 5-退出企业 默认1'
            ])
            ->addColumn('qr_code', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '员工个人二维码url'
            ])
            ->addColumn('external_profile', 'text', [
                'null' => true,
                'comment' => '成员对外属性'
            ])
            ->addColumn('external_position', 'text', [
                'null' => true,
                'comment' => '对外职务'
            ])
            ->addColumn('address', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '地址'
            ])
            ->addColumn('main_department', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '主部门'
            ])
            ->addColumn('is_follow_user', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否配置了客户联系功能 0-否 1-是 默认0'
            ])
            ->addColumn('entry_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '进入企业微信时间'
            ])
            ->addTimestamps()
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addIndex(['userid'], [
                'name' => 'userid_index'
            ])
            ->addIndex(['main_department'], [
                'name' => 'main_department_index'
            ])
            ->create();
    }
}
