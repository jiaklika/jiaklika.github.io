<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class LiveAudienceData extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('live_audience_data', [
            'engine'    => 'InnoDB',
            'comment'   => '直播观众数据表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('live_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '直播场次id'
            ])
            ->addColumn('unionid', 'char', [
                'limit'   => 28,
                'default' => '',
                'comment' => '微信unionid'
            ])
            ->addColumn('is_consume', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否产生消费 0-否 1-是 默认0'
            ])
            ->addIndex(['live_id'], [
                'name' => 'live_id_index'
            ])
            ->addTimestamps()
            ->create();

        $table->removeColumn('update_time')->update();
    }
}
