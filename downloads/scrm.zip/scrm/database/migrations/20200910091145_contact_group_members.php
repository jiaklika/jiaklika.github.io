<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactGroupMembers extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_group_members', [
            'engine'    => 'InnoDB',
            'comment'   => '企业微信客户群成员表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('chat_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '客户群ID'
            ])
            ->addColumn('userid', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '群成员id'
            ])
            ->addColumn('original_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '微信中设置的名字'
            ])
            ->addColumn('group_nickname', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '在群里的昵称'
            ])
            ->addColumn('unionid', 'char', [
                'limit'   => 28,
                'default' => '',
                'comment' => '微信unionid'
            ])
            ->addColumn('type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '成员类型 1-企业成员 2-外部联系人 默认1'
            ])
            ->addColumn('join_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '入群时间'
            ])
            ->addColumn('join_scene', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '入群方式 1-由成员邀请入群（直接邀请入群） 2-由成员邀请入群（通过邀请链接入群） 3-通过扫描群二维码入群 默认1'
            ])
            ->addColumn('invitor', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '邀请者userid'
            ])
            ->addTimestamps()
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否退群 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '退群时间'
            ])
            ->addIndex(['chat_id'], [
                'name'   => 'chat_id_index'
            ])
            ->addIndex(['userid'], [
                'name' => 'userid_index'
            ])
            ->addIndex(['unionid'], [
                'name' => 'unionid_index'
            ])
            ->addIndex(['original_name'], [
                'name' => 'original_name_index'
            ])
            ->create();
    }
}
