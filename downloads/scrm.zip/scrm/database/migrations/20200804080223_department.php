<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class Department extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        // create the table
        $table = $this->table('department', [
            'engine'    => 'InnoDB',
            'comment'   => '企业微信部门表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('department_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '部门ID'
            ])
            ->addColumn('department_name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '部门名称'
            ])
            ->addColumn('department_name_en', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '英文名称'
            ])
            ->addColumn('department_parentid', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '父部门id。根部门为1'
            ])
            ->addColumn('order', 'biginteger', [
                'signed'  => false,
                'limit'   => 20,
                'default' => 0,
                'comment' => '在父部门中的次序值。order值大的排序靠前。'
            ])
            ->addTimestamps()
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addIndex(['department_id'], [
                'name'   => 'department_id_index'
            ])
            ->addIndex(['department_parentid'], [
                'name' => 'department_parentid_index'
            ])
            ->create();
    }
}
