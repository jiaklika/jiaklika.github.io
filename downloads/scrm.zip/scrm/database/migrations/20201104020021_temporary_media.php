<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class TemporaryMedia extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('temporary_media', [
            'engine'    => 'InnoDB',
            'comment'   => '临时素材表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('media_name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '媒体文件名称'
            ])
            ->addColumn('media_id', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '媒体文件唯一标识'
            ])
            ->addColumn('activity_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '活动id'
            ])
            ->addColumn('type', 'string', [
                'limit'   => 50,
                'default' => '',
                'comment' => '媒体文件类型'
            ])
            ->addColumn('media_created_at', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '媒体文件上传时间戳'
            ])
            ->addColumn('media_expire_at', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '媒体文件到期时间戳'
            ])
            ->addTimestamps()
            ->addIndex(['activity_id'], [
                'name' => 'activity_id_index'
            ])
            ->create();
    }
}
