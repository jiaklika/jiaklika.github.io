<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ChannelWelcomeMsg extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('channel_welcome_msg', [
            'engine'    => 'InnoDB',
            'comment'   => '渠道欢迎语表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('channel_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '渠道ID'
            ])
            ->addColumn('is_working_time', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否是上班时间 0-否 1-是 默认0'
            ])
            ->addColumn('random_index', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '欢迎语索引 0-未开启 1-a 2-b 3-c 4-d 5-e 默认0'
            ])
            ->addColumn('welcome_text', 'text', [
                'null'    => true,
                'comment' => '欢迎语文本内容'
            ])
            ->addColumn('attachments', 'json', [
                'null'    => true,
                'comment' => '附件信息'
            ])
            ->addTimestamps()
            ->addIndex(['channel_id'], [
                'name' => 'channel_id_index'
            ])
            ->addIndex(['random_index'], [
                'name' => 'random_index_index'
            ])
            ->create();
    }
}
