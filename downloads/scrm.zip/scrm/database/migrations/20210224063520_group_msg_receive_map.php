<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class GroupMsgReceiveMap extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('group_msg_receive_map', [
            'engine'    => 'InnoDB',
            'comment'   => '企业群发接收客户表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('template_id', 'integer', [
                'limit'   => 11,
                'default' => 0,
                'comment' => '群发记录id'
            ])
            ->addColumn('external_userid', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '接收的客户的id'
            ])
            ->addColumn('user_id', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '发送者userId'
            ])
            ->addColumn('status', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '接收状态  0-未发送 1-已发送 2-因客户不是好友导致发送失败 3-因客户已经收到其他群发消息导致发送失败 4-无效或无法发送 默认0'
            ])
            ->addColumn('send_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '发送时间'
            ])
            ->addColumn('update_time', 'timestamp', [
                'null'    => true,
                'comment' => '更新时间'
            ])
            ->addIndex(['template_id'], [
                'name' => 'template_id_index'
            ])
            ->addIndex(['user_id'], [
                'name' => 'user_id_index'
            ])
            ->addIndex(['external_userid'], [
                'name' => 'external_userid_index'
            ])
            ->create();
    }
}
