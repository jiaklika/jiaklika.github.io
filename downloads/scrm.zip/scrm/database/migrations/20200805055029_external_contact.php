<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ExternalContact extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        // create the table
        $table = $this->table('external_contact', [
            'engine'    => 'InnoDB',
            'comment'   => '企业微信外部联系人表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('external_userid', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '外部联系人的userid'
            ])
            ->addColumn('name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '外部联系人的名称'
            ])
            ->addColumn('avatar', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '外部联系人头像'
            ])
            ->addColumn('type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '外部联系人的类型 1-该外部联系人是微信用户 2-该外部联系人是企业微信用户 默认1'
            ])
            ->addColumn('gender', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '外部联系人性别 0-未知 1-男性 2-女性 默认0'
            ])
            ->addColumn('unionid', 'char', [
                'null'    => true,
                'limit'   => 28,
                'default' => null,
                'comment' => '微信unionid'
            ])
            ->addColumn('position', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '外部联系人的职位'
            ])
            ->addColumn('corp_name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '外部联系人所在企业的简称'
            ])
            ->addColumn('corp_full_name', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '外部联系人所在企业的主体名称'
            ])
            ->addColumn('external_profile', 'text', [
                'null'    => true,
                'comment' => '外部联系人的自定义展示信息'
            ])
            ->addColumn('user_level_id', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '宝姐客户等级 0-新人 1-宝迷 2-忠实宝迷 3-铁杆宝迷 4-名媛 5-风尚名媛 6-至尊名媛 默认0'
            ])
            ->addColumn('is_consume', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否消费 0-否 1-是 默认0'
            ])
            ->addColumn('is_in_group', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否在群 0-否 1-是 默认0'
            ])
            ->addColumn('is_friend', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '是否是好友 0-否 1-是 默认1'
            ])
            ->addTimestamps()
            ->addIndex(['external_userid'], [
                'unique' => true,
                'name'   => 'external_userid_index'
            ])
            ->addIndex(['unionid'], [
                'unique' => true,
                'name'   => 'unionid_index'
            ])
            ->create();
    }
}
