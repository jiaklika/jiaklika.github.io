<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class LiveInfo extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('live_info', [
            'engine'    => 'InnoDB',
            'comment'   => '直播详情表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('living_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '直播ID'
            ])
            ->addColumn('theme', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '直播主题'
            ])
            ->addColumn('living_start', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '直播开始时间戳'
            ])
            ->addColumn('living_duration', 'integer', [
                'signed'  => false,
                'limit'   => 10,
                'default' => 0,
                'comment' => '直播时长，单位为秒'
            ])
            ->addColumn('anchor_userid', 'string', [
                'limit'   => 50,
                'default' => '',
                'comment' => '主播的userId'
            ])
            ->addColumn('main_department', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '主播所在主部门id'
            ])
            ->addColumn('viewer_num', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '观看直播总人数'
            ])
            ->addColumn('comment_num', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '评论数'
            ])
            ->addColumn('mic_num', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '连麦发言人数'
            ])
            ->addColumn('open_replay', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否开启回放 0-关闭 1-开启 默认0'
            ])
            ->addTimestamps()
            ->addIndex(['living_id'], [
                'name' => 'living_id_index'
            ])
            ->create();
    }
}
