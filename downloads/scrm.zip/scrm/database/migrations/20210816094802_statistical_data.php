<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class StatisticalData extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('statistical_data', [
            'engine'    => 'InnoDB',
            'comment'   => '企微数据统计表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('time_range', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '时间范围 1-天 2-周 3-月 默认1'
            ])
            ->addColumn('add_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '当天0点时间戳'
            ])
            ->addColumn('company_first_add_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '企微号新添加：时间段内首次添加公司企微的去重人数（C）'
            ])
            ->addColumn('feiyue_first_add_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '泛流量号新添加：时间段内首次添加泛流量号的去重人数（F）'
            ])
            ->addColumn('zhaowei_first_add_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '电商号新添加：时间段内首次添加电商号的去重人数（Z）'
            ])
            ->addColumn('company_history_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '企微号历史累计添加去重总人数'
            ])
            ->addColumn('feiyue_history_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '泛流量号历史累计添加去重总人数'
            ])
            ->addColumn('zhaowei_history_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '电商号历史累计添加去重总人数'
            ])
            ->addColumn('company_first_add_join_group_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'C中在统计时已经进了公司任一群的去重总人数'
            ])
            ->addColumn('feiyue_first_add_join_group_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'F中在统计时已经进了泛流量号任一群的去重总人数'
            ])
            ->addColumn('zhaowei_first_add_join_group_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'Z中在统计时已经进了电商号任一群的去重总人数'
            ])
            ->addColumn('company_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '企微号互为好友关系的去重总人数'
            ])
            ->addColumn('feiyue_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '泛流量号互为好友关系的去重总人数'
            ])
            ->addColumn('zhaowei_contacts_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '电商号互为好友关系的去重总人数'
            ])
            ->addColumn('company_group_members_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '公司名下所有在群去重总人数'
            ])
            ->addColumn('feiyue_group_members_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '泛流量号名下所有在群去重总人数'
            ])
            ->addColumn('zhaowei_group_members_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '电商号名下所有在群去重总人数'
            ])
            ->addColumn('feiyue_friend_join_group_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'X中在对应泛流量号群内的占比'
            ])
            ->addColumn('zhaowei_friend_join_group_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'Y中在对应电商号群内的占比'
            ])
            ->addColumn('zhaowei_group_not_friend_count', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '电商号在群但不在其号内人数'
            ])
            ->addTimestamps()
            ->addIndex(['time_range'], [
                'name' => 'time_range_index'
            ])
            ->addIndex(['add_time'], [
                'name' => 'add_time_index'
            ])
            ->create();

        $table->removeColumn('update_time')->update();
    }
}
