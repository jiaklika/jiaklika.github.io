<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class MqLogs extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('mq_logs', [
            'engine'    => 'InnoDB',
            'comment'   => 'MQ队列数据日志表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('message_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '阿里云RocketMQ的MessageID'
            ])->addColumn('erp_msg_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => 'ERP的id'
            ])
            ->addColumn('mobile', 'string', [
                'limit'   => 20,
                'default' => '',
                'comment' => '手机号'
            ])
            ->addColumn('type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '消息类型 0-未知 1-用户等级 2-消费金额 默认0'
            ])
            ->addColumn('user_level', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '用户等级id 0-未知 1-宝迷 2-忠实宝迷 3-铁杆宝迷 4-名媛 5-风尚名媛 6-至尊名媛 默认0'
            ])
            ->addColumn('user_level_name', 'string', [
                'limit'   => 20,
                'default' => '',
                'comment' => '用户等级名称'
            ])
            ->addColumn('contract_amount_tag', 'string', [
                'limit'   => 50,
                'default' => '',
                'comment' => '消费金额标签'
            ])
            ->addColumn('is_contact', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否是企微客户 0-不是 1-是 默认0'
            ])
            ->addColumn('is_tag_success', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '打标签是否成功 0-否 1-是 默认0'
            ])
            ->addTimestamps()
            ->addIndex(['message_id'], [
                'name' => 'message_id_index'
            ])
            ->addIndex(['erp_msg_id'], [
                'name' => 'erp_msg_id_index'
            ])
            ->addIndex(['mobile'], [
                'name' => 'mobile_index'
            ])
            ->create();
    }
}
