<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactTags extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_tags', [
            'engine'    => 'InnoDB',
            'comment'   => '企业客户标签表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('group_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '标签组id'
            ])
            ->addColumn('group_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '标签组名称'
            ])
            ->addColumn('group_create_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '标签组创建时间'
            ])
            ->addColumn('group_order', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '标签组排序的次序值，order值大的排序靠前。'
            ])
            ->addColumn('group_is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '标签组是否已经被删除 0-否 1-是 默认0'
            ])
            ->addColumn('tag_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '标签id'
            ])
            ->addColumn('tag_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '标签名称'
            ])
            ->addColumn('tag_create_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '标签创建时间'
            ])
            ->addColumn('tag_order', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '标签排序的次序值，order值大的排序靠前。'
            ])
            ->addColumn('tag_is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '标签是否已经被删除 0-否 1-是 默认0'
            ])
            ->addTimestamps()
            ->addIndex(['group_id'], [
                'name' => 'group_id_index'
            ])
            ->addIndex(['tag_id'], [
                'unique' => true,
                'name' => 'tag_id_index'
            ])
            ->create();
    }
}
