<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactChannels extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_channels', [
            'engine'    => 'InnoDB',
            'comment'   => '企业客户添加渠道表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('channel_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '渠道名称'
            ])
            ->addColumn('tag_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '标签id'
            ])
            ->addColumn('is_open_welcome', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否启用欢迎语 0-否 1-是 默认0'
            ])
            ->addColumn('is_distinguish_time', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否区分时段 0-否 1-是 默认0'
            ])
            ->addColumn('is_random', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否开启随机欢迎语 0-否 1-是 默认0'
            ])
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addTimestamps()
            ->addIndex(['channel_name'], [
                'name' => 'channel_name_index'
            ])
            ->addIndex(['tag_id'], [
                'name' => 'tag_id_index'
            ])
            ->create();
    }
}
