<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ConsumeMqLogs extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('consume_mq_logs', [
            'engine'    => 'InnoDB',
            'comment'   => '宝姐珠宝消费推送队列日志',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('message_id', 'char', [
                    'limit'   => 32,
                    'default' => '',
                    'comment' => '阿里云RocketMQ的MessageID'
                ])
                ->addColumn('unionid', 'char', [
                    'null'    => true,
                    'limit'   => 28,
                    'default' => null,
                    'comment' => '微信unionid'
                ])
                ->addColumn('is_contact', 'boolean', [
                    'signed'  => false,
                    'limit'   => 1,
                    'default' => 0,
                    'comment' => '是否是企微客户 0-不是 1-是 默认0'
                ])
                ->addColumn('is_update_success', 'boolean', [
                    'signed'  => false,
                    'limit'   => 1,
                    'default' => 0,
                    'comment' => '更新消费是否成功 0-否 1-是 默认0'
                ])
                ->addTimestamps()
                ->addIndex(['unionid'], [
                    'name' => 'unionid_index'
                ])
                ->create();

        $table->removeColumn('update_time')->update();
    }
}
