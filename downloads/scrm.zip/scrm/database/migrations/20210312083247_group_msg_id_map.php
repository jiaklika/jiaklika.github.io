<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class GroupMsgIdMap extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('group_msg_id_map', [
            'engine'    => 'InnoDB',
            'comment'   => '企业群发消息ID记录表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('template_id', 'integer', [
            'limit'   => 11,
            'default' => 0,
            'comment' => '群发记录id'
        ])
            ->addColumn('sender_user_id', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '发送客服的userId'
            ])
            ->addColumn('msg_id', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '企业群发消息的id'
            ])
            ->addColumn('is_get_result', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否已获取群发执行结果 0-否 1-是 默认0'
            ])
            ->addColumn('update_time', 'timestamp', [
                'null'    => true,
                'comment' => '获取结果的时间'
            ])
            ->addIndex(['template_id'], [
                'name' => 'template_id_index'
            ])
            ->addIndex(['sender_user_id'], [
                'name' => 'sender_user_id_index'
            ])
            ->addIndex(['msg_id'], [
                'name' => 'msg_id_index'
            ])
            ->create();
    }
}
