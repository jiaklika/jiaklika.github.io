<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class MomentTask extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('moment_task', [
            'engine'    => 'InnoDB',
            'comment'   => '朋友圈群发任务记录表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('job_id', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '异步任务id'
            ])
            ->addColumn('task_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '任务名'
            ])
            ->addColumn('creator', 'string', [
                'limit'   => 60,
                'default' => '',
                'comment' => '创建者'
            ])
            ->addColumn('receiver_range', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '接收客户范围 0-所有 1-只按用户筛选 2-只按标签筛选 3-按用户和标签双重筛选 默认0'
            ])
            ->addColumn('content_text', 'string', [
                'limit'   => 2000,
                'default' => '',
                'comment' => '消息文本内容'
            ])
            ->addColumn('attachment_type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '附件类型 0-未启用 1-图片 2-图文消息 3-视频 默认0'
            ])
            ->addColumn('attachments', 'text', [
                'null'    => true,
                'comment' => '消息文本内容'
            ])
            ->addColumn('is_plan', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否定时发送 0-立即发送 1-定时发送 默认0'
            ])
            ->addColumn('send_time', 'timestamp', [
                'null'    => true,
                'comment' => '发送时间'
            ])
            ->addColumn('is_handle', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否处理了定时 0-否 1-是 默认0'
            ])
            ->addColumn('status', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '状态 0-未开始 1-进行中 2-已结束 默认0'
            ])
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addTimestamps()
            ->addIndex(['is_plan', 'is_handle'], [
                'name' => 'is_plan_handle_index'
            ])
            ->create();
    }
}
