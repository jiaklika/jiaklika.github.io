<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactTagMap extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_tag_map', [
            'engine'    => 'InnoDB',
            'comment'   => '客户企业标签映射表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('tag_id', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '企业标签id'
            ])
            ->addColumn('external_userid', 'char', [
                'limit'   => 32,
                'default' => '',
                'comment' => '外部联系人的userId'
            ])
            ->addColumn('userid', 'string', [
                'limit'   => 50,
                'default' => '',
                'comment' => '员工的userId'
            ])
            ->addTimestamps()
            ->addIndex(['tag_id'], [
                'name' => 'tag_id_index'
            ])
            ->addIndex(['external_userid'], [
                'name' => 'external_userid_index'
            ])
            ->addIndex(['userid'], [
                'name' => 'userid_index'
            ])
            ->create();

        $table->removeColumn('update_time')
            ->update();
    }
}
