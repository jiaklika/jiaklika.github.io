<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class ContactWays extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('contact_ways', [
            'engine'    => 'InnoDB',
            'comment'   => '企业客户联系我路径表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('way_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '活码名称'
            ])
            ->addColumn('channel_id', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '渠道id'
            ])
            ->addColumn('config_id', 'char', [
                'null'    => true,
                'limit'   => 32,
                'default' => '',
                'comment' => '配置id'
            ])
            ->addColumn('type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '联系方式类型 1-单人 2-多人 默认1'
            ])
            ->addColumn('scene', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '场景 1-在小程序中联系 2-通过二维码联系 默认1'
            ])
            ->addColumn('style', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '在小程序中联系时使用的控件样式 默认1'
            ])
            ->addColumn('remark', 'string', [
                'limit'   => 90,
                'default' => '',
                'comment' => '联系方式的备注信息'
            ])
            ->addColumn('skip_verify', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '外部客户添加时是否无需验证 0-否 1-是 默认1'
            ])
            ->addColumn('qr_code', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '联系二维码的URL'
            ])
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '活码是否已经被删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addTimestamps()
            ->addIndex(['config_id'], [
                'unique' => true,
                'name'   => 'config_id_index'
            ])
            ->addIndex(['channel_id'], [
                'name' => 'channel_id_index'
            ])
            ->create();
    }
}
