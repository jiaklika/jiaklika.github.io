<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class GroupMsgTemplates extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('group_msg_templates', [
            'engine'    => 'InnoDB',
            'comment'   => '企业群发记录表',
            'collation' => 'utf8mb4_general_ci'
        ]);

        $table->addColumn('task_name', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '任务名'
            ])
            ->addColumn('creator', 'string', [
                'limit'   => 60,
                'default' => '',
                'comment' => '创建者'
            ])
            ->addColumn('receiver_range', 'boolean', [
                    'signed'  => false,
                    'limit'   => 1,
                    'default' => 0,
                    'comment' => '接收客户范围 0-所有 1-只按用户筛选 2-只按标签筛选 3-按用户和标签双重筛选 默认0'
                ])
            ->addColumn('chat_type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 1,
                'comment' => '群发任务的类型 1-single，表示发送给客户 2-group，表示发送给客户群 默认1'
            ])
            ->addColumn('content_text', 'text', [
                'null'    => true,
                'comment' => '消息文本内容'
            ])
            ->addColumn('second_type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '第2条消息类型 0-未启用 1-小程序 2-图片 3-图文消息 默认0'
            ])
            ->addColumn('image_pic_url', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '图片的链接'
            ])
            ->addColumn('link_title', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '图文消息标题'
            ])
            ->addColumn('link_pic_url', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '图文消息封面的url'
            ])
            ->addColumn('link_desc', 'string', [
                'limit'   => 512,
                'default' => '',
                'comment' => '图文消息的描述'
            ])
            ->addColumn('link_url', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '图文消息的链接'
            ])
            ->addColumn('miniprogram_title', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '小程序消息标题'
            ])
            ->addColumn('miniprogram_pic_media_id', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '小程序消息封面的mediaid'
            ])
            ->addColumn('miniprogram_appid', 'string', [
                'limit'   => 64,
                'default' => '',
                'comment' => '小程序appid'
            ])
            ->addColumn('miniprogram_page', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '小程序page路径'
            ])
            ->addColumn('miniprogram_pic_url', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '小程序图片地址'
            ])
            ->addColumn('miniprogram_pic_create_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '小程序图片上传时间'
            ])
            ->addColumn('miniprogram_pic_expire_time', 'integer', [
                'signed'  => false,
                'limit'   => 11,
                'default' => 0,
                'comment' => '小程序图片过期时间'
            ])
            ->addColumn('is_plan', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否定时发送 0-立即发送 1-定时发送 默认0'
            ])
            ->addColumn('send_time', 'timestamp', [
                'null'    => true,
                'comment' => '发送时间'
            ])
            ->addColumn('is_handle', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否处理了定时 0-否 1-是 默认0'
            ])
            ->addColumn('status', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '状态 0-未开始 1-进行中 2-已结束 默认0'
            ])
            ->addColumn('is_deleted', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否删除 0-否 1-是 默认0'
            ])
            ->addColumn('del_time', 'timestamp', [
                'null'    => true,
                'comment' => '删除时间'
            ])
            ->addTimestamps()
            ->addIndex(['is_plan', 'is_handle'], [
                'name' => 'is_plan_handle_index'
            ])
            ->create();
    }
}
