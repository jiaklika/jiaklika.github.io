<?php

use think\migration\Migrator;

// @codingStandardsIgnoreLine
class CallbackLogs extends Migrator
{
    /**
     * Change Method.
     *
     * Write your reversible migrations using this method.
     *
     * More information on writing migrations is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-abstractmigration-class
     *
     * The following commands can be used in this method and Phinx will
     * automatically reverse them when rolling back:
     *
     *    createTable
     *    renameTable
     *    addColumn
     *    renameColumn
     *    addIndex
     *    addForeignKey
     *
     * Remember to call "create()" or "update()" and NOT "save()" when working
     * with the Table class.
     */
    public function change()
    {
        $table = $this->table('callback_logs', [
            'engine'    => 'InnoDB',
            'comment'   => '企业微信回调记录表',
            'collation' => 'utf8mb4_general_ci'
        ]);
        $table->addColumn('encryption_xml', 'text', [
                'comment' => '加密的xml'
            ])->addColumn('decrypt_xml', 'text', [
                'comment' => '解密的xml'
            ])
            ->addColumn('callback_url', 'string', [
                'limit'   => 255,
                'default' => '',
                'comment' => '回调访问地址'
            ])
            ->addColumn('type', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '消息类型 0-未知 1-通讯录 2-外部联系人 3-消息推送 4-客户群 默认0'
            ])
            ->addColumn('change_type', 'string', [
                'limit'   => 100,
                'default' => '',
                'comment' => '事件的具体类型'
            ])
            ->addColumn('is_success', 'boolean', [
                'signed'  => false,
                'limit'   => 1,
                'default' => 0,
                'comment' => '是否正确处理 0-否 1-是 默认0'
            ])
            ->addColumn('remark', 'string', [
                'limit'   => 500,
                'default' => '',
                'comment' => '备注'
            ])
            ->addTimestamps()
            ->create();
    }
}
